<?php
if ( ! function_exists( 'wpj_display_payment_general_instructions' ) ) {
	function wpj_display_payment_general_instructions() {
		wpj_update_last_checkout_viewed();

		$title       = get_post_meta( wpj_get_option( 'wpjobster_checkout_page_id' ), 'payment_instructions_title', true );
		$description = get_post_meta( wpj_get_option( 'wpjobster_checkout_page_id' ), 'payment_instructions_description', true );

		wpj_get_template( 'elements/checkout/payment-general-instructions-template.php', array(
			'title'       => $title,
			'description' => $description
		) );

	}
}

if ( ! function_exists( 'wpj_display_job_order_details_form' ) ) {
	function wpj_display_job_order_details_form( $pid = '', $display_location = '' ) {

		// PID
		$pid = wpj_get_post_id( $pid );

		// Payment type
		$payment_type = wpj_get_payment_info_by_url( 'payment_type' );
		if ( ! $payment_type ) $payment_type = 'job_purchase';

		// Price
		$sample_prc = 0;
		if ( $payment_type == 'job_purchase' ) {
			$sample_prc = get_post_meta( $pid, 'price', true );
			if ( ! is_numeric( $sample_prc ) || $sample_prc < 0 )
				$sample_prc = wpj_get_option( 'wpjobster_job_fixed_amount' );
			$sample_prc = apply_filters( 'wpjobster_purchase_this_job_price', $sample_prc, $pid );

		} elseif ( $payment_type == 'custom_extra' ) {
			$custom_extra = wpj_get_payment_info_by_url( 'custom_extra' );
			$sample_prc   = $custom_extra->price;

		} elseif ( $payment_type == 'tips' ) {
			$tip        = wpj_get_payment_info_by_url( 'tip' );
			$sample_prc = $tip->amount;
		}

		$prc = apply_filters( 'wpjobster_single_job_price', $sample_prc, $pid );

		// Extras
		$allow_extra = $display_location == 'checkout' && wpj_get_option( 'wpjobster_checkout_extra_enabled' ) == 'no' ? false : true;

		// Extra fast delivery
		$extra_fast_enabled       = $extra_fast_price = $extra_fast_days = '';
		$fast_delivery_amount_max = 1;
		if ( $payment_type == 'job_purchase' ) {
			$extra_fast_price = get_post_meta( $pid, 'extra_fast_price', true );
			$extra_fast_days  = get_post_meta( $pid, 'extra_fast_days', true );

			if ( wpj_get_user_feature_status( 'wpjobster_enable_extra_fast_delivery', 'wpjobster_subscription_ex_fast_delivery_enabled' ) != "no" ) {
				$extra_fast_enabled       = get_post_meta( $pid, 'extra_fast_enabled', true );
				$fast_delivery_amount_max = wpj_get_user_feature_value( 'fast_delivery_multiples', 'fast_del_multiples', '', get_current_user_id() );
			}
		}

		$display_fast_delivery = $extra_fast_enabled && $fast_delivery_amount_max > 0 && $extra_fast_price && $extra_fast_days && ( $allow_extra || WPJ_Form::post( 'extrafast' ) ) ? true : false;

		// Extra revision
		$extra_revision_enabled = $extra_revision_price = $extra_revision_days = '';
		$add_rev_amount_max     = 1;

		if ( $payment_type == 'job_purchase' ) {
			$extra_revision_price  = get_post_meta( $pid, 'extra_revision_price', true );
			$extra_revision_days   = get_post_meta( $pid, 'extra_revision_days', true );

			if ( wpj_get_user_feature_status( 'wpjobster_enable_extra_additional_revision', 'wpjobster_subscription_additional_revision_enabled' ) != "no" ) {
				$extra_revision_enabled = get_post_meta( $pid, 'extra_revision_enabled', true );
				$add_rev_amount_max     = wpj_get_user_feature_value( 'add_rev_multiples', 'add_rev_multiples', '', get_current_user_id() );
			}
		}

		$display_additional_revision = $extra_revision_enabled && $add_rev_amount_max > 0 && $extra_revision_price && $extra_revision_days && ( $allow_extra || WPJ_Form::post( 'extrarevision' ) ) ? true : false;

		// Extra
		$extra_job_add = array(); $extra_price = 0; $h = 0;
		if ( $payment_type == 'job_purchase' ) {
			$sts = 0;
			if ( wpj_get_user_feature_status( 'wpjobster_enable_extra', 'wpjobster_subscription_noof_extras_enabled' ) != "no" ) {
				$sts = wpj_get_user_feature_value( 'extras', 'noof_extras', 0, get_current_user_id() );
			}

			for ( $k = 1; $k <= $sts; $k++ ) {
				$extra_price   = get_post_meta( $pid, 'extra' . $k . '_price',   true );
				$extra_content = get_post_meta( $pid, 'extra' . $k . '_content', true );
				$extra_enabled = get_post_meta( $pid, 'extra' . $k . '_enabled', true );

				if ( ! empty( $extra_price ) && ! empty( $extra_content ) ) {
					$extra_job_add[$h]['content']  = $extra_content;
					$extra_job_add[$h]['price']    = $extra_price;
					$extra_job_add[$h]['extra_nr'] = $k;
					$extra_job_add[$h]['enabled']  = $extra_enabled;
					$h++;
				}
			}
		}

		$job_amount_max   = 1;
		$extra_amount_max = 1;
		if ( $payment_type == 'job_purchase' ) {
			if ( wpj_get_user_feature_status( 'wpjobster_enable_multiples', 'wpjobster_subscription_job_multiples_enabled' ) == "yes" )
				$job_amount_max = wpj_get_user_feature_value( 'jobmultiples', 'job_multiples', '', get_current_user_id() );

			if ( wpj_get_user_feature_status( 'wpjobster_enable_extra_multiples', 'wpjobster_subscription_extra_multiples_enabled' ) == "yes" )
				$extra_amount_max = wpj_get_user_feature_value( 'extramultiples', 'extra_multiples', '', get_current_user_id() );
		}

		// Shipping
		if ( $payment_type == 'job_purchase' )
			$shipping = get_post_meta( $pid, 'shipping', true );
		if ( empty( $shipping ) ) $shipping = 0;

		// Processing fees
		$buyer_processing_fees = wpj_get_site_processing_fee_by_amount( $prc, $extra_price, $shipping );

		// Tax
		$tax_amount = wpj_get_site_tax_by_amount( $prc, $extra_price, $shipping, $buyer_processing_fees );

		// Display order details
		wpj_get_template( 'elements/checkout/job-order-details-form-template.php', array(
			'pid'                         => $pid,
			'display_location'            => $display_location,
			'payment_type'                => $payment_type,
			'prc'                         => $prc ? $prc : 0,
			'is_price_type'               => get_post_meta( $pid, 'price_type', true ) && get_post_meta( $pid, 'price_type', true ) != 'fixed' ? true : false,
			'quantity'                    => wpj_get_user_feature_status( 'wpjobster_enable_multiples', 'wpjobster_subscription_job_multiples_enabled' ),
			'job_amount_max'              => $job_amount_max,
			'display_fast_delivery'       => $display_fast_delivery,
			'fast_delivery_amount_max'    => $fast_delivery_amount_max,
			'display_additional_revision' => $display_additional_revision,
			'add_rev_amount_max'          => $add_rev_amount_max,
			'allow_extra'                 => $allow_extra,
			'extra_job_add'               => $extra_job_add,
			'extra_amount_max'            => $extra_amount_max,
			'shipping'                    => $shipping,
			'buyer_processing_fees'       => $buyer_processing_fees,
			'tax_amount'                  => $tax_amount
		) );
	}
}


if ( ! function_exists( 'wpj_display_checkout_job_price' ) ) {
	function wpj_display_checkout_job_price( $pid = '', $class = '', $include_price_type = true ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		$payment_type = wpj_get_payment_info_by_url( 'payment_type' );
		if ( ! $payment_type ) $payment_type = 'job_purchase';

		$custom_extra = wpj_get_payment_info_by_url( 'custom_extra' );
		$tip          = wpj_get_payment_info_by_url( 'tip' );

		$sample_prc  = 0;
		if ( $payment_type == 'job_purchase' ) {
			$sample_prc = get_post_meta( $pid, 'price', true );
			if ( ! is_numeric( $sample_prc ) || $sample_prc < 0 )
				$sample_prc = wpj_get_option( 'wpjobster_job_fixed_amount' );
			$sample_prc = apply_filters( 'wpjobster_purchase_this_job_price', $sample_prc, $pid );

		} elseif ( $payment_type == 'custom_extra' ) {
			$sample_prc = $custom_extra->price;

		} elseif ( $payment_type == 'tips' ) {
			$sample_prc = $tip->amount;
		}

		wpj_get_template( 'elements/checkout/checkout-job-price-template.php', array(
			'pid'                => wpj_get_post_id( $pid ),
			'sample_prc'         => $sample_prc,
			'main_amount'        => WPJ_Form::post( 'main_value_inp', 1 ),
			'class'              => $class,
			'include_price_type' => $include_price_type
		) );

	}
}


if ( ! function_exists( 'wpj_display_checkout_order_total_price' ) ) {
	function wpj_display_checkout_order_total_price( $payment_type = '' ) {

		if ( ! $payment_type ) $payment_type = wpj_get_payment_info_by_url( 'payment_type' );
		if ( ! $payment_type ) $payment_type = 'job_purchase';

		$pid = wpj_get_post_id();

		$sample_prc = 0;
		if ( $payment_type == 'job_purchase' ) {
			$sample_prc = get_post_meta( $pid, 'price', true );
			if ( ! is_numeric( $sample_prc ) || $sample_prc < 0 )
				$sample_prc = wpj_get_option( 'wpjobster_job_fixed_amount' );
			$sample_prc = apply_filters( 'wpjobster_purchase_this_job_price', $sample_prc, $pid );

		} elseif ( $payment_type == 'custom_extra' ) {
			$custom_extra = wpj_get_payment_info_by_url( 'custom_extra' );
			$sample_prc   = $custom_extra->price;

		} elseif ( $payment_type == 'tips' ) {
			$tip        = wpj_get_payment_info_by_url( 'tip' );
			$sample_prc = $tip->amount;

		}

		$shipping = get_post_meta( $pid, 'shipping', true );
		if ( ! $shipping ) $shipping = 0;

		$decimal_sum_separator = wpj_get_option( 'wpjobster_decimal_sum_separator' );
		if ( empty( $decimal_sum_separator ) ) $decimal_sum_separator = '.';

		$thousands_sum_separator = wpj_get_option( 'wpjobster_thousands_sum_separator' );
		if ( empty( $thousands_sum_separator ) ) $thousands_sum_separator = ',';

		$enable_processingfee_tax      = wpj_get_option( 'wpjobster_enable_processingfee_tax' );
		$buyer_processing_fees_enabled = wpj_get_option( 'wpjobster_enable_buyer_processing_fees' );

		if ( wpj_get_option( 'wpjobster_enable_site_tax' ) == 'yes' )
			$enable_processingfee_tax = $enable_processingfee_tax == 'yes' && wpj_get_option( 'wpjobster_enable_buyer_processing_fees' ) != 'disabled' ? 'yes' : 'no';
		else
			$enable_processingfee_tax = 'no';

		wpj_get_template( 'elements/checkout/checkout-order-total-price-template.php', array(
			'pid'                      => $pid,
			'prc'                      => apply_filters( 'wpjobster_order_price_filter', $sample_prc, $pid ),
			'shipping'                 => $shipping,
			'decimal_sum_separator'    => $decimal_sum_separator,
			'thousands_sum_separator'  => $thousands_sum_separator,
			'enable_processingfee_tax' => $enable_processingfee_tax,
			'payment_type'             => $payment_type
		) );
	}
}

if ( ! function_exists( 'wpj_display_payment_buttons' ) ) {
	function wpj_display_payment_buttons( $payment_type = '', $include_credits = true, $credits_only = false ) {
		if ( ! $payment_type ) $payment_type = wpj_get_payment_info_by_url( 'payment_type' );
		if ( ! $payment_type ) $payment_type = 'job_purchase';

		$pid  = wpj_get_post_id();
		$post = get_post( $pid );

		$is_post_author = get_current_user_id() == $post->post_author ? true : false;

		$author_vacation = wpj_get_user_vacation( $post->post_author );
		$author_vacation = apply_filters( 'wpj_author_vacation_filter', $author_vacation, $pid );
		$author_vacation_reason = $author_vacation && $author_vacation['mode'] == 1 ? $author_vacation['reason'] : false;

		$is_enough_credit = wpj_get_user_credit( get_current_user_id() ) >= wpj_get_checkout_total_price( $payment_type ) ? true : false;

		if (
			(
				( $payment_type == 'job_purchase' && ! $is_post_author && ! $author_vacation && get_post_meta( $pid, "active", true ) == 1 )
				|| wpj_is_custom_offer( $pid )
				|| $payment_type != 'job_purchase'
			)
			&& wpj_get_payment_gateways()
		) {

			foreach ( wpj_get_payment_gateways() as $priority => $gateway ) {
				if ( wpj_is_payment_type_enabled( $gateway['unique_id'], $payment_type ) && empty( $gateway['no_pay_button'] ) ) { $gateway_enabled = true;
					if ( $gateway['unique_id'] == 'cod' && ! wpj_is_COD_payment_allowed( $pid, $payment_type ) ) { $gateway_enabled = false; }
				}
			}
		}

		if ( $include_credits && wpj_get_option( 'wpjobster_credits_enable' ) != 'no' ) { $gateway_enabled = true; }

		// No gateways
		if ( ! isset( $gateway_enabled ) ) {
			$error_msg = __( 'Payment methods are not available at this time. Please contact the administrator of this site for help.', 'wpjobster' );

		} elseif ( $is_post_author && $payment_type == 'job_purchase' ) {
			$error_msg = __( 'You can\'t buy your own job.', 'wpjobster' );

		} elseif ( $author_vacation && $payment_type == 'job_purchase' ) {
			$error_msg = sprintf( __( 'Job temporarily disabled. Reason: %s', 'wpjobster' ), $author_vacation_reason );

		} elseif ( ! wpj_is_custom_offer( $pid ) && ( $payment_type == 'job_purchase' && get_post_meta( $pid, "active", true ) != 1 ) ) {
			$error_msg = __( 'Job deactivated.', 'wpjobster' );

		} else {
			$error_msg = '';

		}

		wpj_get_template( 'elements/checkout/payment-buttons-template.php', array(
			'pid'              => $pid,
			'payment_type'     => $payment_type,
			'is_post_author'   => $is_post_author,
			'author_vacation'  => $author_vacation,
			'include_credits'  => $include_credits,
			'credits_only'     => $credits_only,
			'is_enough_credit' => $is_enough_credit,
			'error_msg'        => $error_msg,
		) );

	}
}

if ( ! function_exists( 'wpj_display_badges_payment_list' ) ) {
	function wpj_display_badges_payment_list() {
		$badges_data = wpj_get_option( 'badge-list-settings' );

		$user_badge = get_user_meta( get_current_user_id(), 'user_badge', true );
		if ( $user_badge && ! is_array( $user_badge ) ) $user_badge = array( $user_badge );

		$ratings_no = wpj_get_seller_rating_avg( get_current_user_id() );
		$reviews_no = wpj_get_seller_reviews_number( get_current_user_id() );

		wpj_get_template( 'elements/checkout/badges-payment-list-template.php', array(
			'badges_data' => $badges_data,
			'user_badge'  => $user_badge,
			'ratings_no'  => $ratings_no,
			'reviews_no'  => $reviews_no,
		) );
	}
}

if ( ! function_exists( 'wpj_display_topup_payment_list' ) ) {
	function wpj_display_topup_payment_list() {
		wpj_get_template( 'elements/checkout/topup-payment-list-template.php', array(
			'topup_packages' => wpj_get_option( 'topup-packages-settings' ),
			'currency'       => wpj_get_site_curreny()
		) );
	}
}

if ( ! function_exists( 'wpj_display_request_withdrawal_gateways_list' ) ) {
	function wpj_display_request_withdrawal_gateways_list() {
		$uid = get_current_user_id();

		$bank_bank_name_enabled      = apply_filters( 'wpj_payments_display_' . 'bank_bank_name' . '_field', true );
		$bank_account_name_enabled   = apply_filters( 'wpj_payments_display_' . 'bank_account_name' . '_field', true );
		$bank_account_number_enabled = apply_filters( 'wpj_payments_display_' . 'bank_account_number' . '_field', true );

		$default_gateways = array();

		if ( wpj_is_payment_type_enabled( 'paypal', 'withdraw' ) ) {
			$default_gateways['paypal'] = array(
				'name'  => 'paypal',
				'label' => __( 'PayPal', 'wpjobster' ),
				'meta'  => get_user_meta( $uid, 'paypal_email', true )
			);
		}

		if ( apply_filters( 'wpj_payoneer_option_enabled_filter', wpj_is_payment_type_enabled( 'payoneer', 'withdraw', true ) ) == 'yes' ) {
			$default_gateways['payoneer'] = array(
				'name'  => 'payoneer',
				'label' => __( 'Payoneer', 'wpjobster' ),
				'meta'  => apply_filters( 'wpj_payoneer_user_enabled_filter', get_user_meta( $uid, 'payoneer_email', true ) )
			);
		}

		if ( wpj_is_payment_type_enabled( 'banktransfer', 'withdraw' ) ) {
			if ( ( ( $bank_bank_name_enabled && get_user_meta( $uid, 'bank_bank_name', true ) != '' ) || ! $bank_bank_name_enabled )
				&& ( ( $bank_account_name_enabled && get_user_meta( $uid, 'bank_account_name', true ) != '' ) || ! $bank_account_name_enabled )
				&& ( ( $bank_account_number_enabled && get_user_meta( $uid, 'bank_account_number', true ) != '' ) || ! $bank_account_number_enabled )
			) {
				$meta = true;
			} else {
				$meta = false;
			}

			$default_gateways['banktransfer'] = array(
				'name'  => 'banktransfer',
				'label' => __( 'Bank Account', 'wpjobster' ),
				'meta'  => $meta
			);
		}

		$default_gateways = apply_filters( 'wpj_withdrawals_gateways_info_filter', $default_gateways );

		wpj_get_template( 'elements/checkout/request-withdrawal-gateways-list-template.php', array(
			'uid'              => $uid,
			'default_gateways' => $default_gateways
		) );
	}
}