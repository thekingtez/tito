<?php
if ( ! function_exists( 'wpj_display_buyer_processing_fees' ) ) {
	function wpj_display_buyer_processing_fees() {
		$buyer_processing_fees_enabled = wpj_get_option( 'wpjobster_enable_buyer_processing_fees' );
		if ( $buyer_processing_fees_enabled != 'disabled' ) {
			if ( $buyer_processing_fees_enabled == 'percent' ) {
				$wpjobster_buyer_processing_fees = 0;
			} else {
				$wpjobster_buyer_processing_fees = wpj_get_option( 'wpjobster_buyer_processing_fees' );
			}
		} else {
			$wpjobster_buyer_processing_fees = 0;
		}

		wpj_get_template( 'elements/fees/buyer-processing-fees-template.php', array( 'processing_fees' => $wpjobster_buyer_processing_fees ) );
	}
}

if ( ! function_exists( 'wpj_display_buyer_tax' ) ) {
	function wpj_display_buyer_tax() {
		wpj_get_template( 'elements/fees/buyer-tax-template.php' );
	}
}