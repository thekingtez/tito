<?php
if ( ! function_exists( 'wpj_display_job_author' ) ) {
	function wpj_display_job_author( $pid = '' ) {
		if ( ! $pid ) $pid  = wpj_get_post_id( $pid );
		$post = get_post( $pid );

		wpj_get_template( 'elements/job/job-author-template.php', array(
			'pid'       => $pid,
			'post'      => $post,
			'author_id' => $post->post_author
		) );
	}
}

if ( ! function_exists( 'wpj_display_job_cover_image' ) ) {
	function wpj_display_job_cover_image( $pid = '' ) {
		global $_wp_additional_image_sizes;

		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		$cover_image_id = get_post_meta( $pid, 'cover-image', true );

		$cover_image_url = '';
		if ( ! empty( $cover_image_id ) )
			$cover_image_url = wpj_get_attachment_image_url( $cover_image_id , array( $_wp_additional_image_sizes['job_cover_image']['width'], $_wp_additional_image_sizes['job_cover_image']['height'] ) );

		wpj_get_template( 'elements/job/job-cover-image-template.php', array(
			'cover_image_id'  => $cover_image_id,
			'cover_image_url' => $cover_image_url,
			'pid'             => $pid
		) );
	}
}

if ( ! function_exists( 'wpj_display_job_location' ) ) {
	function wpj_display_job_location( $pid = '' ) {

		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		$location_display = get_post_meta( $pid, 'location_input', true );

		if ( wpj_get_option( 'wpjobster_location' ) == 'yes' && ! empty( $location_display ) ) {

			wpj_get_template( 'elements/job/job-location-template.php', array( 'location_display' => $location_display, 'pid' => $pid ) );

		}

	}
}

if ( ! function_exists( 'wpj_display_job_order_queue_number' ) ) {
	function wpj_display_job_order_queue_number( $pid = '' ) {
		wpj_get_template( 'elements/job/job-order-queue-number-template.php', array( 'pid' => wpj_get_post_id( $pid ) ) );
	}
}

if ( ! function_exists( 'wpj_display_job_delivery_days_number' ) ) {
	function wpj_display_job_delivery_days_number( $pid = '' ) {

		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		$instant  = get_post_meta( $pid, "instant", true );
		$max_days = get_post_meta( $pid, "max_days", true );

		if ( $instant == 1 ) {
			$deliv_msg = __( 'Instant', 'wpjobster' );
		} elseif ( intval( $max_days ) > 0 ) {
			$deliv_msg = sprintf( _n( '%d day', '%d days', $max_days, 'wpjobster' ), $max_days );
		} else {
			$deliv_msg = __( 'No delivery time', 'wpjobster' );
		}

		wpj_get_template( 'elements/job/job-delivery-days-template.php', array( 'pid' => $pid, 'deliv_msg' => $deliv_msg ) );

	}
}

if ( ! function_exists( 'wpj_display_job_favorite_icon' ) ) {
	function wpj_display_job_favorite_icon( $pid = '', $delete_text = '', $add_text = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		if ( function_exists( 'upb_get_bookmark_count' ) ) {

			$number       = upb_get_bookmark_count( $pid );
			$number_plus  = $number + 1;
			$number_minus = $number - 1;

			if ( $delete_text == '' || $add_text == ''  ) {
				$add_text         = $number;
				$delete_text      = $number;
				$add_text_minus   = $number_minus;
				$delete_text_plus = $number_plus;

				$add_class    = 'bookmark-icon bookmark-add tooltip';
				$remove_class = 'bookmark-icon bookmark-remove tooltip';

			} else {
				$add_text_minus   = $add_text;
				$delete_text_plus = $delete_text;
				$add_class        = '';
				$remove_class     = '';

			}

			wpj_get_template( 'elements/job/job-favourite-icon-template.php', array(
				'pid'              => $pid,
				'add_text'         => $add_text,
				'delete_text'      => $delete_text,
				'add_text_minus'   => $add_text_minus,
				'delete_text_plus' => $delete_text_plus,
				'add_class'        => $add_class,
				'remove_class'     => $remove_class,
			) );

		}
	}
}

if ( ! function_exists( 'wpj_display_job_social_share_icons' ) ) {
	function wpj_display_job_social_share_icons( $include_favorites = true ) {
		global $jobster_design;

		wpj_get_template( 'elements/job/job-social-share-icons-template.php', array(
			'jobster_design'    => $jobster_design,
			'include_favorites' => $include_favorites,
			'pid'               => wpj_get_post_id()
		) );

	}
}

if ( ! function_exists( 'wpj_display_job_description' ) ) {
	function wpj_display_job_description( $pid = '' ) {

		if ( ! $pid ) $pid = wpj_get_post_id( $pid );
		$post = get_post( $pid );

		if ( ! $post ) {
			global $post;
			$pid = wpj_get_post_id( $post->ID );
		}

		$desc_content = $post->post_content;
		if ( wpj_get_option( 'wpjobster_job_description_type' ) == 'wysiwyg' || wpj_get_option( 'wpjobster_job_description_type' ) == 'tinymce' )
			$desc_content = wpautop( $desc_content );
		else
			$desc_content = wpautop( strip_tags( $desc_content ) );

		$desc_content = wpj_apply_filter_to_string( $desc_content, false, 'joblistings' );

		$read_more_enabled = wpj_get_option( 'wpjobster_view_more_description_enabled' );
		$desc_excerpt = stripslashes( wpj_truncate_text( $desc_content, 250 ) );
		$desc_content = stripslashes( $desc_content );

		wpj_get_template( 'elements/job/job-description-template.php', array(
			'read_more_enabled' => $read_more_enabled,
			'desc_excerpt'      => $desc_excerpt,
			'desc_content'      => $desc_content,
			'pid'               => $pid,
			'title'             => $post->post_title
		) );

	}
}

if ( ! function_exists( 'wpj_display_buyer_instructions' ) ) {
	function wpj_display_buyer_instructions( $pid = '' ) {
		wpj_get_template( 'elements/job/job-buyer-instructions-template.php', array( 'pid' => wpj_get_post_id( $pid ) ) );
	}
}

if ( ! function_exists( 'wpj_display_job_faq' ) ) {
	function wpj_display_job_faq( $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		wpj_get_template( 'elements/job/job-faq-template.php', array(
			'pid'          => $pid,
			'post_job_faq' => get_post_meta( $pid, 'faq', true )
		) );
	}
}

if ( ! function_exists( 'wpj_display_job_audio' ) ) {
	function wpj_display_job_audio( $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		wpj_get_template( 'elements/job/job-audio-template.php', array(
			'pid'               => $pid,
			'attachments_audio' => wpj_get_job_audios( $pid )
		) );
	}
}

if ( ! function_exists( 'wpj_display_job_preview' ) ) {
	function wpj_display_job_preview( $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		wpj_get_template( 'elements/job/job-preview-template.php', array(
			'pid'                 => $pid,
			'job_any_attachments' => get_post_meta( $pid, 'preview_job_attchments', true )
		) );
	}
}

if ( ! function_exists( 'wpj_display_job_map' ) ) {
	function wpj_display_job_map( $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );
		wpj_get_template( 'elements/job/job-map-template.php', array( 'pid' => $pid ) );
	}
}

if ( ! function_exists( 'wpj_display_job_custom_fields' ) ) {
	function wpj_display_job_custom_fields( $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		$Custom_Fields = new WPJ_Custom_Fields( $pid, 'job' );

		wpj_get_template( 'elements/job/job-custom-fields-template.php', array( 'pid' => $pid, 'Custom_Fields' => $Custom_Fields ) );
	}
}

if ( ! function_exists( 'wpj_display_job_order_form' ) ) {
	function wpj_display_job_order_form( $pid = '', $display_location = '', $with_label = true ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		wpj_get_template( 'elements/job/job-order-form-template.php', array( 'display_location' => $display_location, 'pid' => $pid, 'with_label' => $with_label ) );
	}
}

if ( ! function_exists( 'wpj_display_job_order_button' ) ) {
	function wpj_display_job_order_button( $button_type = '', $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );
		$post = get_post( $pid );

		$is_post_author = get_current_user_id() == $post->post_author ? true : false;

		$submit_data = apply_filters( 'wpj_buy_job_submit_form_filter', 'data-submit="[name=myFormPurchase]"', 'login-link', $post->post_author );
		if ( is_user_logged_in() ) {
			$submit_action = isset( $submit_data['action'] ) ? $submit_data['action'] : 'data-submit="[name=myFormPurchase]"';
			$submit_class  = isset( $submit_data['class'] ) ? $submit_data['class'] : '';

		} else {
			$submit_action = isset( $submit_data['action'] ) ? $submit_data['action'] : '';
			$submit_class  = isset( $submit_data['class'] ) ? $submit_data['class'] : 'login-link';

		}

		$author_vacation = wpj_get_user_vacation( $post->post_author );
		$author_vacation = apply_filters( 'wpj_author_vacation_filter', $author_vacation, $pid );
		$author_vacation_reason = $author_vacation && $author_vacation['mode'] == 1 ? $author_vacation['reason'] : false;

		if ( get_post_meta( $pid, 'price_type', true ) != 'custom' ) {

			wpj_get_template( 'elements/job/job-order-button-template.php', array(
				'pid'                    => $pid,
				'post'                   => $post,
				'author_vacation'        => $author_vacation,
				'author_vacation_reason' => $author_vacation_reason,
				'is_post_author'         => $is_post_author,
				'button_type'            => $button_type,
				'submit_class'           => $submit_class,
				'submit_action'          => $submit_action
			) );

		}
	}
}

if ( ! function_exists( 'wpj_display_suggested_jobs_list' ) ) {
	function wpj_display_suggested_jobs_list( $pid = '', $author = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );
		$post = get_post( $pid );

		if ( $author ) $uid = $author;
		else $uid = $post->post_author;

		$author = get_userdata( $uid );

		wpj_get_template( 'elements/job/job-suggested-list-template.php', array( 'pid' => $pid, 'author' => $author ) );
	}
}

if ( ! function_exists( 'wpj_display_job_or_offer_button' ) ) {
	function wpj_display_job_or_offer_button( $pid = '', $page = 'single_job', $location = '' ) {

		if ( ! $pid ) $pid = wpj_get_post_id( $pid );
		$post = get_post( $pid );

		wpj_get_template( 'elements/job/job-or-offer-button-template.php', array(
			'pid'                  => $pid,
			'post'                 => $post,
			'page'                 => $page,
			'location'             => $location,
			'display_custom_offer' => wpj_get_option( 'wpjobster_enable_custom_offers' ) != 'no' && $post->post_author != get_current_user_id() && apply_filters( 'hide_for_buyers', true, $post->post_author ) ? true : false
		) );

	}
}

if ( ! function_exists( 'wpj_display_job_secure' ) ) {
	function wpj_display_job_secure() {
		wpj_get_template( 'elements/job/job-secure-template.php' );
	}
}

if ( ! function_exists( 'wpj_display_job_terms' ) ) {
	function wpj_display_job_terms() {
		wpj_get_template( 'elements/job/job-terms-template.php' );
	}
}

if ( ! function_exists( 'wpj_display_job_tags' ) ) {
	function wpj_display_job_tags( $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );
		wpj_get_template( 'elements/job/job-tags-template.php', array( 'pid' => $pid ) );
	}
}

if ( ! function_exists( 'wpj_display_job_views' ) ) {
	function wpj_display_job_views( $pid = '', $display_label = true ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		wpj_get_template( 'elements/job/job-views-template.php', array(
			'pid'           => $pid,
			'display_label' => $display_label
		) );
	}
}

if ( ! function_exists( 'wpj_display_job_recently_bought' ) ) {
	function wpj_display_job_recently_bought( $uid = '', $display_title = 'no' ) {

		global $wpdb, $jobster_design;

		$uid = $uid ? $uid : get_current_user_id();

		$row = $wpdb->get_row( $wpdb->prepare( "SELECT job_title, pid FROM {$wpdb->prefix}job_orders orders WHERE uid = %d AND payment_status != 'pending' ORDER BY date_made DESC", $uid ) );

		$pic_id = isset( $row->pid ) ? get_the_post_thumbnail_url( $row->pid, 'thumb_picture_size' ) : '';

		if ( $pic_id != false ) {
			$img = $pic_id;

		} else {
			$img = ! empty( $jobster_design['no_image_icon_options_job']['url'] ) ? $jobster_design['no_image_icon_options_job']['url'] : get_template_directory_uri() . '/assets/images/dummy/placeholder.webp';
			$img = apply_filters( 'wpj_placeholder_image_url_filter', $img, 'jobs' );

		}

		wpj_get_template( 'elements/job/job-recently-bought-template.php', array(
			'row'           => $row,
			'img'           => $img,
			'display_title' => $display_title
		) );

	}
}

if ( ! function_exists( 'wpj_display_job_recently_viewed' ) ) {
	function wpj_display_job_recently_viewed( $uid = '', $display_title = 'no' ) {

		$uid = $uid ? $uid : get_current_user_id();

		$last_viewed = get_user_meta( $uid, 'last_viewed', true );

		$args = array(
			'post_type'           => 'job',
			'posts_per_page'      => 5,
			'post__in'            => $last_viewed,
			'ignore_sticky_posts' => true,
			'orderby'             => 'post__in'
		);

		wpj_get_template( 'elements/job/job-recently-viewed-template.php', array(
			'uid'           => $uid,
			'last_viewed'   => $last_viewed,
			'args'          => $args,
			'display_title' => $display_title
		) );
	}
}

if ( ! function_exists( 'wpj_display_job_bulk_action_button' ) ) {
	function wpj_display_job_bulk_action_button() {
		wpj_get_template( 'elements/job/job-bulk-action-button-template.php' );
	}
}

if ( ! function_exists( 'wpj_display_job_edit_button' ) ) {
	function wpj_display_job_edit_button( $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );
		wpj_get_template( 'elements/job/job-edit-button-template.php', array( 'pid' => $pid ) );
	}
}