<?php
if ( ! function_exists( 'wpj_display_job_packages' ) ) {
	function wpj_display_job_packages( $pid = '', $display_location = '' ) {

		$pid = wpj_get_post_id( $pid );

		if ( wpj_get_option( 'wpjobster_packages_enabled' ) == 'yes' && get_post_meta( $pid, 'job_packages', true ) == 'yes' ) {

			wpj_get_template( 'elements/package/job-packages-template.php', array(
				'pid'              => $pid,
				'display_location' => $display_location
			) );

		}

	}
}

/* PACKAGES MOBILE */
if ( ! function_exists( 'wpj_display_packages_for_mobile' ) ) {
	function wpj_display_packages_for_mobile( $pid = '' ) {
		$pid = wpj_get_post_id( $pid );

		wpj_get_template( 'elements/package/job-packages-mobile-template.php', array(
			'pid'                   => $pid,
			'packages'              => array( 'basic', 'standard', 'premium' ),
			'package_name'          => get_post_meta( $pid, 'package_name', true ),
			'package_description'   => get_post_meta( $pid, 'package_description', true ),
			'package_max_days'      => get_post_meta( $pid, 'package_max_days', true ),
			'package_price'         => get_post_meta( $pid, 'package_price', true ),
			'package_revisions'     => get_post_meta( $pid, 'package_revisions', true ),
			'package_custom_fields' => get_post_meta( $pid, 'package_custom_fields', true ),
			'package_number'        => apply_filters( 'wpj_package_filter_mobile', 1 )
		) );
	}
}

/* PACKAGES PC */
if ( ! function_exists( 'wpj_display_packages_for_pc' ) ) {
	function wpj_display_packages_for_pc( $pid = '' ) {

		$pid = wpj_get_post_id( $pid );

		wpj_get_template( 'elements/package/job-packages-pc-template.php', array(
			'pid'                   => $pid,
			'package_name'          => get_post_meta( $pid, 'package_name', true ),
			'package_description'   => get_post_meta( $pid, 'package_description', true ),
			'package_max_days'      => get_post_meta( $pid, 'package_max_days', true ),
			'package_price'         => get_post_meta( $pid, 'package_price', true ),
			'package_revisions'     => get_post_meta( $pid, 'package_revisions', true ),
			'package_custom_fields' => get_post_meta( $pid, 'package_custom_fields', true )
		) );
	}
}

/* PACKAGES SIDEBAR */
if ( ! function_exists( 'wpj_display_packages_for_sidebar' ) ) {
	function wpj_display_packages_for_sidebar( $pid = '' ) {

		$pid = wpj_get_post_id( $pid );

		if ( wpj_get_option( 'wpjobster_packages_enabled' ) == 'yes' && get_post_meta( $pid, 'job_packages', true ) == 'yes' ) {

			$arr_key = 2;

			$packages_arr = array( __( 'Premium', 'wpjobster' ), __( 'Standard', 'wpjobster' ), __( 'Basic', 'wpjobster' ) );

			foreach ( $packages_arr as $key => $name ) {

				wpj_get_template( 'elements/package/job-packages-sidebar-template.php', array(
					'pid'                   => $pid,
					'package_name'          => get_post_meta( $pid, 'package_name', true ),
					'package_description'   => get_post_meta( $pid, 'package_description', true ),
					'package_max_days'      => get_post_meta( $pid, 'package_max_days', true ),
					'package_price'         => get_post_meta( $pid, 'package_price', true ),
					'package_revisions'     => get_post_meta( $pid, 'package_revisions', true ),
					'package_custom_fields' => get_post_meta( $pid, 'package_custom_fields', true ),
					'arr_key'               => $arr_key,
					'act'                   => ( $arr_key == 1 ) ? 'active' : '',
					'sel'                   => ( $arr_key == 1 ) ? 'selected' : '',
					'class'                 => ( $arr_key == 1 ) ? 'right labeled' : '',
					'display'               => ( $arr_key == 1 ) ? 'block' : 'none',
					'name'                  => $name
				) );

				$arr_key--;

			}

		}
	}
}

if ( ! function_exists( 'wpj_display_packages_for_post_new' ) ) {
	function wpj_display_packages_for_post_new( $pid = '' ) {

		$wpjobster_packages = wpj_get_option( 'wpjobster_packages_enabled' );

		$pid         = wpj_get_post_id( $pid );
		$post        = $pid ? get_post( $pid ) : array();
		$action      = WPJ_Form::get( 'action' );
		$action_type = $action == 'edit-job' ? 'edit' : 'new';

		$post_job_packages = WPJ_Form::post( 'price_type', get_post_meta( $pid, 'job_packages', true ) );

		if ( $wpjobster_packages == "yes" ) {

			$package_custom_fields = get_post_meta( $pid, 'package_custom_fields', true );

			$instr_arr = array();
			if ( function_exists( 'have_rows' ) && have_rows( 'job_fields', wpj_get_option( 'wpjobster_post_new_page_id' ) ) ) {
				while ( have_rows( 'job_fields', wpj_get_option( 'wpjobster_post_new_page_id' ) ) ) {
					the_row();
					if ( get_row_layout() == 'job_packages' ) {
						$instr_arr[] = array(
							'pck_name'    => get_sub_field( 'pacakge_name_instructions' ),
							'pck_desc'    => get_sub_field( 'pacakge_description_instructions' ),
							'pck_deliv'   => get_sub_field( 'pacakge_delivery_time_instructions' ),
							'pck_rev'     => get_sub_field( 'pacakge_revision_instructions' ),
							'pck_price'   => get_sub_field( 'pacakge_price_instructions' ),
							'pck_cf_name' => get_sub_field( 'pacakge_custom_field_name' ),
							'pck_cf_chk'  => get_sub_field( 'pacakge_custom_field_checklist' ),
						);
					}
				}

			} else {
				$instr_arr[] = array(
					'pck_name'    => get_post_meta( wpj_get_option( 'wpjobster_post_new_page_id' ), 'package_name_instructions', true ),
					'pck_desc'    => get_post_meta( wpj_get_option( 'wpjobster_post_new_page_id' ), 'package_description_instructions', true ),
					'pck_deliv'   => get_post_meta( wpj_get_option( 'wpjobster_post_new_page_id' ), 'package_max_days_instructions', true ),
					'pck_rev'     => get_post_meta( wpj_get_option( 'wpjobster_post_new_page_id' ), 'package_revisions_instructions', true ),
					'pck_price'   => get_post_meta( wpj_get_option( 'wpjobster_post_new_page_id' ), 'package_price_instructions', true ),
					'pck_cf_name' => get_post_meta( wpj_get_option( 'wpjobster_post_new_page_id' ), 'package_cf_name_instructions', true ),
					'pck_cf_chk'  => get_post_meta( wpj_get_option( 'wpjobster_post_new_page_id' ), 'package_cf_checklist_instructions', true )
				);

			}

			$pck_cf_name_value = isset( $_POST['pck-inp-custom-name'] ) ? $_POST['pck-inp-custom-name'][0] : '';
			if ( ! $pck_cf_name_value ) { $pck_cf_name_value = $package_custom_fields ? $package_custom_fields[0]['name'] : ''; }

			$pck_cf_basic_value = isset( $_POST['pck-chk-value']['basic'][0] ) ? $_POST['pck-chk-value']['basic'][0] : '';
			if ( ! $pck_cf_basic_value ) { $pck_cf_basic_value = $package_custom_fields ? $package_custom_fields[0]['basic'] : ''; }

			$checked_basic = $pck_cf_basic_value == 'on' ? 'checked' : '';

			$pck_cf_standard_value = isset( $_POST['pck-chk-value']['standard'][0] ) ? $_POST['pck-chk-value']['standard'][0] : '';
			if ( ! $pck_cf_standard_value ) { $pck_cf_standard_value = $package_custom_fields ? $package_custom_fields[0]['standard'] : ''; }

			$checked_standard = $pck_cf_standard_value == 'on' ? 'checked' : '';

			$pck_cf_premium_value = isset( $_POST['pck-chk-value']['premium'][0] ) ? $_POST['pck-chk-value']['premium'][0] : '';
			if ( ! $pck_cf_premium_value ) { $pck_cf_premium_value = $package_custom_fields ? $package_custom_fields[0]['premium'] : ''; }

			$checked_premium = $pck_cf_premium_value == 'on' ? 'checked' : '';

			wpj_get_template( 'elements/package/job-packages-post-new-template.php', array(
				'wpjobster_packages'    => $wpjobster_packages,
				'pid'                   => $pid,
				'post'                  => $post,
				'action'                => $action,
				'action_type'           => $action_type,
				'post_job_packages'     => $post_job_packages,
				'instr_arr'             => $instr_arr,
				'package_custom_fields' => $package_custom_fields,
				'pck_name_val'          => isset( $_POST['package_name'] ) ? $_POST['package_name'] : get_post_meta( $pid, 'package_name', true ),
				'pck_description_val'   => isset( $_POST['package_description'] ) ? $_POST['package_description'] : get_post_meta( $pid, 'package_description', true ),
				'pck_max_days_val'      => isset( $_POST['package_max_days'] ) ? $_POST['package_max_days'] : get_post_meta( $pid, 'package_max_days', true ),
				'pck_revisions_val'     => isset( $_POST['package_revisions'] ) ? $_POST['package_revisions'] : get_post_meta( $pid, 'package_revisions', true ),
				'pck_price_val'         => isset( $_POST['package_price'] ) ? $_POST['package_price'] : get_post_meta( $pid, 'package_price', true ),
				'pck_cf_name_value'     => $pck_cf_name_value,
				'pck_cf_basic_value'    => $pck_cf_basic_value,
				'checked_basic'         => $checked_basic,
				'pck_cf_standard_value' => $pck_cf_standard_value,
				'checked_standard'      => $checked_standard,
				'pck_cf_premium_value'  => $pck_cf_premium_value,
				'checked_premium'       => $checked_premium
			) );

		}
	}
}