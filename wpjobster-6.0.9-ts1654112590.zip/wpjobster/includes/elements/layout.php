<?php
if ( ! function_exists( 'wpj_display_post_layout_switcher' ) ) {
	function wpj_display_post_layout_switcher( $classes = '' ) {

		wpj_get_template( 'elements/layout/post-layout-switcher-template.php', array( 'classes' => $classes ) );

	}
}