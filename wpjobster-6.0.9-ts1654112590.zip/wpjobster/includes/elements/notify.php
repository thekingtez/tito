<?php
/* PREVIEW PANEL */
if ( ! function_exists( 'wpj_display_preview_pm_list' ) ) {
	function wpj_display_preview_pm_list() {

		global $wpdb;

		$uid = get_current_user_id();

		$messages = $wpdb->get_results( "
			SELECT id, rd, initiator, other, user, content, datemade, archived
			FROM (
				SELECT id, rd, initiator, other, user, content, MAX(datemade) AS datemade, archived
				FROM (
					SELECT id, rd, user AS other, user AS initiator, user AS user, content, datemade, archived_to_source AS archived
					FROM {$wpdb->prefix}job_pm
					WHERE initiator = {$uid}
					AND show_to_source = '1'

					UNION

					SELECT id, rd, initiator AS other, initiator AS initiator, user AS user, content, datemade, archived_to_destination AS archived
					FROM {$wpdb->prefix}job_pm
					WHERE user = {$uid}
					AND show_to_destination = '1'

					ORDER BY datemade DESC
				) tmp
				GROUP BY other
				ORDER BY datemade DESC
			) tmp2
			WHERE archived = '0'
			LIMIT 10
		" );

		wpj_get_template( 'elements/notify/preview-pm-list-template.php', array(
			'uid'      => $uid,
			'messages' => $messages,
			'i'        => 0,
		) );

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_display_preview_notification_list' ) ) {
	function wpj_display_preview_notification_list() {

		global $wpdb;

		$uid = get_current_user_id();

		$buyer_uid  = implode( ", ", wpj_get_chatbox_uid_by_user_type( 'buyer' ) );
		$seller_uid = implode( ", ", wpj_get_chatbox_uid_by_user_type( 'seller' ) );

		$notifications = $wpdb->get_results( "
			SELECT chatbox.id id, chatbox.rd_receiver, orders.id oid, posts.ID pid, posts.post_author sid, orders.uid bid, chatbox.uid code, chatbox.datemade tm, orders.date_made otm
			FROM {$wpdb->prefix}job_chatbox chatbox, {$wpdb->prefix}job_orders orders, $wpdb->posts posts
			WHERE chatbox.oid = orders.id
				AND posts.ID = orders.pid
				AND chatbox.uid != '{$uid}'
				AND ( posts.post_author = '{$uid}' OR orders.uid = '{$uid}' )
				AND ( chatbox.uid > 0
					OR ( posts.post_author = '{$uid}' AND (chatbox.uid IN ( {$seller_uid} ) ) )
					OR ( orders.uid = '{$uid}' AND ( chatbox.uid IN ( {$buyer_uid} ) ) )
			)
			GROUP BY chatbox.datemade
			ORDER BY chatbox.rd_receiver ASC, tm DESC
			LIMIT 10
		" );

		wpj_get_template( 'elements/notify/preview-notification-list-template.php', array(
			'uid'           => $uid,
			'notifications' => $notifications,
			'i'             => 0,
		) );

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

/* MESSAGES */
if ( ! function_exists( 'wpj_display_chat_sidebar_placeholder' ) ) {
	function wpj_display_chat_sidebar_placeholder( $sidebar_status = '', $icon = 'comments' ) {
		global $jobster_design;

		$vars = array(
			'jobster_design' => $jobster_design,
			'sidebar_status' => $sidebar_status,
			'icon'           => $icon
		);

		if ( $jobster_design['chat_sidebar_style'] == 1 )
			wpj_get_template( 'elements/notify/chat-sidebar-placeholder-template.php', $vars );

		else
			wpj_get_template( 'elements/notify/chat-sidebar-minimal-placeholder-template.php', $vars );

	}
}

if ( ! function_exists( 'wpj_display_chat_sidebar' ) ) {
	function wpj_display_chat_sidebar( $users, $sidebar_status = '', $user_on_cnt = 0 , $icon = 'comments' ) {
		global $jobster_design;

		$vars = array(
			'jobster_design' => $jobster_design,
			'users'          => $users,
			'sidebar_status' => $sidebar_status,
			'user_on_cnt'    => $user_on_cnt,
			'icon'           => $icon
		);

		if ( $jobster_design['chat_sidebar_style'] == 1 )
			wpj_get_template( 'elements/notify/chat-sidebar-template.php', $vars );

		else
			wpj_get_template( 'elements/notify/chat-sidebar-minimal-template.php', $vars );

	}
}

if ( ! function_exists( 'wpj_display_chat_messagebox' ) ) {
	function wpj_display_chat_messagebox( $uid = '', $box_status = '' ) {

		if ( ! $uid ) $uid = WPJ_Form::post( 'user_id' );
		if ( ! $box_status ) $box_status = WPJ_Form::post( 'box_status', 'maximized' );

		if ( $uid ) {

			$user_arr = get_userdata( $uid );

			// User last seen
			$time_elapsed    = ! empty ( $user_arr->last_user_login ) ? time() - $user_arr->last_user_login : 60000;
			$time_difference = $time_elapsed / 60;
			$time_difference = (int)$time_difference;

			$attach_class  = wpj_get_option( 'wpjobster_message_attachments_enable' ) != 'no' ? 'is-file-upload-enabled' : '';
			$attach_class .= wpj_get_option( 'wpjobster_message_image_attachments_enable' ) != 'no' ? ' is-image-upload-enabled' : '';

			wpj_get_template( 'elements/notify/chat-messagebox-template.php', array(
				'uid'           => $uid,
				'box_status'    => $box_status,
				'user_nicename' => $user_arr->user_nicename,
				'status_class'  => $time_difference <= 5 ? 'online' : 'offline',
				'attach_class'  => $attach_class
			) );

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_display_user_new_messages' ) ) {
	function wpj_display_user_new_messages( $interlocutor_id = '', $receiver_id = '', $source = '' ) {
		global $wpdb;

		$receiver_id = WPJ_Form::post( 'receiver_id', get_current_user_id() );
		$source      = WPJ_Form::post( 'source', $source );

		$results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_pm WHERE user = {$receiver_id} AND show_to_destination = 1 AND rd = 0" );

		if ( $results ) {
			foreach ( $results as $key => $row ) {
				if ( $source == 'private-messages' ) {
					wpj_display_message_item( $row, $receiver_id, $row->initiator );

				} else {
					wpj_display_chat_message_item( $row, $receiver_id, $row->initiator );

				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_display_message_settings_options' ) ) {
	function wpj_display_message_settings_options() {
		wpj_get_template( 'elements/notify/message-settings-options-template.php', array(
			'interlocutor_id' => wpj_get_pm_interlocutor_from_url( 'id' )
		) );
	}
}

if ( ! function_exists( 'wpj_display_send_message_form' ) ) {
	function wpj_display_send_message_form() {
		$attach_class = wpj_get_option( 'wpjobster_message_attachments_enable' ) != 'no' ? 'is-file-upload-enabled' : '';
		$attach_class .= wpj_get_option( 'wpjobster_message_image_attachments_enable' ) != 'no' ? ' is-image-upload-enabled' : '';

		wpj_get_template( 'elements/notify/send-message-form-template.php', array(
			'interlocutor_id'   => wpj_get_pm_interlocutor_from_url( 'id' ),
			'interlocutor_data' => wpj_get_pm_interlocutor_from_url( 'data' ),
			'attach_class'      => $attach_class
		) );
	}
}

/* QUICK RESPONSE */
if ( ! function_exists( 'wpj_display_quick_response' ) ) {
	function wpj_display_quick_response( $uid = '', $location = '' ) {

		// Create new/edit - modal
		wpj_init_new_quick_response_modal( $uid );

		// Delete all - modal
		wpj_init_delete_quick_responses_modal( $uid );

		wpj_get_template( 'elements/notify/quick-response-template.php',
			array(
				'uid'               => $uid,
				'username'          => wpj_get_user_display_type( $uid ),
				'quick_responses'   => get_user_meta( get_current_user_id(), 'quick_responses', true ),
				'dropdown_icon'     => $location == 'order' ? 'clock outline' : 'bolt',
				'dropdown_position' => is_rtl() && $location != 'chat' ? 'left' : 'right'
			)
		);
	}
}

/* EMAIL SETTINGS */
if ( ! function_exists( 'wpj_display_email_notification_list' ) ) {
	function wpj_display_email_notification_list() {
		$notifications_array = wpj_get_notifications_array();

		unset( $notifications_array['admin'] );
		unset( $notifications_array['registration'] );
		unset( $notifications_array['account_segregation'] );

		wpj_get_template( 'elements/notify/email-notifications-list-template.php', array(
			'user_id'             => get_current_user_id(),
			'notifications_array' => $notifications_array,
		) );
	}
}

if ( ! function_exists( 'wpj_display_sms_notification_list' ) ) {
	function wpj_display_sms_notification_list() {
		$notifications_array = wpj_get_notifications_array();

		unset( $notifications_array['admin'] );
		unset( $notifications_array['registration'] );
		unset( $notifications_array['account_segregation'] );

		wpj_get_template( 'elements/notify/sms-notifications-list-template.php', array(
			'user_id'             => get_current_user_id(),
			'notifications_array' => $notifications_array,
			'sms_gateway_op'      => wpj_get_option( 'wpjobster_sms_gateways_enable' )
		) );
	}
}

/* SMS CODE */
if ( ! function_exists( 'wpj_display_sms_code_field' ) ) {
	function wpj_display_sms_code_field() {
		if ( wpj_get_phone_verification_status( 'status' ) == 'resent' || wpj_get_phone_verification_status( 'status' ) == 'wrongkey' ) {
			wpj_get_template( 'elements/notify/sms-code-field-template.php' );
		}
	}
}