<?php
if ( ! function_exists( 'wpj_display_rating_stars' ) ) {
	function wpj_display_rating_stars( $grade ) {
		$halves = ( $grade + 0.25 ) * 2;

		$full   = (int) ( $halves / 2 );
		$half   = $halves % 2;

		wpj_get_template( 'elements/rating/rating-stars-template.php', array(
			'grade'  => $grade,
			'halves' => $halves,
			'full'   => $full,
			'half'   => $half
		) );

	}
}

// JOB
if ( ! function_exists( 'wpj_display_job_reviews_number' ) ) {
	function wpj_display_job_reviews_number( $pid = false ) {
		$pid = wpj_get_post_id( $pid );

		$rating_count = wpj_get_option( 'wpjobster_job_min_rating' );
		$rating_count = $rating_count && is_numeric( $rating_count ) ? $rating_count : 3;

		wpj_get_template( 'elements/rating/job-reviews-number-template.php', array(
			'pid'          => $pid,
			'rating_count' => $rating_count
		) );
	}
}

if ( ! function_exists( 'wpj_display_job_review_text' ) ) {
	function wpj_display_job_review_text() {

		wpj_get_template( 'elements/rating/job-review-text-template.php' );

	}
}

if ( ! function_exists( 'wpj_display_job_review_response_text' ) ) {
	function wpj_display_job_review_response_text( $order_id, $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		global $wpdb;

		if ( $order_id ) {

			$post_author = get_post_field( 'post_author', $pid );

			$query_seller = "
				SELECT DISTINCT *, ratings.datemade, orders.uid AS buyer_id, datemade
				FROM {$wpdb->prefix}job_ratings_by_seller ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
				WHERE posts.ID = orders.pid
				AND ( posts.ID = {$pid}
					OR ratings.pid IN (
						SELECT custom_offer
						FROM {$wpdb->prefix}job_pm pm, {$wpdb->prefix}job_ratings jr
						WHERE associate_job_id = {$pid}
						AND custom_offer = jr.pid
					)
				)
				AND ratings.awarded = '1'
				AND orders.id = ratings.orderid
				AND posts.post_author = {$post_author}
				AND orders.id = {$order_id}
				ORDER BY datemade DESC
				LIMIT 3
			";

			$r_seller = $wpdb->get_results( $query_seller );

			if ( $r_seller ) {

				wpj_get_template( 'elements/rating/job-review-response-text-template.php', array(
					'row_seller'  => $r_seller[0],
					'post_author' => $post_author,
					'pid'         => $pid
				) );

			}

		}
	}
}

if ( ! function_exists( 'wpj_display_job_rating_stars' ) ) {
	function wpj_display_job_rating_stars( $pid = false ) {
		$pid = wpj_get_post_id( $pid );

		$ratinggrade = wpj_get_job_rating_percent( $pid );
		$ratinggrade = $ratinggrade / 20;

		$rating_count = wpj_get_option( 'wpjobster_job_min_rating' );
		$rating_count = $rating_count && is_numeric( $rating_count ) ? $rating_count : 3;

		wpj_get_template( 'elements/rating/job-rating-stars-template.php', array(
			'pid'          => $pid,
			'ratinggrade'  => $ratinggrade,
			'rating_count' => $rating_count
		) );

	}
}

// USER
if ( ! function_exists( 'wpj_display_user_reviews_number' ) ) {
	function wpj_display_user_reviews_number( $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		$rating_count = wpj_get_option( 'wpjobster_user_min_rating' );
		$rating_count = $rating_count && is_numeric( $rating_count ) ? $rating_count : 3;

		wpj_get_template( 'elements/rating/user-reviews-number-template.php', array(
			'uid'          => $uid,
			'rating_count' => $rating_count
		) );
	}
}

if ( ! function_exists( 'wpj_display_user_review_text' ) ) {
	function wpj_display_user_review_text() {

		wpj_get_template( 'elements/rating/user-review-text-template.php' );

	}
}

if ( ! function_exists( 'wpj_display_user_review_response_text' ) ) {
	function wpj_display_user_review_response_text( $order_id, $pid = '' ) {
		if ( ! $pid ) $pid = wpj_get_post_id( $pid );

		global $wpdb;

		if ( $order_id ) {

			$post_author = get_post_field( 'post_author', $pid );

			$ratings_table = apply_filters( 'wpj_buyer_reviews_database_table_filter', $wpdb->prefix . 'job_ratings_by_seller', $post_author );

			$query_seller = "
				SELECT DISTINCT *, ratings.datemade, orders.uid as buyer_id, datemade
				FROM {$ratings_table} ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
				WHERE posts.ID = orders.pid
				AND posts.ID = {$pid}
				AND ratings.awarded = '1'
				AND orders.id = ratings.orderid
				AND posts.post_author = {$post_author}
				AND orders.id = {$order_id}
				ORDER BY datemade DESC
			";

			$row = $wpdb->get_row( $query_seller );

			$custom_offer_result = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}job_pm WHERE initiator = %d AND custom_offer = %d", $post_author, $pid ) );

			if ( $row ) {

				wpj_get_template( 'elements/rating/user-review-response-text-template.php', array(
					'row'                 => $row,
					'post_author'         => apply_filters( 'wpj_user_review_author_filter', $post_author, wpj_get_user_id(), get_post( $pid ) ),
					'pid'                 => $pid,
					'custom_offer_result' => $custom_offer_result
				) );

			}

		}
	}
}

if ( ! function_exists( 'wpj_display_user_rating_stars' ) ) {
	function wpj_display_user_rating_stars( $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		$rtg = wpj_get_seller_rating_percent( $uid );
		$ratinggrade = $rtg / 20;

		$rating_count = wpj_get_option( 'wpjobster_user_min_rating' );
		$rating_count = $rating_count && is_numeric( $rating_count ) ? $rating_count : 3;

		wpj_get_template( 'elements/rating/user-rating-stars-template.php', array(
			'uid'              => $uid,
			'ratinggrade'      => $ratinggrade,
			'rating_count'     => $rating_count
		) );
	}
}

if ( ! function_exists( 'wpj_display_user_unresponsive_label' ) ) {
	function wpj_display_user_unresponsive_label( $uid = '' ) {
		global $wpdb;

		if ( ! $uid ) $uid = wpj_get_user_id();

		$jobs_count = $wpdb->get_var( "
			SELECT COUNT(*)
			FROM {$wpdb->prefix}job_orders orders,
				 {$wpdb->prefix}posts posts
			WHERE posts.post_author = {$uid}
				AND posts.ID = orders.pid
				AND orders.force_cancellation = 7
		" );
		$jobs_word = _n( "job", "jobs", $jobs_count, "wpjobster" );

		$tooltip_position = is_rtl() ? 'top right' : 'top center';
		$tootltip_content = sprintf( __( 'This seller has %d %s he did not answer', 'wpjobster' ), $jobs_count, $jobs_word );

		wpj_get_template( 'elements/rating/user-unresponsive-label-template.php', array(
			'uid'                     => $uid,
			'jobs_count'              => $jobs_count,
			'orders_rejection_number' => wpj_get_option( 'wpjobster_seller_order_rejection_number' ) ? wpj_get_option( 'wpjobster_seller_order_rejection_number' ) : 1,
			'tooltip_position'        => $tooltip_position,
			'tootltip_content'        => $tootltip_content,
		) );
	}
}

if ( ! function_exists( 'wpj_display_seller_reputation' ) ) {
	function wpj_display_seller_reputation( $uid = '', $pid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();
		wpj_get_template( 'elements/rating/seller-reputation-template.php', array( 'uid' => $uid ) );
	}
}

if ( ! function_exists( 'wpj_display_user_rating_info' ) ) {
	function wpj_display_user_rating_info( $uid = '', $pid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();
		wpj_get_template( 'elements/rating/user-rating-info-template.php', array( 'uid' => $uid ) );
	}
}

if ( ! function_exists( 'wpj_display_work_sample_preview_image' ) ) {
	function wpj_display_work_sample_preview_image( $sample_id = '' ) {

		if ( wpj_get_option( 'wpjobster_enable_review_work_samples' ) == 'yes' && $sample_id != '' ) {

			$sample     = wpj_get_attachment_image_url( $sample_id, array( 42, 42 ) );
			$sample_big = wpj_get_attachment_image_url( $sample_id, 'job_slider_image' );

			wpj_get_template( 'elements/rating/work-sample-preview-image-template.php', array(
				'sample'     => $sample,
				'sample_id'  => $sample_id,
				'sample_big' => $sample_big
			) );

		}

	}
}