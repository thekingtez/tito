<?php
if ( ! function_exists( 'wpj_display_subscription_features_table_for_mobile' ) ) {
	function wpj_display_subscription_features_table_for_mobile( $action_type = '' ) {

		$is_subscribed = '0';

		$current_amount = $current_level = $current_type = '';

		$current_subscription = wpj_get_subscription_by_uid( get_current_user_id() );

		if ( is_object( $current_subscription ) ) {
			$is_subscribed     = '1';
			$current_level     = $current_subscription->subscription_level;
			$current_type      = $current_subscription->subscription_type;
			$current_amount    = $current_subscription->subscription_amount;
		}

		wpj_get_template( 'elements/subscription/subscription-features-table-mobile-template.php', array(
			'features'                         => wpj_get_subscription_features(),
			'padding'                          => isset( $is_eligibility ) ? ' pt20' : '',
			'subscription_levels'              => wpj_get_subscription_levels_info(),
			'subscription_eligibility_enabled' => wpj_get_option( 'wpjobster_subscription_eligibility_enabled' ),
			'is_subscribed'                    => $is_subscribed,
			'current_user_sales'               => floatval( get_user_meta( get_current_user_id(), 'user_total_earnings', true ) ),
			'action_type'                      => $action_type,
			'current_level'                    => $current_level,
			'current_type'                     => $current_type,
			'current_amount'                   => $current_amount,
			'pending_subscription'             => wpj_get_subscription_order_by( 'user_id', get_current_user_id(), 'inactive\' AND payment_status=\'pending' )
		) );

	}
}

if ( ! function_exists( 'wpj_display_subscription_features_table_for_pc' ) ) {
	function wpj_display_subscription_features_table_for_pc( $action_type = '' ) {

		$is_subscribed = '0';

		$current_amount = $current_level = $current_type = '';

		$current_subscription = wpj_get_subscription_by_uid( get_current_user_id() );

		if ( is_object( $current_subscription ) ) {
			$is_subscribed     = '1';
			$current_level     = $current_subscription->subscription_level;
			$current_type      = $current_subscription->subscription_type;
			$current_amount    = $current_subscription->subscription_amount;
		}

		wpj_get_template( 'elements/subscription/subscription-features-table-pc-template.php', array(
			'features'                         => wpj_get_subscription_features(),
			'subscription_levels'              => wpj_get_subscription_levels_info(),
			'subscription_eligibility_enabled' => wpj_get_option( 'wpjobster_subscription_eligibility_enabled' ),
			'is_subscribed'                    => $is_subscribed,
			'current_user_sales'               => floatval( get_user_meta( get_current_user_id(), 'user_total_earnings', true ) ),
			'action_type'                      => $action_type,
			'current_level'                    => $current_level,
			'current_type'                     => $current_type,
			'current_amount'                   => $current_amount,
			'subscription_packages_number'     => 4,
			'pending_subscription'             => wpj_get_subscription_order_by( 'user_id', get_current_user_id(), 'inactive\' AND payment_status=\'pending' )
		) );

	}
}

if ( ! function_exists( 'wpj_display_subscription_billing_period' ) ) {
	function wpj_display_subscription_billing_period( $device = 'pc',  $subscription_levels = '', $subscr_key = '', $is_subscribed = 0, $action_type = 'new-subscription', $current_level = '', $current_type = '' ) {

		if ( $subscription_levels && $subscr_key ) {

			if ( wpj_subscription_package_enabled( $subscr_key ) ) {

				$na = 0;

				$intervals = array( "weekly", "monthly", "quarterly", "yearly", "lifetime" );

				foreach ( $intervals as $keyd => $valued ) {

					if ( $subscription_levels[$subscr_key][$valued] >= 0.1 ) {

						if ( $action_type == 'upgrade-subscription' && $is_subscribed == 1 )
							$amount_chargeable = $subscription_levels[$subscr_key][$valued] - $subscription_levels[$current_level][$current_type];

						else
							$amount_chargeable = $subscription_levels[$subscr_key][$valued];

						if ( wpj_get_option( 'wpjobster_subscription_eligibility_enabled' ) == 'yes' ) {

							if ( wpj_number_format_special( floatval( get_user_meta( get_current_user_id(), 'user_total_earnings', true ) ), 2 ) >= wpj_number_format_special( $subscription_levels[$subscr_key]['eligility'], 2 ) ) {
								$eligible_for_sub = '';
							} else {
								$eligible_for_sub = ' disabled="disabled" ';
							}

						} else {
							$eligible_for_sub = '';
						}

						if ( $amount_chargeable <= 0 ) {
							$eligible_for_sub = ' disabled="disabled" ';
						}

						wpj_get_template( 'elements/subscription/subscription-billing-period-template.php', array(
							'subscription_levels' => $subscription_levels,
							'subscr_key'          => $subscr_key,
							'valued'              => $valued,
							'eligible_for_sub'    => $eligible_for_sub,
							'device'              => $device,
							'amount_chargeable'   => $amount_chargeable,
							'na'                  => $na,
						) );

					} else { $na++; }

				}

			}
		}
	}
}

if ( ! function_exists( 'wpj_display_subscription_features_details' ) ) {
	function wpj_display_subscription_features_details() {
		global $wpdb;

		$column1 = 'seven wide mobile three wide computer';
		$column2 = 'nine wide mobile thirteen wide computer';

		$current_level = $current_type = '';

		$current_subscription = wpj_get_subscription_by_uid( get_current_user_id() );

		$is_subscribed = '0';
		if ( is_object( $current_subscription ) ) {
			$is_subscribed = '1';
			$current_level = $current_subscription->subscription_level;
			$current_type  = $current_subscription->subscription_type;
		}

		$subscription_levels = wpj_get_subscription_levels_info();

		$features = wpj_get_subscription_features();

		$subscription_order = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}job_subscription_orders WHERE user_id = %d AND subscription_status = 'active' LIMIT 1", get_current_user_id() ) );

		if ( ! $subscription_order && is_object( $current_subscription ) )
			$wpdb->delete( $wpdb->prefix . "job_subscriptions", array( "id" => $current_subscription->id ) );

		wpj_get_template( 'elements/subscription/subscription-features-details-template.php', array(
			'column1'                          => $column1,
			'column2'                          => $column2,
			'current_level'                    => $current_level,
			'current_type'                     => $current_type,
			'current_subscription'             => $current_subscription,
			'subscription_eligibility_enabled' => wpj_get_option( 'wpjobster_subscription_eligibility_enabled' ),
			'subscription_levels'              => $subscription_levels,
			'features'                         => $features,
			'is_subscribed'                    => $is_subscribed,
			'subscription_order'               => $subscription_order
		) );
	}
}

if ( ! function_exists( 'wpj_display_subscription_schedule_details' ) ) {
	function wpj_display_subscription_schedule_details() {
		$current_subscription = wpj_get_subscription_by_uid( get_current_user_id() );

		if ( is_object( $current_subscription ) ) {
			wpj_get_template( 'elements/subscription/subscription-schdule-details-template.php', array(
				'current_subscription' => wpj_get_subscription_by_uid( get_current_user_id() ),
				'cancelled'            => wpj_get_subscription_next_billing_date( $current_subscription->subscription_type ) == '0000-00-00' ? 1 : 0,
				'column1'              => 'seven wide mobile three wide computer',
				'column2'              => 'nine wide mobile thirteen wide computer'
			) );
		}
	}
}