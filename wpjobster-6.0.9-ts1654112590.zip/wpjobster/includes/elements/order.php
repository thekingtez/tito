<?php
if ( ! function_exists( 'wpj_display_bank_details' ) ) {
	function wpj_display_bank_details() {
		global $wp_query;

		$payment_type = $payment_gateway = $order = '';

		if ( wpj_is_page( 'wpjobster_topup_order_page_id' ) ) {
			$payment_type    = 'topup';
			$order           = wpj_get_order_by_payment_type( 'topup', $wp_query->query_vars['oid'] );
			$payment_gateway = $order->payment_gateway_name;
		}

		if ( wpj_is_page( 'wpjobster_order_page_id' ) ) {
			$payment_type    = 'job_purchase';
			$order           = wpj_get_order_by_payment_type( 'job_purchase', $wp_query->query_vars['oid'] );
			$payment_gateway = $order->payment_gateway;
		}

		if ( wpj_is_page( 'wpjobster_feature_page_id' ) ) {
			$pid = wpj_get_post_id();
			$uid = get_current_user_id();

			$homepage_row = wpj_get_feature_job_by_page( 'h', $pid, $uid, 'pending' );

			$payment_type    = 'feature';
			$order           = wpj_get_order_by_payment_type( 'feature', $homepage_row->id );
			$payment_gateway = $order->payment_gateway;
		}

		wpj_get_template( 'elements/order/bank-details-template.php', array(
			'order'           => $order,
			'payment_type'    => $payment_type,
			'payment_gateway' => $payment_gateway
		) );
	}
}

if ( ! function_exists( 'wpj_display_topup_camouflaged_order' ) ) {
	function wpj_display_topup_camouflaged_order( $oid = '', $with_link = true ) {
		$order = wpj_get_topup_order_details( false, $oid );

		if ( $order ) {
			wpj_get_template( 'elements/order/order-camouflaged-template.php', array(
				'current_order' => $order,
				'orderid'       => $order['orderid'],
				'payment_type'  => $order['payment_type'],
				'date_made'     => $order['date_made'],
				'with_link'     => $with_link
			) );
		}
	}
}

if ( ! function_exists( 'wpj_display_camouflaged_order' ) ) {
	function wpj_display_camouflaged_order( $order = '', $with_link = true ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		if ( $order ) {
			wpj_get_template( 'elements/order/order-camouflaged-template.php', array(
				'current_order' => $order,
				'orderid'       => $order->id,
				'date_made'     => $order->date_made,
				'payment_type'  => 'job_purchase',
				'with_link'     => $with_link
			) );
		}
	}
}

if ( ! function_exists( 'wpj_display_order_timer' ) ) {
	function wpj_display_order_timer( $order = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		$buyer_arbitration = $expected = $instant = $rtl_clock_dir_class = $class_arr = $short_class_arr = $interval_arr = $show_timer = false;

		if ( $order ) {

			$show_timer = apply_filters( 'wpj_show_order_timer_filter', ( wpj_get_option( 'wpjobster_seller_order_rejection_enable' ) == 'yes' && $order->seller_confirmation == '0' ? false : true ), $order );
			if ( $show_timer ) {

				$pid = $order->pid;

				$arbitration       = wpj_get_arbitration_details_by_order_id( $order->id );
				$buyer_arbitration = isset( $arbitration->buyer_arbitration ) && $arbitration->buyer_arbitration == 1 ? true : false;

				$expected = wpj_get_order_expected_time( $order->id );

				$instant  = get_post_meta( $pid, 'instant', true );

				$show_timer = 0;
				if (
					wpj_bool_option( 'wpjobster_enable_delivery_time', true )
					&& ( get_post_meta( $pid, 'max_days', true ) || get_post_meta( $pid, 'job_packages', true ) == 'yes' )
				) {

					if ( $instant != 1 ) {
						if ( $order->extra_fast == 1 && ( $order->extra_fast_days != 'instant' && $order->extra_fast_days != 0 ) ) {
							$show_timer = 1;

						} elseif ( $order->expected_delivery >= current_time( 'timestamp', 1 ) ) {
							$show_timer = 1;

						} elseif ( wpj_is_order_time_up( $order ) == 1 ) {
							$show_timer = 1;

						} else {
							$show_timer = 0;

						}
					} elseif ( $order->expected_delivery >= current_time( 'timestamp', 1 ) ) {
						$show_timer = 1;

					} else {
						$show_timer = 0;

					}

				}

				$now           = current_time( 'timestamp', 1 );
				$expected_date = strtotime( $expected );
				$days_diff     = $now - $expected_date;

				if ( $show_timer == 1 && round( abs( $days_diff / ( 60 * 60 * 24 ) ) ) > 100 ) {
					$show_timer = 0;
				}

				if ( $show_timer == 1 && $order->payment_status != 'pending' && $order->payment_status != 'processing' && $order->closed != 1 && wpj_is_order_completed( $order ) != 1 && ! $buyer_arbitration ) {

					$class_arr           = array( 'days', 'hours','minutes', 'seconds' );
					$short_class_arr     = array( 'day', 'hour', 'min', 'sec' );
					$interval_arr        = array( __( 'days', 'wpjobster' ), __( 'hours', 'wpjobster' ), __( 'minutes', 'wpjobster' ),  __( 'seconds', 'wpjobster' ) );

					$rtl_clock_dir_class = ' ltr-clock-dir';

					if ( wpj_get_option( 'wpjobster_set_time_direction' ) == 'rtl' && is_rtl() ) {
						$class_arr       = array_reverse( $class_arr );
						$interval_arr    = array_reverse( $interval_arr );
						$short_class_arr = array_reverse( $short_class_arr );

						$rtl_clock_dir_class = ' rtl-clock-dir';
					}

				}
			}

		}

		wpj_get_template( 'elements/order/order-timer-template.php', array(
			'buyer_arbitration'   => $buyer_arbitration,
			'expected'            => $expected,
			'order'               => $order,
			'instant'             => $instant,
			'rtl_clock_dir_class' => $rtl_clock_dir_class,
			'class_arr'           => $class_arr,
			'short_class_arr'     => $short_class_arr,
			'interval_arr'        => $interval_arr,
			'show_timer'          => $show_timer
		) );
	}
}

if ( ! function_exists( 'wpj_display_order_job_price' ) ) {
	function wpj_display_order_job_price( $order = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		if ( $order ) {
			wpj_get_template( 'elements/order/order-job-price-template.php', array( 'order' => $order ) );
		}
	}
}

if ( ! function_exists( 'wpj_display_order_custom_extras_list' ) ) {
	function wpj_display_order_custom_extras_list( $order = '', $include_ul = false, $ul_class = '', $li_class = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		if ( $order ) {

			$custom_extra_data = array();
			$custom_extras     = json_decode( $order->custom_extras );
			if ( $custom_extras ) { $i = -1;

				foreach ( $custom_extras as $custom_extra ) { $i++;

					if ( $custom_extra->paid ) {

						$row = wpj_get_custom_extra( $order->id, $i );

						if ( $row ) {

							$ce_description = $custom_extra->description;
							if ( wpj_get_option( 'wpjobster_enable_filters_for_transaction_page' ) == 'yes' ) {
								$ce_description = wpj_apply_filter_to_string( $ce_description, false, 'transactionpages' );
							}

							$custom_extra_data[] = array( 'custom_extra_id' => $i, 'amount' => $custom_extra->price, 'description' => $ce_description );

						}
					}
				}

			}

			wpj_get_template( 'elements/order/order-custom-extras-list-template.php', array(
				'order'             => $order,
				'custom_extra_data' => $custom_extra_data,
				'include_ul'        => $include_ul,
				'ul_class'          => $ul_class,
				'li_class'          => $li_class
			) );

		}
	}
}

if ( ! function_exists( 'wpj_display_order_tips_list' ) ) {
	function wpj_display_order_tips_list( $order = '', $include_ul = false, $ul_class = '', $li_class = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		if ( $order ) {

			$tips_data            = array();
			$tips                 = json_decode( $order->tips );
			if ( $tips ) { $i = -1;

				foreach ( $tips as $tip ) { $i++;

					if ( $tip->paid ) {

						$row = wpj_get_tip( $order->id, $i );

						if ( $row ) {

							$reason = $tip->reason;
							if ( wpj_get_option( 'wpjobster_enable_filters_for_transaction_page' ) == 'yes' ) {
								$reason = wpj_apply_filter_to_string( $reason, false, 'transactionpages' );
							}

							$tips_data[] = array( 'amount' => $tip->amount, 'reason' => $reason );

						}
					}
				}

			}

			wpj_get_template( 'elements/order/order-tips-list-template.php', array(
				'order'      => $order,
				'tips_data'  => $tips_data,
				'include_ul' => $include_ul,
				'ul_class'   => $ul_class,
				'li_class'   => $li_class
			) );

		}
	}
}

if ( ! function_exists( 'wpj_display_order_buyer_instructions' ) ) {
	function wpj_display_order_buyer_instructions( $order = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		if ( $order ) {
			$job_instructions = '';
			if ( $order->job_instructions ) {
				$job_instructions = str_replace( array( '\r', '\n' ), array( "\r", "\n" ), $order->job_instructions );

			} elseif ( get_post_meta( $order->pid, 'instruction_box', true ) ) {
				$job_instructions = wpautop( strip_tags( get_post_meta( $order->pid, 'instruction_box', true ) ) );

			}

			if ( $job_instructions ) {
				if ( wpj_get_option( 'wpjobster_enable_filters_for_transaction_page' ) == 'yes' ) {
					$job_instructions = wpj_apply_filter_to_string( $job_instructions, true, 'transactionpages' );
				}
			}

			wpj_get_template( 'elements/order/order-buyer-instructions-template.php', array(
				'order'            => $order,
				'job_instructions' => $job_instructions
			) );
		}
	}
}

if ( ! function_exists( 'wpj_display_order_instant_delivery_files' ) ) {
	function wpj_display_order_instant_delivery_files( $order = '' ) {
		global $wpdb, $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		if ( $order ) {
			wpj_get_template( 'elements/order/order-instant-delivery-files-template.php', array(
				'order'                        => $order,
				'instant_attachments'          => $wpdb->get_row( $wpdb->prepare( "SELECT DISTINCT * FROM {$wpdb->prefix}posts WHERE post_parent = %d", $order->pid ) ),
				'instant_delivery_attachments' => get_post_meta( $order->pid, 'job_any_attachments', true ),
			) );
		}
	}
}

if ( ! function_exists( 'wpj_display_order_custom_offer_description' ) ) {
	function wpj_display_order_custom_offer_description( $order = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		if ( $order ) {
			$custom_offer_description = '';
			if ( $order->job_description )
				$custom_offer_description = str_replace( array( '\r', '\n' ), array( "\r", "\n" ), $order->job_description );

			if ( $custom_offer_description ) {
				if ( wpj_get_option( 'wpjobster_enable_filters_for_transaction_page' ) == 'yes' ) {
					$custom_offer_description = wpj_apply_filter_to_string( $custom_offer_description, true, 'transactionpages' );
				}
			}

			wpj_get_template( 'elements/order/order-custom-offer-description-template.php', array(
				'order'                    => $order,
				'custom_offer_description' => $custom_offer_description
			) );
		}
	}
}

if ( ! function_exists( 'wpj_display_order_custom_fields' ) ) {
	function wpj_display_order_custom_fields( $order = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		if ( $order ) {
			$Custom_Fields = new WPJ_Custom_Fields( $order->pid, 'job' );

			wpj_get_template( 'elements/order/order-custom-fields-template.php', array(
				'order'         => $order,
				'Custom_Fields' => $Custom_Fields
			) );
		}

	}
}

if ( ! function_exists( 'wpj_display_order_date_made' ) ) {
	function wpj_display_order_date_made( $order = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		if ( $order ) {
			wpj_get_template( 'elements/order/order-date-made-template.php', array( 'order' => $order ) );
		}

	}
}

if ( ! function_exists( 'wpj_display_order_notification_messages' ) ) {
	function wpj_display_order_notification_messages( $order = '' ) {
		global $wpdb, $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		if ( $order ) {

			// Mark notification as read
			if ( get_current_user_id() != wpj_get_seller_id( $order ) )
				wpj_mark_notification_as_read_by_uid( get_current_user_id(), $order->id, 'buyer' );

			if ( get_current_user_id() == wpj_get_seller_id( $order ) )
				wpj_mark_notification_as_read_by_uid( get_current_user_id(), $order->id, 'seller' );

			// Mark order completed
			if ( $order ) {
				wpj_get_template( 'elements/order/order-notification-messages-template.php', array(
					'order'             => $order,
					'chatbox_row'       => $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT * FROM {$wpdb->prefix}job_chatbox WHERE oid = %d GROUP BY datemade, uid, content ORDER BY id ASC", $order->id ) ),
					'rating_oid_row'    => $wpdb->get_row( $wpdb->prepare( "SELECT DISTINCT * FROM {$wpdb->prefix}job_ratings WHERE orderid = %d", $order->id ) ),
					'custom_extras'     => json_decode( $order->custom_extras ),
					'buyer_arbitration' => isset( $arbitration->buyer_arbitration ) && $arbitration->buyer_arbitration == 1 ? true : false
				) );
			}

		}
	}
}

if ( ! function_exists( 'wpj_display_order_action_buttons' ) ) {
	function wpj_display_order_action_buttons( $args = array() ) {
		global $wp_query, $wpdb;

		$defaults = array(
			'order'                 => ! empty( $wp_query->query_vars['oid'] ) ? $wp_query->query_vars['oid'] : '',
			'buttons_only'          => false,
			'wrapper_class'         => '',
			'buttons_wrapper_class' => '',
			'button_accept_class'   => '',
			'button_deny_class'     => '',
			'button_abort_class'    => '',
			'button1_order'         => '',
			'button2_order'         => ''
		);

		$args = wp_parse_args( $args, $defaults );

		if ( ! is_object( $args['order'] ) ) $args['order'] = wpj_get_order( $args['order'] );

		if ( $args['order'] ) {
			$can_be_completed = true;
			$custom_extras_arr = wpj_get_custom_extras( $args['order']->id );
			if ( $custom_extras_arr ) {
				foreach ( $custom_extras_arr as $key => $ce_value ) {
					if ( $ce_value->payment_gateway_transaction_id == -1 ) {
						$can_be_completed = false;
					}
				}
			}

			$args['can_be_completed']   = $can_be_completed;
			$args['arbitration']        = wpj_get_arbitration_details_by_order_id( $args['order']->id );
			$args['modification_count'] = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT( * ) FROM {$wpdb->prefix}job_chatbox WHERE uid = -15 AND oid = %d", $args['order']->id ) );
			$args['buyer_level']        = wpj_get_user_feature_value( 'tips', 'tips', 'no', get_current_user_id() );
			$args['seller_level']       = wpj_get_user_feature_value( 'tips', 'tips', 'no', wpj_get_seller_id( $args['order'] ) );

			wpj_get_template( 'elements/order/order-action-buttons.php', $args );

		}
	}
}

if ( ! function_exists( 'wpj_display_order_feedback_form' ) ) {
	function wpj_display_order_feedback_form( $order = '' ) {
		global $wpdb, $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		if ( $order ) {
			$uid = get_current_user_id();

			$seller_id   = wpj_get_seller_id( $order );
			$seller_data = get_userdata( $seller_id );
			$seller_name = is_object( $seller_data ) ? wpj_get_user_display_type( $seller_id ) : __( 'Deleted User', 'wpjobster' );

			$buyer_feedback = $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT * FROM {$wpdb->prefix}job_chatbox WHERE oid = %d AND uid = '-18' ORDER BY id ASC", $order->id ) );

			$buyer_given_feedback = count( $buyer_feedback ) ? 1 : 0;

			$rating_row = '';
			if ( $uid != $seller_id && wpj_is_order_completed( $order ) == 1 && $order->done_seller == 1 ) { // buyer

				$rating_row = $wpdb->get_row( $wpdb->prepare( "SELECT DISTINCT * FROM {$wpdb->prefix}job_ratings WHERE awarded = 0 AND orderid = %d AND uid = %d", $order->id, $seller_id ) );

				$user_rated   = $seller_name;
				$user_sample  = 'buyer';
				$rating_class = 'buyer_rating';

			} elseif ( $uid == $seller_id && wpj_is_order_completed( $order ) == 1 && $order->done_seller == 1 && $buyer_given_feedback == 1 ) { // seller

				$rating_row = $wpdb->get_row( $wpdb->prepare( "SELECT DISTINCT * FROM {$wpdb->prefix}job_ratings WHERE awarded = '1' AND orderid = %d AND orderid NOT IN ( SELECT orderid FROM {$wpdb->prefix}job_ratings_by_seller WHERE orderid = %d )", $order->id, $order->id ) );

				$user_rated   = wpj_get_user_display_type( $order->uid );
				$user_sample  = 'seller';
				$rating_class = 'seller_rating';

			}

			if ( ! $rating_row ) {
				$user_rated   = '';
				$user_sample  = '';
				$rating_class = '';
			}

			$textarea_wrapper_classes = wpj_function_has_content( 'wpj_display_work_sample_carousel', array( $order->id, $user_sample ) ) ? 'thirteen wide' : '';

			wpj_get_template( 'elements/order/order-feedback-form-template.php', array(
				'order'                    => $order,
				'user_rated'               => $user_rated,
				'user_sample'              => $user_sample,
				'rating_class'             => $rating_class,
				'rating_row'               => $rating_row,
				'post_tags'                => get_the_tags( $order->pid ),
				'user_skills'              => get_user_meta( $seller_id, 'user_skills', true ),
				'textarea_wrapper_classes' => $textarea_wrapper_classes
			) );
		}

	}
}

if ( ! function_exists( 'wpj_display_order_message_form' ) ) {
	function wpj_display_order_message_form( $order = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		if ( $order ) {
			$arbitration = wpj_get_arbitration_details_by_order_id( $order->id );

			wpj_get_template( 'elements/order/order-message-form-template.php', array(
				'order'              => $order,
				'delivered'          => wpj_is_order_delivered( $order ),
				'completed'          => wpj_is_order_completed( $order ),
				'buyer_arbitration'  => isset( $arbitration->buyer_arbitration ) && $arbitration->buyer_arbitration == 1 ? true : false,
				'uid'                => get_current_user_id(),
				'seller_id'          => wpj_get_seller_id( $order ),
				'buyer_id'           => $order->uid,
				'qr_uid'             => get_current_user_id() == wpj_get_seller_id( $order ) ? $order->uid : wpj_get_seller_id( $order )
			) );
		}

	}
}

if ( ! function_exists( 'wpj_display_order_errors' ) ) {
	function wpj_display_order_errors( $payment_type = 'job_purchase', $error = '' ) {
		global $wp_query;

		if ( $payment_type == 'job_purchase' ) {
			$pid = isset( $wp_query->query_vars['jobid'] ) && $wp_query->query_vars['jobid'] ? $wp_query->query_vars['jobid'] : WPJ_Form::get( 'jobid', 0 );
			if ( ! $pid || $pid === 0 ) $pid = wpj_get_post_id();

			$post = get_post( $pid );

			$seller_id = $post->post_author;

			$amount = WPJ_Form::get( 'amount', 1 );

			$extras = explode( '|', WPJ_Form::get( 'extras' ) );
			if ( count( $extras ) <= 1 ) $extras = explode( '_', WPJ_Form::get( 'extras' ) );

			$extras_amounts = explode( '|', WPJ_Form::get( 'extras_amounts' ) );
			if ( count( $extras_amounts ) <= 1 ) $extras_amounts = explode( '_', WPJ_Form::get( 'extras_amounts' ) );

			$multiples = wpj_get_user_feature_status( 'wpjobster_enable_multiples', 'wpjobster_subscription_job_multiples_enabled' );

			if ( get_current_user_id() == $seller_id ) {
				$error = __( 'You cannot buy your own stuff.', 'wpjobster' );

			} elseif ( ( $multiples != 'yes' && $amount > 1 ) || ( ! ctype_digit( $amount ) && ! is_int( $amount ) ) || $amount < 1 ) {
				$error = __( 'The selected quantity is greater than the amount you are allowed or the quantity does not contain a number.', 'wpjobster' );

			} elseif ( $multiples == 'yes' && $amount > wpj_get_user_feature_value( 'jobmultiples', 'job_multiples', 1, $seller_id ) ) {
				$error = __( 'The selected quantity is greater than the amount you are allowed.', 'wpjobster' );

			} elseif ( count( $extras ) && count( $extras_amounts ) ) { $i = 0;
				foreach ( $extras as $extra ) {
					if ( $extra == 'f' ) {
						$extra_enabled   = get_post_meta( $pid, 'extra_fast_enabled', true );
						$extra_m_enabled = 1;

					} else if ( $extra == 'r' ) {
						$extra_enabled   = get_post_meta( $pid, 'extra_revision_enabled', true );
						$extra_m_enabled = get_post_meta( $pid, 'extra_revision_multiples_enabled', true );

					} else {
						$extra_enabled   = get_post_meta( $pid, 'extra' . $extra . '_extra_enabled', true );
						$extra_m_enabled = get_post_meta( $pid, 'extra' . $extra . '_enabled', true );

					}

					if ( ! empty( $extra ) ) {

						if ( $extra_enabled ) {

							if ( $multiples != 'yes' && $extras_amounts[$i] > 1 )
								$error = __( 'You are not allowed to use an amount greater than 1.', 'wpjobster' );

							if ( $multiples == 'yes' ) {
								if ( ! $extra_m_enabled && $extras_amounts[$i] > 1 )
									$error = __( 'You are not allowed to use an amount greater than 1.', 'wpjobster' );

								if ( $extras_amounts[$i] > wpj_get_user_feature_value( 'extramultiples', 'extra_multiples', 1, $seller_id ) )
									$error = __( 'The selected quantity is greater than the amount you are allowed.', 'wpjobster' );

							}
						}
					} $i++;
				}
			}
		}

		if ( $payment_type == 'feature' ) {
			$pid = isset( $wp_query->query_vars['jobid'] ) && $wp_query->query_vars['jobid'] ? $wp_query->query_vars['jobid'] : WPJ_Form::get( 'jobid', 0 );

			$feature_pages   = WPJ_Form::get( 'feature_pages', '' );
			$process_pending = WPJ_Form::get( 'process_pending', '' );

			// Get start and end date
			$h_start_date = wpj_get_featured_start_date( 'homepage', $pid );
			$h_date_start = WPJ_Form::get( 'h_date_start', '' );

			$c_start_date = wpj_get_featured_start_date( 'category', $pid );
			$c_date_start = WPJ_Form::get( 'c_date_start', '' );

			$s_start_date = wpj_get_featured_start_date( 'subcategory', $pid );
			$s_date_start = WPJ_Form::get( 's_date_start', '' );

			// Errors
			if ( ! $feature_pages && ! $process_pending ) {
				$error = __( 'Please select at least one page.', 'wpjobster' );

			} else if (
				( $h_start_date != $h_date_start && strpos( $feature_pages, 'h' ) !== false ) ||
				( $c_start_date != $c_date_start && strpos( $feature_pages, 'c' ) !== false ) ||
				( $s_start_date != $s_date_start && strpos( $feature_pages, 's' ) !== false )
			) {
				$error = __( 'The interval was changed in the meantime.', 'wpjobster' );

			} else {
				$price = 0;
				if ( strpos( $feature_pages ,'h' ) !== false )
					$price += wpj_get_option( 'wpjobster_featured_price_homepage' );
				if ( strpos( $feature_pages ,'c' ) !== false )
					$price += wpj_get_option( 'wpjobster_featured_price_category' );
				if ( strpos( $feature_pages ,'s' ) !== false )
					$price += wpj_get_option( 'wpjobster_featured_price_subcategory' );

				if ( WPJ_Form::get( 'pay_for_item' ) == 'credits' ) {
					if ( wpj_get_user_credit( get_current_user_id() ) < $price )
						$error = __( 'You don\'t have enough money in your balance. Choose one of the other payment methods.', 'wpjobster' );

				}

			}
		}

		if ( $payment_type == 'topup' ) {
			$package_id = WPJ_Form::get( 'package_id' );
			if ( ! is_numeric( $package_id ) || ( is_numeric( $package_id ) && $package_id < 0 ) )
				$error = __( 'Please select the package first.', 'wpjobster' );
		}

		if ( $payment_type == 'subscription' ) {
			$process_pending = WPJ_Form::get( 'process_pending' );

			if ( ! $process_pending && ( empty( WPJ_Form::get( 'sub_amount' ) ) || empty( 'sub_type' ) || empty( 'sub_level' ) ) )
				$error = __( 'Please select a plan.', 'wpjobster' );

			elseif ( wpj_get_option( 'wpjobster_subscription_eligibility_enabled' ) == 'yes' ) {
				$sub_eligibility = wpj_get_option( 'wpjobster_subscription_eligibility_amount_' . WPJ_Form::get( 'sub_level' ) );
				if ( wpj_number_format_special( get_user_meta( get_current_user_id(), 'user_total_earnings', true ), 2 ) < wpj_number_format_special( $sub_eligibility, 2 ) )
					$error = __( 'You are not eligible for this level.', 'wpjobster' );

			} elseif ( WPJ_Form::get( 'pay_for_item' ) == 'credits' && wpj_get_user_credit( get_current_user_id() ) < WPJ_Form::get( 'sub_amount' ) )
				$error = __( 'You do not have enough balance to purchase this subscription.', 'wpjobster' );

		}

		if ( ! empty( $error ) ) {
			wpj_get_template( 'elements/order/order-errors-template.php', array( 'error' => $error ) );
		}

		return false;

	}
}