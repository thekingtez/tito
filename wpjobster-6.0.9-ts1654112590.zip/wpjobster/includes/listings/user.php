<?php
if ( ! function_exists( 'wpj_display_users_list' ) ) {
	function wpj_display_users_list() {
		$users = new WPJ_Load_More_Queries(
			array(
				'query_type'        => 'users',
				'query_status'      => 'all',
				'function_name'     => 'wpj_display_user_info_item',
				'row_extra_classes' => 'ui four cards'
			)
		);

		wpj_get_template( 'listings/user/users-list-template.php', array(
			'users' => $users
		) );

		if ( wpj_is_ajax_call() ) wp_die();
	}
}