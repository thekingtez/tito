<?php
if ( ! function_exists( 'wpj_display_user_posted_jobs_list' ) ) {
	function wpj_display_user_posted_jobs_list( $tab = '' ) {

		$uid = get_current_user_id();

		if ( $tab == "active" ) {
			$meta_query   = array( 'key' => 'active', 'value' => '1', 'compare' => '=' );
			$post_status  = array( 'publish' );
			$no_jobs_text = __( 'No active jobs.', 'wpjobster' );

		} elseif ( $tab == "inactive" ) {
			$meta_query   = array( 'relation' => 'AND', array( 'key' => 'active', 'value' => '0', 'compare' => '=' ), array( 'key' => 'under_review', 'value' => '0', 'compare' => '=' ) );
			$post_status  = array( 'draft', 'publish' );
			$no_jobs_text = __( 'No inactive jobs.', 'wpjobster' );

		} elseif ( $tab == "under-review" ) {
			$meta_query   = array( 'key' => 'under_review', 'value' => '1', 'compare' => '=' );
			$post_status  = 'draft';
			$no_jobs_text = __( 'No pending review jobs.', 'wpjobster' );

		} elseif ( $tab == "rejected" ) {
			$post_status  = 'pending';
			$meta_query   = array();
			$no_jobs_text = __( 'No rejected jobs.', 'wpjobster' );

		} else {
			$meta_query   = array( 'key' => 'closed', 'value' => '0', 'compare' => '=' );
			$post_status  = array( 'draft', 'publish', 'pending' );
			$no_jobs_text = __( 'There are no jobs yet.', 'wpjobster' );

		}

		$jobs_list = new WPJ_Load_More_Posts(
			array(
				'post_type'       => 'job',
				'function_name'   => 'wpj_display_user_job_posts_list_item',
				'post_status'     => $post_status,
				'order_by'        => 'date',
				'order'           => 'DESC',
				'author'          => $uid,
				'meta_query'      => array( $meta_query ),
				'container_class' => 'my-account-job-listing'
			)
		);

		wpj_get_template( 'listings/job/user-posted-jobs-list-template.php', array(
			'job_data'     => $jobs_list,
			'tab'          => $tab,
			'no_jobs_text' => $no_jobs_text
		) );

	}
}

if ( ! function_exists( 'wpj_display_user_favorites_jobs_list' ) ) {
	function wpj_display_user_favorites_jobs_list() {

		if ( function_exists( 'upb_get_user_meta' ) ) {
			if ( upb_get_user_meta( upb_get_user_id() ) ) {
				$jobs_list = new WPJ_Load_More_Posts(
					array(
						'post_type'       => 'job',
						'post__in'        => upb_get_user_meta( upb_get_user_id() ),
						'function_name'   => 'wpj_display_user_job_favorites_list_item',
						'order_by'        => 'date',
						'order'           => 'DESC',
						'container_class' => 'my-account-job-listing'
					)
				);

			} else {
				$jobs_list = 'not_found';

			}

		} else {
			$jobs_list = 'not_allowed';

		}

		wpj_get_template( 'listings/job/user-favorites-jobs-list-template.php', array( 'job_data' => $jobs_list ) );

	}
}

if ( ! function_exists( 'wpj_display_job_posts_list' ) ) {
	function wpj_display_job_posts_list( $args = array() ) {

		$uid       = ! empty( $args['uid'] ) ? $args['uid'] : '';
		$load_type = ! empty( $args['load_type'] ) ? $args['load_type'] : 'button';
		$columns   = ! empty( $args['columns'] ) ? wpj_number_to_string( $args['columns'] ) : 'four';

		$query_args = array(
			'query_type'        => 'jobs',
			'query_status'      => 'all',
			'function_name'     => 'wpj_display_job_card_layout',
			'row_extra_classes' => 'ui ' . $columns . ' cards',
			'load_type'         => $load_type,
			'uid'               => $uid,
			'posts_per_page'    => ! empty( $args['jobs'] ) ? $args['jobs'] : wpj_get_option( 'posts_per_page' )
		);

		if ( ! empty( $args['post__not_in'] ) )
			$query_args['query_params']['post__not_in'] = array( $args['post__not_in'] );

		if ( ! empty( $args['category'] ) )
			$query_args['query_params']['category'] = $args['category'];

		if ( ! empty( $args['order'] ) )
			$query_args['query_params']['order'] = $args['order'];

		if ( isset( $args['featured'] ) && is_numeric( $args['featured'] ) )
			$query_args['query_params']['featured'] = $args['featured'];

		$posts = new WPJ_Load_More_Queries( $query_args );

		// Display posts
		wpj_get_template( 'listings/job/job-posts-list-template.php', array(
			'posts'     => $posts,
			'post_type' => 'job'
		) );

	}
}

if ( ! function_exists( 'wpj_display_latest_job_posts' ) ) {
	function wpj_display_latest_job_posts( $cols = 4, $load_type = 'load_more' ) {

		$meta_querya = array( array(
			'key'     => 'active',
			'value'   => "1",
			'compare' => '='
		) );

		$jobs_order = wpj_get_option( 'wpjobster_jobs_order' );

		if ( $jobs_order == 'new' ) {

			$orderby_featured     = array( 'meta_value' => 'ASC', 'date' => 'DESC' );
			$orderby_non_featured = array( 'date' => 'DESC' );

		} elseif ( $jobs_order == 'old' ) {

			$orderby_featured     = array( 'meta_value' => 'ASC', 'date' => 'ASC' );
			$orderby_non_featured = array( 'date' => 'ASC' );

		} else {

			$seed = WPJ_Form::cookie( 'homepage_random_seed' );
			if ( ! $seed ) {
				$seed = rand();
				setcookie( 'homepage_random_seed', $seed, time() + 900, '/' ); // 15 min
			}

			$orderby_featured     = array( 'meta_value' => 'ASC', "RAND( $seed )" => '' );
			$orderby_non_featured = array( "RAND( $seed )" => '' );

		}

		$posts_per_page  = wpj_get_option( 'posts_per_page' ) ? wpj_get_option( 'posts_per_page' ) : 12;

		$feature_enabled = wpj_get_option( 'wpjobster_featured_enable' );

		if ( $feature_enabled == 'yes' ) {

			$args = array(
				'post_status'    =>'publish',
				'paged'          => 1,
				'posts_per_page' => $posts_per_page,
				'post_type'      => 'job',
				'meta_query'     => $meta_querya ,
				'meta_key'       => 'home_featured_now',
				'orderby'        => $orderby_featured
			);

		} else {

			$args = array(
				'post_status'    =>'publish',
				'paged'          => 1,
				'posts_per_page' => $posts_per_page,
				'post_type'      => 'job',
				'meta_query'     => $meta_querya,
				'orderby'        => $orderby_non_featured
			);

		}

		if ( $cols == 3 ) {
			$jobs_list = new WPJ_Load_More_Posts( $args + array ( 'function_name' => 'wpj_display_job_card_layout', 'container_class' => 'ui three cards ', 'load_type' => $load_type ) );
		} else {
			$jobs_list = new WPJ_Load_More_Posts( $args + array ( 'function_name' => 'wpj_display_job_card_layout', 'container_class' => 'ui four cards', 'load_type' => $load_type ) );
		}

		wpj_get_template( 'listings/job/latest-jobs-list-template.php', array( 'jobs_list' => $jobs_list, 'load_type' => $load_type ) );

	}
}