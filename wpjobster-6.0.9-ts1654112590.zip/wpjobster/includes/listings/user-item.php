<?php
if ( ! function_exists( 'wpj_display_user_info_item' ) ) {
	function wpj_display_user_info_item( $user_data = '' ) { // search user style

		if ( ! is_object( $user_data ) )
			$user_data = get_userdata( $user_data );

		$uid = $user_data->ID;
		$cid = get_current_user_id();

		$completed_jobs = intval( wpj_get_sales_orders( $uid, 'completed' ) ) + intval( wpj_get_shopping_orders_count( $uid, 'completed' ) );

		$registered_data = strtotime( $user_data->user_registered ) > 0 ? wpj_seconds_to_words_joined( time() - strtotime( $user_data->user_registered ) ) : __( 'There is no record of the date!', 'wpjobster' );

		if ( wpj_get_option( 'wpjobster_enable_user_company' ) == 'yes' && get_user_meta( $uid, 'user_company', true ) ) {
			$user_company = '(' . get_user_meta( $uid, 'user_company', true ) . ')';

		} else {
			$user_company = '';

		}

		$personal_info = stripslashes( get_user_meta( $uid, 'description', true ) );

		if ( wpj_get_option( 'wpjobster_wysiwyg_for_profile' ) != 'yes' ) {
			$personal_info = stripslashes( $personal_info );
		} else {
			$personal_info = wpj_get_allowed_html_tags_for_wysiwyg( get_user_meta( $uid, 'description', true ) );
		}

		$personal_info = wpj_apply_filter_to_string( $personal_info, false, 'userprofiles' );

		$description = get_user_meta( $uid, 'description', true );
		if ( ! empty( $personal_info ) ) {
			$user_desc = wpj_truncate_html( $personal_info, 300 );

		} else if ( ! empty( $description ) ) {
			$user_desc = wpj_truncate_html( $description, 300 );

		} else {
			$user_desc = '';
		}

		$contact_section = apply_filters( 'hide_for_buyers', true, $uid );
		if ( $uid != $cid && ( $contact_section || wpj_users_have_conversations( $cid, $uid ) || wpj_users_have_transactions( $cid, $uid ) ) ) {
			$contact_url = wpj_get_pm_link( $user_data->user_login );

		} else {
			$contact_url = '';

		}

		wpj_get_template( 'listings/user-item/users-list-item-template.php', array(
			'uid'             => $uid,
			'user_data'       => $user_data,
			'completed_jobs'  => $completed_jobs,
			'registered_data' => $registered_data,
			'company'         => $user_company,
			'description'     => $user_desc,
			'contact_url'     => $contact_url
		) );

	}
}