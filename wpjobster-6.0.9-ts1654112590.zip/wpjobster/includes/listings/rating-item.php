<?php
if ( ! function_exists( 'wpj_display_ratings_to_award_item' ) ) {
	function wpj_display_ratings_to_award_item( $row ) {
		$post  = get_post( $row->pid );
		$title = isset( $post->post_title ) ? $post->post_title : '';

		wpj_get_template( 'listings/rating-item/ratings-to-award-list-item-template.php', array(
			'row'   => $row,
			'pid'   => $row->pid,
			'post'  => $post,
			'title' => $title
		) );
	}
}

if ( ! function_exists( 'wpj_display_ratings_pending_item' ) ) {
	function wpj_display_ratings_pending_item( $row ) {
		$post = get_post( $row->pid );
		$user = get_userdata( $row->uid );

		wpj_get_template( 'listings/rating-item/ratings-pending-list-item-template.php', array(
			'row'  => $row,
			'pid'  => $row->pid,
			'post' => $post,
			'user' => $user
		) );
	}
}

if ( ! function_exists( 'wpj_display_ratings_received_item' ) ) {
	function wpj_display_ratings_received_item( $row ) {
		$post = get_post( $row->pid );

		if ( get_current_user_id() == wpj_get_seller_id( $row ) ) {
			$buyer_info = get_user_by( 'id', $row->uid );

		} else {
			$buyer_info = get_user_by( 'id', wpj_get_seller_id( $row ) );

		}

		$buyer_slug = isset( $buyer_info->data->user_nicename ) ? $buyer_info->data->user_nicename : '';

		wpj_get_template( 'listings/rating-item/ratings-received-list-item-template.php', array(
			'row'        => $row,
			'pid'        => $row->pid,
			'post'       => $post,
			'buyer_info' => $buyer_info,
			'buyer_slug' => $buyer_slug
		) );
	}
}

if ( ! function_exists( 'wpj_display_job_reviews_item' ) ) {
	function wpj_display_job_reviews_item( $row ) {
		wpj_get_template( 'listings/rating-item/job-reviews-list-item-template.php', array(
			'row'  => $row,
			'pid'  => $row->pid,
			'uid'  => $row->uid,
			'user' => get_userdata( $row->uid )
		) );
	}
}

if ( ! function_exists( 'wpj_display_user_reviews_item' ) ) {
	function wpj_display_user_reviews_item( $row ) {
		$cid = get_current_user_id();

		global $wpdb;
		$custom_offer_result = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}job_pm WHERE initiator = %d AND custom_offer = %d", $cid, $row->pid ) );

		wpj_get_template( 'listings/rating-item/user-reviews-list-item-template.php', array(
			'row'                 => $row,
			'pid'                 => $row->pid,
			'uid'                 => $row->uid,
			'cid'                 => $cid,
			'user'                => get_userdata( apply_filters( 'wpj_user_review_author_filter', $row->uid, $cid, get_post( $row->pid ) ) ),
			'custom_offer_result' => $custom_offer_result
		) );
	}
}