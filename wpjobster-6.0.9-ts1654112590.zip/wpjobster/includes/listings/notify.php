<?php
if ( ! function_exists( 'wpj_display_notifications_list' ) ) {
	function wpj_display_notifications_list() {

		$notifications = new WPJ_Load_More_Queries(
			array(
				'query_type'    => 'notifications',
				'query_status'  => 'all',
				'function_name' => 'wpj_display_notification_item',
			)
		);

		wpj_get_template( 'listings/notify/notifications-list-template.php', array(
			'notifications_data' => $notifications
		) );

	}
}

if ( ! function_exists( 'wpj_display_messages_list' ) ) {
	function wpj_display_messages_list( $user1 = '', $user2 = '', $message_type = '', $display_location = '' ) {

		if ( ! $user1 )            $user1            = get_current_user_id();
		if ( ! $user2 )            $user2            = wpj_get_pm_interlocutor_from_url( 'id' );
		if ( ! $message_type )     $message_type     = 'all';
		if ( ! $display_location ) $display_location = 'pm';

		$messages = new WPJ_Load_More_Queries(
			array(
				'query_type'      => 'messages',
				'query_status'    => $message_type,
				'function_name'   => $display_location == 'chat' ? 'wpj_display_chat_message_item' : 'wpj_display_message_item',
				'function_params' => array( 'user1' => $user1, 'user2' => $user2 ),
				'uid'             => $user2,
				'load_type'       => 'icon'
			)
		);

		wpj_get_template( 'listings/notify/messages-list-template.php', array(
			'messages_data' => $messages
		) );

	}
}

if ( ! function_exists( 'wpj_display_users_conversation_list' ) ) {
	function wpj_display_users_conversation_list( $type = 'all' ) {

		wpj_get_template( 'listings/notify/users-conversation-list-template.php', array(
			'type'    => WPJ_Form::get( 'type', $type ),
			'results' => wpj_get_conversations_by_type( $type )
		) );

	}
}
