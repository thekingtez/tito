<?php /* Request */
if ( ! function_exists( 'wpj_init_request_modals' ) ) {
	function wpj_init_request_modals() {
		wpj_init_request_activate_modal();
		wpj_init_request_deactivate_modal();
		wpj_init_request_delete_modal();
	}
}

if ( ! function_exists( 'wpj_init_request_activate_modal' ) ) {
	function wpj_init_request_activate_modal() {
		wpj_get_template( 'modals/request/activate-template.php' );
	}
}

if ( ! function_exists( 'wpj_init_request_deactivate_modal' ) ) {
	function wpj_init_request_deactivate_modal() {
		wpj_get_template( 'modals/request/deactivate-template.php' );
	}
}

if ( ! function_exists( 'wpj_init_request_delete_modal' ) ) {
	function wpj_init_request_delete_modal() {
		wpj_get_template( 'modals/request/delete-template.php' );
	}
}