<?php
/* Vacation Mode */
if ( ! function_exists( 'wpj_init_vacation_mode_modal' ) ) {
	function wpj_init_vacation_mode_modal() {
		wpj_get_template( 'modals/user/vacation-template.php', array(
			'user_vacation' => wpj_get_user_vacation( get_current_user_id() )
		) );
	}
}

/* Quick Responses */
if ( ! function_exists( 'wpj_init_new_quick_response_modal' ) ) {
	function wpj_init_new_quick_response_modal( $uid = '' ) {
		wpj_get_template( 'modals/user/new-quick-response-template.php', array(
			'uid'      => $uid,
			'username' => wpj_get_user_display_type( $uid )
		) );
	}
}

if ( ! function_exists( 'wpj_init_delete_quick_responses_modal' ) ) {
	function wpj_init_delete_quick_responses_modal( $uid = '' ) {
		wpj_get_template( 'modals/user/delete-quick-responses-template.php', array(
			'uid' => $uid
		) );
	}
}

if ( ! function_exists( 'wpj_init_new_education_modal' ) ) {
	function wpj_init_new_education_modal( $indx = '' ) {
		$education_fields = array( 'school', 'degree', 'grade', 'study', 'activities', 'from', 'to', 'description', 'attachments' );

		if ( $indx || $indx === 0 ) {
			$education = get_user_meta( get_current_user_id(), 'user_educations', true );

			if ( $education ) {
				foreach ( $education_fields as $key => $val ) {
					$$val = isset( $education[$indx][$val] ) ? $education[$indx][$val] : '';
				}
			}

		}

		foreach ( $education_fields as $key => $val ) {
			$$val = isset( $$val ) ? $$val : '';
		}

		wpj_get_template( 'modals/user/new-education-template.php', array(
			'indx'        => $indx,
			'school'      => $school,
			'degree'      => $degree,
			'grade'       => $grade,
			'study'       => $study,
			'activities'  => $activities,
			'from'        => $from,
			'to'          => $to,
			'description' => $description,
			'attachments' => $attachments
		) );
	}
}

if ( ! function_exists( 'wpj_init_new_certification_modal' ) ) {
	function wpj_init_new_certification_modal( $indx = '' ) {
		$certification_fields = array( 'certification_name', 'certification_authority', 'license_number', 'from_year', 'to_year', 'from_month', 'to_month', 'certification_not_expire', 'certification_url' );

		if ( $indx || $indx === 0 ) {
			$certification = get_user_meta( get_current_user_id(), 'user_certifications', true );

			if ( $certification ) {
				foreach ( $certification_fields as $key => $val ) {
					$$val = isset( $certification[$indx][$val] ) ? $certification[$indx][$val] : '';
				}
			}

		}

		foreach ( $certification_fields as $key => $val ) {
			$$val = isset( $$val ) ? $$val : '';
		}

		wpj_get_template( 'modals/user/new-certification-template.php', array(
			'indx'                     => $indx,
			'certification_name'       => $certification_name,
			'certification_authority'  => $certification_authority,
			'license_number'           => $license_number,
			'from_year'                => $from_year,
			'to_year'                  => $to_year,
			'from_month'               => $from_month,
			'to_month'                 => $to_month,
			'certification_not_expire' => $certification_not_expire,
			'certification_url'        => $certification_url,
		) );
	}
}