<?php
if ( ! function_exists( 'wpj_init_order_modals' ) ) {
	function wpj_init_order_modals( $order = '' ) {
		global $wp_query;

		if ( ! $order && ! empty ( $wp_query->query_vars['oid'] ) ) $order = wpj_get_order( $wp_query->query_vars['oid'] );
		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		if ( $order ) {
			wpj_init_add_tips_modal( $order );
			wpj_init_request_arbitration_modal( $order );
			wpj_init_request_extended_delivery_modal( $order );
			wpj_init_request_modification_modal( $order );
			wpj_init_request_mutual_cancellation_modal( $order );
			wpj_init_resolution_center_modal( $order );
		}
	}
}

if ( ! function_exists( 'wpj_init_legend_modal' ) ) {
	function wpj_init_legend_modal( $page = '', $active_tab = '' ) {
		wpj_get_template( 'modals/order/legend-template.php', array(
			'statuses'   => wpj_get_post_status_legend( $page ),
			'page'       => $page,
			'active_tab' => $active_tab
		) );
	}
}

if ( ! function_exists( 'wpj_init_add_tips_modal' ) ) {
	function wpj_init_add_tips_modal( $order = '' ) {
		wpj_get_template( 'modals/order/add-tips-template.php', array(
			'order'   => $order,
			'orderid' => $order->id,
		) );
	}
}

if ( ! function_exists( 'wpj_init_request_arbitration_modal' ) ) {
	function wpj_init_request_arbitration_modal( $order = '' ) {
		wpj_get_template( 'modals/order/request-arbitration-template.php', array(
			'order'   => $order,
			'orderid' => $order->id,
		) );
	}
}

if ( ! function_exists( 'wpj_init_request_extended_delivery_modal' ) ) {
	function wpj_init_request_extended_delivery_modal( $order = '' ) {
		wpj_get_template( 'modals/order/request-extended-delivery-template.php', array(
			'order'   => $order,
			'orderid' => $order->id,
		) );
	}
}

if ( ! function_exists( 'wpj_init_request_modification_modal' ) ) {
	function wpj_init_request_modification_modal( $order = '' ) {
		wpj_get_template( 'modals/order/request-modification-template.php', array(
			'order'   => $order,
			'orderid' => $order->id,
		) );
	}
}

if ( ! function_exists( 'wpj_init_request_mutual_cancellation_modal' ) ) {
	function wpj_init_request_mutual_cancellation_modal( $order = '' ) {
		wpj_get_template( 'modals/order/request-mutual-cancellation-template.php', array(
			'order'   => $order,
			'orderid' => $order->id,
		) );
	}
}

if ( ! function_exists( 'wpj_init_resolution_center_modal' ) ) {
	function wpj_init_resolution_center_modal( $order = '' ) {
		global $wpdb;

		wpj_get_template( 'modals/order/resolution-center-template.php', array(
			'order'              => $order,
			'orderid'            => $order->id,
			'cancellation_count' => $wpdb->get_var( $wpdb->prepare( "SELECT COUNT( * ) FROM {$wpdb->prefix}job_chatbox WHERE ( uid = -8 OR uid = -9 ) AND oid = %d", $order->id ) )
		) );
	}
}