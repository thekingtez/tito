<?php /* Job */
if ( ! function_exists( 'wpj_init_job_modals' ) ) {
	function wpj_init_job_modals() {
		wpj_init_job_activate_all_modal();
		wpj_init_job_activate_modal();
		wpj_init_job_deactivate_all_modal();
		wpj_init_job_deactivate_modal();
		wpj_init_job_delete_all_modal();
		wpj_init_job_delete_modal();
		wpj_init_job_share_modal();
		wpj_init_vacation_mode_modal();
	}
}

if ( ! function_exists( 'wpj_init_job_activate_all_modal' ) ) {
	function wpj_init_job_activate_all_modal() {
		wpj_get_template( 'modals/job/activate-all-template.php' );
	}
}

if ( ! function_exists( 'wpj_init_job_activate_modal' ) ) {
	function wpj_init_job_activate_modal() {
		wpj_get_template( 'modals/job/activate-template.php' );
	}
}

if ( ! function_exists( 'wpj_init_job_deactivate_all_modal' ) ) {
	function wpj_init_job_deactivate_all_modal() {
		wpj_get_template( 'modals/job/deactivate-all-template.php' );
	}
}

if ( ! function_exists( 'wpj_init_job_deactivate_modal' ) ) {
	function wpj_init_job_deactivate_modal() {
		wpj_get_template( 'modals/job/deactivate-template.php' );
	}
}

if ( ! function_exists( 'wpj_init_job_delete_all_modal' ) ) {
	function wpj_init_job_delete_all_modal() {
		wpj_get_template( 'modals/job/delete-all-template.php' );
	}
}

if ( ! function_exists( 'wpj_init_job_delete_modal' ) ) {
	function wpj_init_job_delete_modal() {
		wpj_get_template( 'modals/job/delete-template.php' );
	}
}

if ( ! function_exists( 'wpj_init_job_share_modal' ) ) {
	function wpj_init_job_share_modal() {
		wpj_get_template( 'modals/job/share-template.php' );
	}
}