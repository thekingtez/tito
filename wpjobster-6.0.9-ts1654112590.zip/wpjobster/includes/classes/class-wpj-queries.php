<?php if ( ! class_exists( 'WPJ_Load_More_Queries' ) ) {

	class WPJ_Load_More_Queries {

		public function __construct( $args = array() ) {

			$defaults = array(
				'pid'               => '',
				'uid'               => '',
				'query_type'        => '',
				'query_status'      => '',
				'query_params'      => '',
				'function_name'     => '',
				'function_params'   => '',
				'posts_per_page'    => wpj_get_option( 'posts_per_page' ) ? wpj_get_option( 'posts_per_page' ) : 12,
				'row_extra_classes' => '',
				'load_type'         => 'button'
			);

			$args = wp_parse_args( $args, $defaults );

			$this->pid               = WPJ_Form::post( 'pid', $args['pid'] );
			$this->uid               = WPJ_Form::post( 'uid', $args['uid'] );
			$this->query_type        = WPJ_Form::post( 'query_type', $args['query_type'] );
			$this->query_status      = WPJ_Form::post( 'query_status', $args['query_status'] );
			$this->query_params      = WPJ_Form::post( 'query_params', $args['query_params'] );
			$this->function_name     = WPJ_Form::post( 'function_name', $args['function_name'] );
			$this->function_params   = WPJ_Form::post( 'function_params', $args['function_params'] );
			$this->posts_per_page    = WPJ_Form::post( 'posts_per_page', $args['posts_per_page'] );
			$this->row_extra_classes = WPJ_Form::post( 'row_extra_classes', $args['row_extra_classes'] );
			$this->load_type         = WPJ_Form::post( 'load_type', $args['load_type'] );

			if ( $this->load_type == 'slider' ) $this->posts_per_page = 36;

			$this->query = $this->get_query( array(
				'pid'          => $this->pid,
				'uid'          => $this->uid,
				'query_type'   => $this->query_type,
				'query_status' => $this->query_status,
				'query_params' => $this->query_params
			) );

			$this->r                = array();
			$this->total_results    = 0;
			$this->number_of_clicks = 0;

			global $wpdb;

			if ( $this->query && $this->function_name ) {
				$this->limit = $this->posts_per_page * ( WPJ_Form::post( 'page_nr', 1 ) - 1 );
				if ( $this->limit < 0 ) $this->limit = 0;

				if ( $this->query_type == 'messages' && $this->query_status == 'all' ) {
					$query = explode( 'DESC', $this->query );
					$this->query_limited = $query[0] . ' DESC LIMIT ' . $this->limit . ', ' . $this->posts_per_page . ' ' . $query[1];

				} else $this->query_limited = $this->query . " LIMIT " . $this->limit . ", " . $this->posts_per_page;

				$this->r = $wpdb->get_results( $this->query_limited );

				$this->total_results    = count( $wpdb->get_results( $this->query ) );
				$this->number_of_clicks = ceil( ( $this->total_results / $this->posts_per_page ) - 1 );
			}

			add_action( 'wp_ajax_nopriv_show_query_list_ajax', array( $this, 'show_list_ajax' ) );
			add_action( 'wp_ajax_show_query_list_ajax', array( $this, 'show_list_ajax' ) );
		}

		public static function init() {
			$class = __CLASS__;
			new $class( array() );
		}

		public function have_rows() {
			if ( $this->r ) return true;
			else return false;
		}

		public function show_list_item( $row ) {
			$function_params = $this->function_params;
			if ( $function_params ) array_unshift( $function_params, $row ); // add row to params
			else $function_params = array( $row );

			call_user_func_array( $this->function_name, $function_params );
		}

		public function show_chat_list_item() { $prev_datemade = $initiator = $user = 0; ?>

			<div class="multiple-messages-wrapper">

				<?php foreach ( $this->r as $row ) {

					if ( ( $prev_datemade > 0 && $row->datemade - $prev_datemade >= 30 ) || ( $row->initiator != $initiator || $row->user != $user ) ) { /* 30 seconds */ ?>

						</div><div class="multiple-messages-wrapper">

					<?php }

					$this->show_list_item( $row );

					$prev_datemade = $row->datemade; $initiator = $row->initiator; $user = $row->user;

				} ?>

			</div>

		<?php }

		public function show_list_ajax() {
			if ( $this->r ) {
				if ( $this->function_name == 'wpj_display_chat_message_item' ) $this->show_chat_list_item();
				else { foreach ( $this->r as $row ) { $this->show_list_item( $row ); } }
			}

			if ( wpj_is_ajax_call() ) wp_die();
		}

		public function show_list_fnc() {
			if ( $this->r ) {

				if ( $this->load_type == 'icon' && count( $this->r ) == $this->posts_per_page ) { ?>

					<div id="wpjobster-query-load-more-icon"
						class="load-more-icon wpj-load-more js-load-more-icon"
						data-click-nr="1"
						data-clicks="<?php echo $this->number_of_clicks; ?>"
						data-action="show_query_list_ajax"
						data-max="<?php echo $this->posts_per_page; ?>"
						data-pid="<?php echo $this->pid; ?>"
						data-uid="<?php echo $this->uid; ?>"
						data-querytype="<?php echo $this->query_type; ?>"
						data-querystatus="<?php echo $this->query_status; ?>"
						data-queryparams='<?php echo $this->query_params ? json_encode( $this->query_params ) : ''; ?>'
						data-functionname="<?php echo $this->function_name; ?>"
						data-functionparams='<?php echo $this->function_params ? json_encode( $this->function_params ) : ''; ?>'
						data-postsperpage="<?php echo $this->posts_per_page; ?>"
						data-rowextraclasses="<?php echo $this->row_extra_classes; ?>"
						data-loadtype="<?php echo $this->load_type; ?>"
					></div>

				<?php } ?>

				<div class="<?php echo $this->load_type == 'slider' ? 'jobs-carousel js-jobs-carousel owl-carousel owl-theme' : 'row special wpj-load-more-target cf ' . wpj_get_cards_layout_class() . ' ' . $this->row_extra_classes; ?>">

					<?php if ( $this->function_name == 'wpj_display_chat_message_item' ) $this->show_chat_list_item();
					else {
						foreach ( $this->r as $row ) {
							if ( $this->load_type == 'slider' ) { echo '<div class="item">'; }
								$this->show_list_item( $row );
							if ( $this->load_type == 'slider' ) { echo '</div>'; }
						}
					} ?>

				</div>

				<?php if ( $this->load_type == 'button' && $this->total_results > $this->posts_per_page ) { ?>

					<div class="div-center">
						<div id="wpjobster-query-load-more-button"
							class="load-more-button js-load-more-button wpj-load-more text-button<?php if ( wpj_get_option( 'wpjobster_enable_auto-load' ) == "yes" ) { echo ' auto-load'; } ?>"
							data-click-nr="1"
							data-clicks="<?php echo $this->number_of_clicks; ?>"
							data-action="show_query_list_ajax"
							data-max="<?php echo $this->posts_per_page; ?>"
							data-pid="<?php echo $this->pid; ?>"
							data-uid="<?php echo $this->uid; ?>"
							data-querytype="<?php echo $this->query_type; ?>"
							data-querystatus="<?php echo $this->query_status; ?>"
							data-queryparams='<?php echo $this->query_params ? json_encode( $this->query_params ) : ''; ?>'
							data-functionname="<?php echo $this->function_name; ?>"
							data-functionparams='<?php echo $this->function_params ? json_encode( $this->function_params ) : ''; ?>'
							data-postsperpage="<?php echo $this->posts_per_page; ?>"
							data-rowextraclasses="<?php echo $this->row_extra_classes; ?>"
							data-loadtype="<?php echo $this->load_type; ?>"
						><?php _e( "Load more", "wpjobster" ); ?></div>
					</div>

				<?php }

			}
		}

		public static function get_query( $args ) {
			global $wpdb;

			$defaults = array(
				'uid'          => false,
				'pid'          => false,
				'query_type'   => false,
				'query_status' => false,
				'query_params' => false
			);

			$args = wp_parse_args( $args, $defaults );

			$uid          = $args['uid'];
			$pid          = $args['pid'];
			$query_type   = $args['query_type'];
			$query_status = $args['query_status'];
			$query_params = $args['query_params'];

			if ( ! $pid ) $pid = get_the_ID();

			if ( ! $uid ) $uid = wpj_get_user_id();

			$query = false;

			if ( $query_type == 'jobs' && $query_status == 'all' ) $query = wpj_get_job_search_query( $args );

			elseif ( $query_type == 'users' && $query_status == 'all' ) $query = wpj_get_user_search_query();

			elseif ( $query_type == 'messages' ) {
				if ( $query_status == 'all' )
					$query = wpj_get_private_messages_by_users( $uid, get_current_user_id(), 'query' );

				elseif ( is_numeric( $query_status ) )
					$query = wpj_get_private_message_by_id( $query_status, 'query' );

				elseif ( $query_status == 'custom_offer' )
					$query = wpj_get_user_offers_received( $pid, get_current_user_id(), 'query' );

			}

			elseif ( $query_type == 'notifications' && $query_status == 'all' ) $query = wpj_get_notifications( array( 'limit' => 0, 'uid' => $uid ), 'query' );

			if ( $query_type == 'transactions' && $query_status == 'all' ) {
				$query = $wpdb->prepare(
					"
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_payment_transactions
					WHERE uid = %d
					GROUP BY datemade, rid
					ORDER BY id DESC
					",
					$uid
				);

			} elseif ( $query_type == 'payments' ) {
				if ( $query_status == 'pending' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.post_author = %d
							AND posts.ID = orders.pid
							AND orders.clearing_period = '2'
							AND orders.closed = '0'
						ORDER BY orders.id DESC
						",
						$uid
					);

				}

			} elseif ( $query_type == 'withdrawals' ) {
				if ( $query_status == 'pending' ) {
					$query = $wpdb->prepare(
						"
						SELECT * FROM {$wpdb->prefix}job_withdraw
						WHERE done = '0'
							AND uid = %d
						ORDER BY id DESC
						",
						$uid
					);

				}

			} elseif ( $query_type == 'reviews' ) {
				if ( $query_status == 'to_award' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *,
							ratings.id ratid
						FROM {$wpdb->prefix}job_ratings ratings,
							 {$wpdb->prefix}job_orders orders
						WHERE ratings.awarded = '0'
							AND orders.id = ratings.orderid
							AND orders.uid = %d
							AND orders.closed != 1
							AND orders.completed = 1
							AND orders.done_seller = 1
						ORDER BY ratid DESC
						",
						$uid
					);

				} elseif ( $query_status == 'to_receive' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *,
							ratings.id ratid
						FROM {$wpdb->prefix}job_ratings ratings,
							 {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.ID = orders.pid
							AND ratings.awarded = '0'
							AND orders.id = ratings.orderid
							AND posts.post_author = %d
							AND orders.closed != 1
						ORDER BY ratings.id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'received' ) {
					$query = $wpdb->prepare(
						"
						SELECT
							ratings.id ratid,
							ratings.orderid,
							ratings.grade,
							ratings.datemade,
							ratings.reason,
							ratings.awarded,
							ratings.uid,
							ratings.pid,
							ratings.sample
						FROM {$wpdb->prefix}job_ratings ratings,
							 {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.ID = orders.pid
							AND ratings.awarded = '1'
							AND orders.id = ratings.orderid
							AND posts.post_author = %d
						UNION
						SELECT
							ratings.id ratid,
							ratings.orderid,
							ratings.grade,
							ratings.datemade,
							ratings.reason,
							ratings.awarded,
							ratings.uid,
							ratings.pid,
							null
						FROM {$wpdb->prefix}job_ratings_by_seller ratings,
							 {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.ID = orders.pid
							AND ratings.awarded = '1'
							AND orders.id = ratings.orderid
							AND ratings.uid = %d
						ORDER BY datemade DESC
						",
						$uid, $uid
					);

				} elseif ( $query_status == 'job_reviews' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *, ratings.datemade datemade
						FROM {$wpdb->prefix}job_ratings ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
						WHERE posts.ID = orders.pid
						AND ( posts.ID = %d
								OR ratings.pid IN (
									SELECT custom_offer
									FROM {$wpdb->prefix}job_pm pm, {$wpdb->prefix}job_ratings jr
									WHERE associate_job_id = %d
									AND custom_offer = jr.pid
								)
							)
						AND ratings.awarded = '1'
						AND orders.id = ratings.orderid
						AND posts.post_author = %d
						ORDER BY datemade DESC
						",
						$pid, $pid, $uid
					);

				} elseif ( $query_status == 'user_reviews' ) {
					$ratings_table = apply_filters( 'wpj_seller_reviews_database_table_filter', $wpdb->prefix . 'job_ratings', $uid );

					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *, ratings.datemade datemade
						FROM {$ratings_table} ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
						WHERE posts.ID = orders.pid
						AND ratings.awarded = '1'
						AND orders.id = ratings.orderid
						AND posts.post_author = %d
						ORDER BY datemade DESC
						",
						$uid
					);

				}

			} elseif ( $query_type == 'sales' ) {
				if ( $query_status == 'active' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.post_author = %d
							AND posts.ID = orders.pid
							AND orders.done_seller = '0'
							AND orders.done_buyer = '0'
							AND orders.date_finished = '0'
							AND orders.closed = '0'
							AND payment_status != 'pending'
						ORDER BY orders.id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'pending-confirmation' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.post_author = %d
							AND posts.ID = orders.pid
							AND orders.done_seller = '0'
							AND orders.done_buyer = '0'
							AND orders.date_finished = '0'
							AND orders.closed = '0'
							AND orders.seller_confirmation = '0'
							AND orders.payment_status != 'pending'
						ORDER BY orders.id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'pending-payment' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.post_author = %d
							AND posts.ID = orders.pid
							AND orders.done_seller = '0'
							AND orders.done_buyer = '0'
							AND orders.date_finished = '0'
							AND orders.closed = '0'
							AND ( payment_status = 'pending'
								OR payment_status = 'processing' )
						ORDER BY orders.id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'delivered' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.post_author = %d
							AND posts.ID = orders.pid
							AND orders.done_seller = '1'
							AND orders.done_buyer = '0'
							AND orders.closed = '0'
						ORDER BY orders.id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'cancelled' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.post_author = %d
							AND posts.ID = orders.pid
							AND orders.closed = '1'
						ORDER BY orders.id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'completed' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE posts.post_author = %d
							AND posts.ID = orders.pid
							AND orders.done_seller = '1'
							AND orders.done_buyer = '1'
							AND orders.closed = '0'
						ORDER BY orders.id DESC
						",
						$uid
					);
				}

			} elseif ( $query_type == 'shopping' ) {
				if ( $query_status == 'active' ) {
					$query = $wpdb->prepare(
						"
						SELECT *
						FROM {$wpdb->prefix}job_orders
						WHERE uid = %d
							AND done_seller = '0'
							AND done_buyer = '0'
							AND date_finished = '0'
							AND closed = '0'
							AND payment_status != 'pending'
						ORDER BY id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'pending-confirmation' ) {
					$query = $wpdb->prepare(
						"
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders,
							 {$wpdb->prefix}posts posts
						WHERE orders.uid = %d
							AND posts.ID = orders.pid
							AND orders.done_seller = '0'
							AND orders.done_buyer = '0'
							AND orders.date_finished = '0'
							AND orders.closed = '0'
							AND orders.seller_confirmation = '0'
							AND orders.payment_status != 'pending'
						ORDER BY orders.id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'pending-payment' ) {
					$query = $wpdb->prepare(
						"
						SELECT *
						FROM {$wpdb->prefix}job_orders
						WHERE uid = %d
							AND done_seller = '0'
							AND done_buyer = '0'
							AND date_finished = '0'
							AND closed = '0'
							AND ( payment_status = 'pending'
								OR payment_status = 'processing' )
						ORDER BY id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'pending-review' ) {
					$query = $wpdb->prepare(
						"
						SELECT *
						FROM {$wpdb->prefix}job_orders
						WHERE uid = %d
							AND done_seller = '1'
							AND done_buyer = '0'
							AND closed = '0'
						ORDER BY id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'cancelled' ) {
					$query = $wpdb->prepare(
						"
						SELECT *
						FROM {$wpdb->prefix}job_orders
						WHERE uid = %d
							AND closed = '1'
						ORDER BY id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'completed' ) {
					$query = $wpdb->prepare(
						"
						SELECT *
						FROM {$wpdb->prefix}job_orders
						WHERE uid = %d
							AND completed = '1'
						ORDER BY id DESC
						",
						$uid
					);
				}

			} elseif ( $query_type == 'topup' ) {
				if ( $query_status == 'pending' ) {
					$query = $wpdb->prepare(
						"
						SELECT *
						FROM {$wpdb->prefix}job_topup_orders
						WHERE user_id = %d
							AND ( payment_status = 'pending'
								OR payment_status = 'processing' )
						ORDER BY id DESC
						",
						$uid
					);

				} elseif ( $query_status == 'completed' ) {
					$query = $wpdb->prepare(
						"
						SELECT *
						FROM {$wpdb->prefix}job_topup_orders
						WHERE user_id = %d
							AND payment_status = 'completed'
						ORDER BY id DESC
						",
						$uid
					);

				}

			}

			return apply_filters( 'wpj_sql_user_account_query_filter', $query, $query_type, $query_status, $uid );
		}

	}

}

add_action( 'init', array( 'WPJ_Load_More_Queries', 'init' ) );