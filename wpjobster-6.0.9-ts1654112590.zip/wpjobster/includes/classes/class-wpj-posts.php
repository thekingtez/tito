<?php if ( ! class_exists( 'WPJ_Load_More_Posts' ) ) {

	class WPJ_Load_More_Posts {

		public function __construct() {

			$this->post_type             = '';
			$this->page                  = '';
			$this->posts_per_page        = wpj_get_option( 'posts_per_page' ) ? wpj_get_option( 'posts_per_page' ) : 12;
			$this->post_status           = '';
			$this->orderby               = '';
			$this->order                 = '';
			$this->author                = '';
			$this->meta_query            = '';
			$this->meta_key              = '';
			$this->force_no_custom_order = '';
			$this->tax_query             = '';
			$this->year                  = '';
			$this->monthnum              = '';
			$this->tag                   = '';
			$this->term                  = '';
			$this->taxonomy              = '';
			$this->s                     = '';
			$this->container_class       = '';
			$this->load_type             = 'button';
			$this->params                = '';
			$this->current_page          = '';
			$this->post__in              = '';
			$this->post__not_in          = '';
			$this->search_args           = '';
			$this->function_name         = '';
			$this->category_name         = '';

			$this->arguments = func_get_args();

			if ( ! empty( $this->arguments ) ) {
				foreach ( $this->arguments[0] as $key => $property ) {
					$this->{$key} = $property;
				}
			}

			$this->args = array(
				'post_type'             => $this->post_type,
				'posts_per_page'        => $this->load_type == 'slider' ? -1 : $this->posts_per_page,
				'post_status'           => $this->post_status ? $this->post_status : 'publish',
				'orderby'               => $this->orderby,
				'order'                 => $this->order,
				'author'                => $this->author,
				'meta_query'            => $this->meta_query,
				'meta_key'              => $this->meta_key,
				'force_no_custom_order' => $this->force_no_custom_order,
				'tax_query'             => $this->tax_query,
				'year'                  => $this->year,
				'monthnum'              => $this->monthnum,
				'tag'                   => $this->tag,
				'term'                  => $this->term,
				'taxonomy'              => $this->taxonomy,
				's'                     => $this->s,
				'container_class'       => $this->container_class,
				'load_type'             => $this->load_type,
				'params'                => $this->params,
				'current_page'          => $this->current_page,
				'post__in'              => $this->post__in,
				'post__not_in'          => $this->post__not_in,
				'search_args'           => $this->search_args,
				'function_name'         => $this->function_name,
				'category_name'         => $this->category_name
			);

			$this->filters = new WPJ_Search_SQL_Filters( $this->args, $this->search_args, $this->post_type );

			$this->first_posts = false;

			add_action( 'wp_ajax_nopriv_show_list_ajax', array( $this, 'show_list_ajax' ) );
			add_action( 'wp_ajax_show_list_ajax',  array( $this, 'show_list_ajax' ) );
		}

		public static function init() {
			$arguments = isset( $_POST['args_encoded'] ) ? $_POST['args_encoded'] : '';

			$arg = array();

			if ( ! empty( $arguments[0] ) && is_array( $arguments[0] ) ) {
				foreach ( $arguments[0] as $key => $property ) {
					$arg[$key] = $property;
				}
			}

			$class = __CLASS__;
			new $class( $arg );
		}

		public function get_first_posts() {
			if ( $this->first_posts === false ) {
				$args = $this->args + array( 'paged' => 1 );

				$this->filters->add_search_filters();
				$the_query = new WP_Query( $args );
				$this->filters->remove_search_filters();

				$this->first_posts = $the_query;
			}

			return $this->first_posts;
		}

		public function have_rows() {
			$the_query = $this->get_first_posts();
			return $the_query->have_posts();
		}

		public function show_list_item() {
			if ( ! is_array( $this->params ) ) $this->params = array( $this->params );
			call_user_func_array( $this->function_name, $this->params );
		}

		public function show_list_ajax() {
			$page_nr = WPJ_Form::post( 'page_nr', 2 );
			$args    = $this->args + array( 'paged' => $page_nr );

			$this->filters->add_search_filters();
			$the_query = new WP_Query( $args );
			$this->filters->remove_search_filters();

			if ( $the_query->have_posts() ) {
				while ( $the_query->have_posts() ) {
					$the_query->the_post();
					$this->show_list_item();
				}

				wp_reset_query();
			}

			if ( wpj_is_ajax_call() ) { wp_die(); }
		}

		public function show_list_fnc() {

			$the_query = $this->get_first_posts();

			if ( $the_query->have_posts() ) {

				$class = $this->load_type == 'slider' ? 'jobs-carousel js-jobs-carousel owl-carousel owl-theme' : 'row wpj-load-more-target' . ' ' . wpj_get_cards_layout_class() . ' ' . $this->container_class;
				$id    = $this->load_type != 'slider' ? 'job_listings' : '';

				if ( is_page( wpj_get_option( 'wpjobster_user_profile_page_id' ) ) ) $page_type = 'data-querytype="user_profile"';
				elseif ( is_front_page() ) $page_type = 'data-querytype="homepage"';
				else $page_type = ''; ?>

				<div id="<?php echo $id; ?>" class="<?php echo $class; ?>">

					<?php while ( $the_query->have_posts() ) {
						if ( $this->load_type == 'slider' ) { echo '<div class="item">'; }
							$the_query->the_post();
							$this->show_list_item();
						if ( $this->load_type == 'slider' ) { echo '</div>'; }
					}

					wp_reset_query(); ?>

				</div>

				<?php if ( $the_query->max_num_pages > 1 ) { ?>

					<div class="div-center">

						<div id="wpjobster-post-load-more-button"
							class="load-more-button text-button js-load-more-button wpj-load-more z-index-bigger<?php if ( wpj_get_option( 'wpjobster_enable_auto-load' ) == "yes" ) { echo ' auto-load'; } ?>" <?php echo $page_type; ?>
							data-clicks="<?php echo $the_query->found_posts > 0 && $this->posts_per_page > 0 ? ceil( ( intval( $the_query->found_posts ) / intval( $this->posts_per_page ) ) - 1 ) : 0; ?>"
							data-click-nr="1"
							data-action="show_list_ajax"
							data-max="<?php echo $the_query->max_num_pages; ?>"
							data-functionname="<?php echo $this->function_name; ?>"
							data-class-args='<?php echo json_encode( $this->arguments ); ?>'
							data-postsperpage="<?php echo $this->posts_per_page; ?>"
						>

							<?php _e( "Load more", "wpjobster" ); ?>

						</div>

					</div>
					
				<?php }

			}

		}

	}
}

add_action( 'init', array( 'WPJ_Load_More_Posts', 'init' ) );