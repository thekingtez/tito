<?php
// Scan folders & files
if ( ! function_exists( 'wpj_get_folder_files' ) ) {
	function wpj_get_folder_files( $dir = '', $ret = [] ) {
		$dir = $dir == '' ? dirname( __FILE__ ) : $dir;
		$files = @scandir( $dir );

		if ( ! empty( $files ) ) {
			foreach ( $files as $key => $filename ) {
				$path = realpath( $dir . DIRECTORY_SEPARATOR . $filename );
				if ( ! is_dir( $path ) ) {
					$ret[] = $path;
				} else if ( $filename != "." && $filename != ".." ) {
					wpj_get_folder_files( $path, $ret );
				}
			}
		}

		return $ret;
	}
}

// Include asset file
if ( ! function_exists( 'wpj_include_assets' ) ) {
	function wpj_include_assets( $path = '', $uri = '', $type = 'css', $exclude_array = [], $in_footer = true ) {
		$files_arr   = wpj_get_folder_files( $path );
		$folder_name = pathinfo( $path, PATHINFO_FILENAME );

		if ( $files_arr ) {
			foreach ( $files_arr as $key => $file ) {
				$name     = pathinfo( $file, PATHINFO_FILENAME );
				$ext      = pathinfo( $file, PATHINFO_EXTENSION );

				if ( $name && $ext ) {
					if ( $type == 'js' && $ext == 'js' ) {
						wp_enqueue_script( 'wpj-' . $folder_name . '-' . $name . '-scripts', $uri . '/' . $name . '.js', array( 'jquery', 'underscore' ), wpjobster_VERSION, $in_footer );

					} elseif ( $type == 'css' && $ext == 'css' ) {
						if ( ! in_array( $name, $exclude_array ) ) {
							wp_enqueue_style( 'wpj-' . $folder_name . '-' . $name . '-stylesheet', $uri . '/' . $name . '.css', array(), wpjobster_VERSION );
						}

					}
				}
			}
		}
	}
}

// Init shortcodes
if ( ! function_exists( 'wpj_add_shortcode' ) ) {
	function wpj_add_shortcode( $tag, $func ) {
		if ( ! is_admin() ) {
			add_shortcode( $tag, $func );
		} else {
			return false;
		}
	}
}

// Init options
if ( ! function_exists( 'wpj_get_option' ) ) {
	function wpj_get_option( $option ) {
		$options = get_option( 'jobster_settings' );

		if ( class_exists( 'Redux' ) && isset( $options[$option] ) ) {
			$field = Redux::get_field( 'jobster_settings', $option );

			if ( isset( $field['type'] ) && $field['type'] == 'switch' && $options[$option] == '1' )
				return 'yes';

			elseif ( isset( $field['type'] ) && $field['type'] == 'switch' && ( $options[$option] == '0' || $options[$option] == '' ) )
				return 'no';

			else
				return $options[$option];
		}

		return get_option( $option );
	}
}

// Check options
if ( ! function_exists( 'wpj_bool_option' ) ) {
	function wpj_bool_option( $option, $default = false ) {
		// returns true and false for options set as "yes" and "no"
		// returns true and false for options set as "true" and "false", case insensitive
		// returns false for empty() which includes:
		// str "", FALSE, array(), NULL, str "0", int 0, float 0.0, empty $var

		$get_option = wpj_get_option( $option, $default );
		if ( strtolower( $get_option ) === 'no'
			|| strtolower( $get_option ) === 'false'
			|| empty( $get_option )
		) {
			return false;
		}

		return true;
	}
}