<?php
if ( ! function_exists( 'wpj_page_verify_email_fnc' ) ) {
	function wpj_page_verify_email_fnc() {

		wpj_process_email_verification();

		$email_status = wpj_get_email_verification_status();

		wpj_get_template( 'pages/verify/verify-email-template.php', array(
			'status'  => $email_status['status'],
			'title'   => $email_status['title'],
			'message' => $email_status['message']
		) );

	}
}

if ( ! function_exists( 'wpj_page_verify_phone_fnc' ) ) {
	function wpj_page_verify_phone_fnc() {

		wpj_process_phone_verification();

		$phone_status = wpj_get_phone_verification_status();

		wpj_get_template( 'pages/verify/verify-phone-template.php', array(
			'title'   => $phone_status['title'],
			'message' => $phone_status['message'],
			'status'  => $phone_status['status']
		) );

	}
}