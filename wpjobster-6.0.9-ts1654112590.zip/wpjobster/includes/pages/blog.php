<?php
if ( ! function_exists( 'wpj_page_blog_posts_fnc' ) ) {
	function wpj_page_blog_posts_fnc() {
		wpj_get_template( 'pages/blog/all-blogs-template.php' );
	}
}

if ( ! function_exists( 'wpj_page_news_posts_fnc' ) ) {
	function wpj_page_news_posts_fnc() {
		wpj_get_template( 'pages/blog/all-news-template.php' );
	}
}

if ( ! function_exists( 'wpj_page_single_blog_fnc' ) ) {
	function wpj_page_single_blog_fnc() {
		wpj_get_template( 'pages/blog/single-blog-template.php' );
	}
}

if ( ! function_exists( 'wpj_page_single_news_fnc' ) ) {
	function wpj_page_single_news_fnc() {
		wpj_get_template( 'pages/blog/single-news-template.php' );
	}
}