<?php

// Add header to login / register page
add_action( 'login_head', function() { get_header(); });

// Login validation
add_filter( 'wp_authenticate_user', 'wpj_page_login_validation', 10, 2 );
if ( ! function_exists( 'wpj_page_login_validation' ) ) {
	function wpj_page_login_validation( $user, $password ) {

		if (
			wpj_get_option( 'wpjobster_enable_user_reCaptcha' ) == 'yes'
			&& wpj_get_option( 'wpjobster_recaptcha_api_key' )
			&& wpj_get_option( 'wpjobster_recaptcha_api_secret' )
		) {

			if ( ! isset( $_POST['_wp_http_referer'] ) && ! isset( $_POST['bouncer_account_linking'] ) ) {

				$post = isset( $_POST["g-recaptcha-response"] ) ? $_POST["g-recaptcha-response"] : '';

				$parameters = array(
					'secret'   => wpj_get_option( 'wpjobster_recaptcha_api_secret' ),
					'response' => $post
				);

				$url = 'https://www.google.com/recaptcha/api/siteverify?' . http_build_query( $parameters );

				$response      = wpj_get_data_with_cURL( $url );
				$json_response = json_decode( $response, true );

				if ( isset( $json_response['error-codes'] ) && is_array( $json_response['error-codes'] ) )
					return new WP_Error( 'captcha_error', sprintf( __( '<strong>ERROR</strong>: %s', 'wpjobster' ), implode( ',', $json_response['error-codes'] ) ) );

				elseif ( $json_response['success'] == false )
					return new WP_Error( 'captcha_error', __( '<strong>ERROR</strong>: Please verify the captcha!', 'wpjobster' ) );

			}

		}

		if ( wpj_get_option( 'wpjobster_enable_user_2fa' ) == 'yes' ) {
			include_once get_template_directory() . '/vendor/google-authenticator/FixedBitNotation.php';
			include_once get_template_directory() . '/vendor/google-authenticator/GoogleAuthenticatorInterface.php';
			include_once get_template_directory() . '/vendor/google-authenticator/GoogleAuthenticator.php';
			include_once get_template_directory() . '/vendor/google-authenticator/GoogleQrUrl.php';
			include_once get_template_directory() . '/vendor/google-authenticator/RuntimeException.php';

			$g = new \Sonata\GoogleAuthenticator\GoogleAuthenticator();

			$secret = get_user_meta( preg_replace( "/[^0-9]/", "", wpj_get_user_ip() ), '2fa_secret_code', true );

			if ( $g->checkCode( $secret, $_POST['2fa_code'] ) ) {}
			else {
				return new WP_Error( '2fa_error', __( '<strong>ERROR</strong>: The verification code is invalid!', 'wpjobster' ) );
			}
		}


		return $user;
	}
}

// Login form
add_action( 'login_form', 'wpj_page_login_fnc' );
if ( ! function_exists( 'wpj_page_login_fnc' ) ) {
	function wpj_page_login_fnc() {

		wpj_get_template( 'pages/authentication/login-template.php' );

	}
}

// Register validation
add_filter( 'registration_errors', 'wpj_page_register_validation', 10, 3 );
if ( ! function_exists( 'wpj_page_register_validation' ) ) {
	function wpj_page_register_validation( $errors ) {

		// password
		if ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'register' ) {

			if ( $_POST['user_password'] == '' ) {
				$errors->add( 'empty_password', __( '<strong>ERROR</strong>: Please enter a password.', 'wpjobster' ) );

			} elseif ( $_POST['user_password'] != $_POST['user_confirm_password'] ) {
				$errors->add( 'confirm_password', __( '<strong>ERROR</strong>: Passwords do not match', 'wpjobster' ) );

			}

		}

		// phone number
		if ( wpj_get_option( 'wpjobster_enable_phone_number' ) == 'yes' && wpj_get_option( 'wpjobster_phone_number_mandatory' ) == 'yes' ) {
			global $wpdb;

			$user_meta_table = defined( 'CUSTOM_USER_META_TABLE' ) ? CUSTOM_USER_META_TABLE : $wpdb->prefix . 'usermeta';

			$results = $wpdb->get_results( "SELECT * FROM {$user_meta_table} WHERE meta_key = 'cell_number' AND meta_value = '{$_POST['cell_number']}'" );

			if ( $results ) {
				$errors->add( 'phone_exists', __( '<strong>ERROR</strong>: This phone number is already registered, please choose another one.', 'wpjobster' ) );

			} elseif ( ! $_POST['cell_number'] ) {
				$errors->add( 'empty_cell_number', __( '<strong>ERROR</strong>: Please enter phone number.', 'wpjobster' ) );

			}

		}

		// tos
		if ( wpj_get_option( 'wpjobster_register_tos_and_privacy' ) == 'checkbox' ) {

			if ( ! isset( $_POST['wpj_agree_tos_privacy'] ) ) {

				$errors->add( 'error_tos_privacy', __( '<strong>ERROR</strong>: Terms of Service and Privacy Policy agreement is required.', 'wpjobster' ) );

			}
		}

		// reCaptcha
		if ( isset( $_REQUEST['action'] ) && $_REQUEST['action'] == 'register' ) {

			if (
				wpj_get_option( 'wpjobster_enable_user_reCaptcha' ) == 'yes'
				&& wpj_get_option( 'wpjobster_recaptcha_api_key' )
				&& wpj_get_option( 'wpjobster_recaptcha_api_secret' )
			) {

				$parameters = array(
					'secret'   => wpj_get_option( 'wpjobster_recaptcha_api_secret' ),
					'response' => $_POST["g-recaptcha-response"]
				);

				$url = 'https://www.google.com/recaptcha/api/siteverify?' . http_build_query( $parameters );

				$response      = wpj_get_data_with_cURL( $url );
				$json_response = json_decode( $response, true );

				if ( isset( $json_response['error-codes'] ) && is_array( $json_response['error-codes'] ) )
					$errors->add( 'captcha_error', sprintf( __( '<strong>ERROR</strong>: %s', 'wpjobster' ), implode( ',', $json_response['error-codes'] ) ) );

				elseif ( $json_response['success'] == false )
					$errors->add( 'captcha_error', __( '<strong>ERROR</strong>: Please verify the captcha!', 'wpjobster' ) );

			}

		}

		return $errors;
	}
}

// Register form
add_action( 'register_form', 'wpj_page_register_fnc' );
if ( ! function_exists( 'wpj_page_register_fnc' ) ) {
	function wpj_page_register_fnc() {

		wpj_get_template( 'pages/authentication/register-template.php' );

	}
}

// Register form save
add_action( 'user_register', 'wpj_page_register_save' );
if ( ! function_exists( 'wpj_page_register_save' ) ) {
	function wpj_page_register_save( $user_id ) {

		if ( $user_id > 0 ) {

			wpj_save_user( $user_id );

		}
	}
}

// Add footer to login / register page
add_action( 'login_footer', function() { get_footer(); });