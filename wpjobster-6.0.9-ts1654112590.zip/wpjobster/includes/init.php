<?php
/**
 * WPJobster Engine Room.
 * This is where all Theme Functions runs.
 *
 * @package wpjobster
 */

// Setup
include_once get_template_directory() . '/includes/function.php';
include_once get_template_directory() . '/includes/setup.php';
include_once get_template_directory() . '/includes/hook.php';

// Gateways
include_once get_template_directory() . '/lib/gateways/init.php';

// Plugins
include_once get_template_directory() . '/lib/plugins/init.php';

// Mobile Detect
if ( ! class_exists( 'Mobile_Detect' ) ) include_once get_template_directory() . '/vendor/mobile-detect.php';

// Shortcodes
$shortcodes = wpj_get_folder_files( get_template_directory() . '/includes/shortcodes' );
foreach ( $shortcodes as $shortcode ) { include_once $shortcode; }

// Elements
$elements = wpj_get_folder_files( get_template_directory() . '/includes/elements' );
foreach ( $elements as $element ) { include_once $element; }

// Modals
$modals = wpj_get_folder_files( get_template_directory() . '/includes/modals' );
foreach ( $modals as $modal ) { include_once $modal; }

// Listings
$listings = wpj_get_folder_files( get_template_directory() . '/includes/listings' );
foreach ( $listings as $listing ) { include_once $listing; }

// Pages
$pages = wpj_get_folder_files( get_template_directory() . '/includes/pages' );
foreach ( $pages as $page ) { include_once $page; }

// Functions
$functions = wpj_get_folder_files( get_template_directory() . '/includes/functions' );
foreach ( $functions as $function ) { include_once $function; }

// Order Functions
$o_functions = wpj_get_folder_files( get_template_directory() . '/includes/functions/orders' );
foreach ( $o_functions as $o_function ) { include_once $o_function; }

// Classes
$classes = wpj_get_folder_files( get_template_directory() . '/includes/classes' );
foreach ( $classes as $class ) { include_once $class; }

// Admin
include_once get_template_directory() . '/admin/admin-init.php';

// Flush rewrite rules for existing installations
add_action( 'init', function() {
	if ( ! wpj_get_option( 'theme_permalinks_flushed' ) ) {
		flush_rewrite_rules();
		update_option( 'theme_permalinks_flushed', 1 );
	}
}, 99 );