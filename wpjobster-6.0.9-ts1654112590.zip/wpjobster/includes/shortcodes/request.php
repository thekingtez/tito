<?php /* REQUEST */

wpj_add_shortcode( 'request_notices',           function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_notices' );
});
wpj_add_shortcode( 'request_posts_list',        function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_posts_list' );
});
wpj_add_shortcode( 'request_search_posts',      function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_search_request_posts_list' );
});
wpj_add_shortcode( 'user_requests_number',      function( $atts = '' ) {
	$_atts = shortcode_atts( array( 'uid' => '', 'order_status' => '', 'return' => 'count' ), $atts );
	return '<span class="item-count">' . wpj_get_user_requests( $_atts['uid'], $_atts['order_status'], $_atts['return'] ) . '</span>';
});
wpj_add_shortcode( 'user_posted_requests_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_user_posted_requests_list', array( 'tab' => '' ) );
});

/* POST NEW */
wpj_add_shortcode( 'post_new_request_notices',  function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_post_new_notices' );
});

/* SINGLE REQUEST */

wpj_add_shortcode( 'request_description',       function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_description', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_budget',            function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_budget', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_delivery',          function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_delivery_days_number', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_deadline',          function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_deadline', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_tags',              function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_tags', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_start_date',        function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_start_date', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_end_date',          function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_end_date', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_custom_fields',     function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_custom_fields', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_attachments',       function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_attachments', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_location',          function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_location', array( 'pid' => '', 'page' => '' ) );
});
wpj_add_shortcode( 'request_map',               function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_map', array( 'pid' => '', 'location_type' => '', 'location_display' => '' ) );
});
wpj_add_shortcode( 'request_pick_up_location',  function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_pick_up_location', array( 'pid' => '', 'page' => '' ) );
});
wpj_add_shortcode( 'request_drop_off_location', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_drop_off_location', array( 'pid' => '', 'page' => '' ) );
});
wpj_add_shortcode( 'request_category',          function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_category', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_post_date',         function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_post_date', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_offers',            function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_offer_list', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'request_or_offer_button',   function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_or_offer_button', array( 'pid' => '' ) );
});