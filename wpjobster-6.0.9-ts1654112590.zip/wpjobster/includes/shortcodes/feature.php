<?php /* FEATURE */

wpj_add_shortcode( 'featured_notices', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_featured_notices' );
});

wpj_add_shortcode( 'featured_homepage_row', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_featured_homepage_row' );
});

wpj_add_shortcode( 'featured_category_row', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_featured_category_row' );
});

wpj_add_shortcode( 'featured_subcategory_row', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_featured_subcategory_row' );
});