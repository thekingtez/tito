<?php /* TOPUP */

wpj_add_shortcode( 'topup_notices', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_topup_notices' );
});

wpj_add_shortcode( 'topup_payment_items_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_topup_payment_list' );
});

wpj_add_shortcode( 'topup_pending_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_topup_pending_list' );
});

wpj_add_shortcode( 'topup_completed_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_topup_completed_list' );
});

wpj_add_shortcode( 'topup_camouflaged_order', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_topup_camouflaged_order', array( 'oid' => '', 'with_link' => '' ) );
});

wpj_add_shortcode( 'topup_order_status', function( $atts = '' ) {
	return wpj_get_topup_order_details( 'order_status_lbl' );
});

wpj_add_shortcode( 'topup_payment_method', function( $atts = '' ) {
	return wpj_get_topup_order_details( 'payment_method' );
});

wpj_add_shortcode( 'topup_order_description', function( $atts = '' ) {
	return wpj_get_topup_order_details( 'order_status_desc' );
});