<?php /* JOB */

wpj_add_shortcode( 'job_categories_list',      function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_all_categories_and_subcategories' );
});
wpj_add_shortcode( 'job_popular_categories',   function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_popular_categories', array( 'taxonomy' => 'job_cat', 'number' => '6', 'display_title' => 'no' ) );
});
wpj_add_shortcode( 'recently_viewed_jobs',     function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_recently_viewed', array( 'uid' => '', 'display_title' => 'no' ) );
});
wpj_add_shortcode( 'recently_bought_job',      function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_recently_bought', array( 'uid' => '', 'display_title' => 'no' ) );
});
wpj_add_shortcode( 'job_posts_list',           function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_posts_list', array( 'args' => $atts ) );
});
wpj_add_shortcode( 'job_posts_list_3',         function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_latest_job_posts', array( 'cols' => 3, 'load_type' => 'button' ) );
});
wpj_add_shortcode( 'job_posts_list_4',         function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_latest_job_posts', array( 'cols' => 4, 'load_type' => 'button' ) );
});
wpj_add_shortcode( 'user_jobs_number',         function( $atts = '' ) {
	$_atts = shortcode_atts( array( 'uid' => '', 'order_status' => '' ), $atts );
	return  '<span class="item-count">' . wpj_get_user_jobs_count( $_atts['uid'], $_atts['order_status'] ) . '</span>';
});
wpj_add_shortcode( 'user_posted_jobs_list',    function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_user_posted_jobs_list', array( 'tab' => '' ) );
});
wpj_add_shortcode( 'user_favorites_jobs_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_user_favorites_jobs_list' );
});
wpj_add_shortcode( 'job_bulk_action_button',   function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_bulk_action_button' );
});

/* POST NEW */
wpj_add_shortcode( 'post_new_job_notices',     function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_post_new_notices' );
});

/* SINGLE JOB */

wpj_add_shortcode( 'job_author',               function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_author', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_cover',                function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_cover_image', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_location',             function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_location', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_stars_number',         function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_rating_stars', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_reviews_number',       function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_reviews_number', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_queue_number',         function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_order_queue_number', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_delivery_days_number', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_delivery_days_number', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_social_share_panel',   function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_social_share_icons', array( 'include_favorites' => '' ) );
});
wpj_add_shortcode( 'job_description',          function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_description', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_instructions',         function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_buyer_instructions', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_faq',                  function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_faq', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_audio',                function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_audio', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_preview',              function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_preview', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_map',                  function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_map', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_package_table',        function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_packages_for_pc', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_package_tabs',         function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_packages_for_mobile', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_payment_form',         function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_order_form', array( 'pid' => '', 'display_location' => '', 'with_label' => '' ) );
});
wpj_add_shortcode( 'job_payment_buy_button',   function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_order_button', array( 'button_type' => '', 'pid' => '' ) );
});
wpj_add_shortcode( 'job_reviews',              function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_review_text' );
});
wpj_add_shortcode( 'job_suggested_list',       function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_suggested_jobs_list', array( 'pid' => '', 'author' => '' ) );
});
wpj_add_shortcode( 'job_custom_fields',        function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_custom_fields', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_package_sidebar',      function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_packages_for_sidebar', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_or_offer_button',      function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_or_offer_button', array( 'pid' => '', 'page' => 'single_job', 'location' => '' ) );
});
wpj_add_shortcode( 'job_user_icons',           function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_user_info_icons', array( 'uid' => '', 'filter' => '', 'pid' => '' ) );
});
wpj_add_shortcode( 'job_tags',                 function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_tags', array( 'pid' => '' ) );
});
wpj_add_shortcode( 'job_views',                function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_views', array( 'pid' => '', 'display_label' => false ) );
});