<?php /* BADGE */

wpj_add_shortcode( 'badge_notices', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_badge_notices' );
});

wpj_add_shortcode( 'badge_payment_items_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_badges_payment_list' );
});