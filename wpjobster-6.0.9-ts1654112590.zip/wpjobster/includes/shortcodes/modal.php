<?php /* MODAL */

wpj_add_shortcode( 'job_modals_init', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_init_job_modals' );
});

wpj_add_shortcode( 'request_modals_init', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_init_request_modals' );
});

wpj_add_shortcode( 'order_modals_init', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_init_order_modals', array( 'order' => '' ) );
});