<?php /* PROPOSAL */

wpj_add_shortcode( 'user_proposals_number', function( $atts = '' ) {
	$_atts = shortcode_atts( array( 'uid' => '', 'type' => '', 'return' => 'count' ), $atts );
	return '<span class="item-count">' . wpj_get_user_proposals( $_atts['uid'], $_atts['type'], $_atts['return'] ) . '</span>';
});

wpj_add_shortcode( 'user_proposals_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_proposals_list', array( 'type' => '' ) );
});

wpj_add_shortcode( 'custom_offer_button', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_custom_offer_button', array( 'args' => $atts ) );
});