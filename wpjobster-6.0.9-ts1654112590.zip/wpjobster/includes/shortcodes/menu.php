<?php /* MENU */

wpj_add_shortcode( 'menu', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_menu_by_name', array( 'name' => '', 'container' => '' ) );
});