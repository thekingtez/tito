<?php /* SUBSCRIPTION */

wpj_add_shortcode( 'subscription_notices', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_subscription_notices' );
});

wpj_add_shortcode( 'subscription_form_pc', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_subscription_features_table_for_pc', array( 'action_type' => '' ) );
});

wpj_add_shortcode( 'subscription_form_mobile', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_subscription_features_table_for_mobile', array( 'action_type' => '' ) );
});

wpj_add_shortcode( 'user_subscription_info', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_subscription_features_details' );
});

wpj_add_shortcode( 'subscription_schedule_details', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_subscription_schedule_details' );
});