<?php /* LINK */

wpj_add_shortcode( 'page_url', function( $atts = [] ) {
	$_atts = shortcode_atts( array( 'page_id' => '' ), $atts );
	return wpj_get_link_by_page_id_name( $_atts['page_id'] );
});

wpj_add_shortcode( 'user_url', function( $atts = [] ) {
	$_atts = shortcode_atts( array( 'user_id' => wpj_get_user_id() ), $atts );
	return wpj_get_user_profile_link( $_atts['user_id'] );
});