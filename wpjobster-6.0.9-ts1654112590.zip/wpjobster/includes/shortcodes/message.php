<?php /* MESSAGE */

wpj_add_shortcode( 'users_conversation_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_users_conversation_list', array( 'type' => ' right' ) );
});

wpj_add_shortcode( 'messages_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_messages_list', array( 'user1' => '', 'user2' => '', 'message_type' => 'all', 'display_location' => '' ) );
});

wpj_add_shortcode( 'message_settings', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_message_settings_options' );
});

wpj_add_shortcode( 'send_message_form', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_send_message_form' );
});