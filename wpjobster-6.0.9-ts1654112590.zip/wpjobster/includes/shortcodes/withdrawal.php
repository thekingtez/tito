<?php /* WITHDRAWAL */

wpj_add_shortcode( 'request_withdrawal_form', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_request_withdrawal_gateways_list' );
});