<?php /* POST */

wpj_add_shortcode( 'post_title', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_title', array( 'args' => $atts ) );
});

wpj_add_shortcode( 'post_category', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_post_category_name' );
});

wpj_add_shortcode( 'post_category_description', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_post_category_description' );
});

wpj_add_shortcode( 'post_category_url', function( $atts = [] ) {
	$_atts = shortcode_atts( array( 'category' => '', 'taxonomy' => 'job_cat' ), $atts );
	return wpj_get_category_link( $_atts['category'], $_atts['taxonomy'] );
});

wpj_add_shortcode( 'post_category_and_subcategory', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_post_category_and_subcategory', array( 'pid' => '', 'taxonomy' => '' ) );
});

wpj_add_shortcode( 'post_subcategories_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_subcategories_list_of_current_category', array( 'taxonomy_name' => '' ) );
});

wpj_add_shortcode( 'post_image', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_round_job_image', array( 'pid' => '', 'width' => '', 'height' => '' ) );
});

wpj_add_shortcode( 'post_layout_switcher', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_post_layout_switcher', array( 'classes' => 'grid-switch-relative' ) );
});

wpj_add_shortcode( 'post_sort_filter', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_post_sort_filter', array( 'args' => $atts ) );
});