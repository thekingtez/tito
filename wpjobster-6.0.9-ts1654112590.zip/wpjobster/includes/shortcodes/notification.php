<?php /* NOTIFICATION */

wpj_add_shortcode( 'user_notifications_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_notifications_list' );
});

wpj_add_shortcode( 'user_email_notifications_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_email_notification_list' );
});

wpj_add_shortcode( 'user_sms_notifications_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_sms_notification_list' );
});