<?php /* USER VERIFICATION */

wpj_add_shortcode( 'email_verification_notice', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_email_verification_notice' );
});

wpj_add_shortcode( 'phone_verification_notice', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_phone_verification_notice' );
});

wpj_add_shortcode( 'user_email_verification_status', function( $atts = '' ) {
	$_atts = shortcode_atts( array( 'item' => '' ), $atts );
	return wpj_get_email_verification_status( $_atts['item'] );
});

wpj_add_shortcode( 'user_phone_verification_status', function( $atts = '' ) {
	$_atts = shortcode_atts( array( 'item' => '' ), $atts );
	return wpj_get_phone_verification_status( $_atts['item'] );
});

wpj_add_shortcode( 'user_email_verification_process', function( $atts = '' ) {
	return wpj_process_email_verification();
});

wpj_add_shortcode( 'user_phone_verification_process', function( $atts = '' ) {
	return wpj_process_phone_verification();
});

wpj_add_shortcode( 'sms_verification_code_field', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_sms_code_field' );
});

wpj_add_shortcode( 'user_verification_redirect_button', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_user_verification_redirect_buttons' );
});