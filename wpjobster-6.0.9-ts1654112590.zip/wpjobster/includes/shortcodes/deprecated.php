<?php /* DEPRECATED */

wpj_add_shortcode( 'wpj_list_categories', function( $atts = '' ) {
	$attr = shortcode_atts( array( 'taxonomy' => 'job_cat', 'show_childs' => false, 'hide_empty' => false ), $atts );

	$args = array( 'taxonomy' => $attr['taxonomy'], 'orderby' => 'name', 'order' => 'ASC' );
	if ( ! $attr['show_childs'] ) $args['parent'] = 0;
	if ( ! $attr['hide_empty'] ) $args['hide_empty'] = 0;

	$cats = get_categories( $args );
	if ( $cats ) {
		$ret = '<ul>';
			foreach ( $cats as $cat ) {
				$ret .= '<li><a href="' . get_category_link( $cat->term_id ) . '">' . $cat->name . '</a></li>';
			}
		$ret .= '</ul>';

		return $ret;
	}

	return false;
});