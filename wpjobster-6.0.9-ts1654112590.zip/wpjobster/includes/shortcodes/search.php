<?php /* SEARCH */

wpj_add_shortcode( 'search_filters_vertical', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_site_search_form', array( 'post_type' => '', 'layout' => 'vertical' ) );
});

wpj_add_shortcode( 'search_filters_horizontal', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_site_search_form', array( 'post_type' => '', 'layout' => 'horizontal' ) );
});

wpj_add_shortcode( 'search_bar_without_button', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_autosuggest_search_without_button', array( 'display_title' => 'no' ) );
});

wpj_add_shortcode( 'search_bar_with_button', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_autosuggest_search_with_button' );
});

wpj_add_shortcode( 'search_with_categories', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_search_with_categories' );
});