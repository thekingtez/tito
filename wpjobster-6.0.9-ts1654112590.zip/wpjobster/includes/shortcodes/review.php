<?php /* REVIEW */

wpj_add_shortcode( 'ratings_to_award_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_ratings_to_award_list' );
});

wpj_add_shortcode( 'ratings_pending_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_ratings_pending_list' );
});

wpj_add_shortcode( 'ratings_received_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_ratings_received_list' );
});