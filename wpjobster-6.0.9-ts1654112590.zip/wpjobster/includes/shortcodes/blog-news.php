<?php /* BLOG & NEWS */

wpj_add_shortcode( 'blog_post_image', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_post_image', array( 'pid' => '' ) );
});

wpj_add_shortcode( 'blog_post_title', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_post_title', array( 'pid' => '' ) );
});

wpj_add_shortcode( 'blog_post_date', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_post_date', array( 'pid' => '' ) );
});

wpj_add_shortcode( 'blog_post_categories', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_post_categories', array( 'pid' => '', 'taxonomy' => 'news_cat' ) );
});

wpj_add_shortcode( 'blog_post_description', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_post_content', array( 'pid' => '' ) );
});

wpj_add_shortcode( 'blog_post_tags', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_post_categories', array( 'pid' => '', 'taxonomy' => 'post_tag' ) );
});

wpj_add_shortcode( 'blog_post_share', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_post_share' );
});

wpj_add_shortcode( 'blog_post_comment_form', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_post_comment_form' );
});

wpj_add_shortcode( 'blog_post_comments_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_post_comments' );
});

wpj_add_shortcode( 'blog_search_form', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_search_form', array( 'post_type' => '' ) );
});

wpj_add_shortcode( 'blog_categories', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_categories', array( 'taxonomy' => '' ) );
});

wpj_add_shortcode( 'blog_tags', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_tags', array( 'tags' => '' ) );
});

wpj_add_shortcode( 'blog_posts_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_blog_posts_list' );
});

wpj_add_shortcode( 'news_posts_list', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_news_posts_list' );
});