<?php /* COUNT */

wpj_add_shortcode( 'user_ongoing_jobs', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_tooltip', array( 'args' => array( 'tooltip' => wpj_get_ongoing_jobs_count( 'tooltip' ), 'value' => wpj_get_ongoing_jobs_count( 'total' ) ) ) );
});

wpj_add_shortcode( 'user_completed_jobs', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_tooltip', array( 'args' => array( 'tooltip' => wpj_get_completed_jobs_count( 'tooltip' ), 'value' => wpj_get_completed_jobs_count( 'total' ) ) ) );
});

wpj_add_shortcode( 'user_cancelled_jobs', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_tooltip', array( 'args' => array( 'tooltip' => wpj_get_cancelled_jobs_count( 'tooltip' ), 'value' => wpj_get_cancelled_jobs_count( 'total' ) ) ) );
});

wpj_add_shortcode( 'user_posted_jobs', function( $atts = '' ) {
	return wpj_get_posted_jobs_count();
});

wpj_add_shortcode( 'user_ongoing_requests', function( $atts = '' ) {
	return wpj_get_ongoing_requests_count();
});

wpj_add_shortcode( 'user_completed_requests', function( $atts = '' ) {
	return wpj_get_completed_requests_count();
});

wpj_add_shortcode( 'user_cancelled_requests', function( $atts = '' ) {
	return wpj_get_cancelled_requests_count();
});

wpj_add_shortcode( 'user_posted_requests', function( $atts = '' ) {
	return wpj_get_posted_requests_count();
});

wpj_add_shortcode( 'total_posted_jobs', function( $atts = '' ) {
	return wpj_get_total_posted_jobs();
});

wpj_add_shortcode( 'total_posted_requests', function( $atts = '' ) {
	return wpj_get_total_posted_requests();
});

wpj_add_shortcode( 'total_amount_spent', function( $atts = [] ) {
	$_atts = shortcode_atts( array( 'by_user' => '' ), $atts );
	return wpj_get_total_amount_spent( $_atts['by_user'] );
});

wpj_add_shortcode( 'total_completed_jobs', function( $atts = [] ) {
	$_atts = shortcode_atts( array( 'by_user' => '' ), $atts );
	return wpj_get_total_completed_orders( $_atts['by_user'] );
});

wpj_add_shortcode( 'count_site_users', function( $atts = [] ) {
	$_atts = shortcode_atts( array( 'rated_type' => '', 'user_type' => '' ), $atts );
	return wpj_get_total_site_users( $_atts['rated_type'], $_atts['user_type'] );
});