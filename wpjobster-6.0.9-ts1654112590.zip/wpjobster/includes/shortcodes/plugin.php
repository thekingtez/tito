<?php /* PLUGIN */

if ( ! shortcode_exists( 'job_milestones' ) ) {
	wpj_add_shortcode( 'job_milestones', function( $atts = '' ) {
		return '<style>.job-milestones-row-wrapper{display:none;}</style>'; // for page builder
	});
}

if ( ! shortcode_exists( 'job_booking' ) ) {
	wpj_add_shortcode( 'job_booking', function( $atts = '' ) {
		return '<style>.job-booking-row-wrapper{display:none;}</style>'; // for page builder
	});
}