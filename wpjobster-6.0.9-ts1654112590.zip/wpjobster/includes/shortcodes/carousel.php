<?php /* CAROUSEL */

wpj_add_shortcode( 'posts_hero_carousel',      function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_posts_hero_slider', array( 'articles_no' => '', 'type' => '' ) );
});

wpj_add_shortcode( 'posts_carousel',           function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_posts_carousel', array( 'articles_no' => '', 'type' => '', 'posts_only_from_category' => '' ) );
});

wpj_add_shortcode( 'home_hero_carousel',       function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_home_hero_carousel' );
});

wpj_add_shortcode( 'job_simplified_carousel',  function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_simplified_carousel', array( 'dummy_content' => false ) );
});

wpj_add_shortcode( 'job_carousel',             function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_job_carousel', array( 'preview' => '', 'pid' => '' ) );
});

wpj_add_shortcode( 'category_icons_carousel',  function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_category_icons_carousel' );
});

wpj_add_shortcode( 'category_images_carousel', function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_category_images_carousel' );
});

wpj_add_shortcode( 'user_reviews_carousel',    function( $atts = '' ) {
	return wpj_fnc_to_shortcode( $atts, 'wpj_display_user_reviews_carousel' );
});