<?php
/* Lighter Ajax Process Execution
 * make sure we skip most of the loading which we might not need
 * http://core.trac.wordpress.org/browser/branches/3.4/wp-settings.php#L99
 */

define( 'DOING_AJAX', true );
define( 'SHORTINIT', true );

$absolute_path = __FILE__;
$path_to_file  = explode( 'wp-content', $absolute_path );
$path_to_wp    = $path_to_file[0];

require_once( $path_to_wp . 'wp-load.php' );

// Functions with very small requirements, to be used with shortinit
add_action( 'light_ajax_check_live_site_changes_action', 'wpj_check_site_changes' );
if ( ! function_exists( 'wpj_check_site_changes' ) ) {
	function wpj_check_site_changes() {
		$options = get_option( 'jobster_settings' );
		$enabled = $options['wpjobster_enable_live_notifications'];

		$notifications = get_user_meta( get_current_user_id(), 'notifications_number', true );
		$messages      = get_user_meta( get_current_user_id(), 'messages_number', true );

		$notification_info = get_user_meta( get_current_user_id(), 'notification_info', true );

		$response = array(
			'enabled'           => $enabled,
			'notifications'     => $notifications,
			'messages'          => $messages,
			'current_time'      => time(),
			'timeout'           => 2000,
			'max_timeout'       => 32000,
			'notification_info' => json_encode( $notification_info )
		);

		// update user last visit
		update_user_meta( get_current_user_id(), 'last_user_login', current_time( 'timestamp', 1 ) );

		// update user last IP
		if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) $ip = $_SERVER['HTTP_CLIENT_IP'];
		elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else $ip = $_SERVER['REMOTE_ADDR'];

		update_user_meta( get_current_user_id(), 'ip_reg', $ip );

		wp_send_json( $response );
		wp_die();
	}
}

require( ABSPATH . WPINC . '/capabilities.php' );

require( ABSPATH . WPINC . '/class-wp-roles.php' );
require( ABSPATH . WPINC . '/class-wp-role.php' );
require( ABSPATH . WPINC . '/class-wp-user.php' );

require( ABSPATH . WPINC . '/user.php' );

require_once( ABSPATH . WPINC . '/class-wp-session-tokens.php' );
require_once( ABSPATH . WPINC . '/class-wp-user-meta-session-tokens.php' );

require( ABSPATH . WPINC . '/kses.php' );
require( ABSPATH . WPINC . '/rest-api.php' );

// Define constants that rely on the API to obtain the default value.
// Define must-use plugin directory constants, which may be overridden in the sunrise.php drop-in.
wp_plugin_directory_constants();

if ( is_multisite() )
	ms_cookie_constants();

// Define constants after multisite is loaded.
wp_cookie_constants();

// Define and enforce our SSL constants
wp_ssl_constants();

// Create common globals.
require( ABSPATH . WPINC . '/vars.php' );

// Load pluggable functions.
require( ABSPATH . WPINC . '/pluggable.php' ); // is_user_logged_in

// Require an action parameter
if ( empty( $_REQUEST['action'] ) ) {
	die( '0' );
}

@header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
@header( 'X-Robots-Tag: noindex' );

send_nosniff_header();
nocache_headers();

if ( is_user_logged_in() ) {
	do_action( 'light_ajax_' . $_REQUEST['action'] );
} else {
	do_action( 'light_ajax_nopriv_' . $_REQUEST['action'] );
}

// Default status
die( '0' );