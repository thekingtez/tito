<?php
// Functions
if ( ! function_exists( 'wpj_get_post_status_legend' ) ) {
	function wpj_get_post_status_legend( $page ) {

		$job_page = array(
			array(
				'class'       => 'oe-green oe-full',
				'title'       => __( 'published', 'wpjobster' ),
				'description' => __( 'Your Job is visible and may be ordered by all users.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-yellow oe-full',
				'title'       => __( 'paused', 'wpjobster' ),
				'description' => __( 'No one can see your Job. You may reactivate it whenever you like.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-orange oe-full',
				'title'       => __( 'pending', 'wpjobster' ),
				'description' => __( 'Your Job is pending review and is not yet available.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red oe-full',
				'title'       => __( 'rejected', 'wpjobster' ),
				'description' => __( 'Your job failed to pass our review and is not visible to anyone.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-full',
				'title'       => __( 'disabled', 'wpjobster' ),
				'description' => __( 'Your job was automatically disabled.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-burgundy oe-full',
				'title'       => __( 'expired', 'wpjobster' ),
				'description' => __( 'Your job has expired.', 'wpjobster' )
			)
		);
		$job_page = apply_filters( 'wpj_job_page_status_filter', $job_page );

		$shopping_page = array(
			array(
				'class'       => 'oe-green oe-full',
				'title'       => __( 'active', 'wpjobster' ),
				'description' => __( 'The job is active and you wait for the seller to deliver.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-green',
				'title'       => __( 'active', 'wpjobster' ),
				'description' => __( 'The job is active and the seller is waiting for your answer.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-orange oe-full',
				'title'       => __( 'pending', 'wpjobster' ),
				'description' => __( 'The buyer has not yet made the payment.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-orange',
				'title'       => __( 'modification', 'wpjobster' ),
				'description' => __( 'You requested a modification of the current job.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red oe-full',
				'title'       => __( 'problem', 'wpjobster' ),
				'description' => __( 'You requested a cancellation for the transaction.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red',
				'title'       => __( 'problem', 'wpjobster' ),
				'description' => __( 'The seller requested a cancellation and you need to respond.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-green oe-full',
				'title'       => __( 'delivered', 'wpjobster' ),
				'description' => __( 'The job was delivered and you have to review it.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-green-txt',
				'title'       => __( 'completed', 'wpjobster' ),
				'description' => __( 'The transaction was completed and accepted by you.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red-txt',
				'title'       => __( 'cancelled', 'wpjobster' ),
				'description' => __( 'You and the seller agreed to cancel the transaction.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red oe-full',
				'title'       => __( 'failed', 'wpjobster' ),
				'description' => __( 'Buyer\'s payment was declined', 'wpjobster' )
			),
			array(
				'class'       => 'oe-burgundy',
				'title'       => __( 'expired', 'wpjobster' ),
				'description' => sprintf( __( 'More than %s days passed without the buyer paying', 'wpjobster' ), ( ! wpj_get_option( 'wpjobster_pending_jobs_days' ) && wpj_get_option( 'wpjobster_pending_jobs_days' ) == 0 ? 7 : wpj_get_option( 'wpjobster_pending_jobs_days' ) ) )
			)
		);
		$shopping_page = apply_filters( 'wpj_shopping_page_status_filter', $shopping_page );

		$sales_page = array(
			array(
				'class'       => 'oe-green oe-full',
				'title'       => __( 'active', 'wpjobster' ),
				'description' => __( 'The job is active and you wait for an answer from the buyer.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-green',
				'title'       => __( 'active', 'wpjobster' ),
				'description' => __( 'The job is active and the buyer is waiting for you to deliver.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-orange',
				'title'       => __( 'pending', 'wpjobster' ),
				'description' => __( 'The buyer has not yet made the payment.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-orange',
				'title'       => __( 'processing', 'wpjobster' ),
				'description' => __( 'The job has been paid and payment confirmation is awaited.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-orange',
				'title'       => __( 'modification', 'wpjobster' ),
				'description' => __( 'The buyer requested a modification and you need to deliver the job again.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red oe-full',
				'title'       => __( 'problem', 'wpjobster' ),
				'description' => __( 'You requested a cancellation for the current job.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red',
				'title'       => __( 'problem', 'wpjobster' ),
				'description' => __( 'The buyer requested a cancellation and you need to respond.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-green oe-full',
				'title'       => __( 'delivered', 'wpjobster' ),
				'description' => __( 'You delivered the job and wait for the buyer to accept.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-green-txt',
				'title'       => __( 'completed', 'wpjobster' ),
				'description' => __( 'The transaction was completed and accepted by the buyer.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red-txt',
				'title'       => __( 'cancelled', 'wpjobster' ),
				'description' => __( 'You and the buyer agreed to cancel the transaction.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red',
				'title'       => __( 'failed', 'wpjobster' ),
				'description' => __( 'Buyer\'s payment was declined', 'wpjobster' )
			),
			array(
				'class'       => 'oe-burgundy',
				'title'       => __( 'expired', 'wpjobster' ),
				'description' => sprintf( __( 'More than %s days passed without the buyer paying', 'wpjobster' ), ( ! wpj_get_option( 'wpjobster_pending_jobs_days' ) && wpj_get_option( 'wpjobster_pending_jobs_days' ) == 0 ? 7 : wpj_get_option( 'wpjobster_pending_jobs_days' ) ) )
			)
		);
		$sales_page = apply_filters( 'wpj_sales_page_status_filter', $sales_page );

		$request_page = array(
			array(
				'class'       => 'oe-green oe-full',
				'title'       => __( 'published', 'wpjobster' ),
				'description' => __( 'Your request is visible and can be taken by all users.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-yellow oe-full',
				'title'       => __( 'paused', 'wpjobster' ),
				'description' => __( 'No one can see your Request. You may reactivate it whenever you like.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-orange oe-full',
				'title'       => __( 'pending', 'wpjobster' ),
				'description' => __( 'Your request is pending review and is not yet available.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-red oe-full',
				'title'       => __( 'rejected', 'wpjobster' ),
				'description' => __( 'Your request failed to pass our review and is not visible to anyone.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-burgundy oe-full',
				'title'       => __( 'assigned', 'wpjobster' ),
				'description' => __( 'Your request is assigned to a seller.', 'wpjobster' )
			),
			array(
				'class'       => 'oe-green-txt',
				'title'       => __( 'completed', 'wpjobster' ),
				'description' => __( 'Your request was completed.', 'wpjobster' )
			)
		);
		$request_page = apply_filters( 'wpj_request_page_status_filter', $request_page );

		return ${$page . '_page'};

	}
}