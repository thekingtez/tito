<?php
if ( ! function_exists( 'wpj_get_user_authentication_links' ) ) {
	function wpj_get_user_authentication_links( $device = 'pc' ) {
		$buttons_list = array(
			'login' => array(
				'label'   => __( "Login", "wpjobster" ),
				'url'     => esc_url( wp_login_url() ),
				'a_class' => "login-link " . ( $device == 'mobile' ? 'item' : 'text-button text-button-simple' ),
			),
			'register' => array(
				'label'   => __( "Register", "wpjobster" ),
				'url'     => esc_url( wp_registration_url() ),
				'a_class' => "register-link " . ( $device == 'mobile' ? 'item' : 'text-button' ),
			),
		);

		$buttons_list = apply_filters( 'wpj_header_buttons_filter', $buttons_list );

		return $buttons_list;
	}
}

if ( ! function_exists( 'wpj_generate_user_empty_password' ) ) {
	function wpj_generate_user_empty_password() {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

		$characters_length = strlen( $characters );

		$generated_pass = '';
		for ( $i = 0; $i < 10; $i++ ) {
			$generated_pass .= $characters[rand( 0, $characters_length - 1 )];
		}

		$user_pass = WPJ_Form::post( 'user_password' );
		if ( ! $user_pass ) $user_pass = $generated_pass;

		return $user_pass;
	}
}

if ( ! function_exists( 'wpj_change_social_login_label' ) ) {
	function wpj_change_social_login_label( $provider_id, $provider_name, $authenticate_url ) {
		ob_start();

		wpj_display_social_login_field( $provider_id, $provider_name, $authenticate_url );

		$ret = ob_get_contents(); ob_clean();

		return $ret;
	}
}

if ( ! function_exists( 'wpj_add_recaptcha_field_to_aio' ) ) {
	function wpj_add_recaptcha_field_to_aio() {
		ob_start();

		wpj_display_recaptcha_field( 'aio_form' );

		wpj_display_2fa_field();

		$ret = ob_get_contents(); ob_clean();

		return $ret;
	}
}

if ( ! function_exists( 'wpj_validate_username' ) ) {
	function wpj_validate_username( $valid = '', $username = '' ) {
		if ( preg_match( "/\\s/", $username ) || preg_match( "/@/", $username ) ) {
			return $valid = false;
		}

		return $valid;
	}
}

if ( ! function_exists( 'wpj_set_fb_user_avatar' ) ) {
	function wpj_set_fb_user_avatar() {
		if ( function_exists( 'wsl_get_stored_hybridauth_user_profiles_by_user_id' ) ) {

			$current_user = wp_get_current_user();
			$uid          = $current_user->ID;
			$is_social    = wsl_get_stored_hybridauth_user_profiles_by_user_id( $uid );

			if ( $is_social ) {
				if ( $uid ) {
					$wsl_photo_updated = get_user_meta( $uid, 'wsl_photo_updated', true );
					if ( $wsl_photo_updated != 'done' ) {
						$avatar = get_user_meta( $uid, 'avatar', true );
						if ( $avatar == '' ) {
							$wsl_account = wsl_get_stored_hybridauth_user_profiles_by_user_id( $uid );
							if ( $wsl_account != '' ) {
								if ( isset( $wsl_account[0]->photourl ) ) {
									$wsl_avatar = $wsl_account[0]->photourl;
									update_user_meta( $uid, 'avatar', $wsl_avatar );
									update_user_meta( $uid, 'wsl_photo_updated', 'done' );
								}
							}
						}
					}
				}
			}
		}
	}
}

if ( ! function_exists( 'wpj_reset_password' ) ) {
	function wpj_reset_password( $message, $reset_key, $user_login, $user_data ) {
		$uid = $user_data->ID;

		$uz_email_user_forgot_password_enable = wpj_get_option( "uz_email_user_forgot_password_enable" );

		$password_reset_link = apply_filters( 'wpj_reset_password_link_filter', wp_login_url() . "?action=rp&key={$reset_key}&login=" . rawurlencode( $user_data->user_login ), $reset_key, $user_data->user_login );

		if ( $uz_email_user_forgot_password_enable != 'no' ) {
			wpj_notify_user_translated( 'user_forgot_password', $uid, array( '##password_reset_link##' => $password_reset_link, '##receiver_email##' => $user_data->user_email ) );
		} else {
			return $message;
		}
	}
}

if ( ! function_exists( 'wpj_replace_wp_error_messages' ) ) {
	function wpj_replace_wp_error_messages( $errors ) {
		if ( wpj_get_option( 'wpjobster_enable_login_hints' ) != 'no' )
			return $errors;
		else
			return __( 'The data entered is incorrect!', 'wpjobster' );
	}
}

if ( ! function_exists( 'wpj_deregister_load_style_php_style' ) ) {
	function wpj_deregister_load_style_php_style() {
		if ( $GLOBALS['pagenow'] === 'wp-login.php' )
			wp_deregister_style( 'login' );
	}
}

if ( ! function_exists( 'wpj_register_dashicons_style' ) ) {
	function wpj_register_dashicons_style() {
		if ( $GLOBALS['pagenow'] === 'wp-login.php' )
			wp_enqueue_style( 'dashicons' );
	}
}