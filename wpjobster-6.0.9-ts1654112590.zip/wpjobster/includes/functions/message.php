<?php

// GET //

/* Get private message by ID */
if ( ! function_exists( 'wpj_get_private_message_by_id' ) ) {
	function wpj_get_private_message_by_id( $id, $ret_type = 'row' ) {

		global $wpdb;

		$query = $wpdb->prepare( "SELECT DISTINCT * FROM {$wpdb->prefix}job_pm WHERE id = %d", $id );

		if ( $ret_type == 'query' ) $message = $query;
		else $message = $wpdb->get_row( $query );

		return $message;
	}
}

/* Get private messages by users */
if ( ! function_exists( 'wpj_get_private_messages_by_users' ) ) {
	function wpj_get_private_messages_by_users( $user1 = '', $user2 = '', $ret_type = 'row' ) {

		if ( ! $user1 ) $user1 = get_current_user_id();
		if ( ! $user2 ) $user2 = wpj_get_pm_interlocutor_from_url( 'id' );

		global $wpdb;

		$query = $wpdb->prepare(
			"
			SELECT *
			FROM (
				SELECT * FROM {$wpdb->prefix}job_pm
				WHERE (
					user = '%d' AND initiator = '%d' AND show_to_source = '1'
				)
				OR (
					initiator = '%d' AND user = '%d' AND show_to_destination = '1'
				)
				ORDER BY datemade DESC
			) AS t1 ORDER BY datemade ASC
			",
			$user1, $user2, $user1, $user2
		);

		if ( $ret_type == 'query' ) $message = $query;
		else $message = $wpdb->get_results( $query );

		return $message;
	}
}

/* Get message initiator by message id */
if ( ! function_exists( 'wpj_get_message_author_id' ) ) {
	function wpj_get_message_author_id( $message_id ) {
		if ( ! is_object( $message_id ) ) {
			$message = wpj_get_private_message_by_id( $message_id, 'row' );
		}

		return ! empty( $message->initiator ) ? $message->initiator : false;
	}
}

/* Get conversations query */
if ( ! function_exists( 'wpj_get_conversations_by_type' ) ) {
	function wpj_get_conversations_by_type( $type = 'all' ) {
		$type = WPJ_Form::get( 'type', $type );

		global $wpdb;

		$uid = get_current_user_id();

		if ( $type == 'archived' ) {
			$query = $wpdb->prepare(
				"
				SELECT id, other, content, datemade, author, rd, max_custom_offer, min_custom_offer
				FROM (
					SELECT id, other, content, MAX(datemade) AS datemade, author, rd, MAX(custom_offer) AS max_custom_offer, MIN(custom_offer) AS min_custom_offer, archived
					FROM (
						SELECT id, user AS other, initiator AS author, content, datemade, rd, custom_offer, archived_to_source AS archived
						FROM {$wpdb->prefix}job_pm
						WHERE initiator = %d AND show_to_source = '1'

						UNION

						SELECT id, initiator AS other, initiator AS author, content, datemade, rd, custom_offer, archived_to_destination AS archived
						FROM {$wpdb->prefix}job_pm
						WHERE user = %d AND show_to_destination = '1'
						ORDER BY datemade DESC
					) tmp
					GROUP BY other
					ORDER BY datemade DESC) tmp2
				WHERE archived = '1'
				",
				$uid, $uid
			);

		} elseif ( $type == 'archive' ) {
			$query = $wpdb->prepare(
				"
				SELECT * FROM (
					SELECT id, count( id ) as cnt, initiator, MAX(datemade) AS datemade, archived, content
					FROM (
						SELECT id, initiator AS initiator, datemade, content, archived_to_destination AS archived
						FROM {$wpdb->prefix}job_pm
						WHERE user = %d
							AND show_to_destination = '1'
							AND rd = '0'
						ORDER BY datemade DESC
						LIMIT 10
					) tmp
					GROUP BY initiator
					ORDER BY datemade DESC
				) tmp2
				WHERE archived = '0'
				",
				$uid
			);

		} else {
			$query = $wpdb->prepare(
				"
				SELECT id, other, content, datemade, author, rd, max_custom_offer, min_custom_offer
				FROM (
					SELECT id, other, content, MAX(datemade) AS datemade, author, rd, MAX(custom_offer) AS max_custom_offer, MIN(custom_offer) AS min_custom_offer, archived
					FROM (
						SELECT id, user AS other, initiator AS author, content, datemade, rd, custom_offer, archived_to_source AS archived
						FROM {$wpdb->prefix}job_pm
						WHERE initiator = %d AND show_to_source = '1'

						UNION

						SELECT id, initiator AS other, initiator AS author, content, datemade, rd, custom_offer, archived_to_destination AS archived
						FROM {$wpdb->prefix}job_pm
						WHERE user = %d AND show_to_destination = '1'

						ORDER BY datemade DESC
					) tmp
					GROUP BY other
					ORDER BY datemade DESC) tmp2
				WHERE archived = '0'
				",
				$uid, $uid
			);

		}

		return $wpdb->get_results( $query );
	}
}

/* Get count of unread messages by receiver ID */
if ( ! function_exists( 'wpj_get_unread_number_messages' ) ) {
	function wpj_get_unread_number_messages( $receiver_id = '' ) {
		global $wpdb;

		if ( ! $receiver_id ) { $receiver_id = get_current_user_id(); }

		$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_pm WHERE user = {$receiver_id} AND show_to_destination = '1' AND rd = '0' " );

		return count( $r );
	}
}

/* Get count of unread messages between two users */
if ( ! function_exists( 'wpj_get_unread_number_messages_from_user' ) ) {
	function wpj_get_unread_number_messages_from_user( $sender_id, $receiver_id = '' ) {
		global $wpdb;

		if ( ! $receiver_id ) { $receiver_id = get_current_user_id(); }

		$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_pm WHERE user = {$receiver_id} AND initiator = {$sender_id} AND show_to_source = '1' AND rd = '0'" );

		return count( $r );
	}
}

/* Get interlocutor from URL */
if ( ! function_exists( 'wpj_get_pm_interlocutor_from_url' ) ) {
	function wpj_get_pm_interlocutor_from_url( $ret_type = 'data' ) {
		global $wp_query;

		$interlocutor_id = $interlocutor_data = '';

		$url_user = isset( $wp_query->query_vars['pg'] ) ? urldecode( $wp_query->query_vars['pg'] ) : '';

		if ( isset( $_GET['username'] ) || isset( $_GET['user_id'] ) || $url_user ) {

			if ( isset( $_GET['username'] ) ) {
				$interlocutor_data = get_user_by( 'slug', WPJ_Form::get( 'username' ) );
				$interlocutor_id   = isset( $interlocutor_data->ID ) ? $interlocutor_data->ID : '';

			} elseif ( isset( $_GET['user_id'] ) ) {
				$interlocutor_id   = WPJ_Form::get( 'user_id' );
				$interlocutor_data = get_userdata( $interlocutor_id );

			} elseif ( $url_user ) {
				$interlocutor_data = get_user_by( 'slug', $url_user );
				$interlocutor_id   = isset( $interlocutor_data->ID ) ? $interlocutor_data->ID : '';

			}

		}

		if ( $ret_type == 'id' ) return $interlocutor_id;
		return $interlocutor_data;
	}
}

/* Get message job or request post */
if ( ! function_exists( 'wpj_get_message_post_id' ) ) {
	function wpj_get_message_post_id( $message ) {
		$message_with_title = explode( '\n', $message );

		if ( ! empty( $message_with_title[0] ) ) {

			$post = get_page_by_title( $message_with_title[0], OBJECT, 'request' );
			if ( ! $post ) $post = get_page_by_title( $message_with_title[0], OBJECT, 'job' );

			if ( $post && $post->post_status == 'publish' && ( $post->post_type == 'job' || $post->post_type == 'request' ) && get_post_meta( $post->ID, 'active', true ) == 1 && $post->post_name ) {
				unset( $message_with_title[0] );

				return array( 'id' => $post->ID, 'message' => implode( ' ', $message_with_title ) );
			}

		}

		return $message;
	}
}


// ACTION //

/* Mark message as read */
if ( ! function_exists( 'wpj_mark_pm_as_read' ) ) {
	function wpj_mark_pm_as_read( $message ) {
		if ( ! is_object( $message ) )
			$message = wpj_get_private_message_by_id( $message, 'row' );

		global $wpdb;

		$wpdb->query( $wpdb->prepare(
			"
			UPDATE {$wpdb->prefix}job_pm
			SET rd = %d, readdate = %d
			WHERE id = %d
			",
			1, current_time( 'timestamp', 1 ), $message->id
		) );

		if ( $message->rd != 1 ) wpj_refresh_user_notifications( $message->user, 'messages' );

		return;
	}
}

/* Archive conversation */
if ( ! function_exists( 'wpj_archive_conversation' ) ) {
	function wpj_archive_conversation( $user1 = '', $user2 = '' ) {

		if ( ! $user1 ) $user1 = get_current_user_id();
		if ( ! $user2 ) $user2 = WPJ_Form::post( 'interlocutor' );

		if ( ! is_demo_user() ) {

			global $wpdb;

			if ( ! wpj_users_have_conversations( $user2, $user1 ) ) {
				$wpdb->insert(
					$wpdb->prefix . 'job_pm',
					array(
						'content'             => 'Archived from chat',
						'datemade'            => current_time( 'timestamp', 1 ),
						'initiator'           => $user1,
						'user'                => $user2,
						'show_to_source'      => 0,
						'show_to_destination' => 0,
						'rd'                  => 1,
						'readdate'            => current_time( 'timestamp', 1 )
					),
					array( '%s', '%d', '%d', '%d', '%d', '%d', '%d', '%d' )
				);
			}

			$wpdb->query( "
				UPDATE {$wpdb->prefix}job_pm
				SET
					archived_to_source = CASE WHEN initiator = '{$user1}' THEN '1' ELSE archived_to_source END,
					archived_to_destination = CASE WHEN user = '{$user1}' THEN '1' ELSE archived_to_destination END
				WHERE ( initiator = '{$user1}' AND user = '{$user2}' )
				OR ( initiator = '{$user2}' AND user = '{$user1}' )
			" );

		}

		if ( wpj_is_ajax_call() ) wp_die();

	}
}

/* Unarchive conversation */
if ( ! function_exists( 'wpj_unarchive_conversation' ) ) {
	function wpj_unarchive_conversation( $user1 = '', $user2 = '' ) {

		if ( ! $user1 ) $user1 = get_current_user_id();
		if ( ! $user2 ) $user2 = WPJ_Form::post( 'interlocutor' );

		if ( ! is_demo_user() ) {
			global $wpdb;

			$wpdb->query( "
				UPDATE {$wpdb->prefix}job_pm
				SET
					archived_to_source = CASE WHEN initiator = '{$user1}' THEN '0' ELSE archived_to_source END,
					archived_to_destination = CASE WHEN user = '{$user1}' THEN '0' ELSE archived_to_destination END
				WHERE ( initiator = '{$user1}' AND user = '{$user2}' )
				OR ( initiator = '{$user2}' AND user = '{$user1}' )
			" );
		}

		if ( wpj_is_ajax_call() ) wp_die();

	}
}

/* Delete conversation */
if ( ! function_exists( 'wpj_delete_conversation' ) ) {
	function wpj_delete_conversation( $user1 = '', $user2 = '' ) {

		if ( ! $user1 ) $user1 = get_current_user_id();
		if ( ! $user2 ) $user2 = WPJ_Form::post( 'interlocutor' );

		if ( ! is_demo_user() ) {
			global $wpdb;

			$wpdb->query( "
				UPDATE {$wpdb->prefix}job_pm
				SET
					show_to_source = CASE WHEN initiator = '{$user1}' THEN '0' ELSE show_to_source END,
					show_to_destination = CASE WHEN user = '{$user1}' THEN '0' ELSE show_to_destination END
				WHERE ( initiator = '{$user1}' AND user = '{$user2}' )
				OR ( initiator = '{$user2}' AND user = '{$user1}' )
			" );

			wpj_refresh_user_notifications( $user1, 'messages' );
		}

		if ( wpj_is_ajax_call() ) wp_die();

	}
}

/* Delete message */
if ( ! function_exists( 'wpj_delete_message' ) ) {
	function wpj_delete_message( $user1 = '', $user2 = '', $message_id = '' ) {

		if ( ! $user1 )      $user1      = get_current_user_id();
		if ( ! $user2 )      $user2      = WPJ_Form::post( 'interlocutor' );
		if ( ! $message_id ) $message_id = WPJ_Form::post( 'message_id' );

		if ( ! is_demo_user() ) {

			global $wpdb;

			$row = $wpdb->get_row( "SELECT DISTINCT * FROM {$wpdb->prefix}job_pm WHERE id = '{$message_id}'" );

			if ( isset( $row->id ) ) {
				if ( $user1 == $row->initiator ) {
					$wpdb->query( "UPDATE {$wpdb->prefix}job_pm SET show_to_source = '0' WHERE id = '{$row->id}'" );

				} elseif ( $user1 == $row->user ) {
					$wpdb->query( "UPDATE {$wpdb->prefix}job_pm SET show_to_destination = '0' WHERE id = '{$row->id}'" );
					wpj_refresh_user_notifications( $row->user, 'messages' );

				}
			}

		}

		if ( wpj_is_ajax_call() ) wp_die();

	}
}

/* Send new message */
if ( ! function_exists( 'wpj_send_message' ) ) {
	function wpj_send_message() {

		if ( WPJ_Form::post( 'request_id' ) ) $post = get_post( WPJ_Form::post( 'request_id' ) );
		elseif ( WPJ_Form::post( 'job_id' ) ) $post = get_post( WPJ_Form::post( 'job_id' ) );

		$pm_message = ! empty( $post ) ? $post->post_title . '\n' . $_POST['message'] : $_POST['message'];

		if ( ! is_demo_user() ) {

			$this_pm = wpj_save_private_message( array(
				'content'      => trim( nl2br( strip_tags( htmlspecialchars( wpj_encode_emoji( $pm_message ) ) ) ) ),
				'datemade'     => current_time( 'timestamp', 1 ),
				'initiator'    => get_current_user_id(),
				'user'         => $_POST['otheruid'],
				'attached'     => WPJ_Form::post( 'upload' ),
				'img_attached' => WPJ_Form::post( 'img_upload' ),
			) );

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

/* Save message to database */
if ( ! function_exists( 'wpj_save_private_message' ) ) {
	function wpj_save_private_message( $args ) {

		global $wpdb;

		$defaults = array(
			'content'              => '',
			'datemade'             => current_time( 'timestamp', 1 ),
			'initiator'            => get_current_user_id(),
			'user'                 => 0,
			'attached'             => '',
			'img_attached'         => '',
			'custom_offer'         => 0,
			'associate_request_id' => 0,
			'associate_job_id'     => 0,
		);

		$args = wp_parse_args( $args, $defaults );

		$wpdb->query( $wpdb->prepare(
			"
			INSERT INTO {$wpdb->prefix}job_pm
				( content, datemade, initiator, user, attached, custom_offer, associate_request_id, associate_job_id, more_details )
			VALUES
				( %s, %d, %d, %d, %s, %d, %d, %d, %s )
			",
			$args['content'],
			$args['datemade'],
			$args['initiator'],
			$args['user'],
			$args['attached'],
			$args['custom_offer'],
			$args['associate_request_id'],
			$args['associate_job_id'],
			$args['img_attached']
		) );

		$this_pm = $wpdb->insert_id;

		wpj_update_user_notifications( array(
			'user1'       => $args['user'],
			'user2'       => $args['initiator'],
			'type'        => 'messages',
			'number'      => +1,
			'notify_id'   => $this_pm,
			'notify_type' => 'new_message',
			'order_id'    => $args['custom_offer']
		) );

		if ( $args['attached'] ) {
			$pm_files_array = explode( ',', $args['attached'] );
			if ( $pm_files_array ) {
				foreach ( $pm_files_array as $attachment ) {
					add_post_meta( $attachment, 'pm_id', $this_pm );

					if ( $args['custom_offer'] == -1 ) add_post_meta( $attachment, 'is_custom_offer', $this_pm );
					else add_post_meta( $attachment, 'is_private_message', $this_pm );
				}
			}
		}

		if ( $args['img_attached'] ) {
			$pm_images_array = explode( ',', $args['img_attached'] );
			if ( $pm_images_array ) {
				foreach ( $pm_images_array as $img_attachment ) {
					add_post_meta( $img_attachment, 'pm_id', $this_pm );

					if ( $args['custom_offer'] == -1 ) add_post_meta( $img_attachment, 'is_custom_offer', $this_pm );
					else add_post_meta( $img_attachment, 'is_private_message', $this_pm );
				}
			}
		}

		if ( $args['custom_offer'] == -1 ) $reason = 'new_request';
		elseif ( $args['custom_offer'] > 0 ) $reason = 'new_offer';
		else $reason = 'new_message';

		wpj_notify_user_translated( $reason, $args['user'], array(
			'##sender_username##'         => wpj_get_user_display_type( $args['initiator'] ),
			'##private_message_link##'    => wpj_get_pm_link( $args['initiator'] ),
			'##private_message_excerpt##' => wpj_apply_filter_to_string( stripslashes( wpj_trim( $args['content'], 55, '...' ) ), true, 'privatemessages' ),
			'##private_message_content##' => wpj_apply_filter_to_string( stripslashes( $args['content'] ), true, 'privatemessages' )
		) );

		do_action( 'wpj_after_pm_is_sent', $this_pm, 'messages' );

		return $this_pm;
	}
}

/* Save enter key option */
if ( ! function_exists( 'wpj_save_pm_enter_key' ) ) {
	function wpj_save_pm_enter_key() {
		if ( $_POST['value'] == 'true' ) update_user_meta( get_current_user_id(), 'pm_enter_key_enabled', 1 );
		else update_user_meta( get_current_user_id(), 'pm_enter_key_enabled', 0 );

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

/* Filter the message */
if ( ! function_exists( 'wpj_filter_message' ) ) {
	function wpj_filter_message( $message = '' ) {
		$message = WPJ_Form::post( 'message', $message );
		if ( $message ) {

			// get content message
			echo wpj_make_links_clickable( wpj_apply_filter_to_string( stripslashes( $message ), true, 'privatemessages' ) );

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}


// VERIFY //

/* Check if conversation is archived */
if ( ! function_exists( 'wpj_is_conversation_archived' ) ) {
	function wpj_is_conversation_archived( $user_id = '', $current_user_id = '' ) {
		if ( ! $current_user_id ) { $current_user_id = get_current_user_id(); }

		if ( ! $user_id ) { return false; }

		global $wpdb;
		$r = $wpdb->get_results( "
			SELECT *
			FROM {$wpdb->prefix}job_pm
			WHERE ( user = '{$user_id}' AND initiator = '{$current_user_id}' )
			OR ( initiator = '{$user_id}' AND user = '{$current_user_id}' )
		" );

		if ( isset( $r[0] ) && (
			( $r[0]->initiator == $current_user_id && $r[0]->archived_to_source == 1 ) ||
			( $r[0]->user == $current_user_id && $r[0]->archived_to_destination == 1 )
		) ) {
			return true;
		}

		return false;
	}
}

/* Check if two users have conversation */
if ( ! function_exists( 'wpj_users_have_conversations' ) ) {
	function wpj_users_have_conversations( $usr1, $usr2 ) {
		if ( $usr1 && $usr2 ) {
			global $wpdb;

			$r = $wpdb->get_results( "
				SELECT *
				FROM {$wpdb->prefix}job_pm
				WHERE ( user = '{$usr1}' AND initiator = '{$usr2}' )
				OR ( initiator = '{$usr1}' AND user = '{$usr2}' )
			" );

			if ( isset( $r[0] ) ) { return true; }
		}

		return false;
	}
}


// PAGE WRAPPER //

/* Add class to PM page by scren type */
if ( ! function_exists( 'wpj_add_pm_class_to_wrapper' ) ) {
	function wpj_add_pm_class_to_wrapper( $classes ) {
		if ( is_page( wpj_get_option( 'wpjobster_my_account_priv_mess_page_id' ) ) ) {
			$classes .= ' is-page-pm is-page-without-chat';
			if ( wpj_get_pm_interlocutor_from_url() ) $classes .= ' is-page-pm-single';
		}

		return $classes;
	}
}

/* Remove 'admin-bar' class from PM page */
if ( ! function_exists( 'wpj_remove_admin_bar_class_from_pm_page' ) ) {
	function wpj_remove_admin_bar_class_from_pm_page( $classes ) {
		if ( is_page( wpj_get_option( 'wpjobster_my_account_priv_mess_page_id' ) ) ) {
			$classes = array_diff( $classes, array( 'admin-bar' ) );
		}

		return $classes;
	}
}