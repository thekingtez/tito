<?php
if ( ! function_exists( 'wpj_add_chat_class_to_wrapper' ) ) {
	function wpj_add_chat_class_to_wrapper( $classes ) {
		if ( wpj_get_option( 'wpjobster_chat_enable' ) == 'yes' && is_user_logged_in() ) {

			global $jobster_design;

			$sidebar_status = isset( $_COOKIE['sidebar'] ) ? $_COOKIE['sidebar'] : 'maximized';

			if ( $jobster_design['chat_sidebar_style'] == 2 )
				return wpj_chat_get_users_list() && is_user_logged_in() ? 'is-chat-active is-sidebar-minimalist ' . $classes : $classes;

			if ( $sidebar_status == 'minimized' )
				return wpj_get_option( 'wpjobster_chat_enable' ) == 'yes' && is_user_logged_in() ? $classes . ' is-chat-active is-chat-minimized' : $classes;

			return wpj_get_option( 'wpjobster_chat_enable' ) == 'yes' && is_user_logged_in() ? $classes . ' is-chat-active is-chat-maximized' : $classes;

		}

		return $classes;
	}
}

if ( ! function_exists( 'wpj_init_chat_system_placeholder' ) ) {
	function wpj_init_chat_system_placeholder() {
		if ( wpj_get_option( 'wpjobster_chat_enable' ) == 'yes' && is_user_logged_in() ) {
			global $jobster_design;

			// Sidebar icon
			$icon = $jobster_design['chat_sidebar_icon_name'] == true ? $jobster_design['chat_sidebar_icon_name'] : 'comments';

			// Sidebar position
			$sidebar_status = isset( $_COOKIE['sidebar'] ) ? $_COOKIE['sidebar'] : 'maximized';

			wpj_display_chat_sidebar_placeholder( $sidebar_status, $icon );
		}
	}
}

if ( ! function_exists( 'wpj_init_chat_system' ) ) {
	function wpj_init_chat_system() {

		if ( wpj_get_option( 'wpjobster_chat_enable' ) == 'yes' && is_user_logged_in() ) {
			global $jobster_design;

			// Create users array
			$users = array();

			$users_list = wpj_chat_get_users_list();

			if ( $users_list ) {
				foreach ( $users_list as $user_id ) {
					$user_arr = get_userdata( $user_id );

					if ( $user_arr->last_user_login ) {
						$time_elapsed    = time() - ( $user_arr->last_user_login ?: 60000 );
						$time_difference = $time_elapsed / 60;
						$time_difference = (int)$time_difference;
					} else {
						$time_difference = '';
						$time_elapsed    = '';
					}

					$users[$user_arr->ID] = array(
						'ID'              => $user_arr->ID,
						'user_login'      => wpj_get_user_display_type( $user_arr->ID ),
						'user_nicename'   => $user_arr->user_nicename,
						'time_elapsed'    => $time_elapsed,
						'time_difference' => $time_difference,
						'unread_messages' => wpj_get_unread_number_messages_from_user( $user_arr->ID )
					);
				}
			}

			// Online users count
			$user_on_cnt = 0;
			if ( $users ) {
				foreach ( $users as $user ) {
					if ( $user['time_elapsed'] && $user['time_elapsed'] <= 359 ) {
						$user_on_cnt++;
					}
				}
			}

			// Sidebar icon
			$icon = $jobster_design['chat_sidebar_icon_name'] == true ? $jobster_design['chat_sidebar_icon_name'] : 'comments';

			// Sidebar position
			$sidebar_status = isset( $_COOKIE['sidebar'] ) ? $_COOKIE['sidebar'] : 'maximized';

			wpj_display_chat_sidebar( $users, $sidebar_status, $user_on_cnt, $icon );

			if ( wpj_is_ajax_call() ) wp_die();
		}
	}
}

if ( ! function_exists( 'wpj_chat_get_users_list' ) ) {
	function wpj_chat_get_users_list() {
		global $wpdb;

		$current_user_id = get_current_user_id();

		// Tangential users
		$tangential_users_sql = $wpdb->get_results( "
			SELECT orders.uid as user FROM {$wpdb->prefix}job_orders orders INNER JOIN {$wpdb->prefix}posts posts ON posts.iD = orders.pid WHERE posts.post_author = {$current_user_id} GROUP BY orders.uid

			UNION ALL

			SELECT posts.post_author as user FROM {$wpdb->prefix}posts posts INNER JOIN {$wpdb->prefix}job_orders orders ON posts.ID = orders.pid WHERE orders.uid = {$current_user_id} GROUP BY posts.post_author

			UNION ALL

			SELECT initiator as user FROM {$wpdb->prefix}job_pm WHERE user = {$current_user_id} GROUP BY initiator

			UNION ALL

			SELECT user as user FROM {$wpdb->prefix}job_pm WHERE initiator = {$current_user_id} GROUP BY user
		" );

		$tangential_users_arr = array();
		if ( $tangential_users_sql ) {
			foreach ( $tangential_users_sql as $key => $user ) {
				$user_arr = get_userdata( $user->user );
				if ( $user_arr ) {
					if ( isset( $user_arr->last_user_login ) ) {
						$tangential_users_arr[$user_arr->ID] = $user_arr->last_user_login;
					} else {
						$tangential_users_arr[$user_arr->ID] = $user_arr->ID;
					}
				}
			}
		}

		arsort( $tangential_users_arr ); // sort the array by last login

		$tangential_users = array_keys( $tangential_users_arr );

		// Return
		if ( wpj_get_option( 'wpjobster_all_users_to_sidebar' ) == 'yes' ) {

			// All users
			$all_users_arr = array();

			$user_table      = defined( 'CUSTOM_USER_TABLE' ) ? CUSTOM_USER_TABLE : $wpdb->prefix . 'users';
			$user_meta_table = defined( 'CUSTOM_USER_META_TABLE' ) ? CUSTOM_USER_META_TABLE : $wpdb->prefix . 'usermeta';

			$all_users_sql = $wpdb->get_results(
				$wpdb->prepare( "
					SELECT *
					FROM {$user_table} u, {$user_meta_table} um
					WHERE u.ID = um.user_id
						AND um.meta_key = 'last_user_login'
						AND u.ID != %d
					ORDER BY um.meta_value DESC
				", $current_user_id )
			);

			if ( $all_users_sql ) { $i = 0;
				foreach ( $all_users_sql as $key => $user ) {

					$user_arr = get_userdata( $user->ID );
					if ( $user_arr && $i < 50 ) {

						$is_seller = apply_filters( 'hide_for_buyers', true, $user->ID );
						if ( $is_seller ) { $i++;

							if ( isset( $user_arr->last_user_login ) ) {
								$all_users_arr[$user_arr->ID] = $user_arr->last_user_login;

							} else {
								$all_users_arr[$user_arr->ID] = $user_arr->ID;

							}

						}

					}

				}
			}

			if ( isset( $all_users_arr[$current_user_id] ) ) unset( $all_users_arr[$current_user_id] );

			arsort( $all_users_arr ); // sort the array by last login

			$all_users = array_keys( $all_users_arr );

			$ret_array = array_merge( $tangential_users, $all_users );

		} else {

			$ret_array = $tangential_users;

		}

		$ret_array = array_unique( $ret_array );

		return $ret_array;
	}
}

if ( ! function_exists( 'wpj_chat_get_message_date' ) ) {
	function wpj_chat_get_message_date( $row ) {
		$begin_of_day = strtotime( 'midnight', time() );
		$end_of_day   = strtotime( 'tomorrow', $begin_of_day ) - 1;

		$begin_of_week = strtotime( 'last Monday', time() );
		$end_of_week   = strtotime( 'next Sunday', time() ) + 86400;

		if ( $row->datemade ) {
			if ( $row->datemade > $begin_of_day && $row->datemade < $end_of_day ) {
				return wpj_date( wpj_get_option( 'time_format' ), $row->datemade );
			} elseif ( $row->datemade > $begin_of_week && $row->datemade < $end_of_week ) {
				return wpj_date( 'l, ' . wpj_get_option( 'time_format' ), $row->datemade );
			} else {
				return wpj_date( wpj_get_option( 'date_format' ), $row->datemade );
			}
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_chat_get_custom_offer_info' ) ) {
	function wpj_chat_get_custom_offer_info( $row ) {
		$sender_id    = $row->initiator;
		$sender_arr   = get_userdata( $sender_id );

		$receiver_id  = $row->user;
		$receiver_arr = get_userdata( $receiver_id );

		if ( $row->custom_offer == -1 ) {
			if ( get_current_user_id() == $row->initiator ) {
				return '<a href="' . wpj_get_pm_link( $receiver_arr->user_nicename ) . '"><span class="line-clamp-2">' . sprintf( __( "You requested a custom offer from %s", "wpjobster" ), wpj_get_user_display_type( $receiver_arr->ID ) ) . '</span></a>';
			} elseif ( get_current_user_id() == $row->user ) {
				return '<a href="' . wpj_get_pm_link( $sender_arr->user_nicename ) . '"><span class="line-clamp-2">' . sprintf( __( "%s sent you a custom offer request", "wpjobster" ), wpj_get_user_display_type( $sender_arr->ID ) ) . '</span></a>';
			}
		} elseif ( $row->custom_offer > 0 ) {
			if ( get_current_user_id() == $row->initiator ) {
				return '<a href="' . wpj_get_pm_link( $receiver_arr->user_nicename ) . '"><span class="line-clamp-2">' . sprintf( __( "You sent a custom price offer to %s", "wpjobster" ), wpj_get_user_display_type( $receiver_arr->ID ) ) . '</span></a>';
			} elseif ( get_current_user_id() == $row->user ) {
				return '<a href="' . wpj_get_pm_link( $sender_arr->user_nicename ) . '"><span class="line-clamp-2">' . sprintf( __( "%s sent you a custom price offer", "wpjobster" ), wpj_get_user_display_type( $sender_arr->ID ) ) . '</span></a>';
			}
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_chat_get_custom_offer_response' ) ) {
	function wpj_chat_get_custom_offer_response( $row ) {

		if ( $row ) {
			if ( get_post_meta( $row->custom_offer, "offer_accepted", true ) == 1 ) { return __( "Accepted", "wpjobster" ); }
			elseif ( get_post_meta( $row->custom_offer, "offer_declined", true ) == 1 ) { return __( "Declined", "wpjobster" ); }
			elseif ( get_post_meta( $row->custom_offer, "offer_withdrawn", true ) == 1 ) { return __( "Withdrawn", "wpjobster" ); }
			elseif ( get_post_meta( $row->custom_offer, "offer_expired", true ) == 1 ) { return __( "Expired", "wpjobster" ); }
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_chat_get_custom_offer_response_status' ) ) {
	function wpj_chat_get_custom_offer_response_status( $row ) {

		if ( $row ) {
			if ( get_post_meta( $row->custom_offer, "offer_accepted", true ) == 1 ) { return "offer_accepted"; }
			elseif ( get_post_meta( $row->custom_offer, "offer_declined", true ) == 1 ) { return "offer_declined"; }
			elseif ( get_post_meta( $row->custom_offer, "offer_withdrawn", true ) == 1 ) { return "offer_withdrawn"; }
			elseif ( get_post_meta( $row->custom_offer, "offer_expired", true ) == 1 ) { return "offer_expired"; }
		}

		return false;
	}
}