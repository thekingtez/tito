<?php
if ( ! function_exists( 'wpj_create_request_post_id' ) ) {
	function wpj_create_request_post_id() {
		// Init new post
		if ( ! isset( $_GET['requestid'] ) ) {

			$pid = wpj_get_auto_draft_post( get_current_user_id(), 'request' );

			wp_redirect( add_query_arg( 'requestid', $pid, get_permalink( wpj_get_option( 'wpjobster_new_request_page_id' ) ) ) );
			exit;

		} else {

			$pid = WPJ_Form::get( 'requestid' );

		}

		// Double check that we are on the right page
		if ( is_user_logged_in() ) {

			global $wpdb;

			$last_draft = $wpdb->get_row(
				$wpdb->prepare(
					"
					SELECT *
					FROM $wpdb->posts
					WHERE post_type = 'request'
						AND post_status = 'auto-draft'
						AND post_author = %d
					ORDER BY ID DESC
					",
					get_current_user_id()
				)
			);

			if ( WPJ_Form::get( 'action' ) != 'edit-request' ) {

				if ( ( isset( $last_draft->ID ) && $last_draft->ID > $pid ) || get_current_user_id() != get_post_field( 'post_author', $pid ) ) {
					wp_redirect( add_query_arg( 'requestid', $last_draft->ID, get_permalink( wpj_get_option( 'wpjobster_new_request_page_id' ) ) ) );
					exit;
				}

			}

		} else {

			if ( isset( $_COOKIE['wpj_request_id'] ) && $pid != $_COOKIE['wpj_request_id'] ) {
				wp_redirect( add_query_arg( 'requestid', $_COOKIE['wpj_request_id'], get_permalink( wpj_get_option( 'wpjobster_new_request_page_id' ) ) ) );
				exit;
			} elseif ( ! isset( $_COOKIE['wpj_request_id'] ) ) {
				wp_redirect( get_permalink( wpj_get_option( 'wpjobster_new_request_page_id' ) ) );
				exit;
			}

		}
	}
}

if ( ! function_exists( 'wpj_activate_request' ) ) {
	function wpj_activate_request( $pid = '' ) {

		if ( is_user_logged_in() ) {

			$pid = WPJ_Form::post( 'post_id', $pid );
			if ( ! $pid ) $pid = wpj_get_post_id();
			$post = get_post( $pid );

			if ( $post->post_author == get_current_user_id() ) {
				update_post_meta( $pid, 'active', 1 );
				delete_post_meta( $pid, 'deactivation_reason' );
				echo 'success';

			} else echo 'not_your_post';

		} else echo 'not_logged_in';

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_deactivate_request' ) ) {
	function wpj_deactivate_request( $pid = '' ) {

		if ( is_user_logged_in() ) {

			$pid = WPJ_Form::post( 'post_id', $pid );
			if ( ! $pid ) $pid = wpj_get_post_id();
			$post = get_post( $pid );

			if ( $post->post_author == get_current_user_id() ) {
				update_post_meta( $pid, 'active', 0 );
				echo 'success';

			} else echo 'not_your_post';

		} else echo 'not_logged_in';

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_delete_request' ) ) {
	function wpj_delete_request( $pid = '' ) {

		if ( is_user_logged_in() ) {

			$pid = WPJ_Form::post( 'post_id', $pid );
			if ( ! $pid ) $pid = wpj_get_post_id();
			$post = get_post( $pid );

			if ( $post->post_author == get_current_user_id() ) {
				wp_trash_post( $post->ID );
				echo 'success';

			} else echo 'not_your_post';

		} else echo 'not_logged_in';

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_get_user_requests' ) ) {
	function wpj_get_user_requests( $uid = '', $order_status = 'active', $return = 'count' ) {

		if ( ! $uid ) { $uid = get_current_user_id(); }

		if ( $order_status ) {
			if ( $order_status == 'active' ) {

				$args = array(
					'posts_per_page' => '-1',
					'post_type'      => 'request',
					'post_status'    => array( 'publish' ),
					'meta_query'     => array(
						array(
							'key'     => 'active',
							'value'   => '1',
							'compare' => '='
						)
					)
				);

			} elseif ( $order_status == 'inactive' ) {

				$args = array(
					'posts_per_page' => '-1',
					'post_type'      => 'request',
					'post_status'    => array( 'publish' ),
					'meta_query'     => array(
						array(
							'key'     => 'active',
							'value'   => '0',
							'compare' => '='
						)
					)
				);

			} elseif ( $order_status == 'rejected' ) {

				$args = array(
					'posts_per_page' => '-1',
					'post_type'      => 'request',
					'post_status'    => array( 'pending' )
				);

			} elseif ( $order_status == 'in-review' ) {

				$args = array(
					'posts_per_page' => '-1',
					'post_type'      => 'request',
					'post_status'    => array( 'draft' )
				);

			} elseif ( $order_status == 'assigned' ) {

				$args = array(
					'posts_per_page' => '-1',
					'post_type'      => 'request',
					'post_status'    => array( 'publish' ),
					'meta_query'     => array(
						'relation' => 'AND',
						array(
							'key'     => 'assigned',
							'value'   => '1',
							'compare' => '='
						)
					)
				);

			} elseif ( $order_status == 'completed' ) {

				$args = array(
					'posts_per_page' => '-1',
					'post_type'      => 'request',
					'post_status'    => array( 'publish' ),
					'meta_query'     => array(
						array(
							'key'     => 'completed',
							'value'   => '1',
							'compare' => '='
						)
					)
				);

			}

			if ( $uid ) $args['author'] = $uid;

			if ( isset( $args ) ) {
				$result = new WP_Query( $args );

				if ( $return == 'query' ) {
					return apply_filters( 'wpj_user_requests_' . $order_status . '_query_filter', $args );
				}

				if ( $return == 'result' ) {
					return apply_filters( 'wpj_user_requests_' . $order_status . '_result_filter', $result );
				}

				if ( $return == 'count' ) {
					return apply_filters( 'wpj_user_requests_' . $order_status . '_count_filter', $result->post_count );
				}
			}
		}

		return 0;
	}
}

if ( ! function_exists( 'wpj_get_total_posted_requests' ) ) {
	function wpj_get_total_posted_requests() {
		return wp_count_posts( 'request' )->publish;
	}
}

if ( ! function_exists( 'wpj_get_request_rejected_input' ) ) {
	function wpj_get_request_rejected_input( $input = '', $pid = '' ) {
		$pid = wpj_get_post_id( $pid );

		${ 'rejected_' . $input } = get_post_meta( $pid, "req_rejected_" . $input, true );
		$rejected = get_post_status( $pid ) == 'pending' && ${ 'rejected_' . $input } == 1 ? 'rejected-input' : '';

		return $rejected;
	}
}