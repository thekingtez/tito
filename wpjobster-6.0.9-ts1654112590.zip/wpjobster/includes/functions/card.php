<?php
if ( ! function_exists( 'wpj_get_cards_layout_class' ) ) {
	function wpj_get_cards_layout_class() {
		if ( isset( $_COOKIE['cards-layout'] ) && $_COOKIE['cards-layout'] == 'list' )
			$list_class = 'list-grid';

		else
			$list_class = '';

		return $list_class;
	}
}

if ( ! function_exists( 'wpj_get_job_card_style' ) ) {
	function wpj_get_job_card_style() {
		global $jobster_design;

		if ( ! empty( $jobster_design['cards_style'] ) && $jobster_design['cards_style'] == '3' )
			$style = 'slider';

		elseif ( ! empty( $jobster_design['cards_style'] ) && $jobster_design['cards_style'] == '2' )
			$style = 'rich';

		else
			$style = 'simple';

		return apply_filters( 'wpj_get_job_card_style', $style );
	}
}