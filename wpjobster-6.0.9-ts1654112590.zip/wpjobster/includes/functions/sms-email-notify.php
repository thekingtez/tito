<?php
if ( ! function_exists( 'wpj_notify_user_translated' ) ) {
	function wpj_notify_user_translated( $reason = '', $receiver = '', $params = array(), $params_multiple = array(), $notify_type = 'both' ) {

		if ( ! $reason || ! $receiver ) { return false; }

		$receiver_data = get_userdata( $receiver );
		$user_data     = get_userdata( get_current_user_id() );

		// GLOBAL PARAMS
		$global_params_arr = array(
			'##your_site_name##' => get_bloginfo( 'name' ),
			'##your_site_url##'  => get_bloginfo( 'url' )
		);

		if ( ! isset( $params['##receiver_username##'] ) ) { $global_params_arr['##receiver_username##'] = ! empty( $receiver_data->ID ) ? wpj_get_user_display_type( $receiver_data->ID ) : $receiver; }
		if ( ! isset( $params['##sender_username##'] ) )   { $global_params_arr['##sender_username##']   = ! empty( $user_data->ID ) ? wpj_get_user_display_type( $user_data->ID ) : get_current_user_id(); }
		if ( ! isset( $params['##my_account_url##'] ) )    { $global_params_arr['##my_account_url##']    = wpj_get_my_account_link(); }

		$global_params = apply_filters( 'wpj_user_notification_global_params', $global_params_arr );

		$params = $params ? array_merge( $params, $global_params ) : $global_params;

		// EMAIL
		$email_enable      = wpj_get_option( 'uz_email_' . $reason . '_enable' );
		$email_enable_user = get_user_meta( $receiver, 'uz_email_' . $reason . '_enable', true );

		$email_content = wpj_get_email_content( $reason, $receiver, $params, $params_multiple );

		// SMS
		$sms_enable      = wpj_get_option( 'uz_sms_' . $reason . '_enable' );
		$sms_enable_user = get_user_meta( $receiver, 'uz_sms_' . $reason . '_enable', true );

		$sms_content = wpj_get_sms_content( $reason, $receiver, $params, $params_multiple );

		// RECEIVER
		if ( $receiver == 'admin' ) {
			$to = get_bloginfo( 'admin_email' );
		} elseif ( $receiver ) {
			$to = is_object( $receiver_data ) && isset( $receiver_data->user_email ) ? $receiver_data->user_email : '';
		} else {
			return false;
		}

		if ( ! $to ) { return false; }

		// SEND
		if ( $notify_type == 'email' && $email_enable != 'no' && $email_enable_user != 'no' ) {

			if ( $to && $email_content['subject'] && $email_content['message'] ) {
				wpj_send_email( $to, $email_content['subject'], $email_content['message'] );
			}

		} elseif ( $notify_type == 'sms' && $sms_enable != 'no' && $sms_enable_user != 'no' ) {

			if ( $receiver && $sms_content ) {
				wpj_send_sms( $receiver, $sms_content );
			}

		} else {

			if ( $email_enable != 'no' && $email_enable_user != 'no' ) {
				if ( $to && $email_content['subject'] && $email_content['message'] ) {
					wpj_send_email( $to, $email_content['subject'], $email_content['message'] );
				}
			}

			if ( $sms_enable != 'no' && $sms_enable_user != 'no' ) {
				if ( $receiver && $sms_content ) {
					wpj_send_sms( $receiver, $sms_content );
				}
			}

		}
	}
}

if ( ! function_exists( 'wpj_get_email_content' ) ) {
	function wpj_get_email_content( $reason = '', $receiver = '', $params = '', $params_multiple = '' ) {

		$default_lang = trim( wpj_get_option( 'wpjobster_language_1' ) );
		$lang = wpj_get_language_by_uid( $receiver, $default_lang );

		$email_subject = wpj_get_option( 'uz_email_' . $reason . '_' . $lang . '_subject' );
		$email_message = wpj_get_option( 'uz_email_' . $reason . '_' . $lang . '_message' );

		if ( ! $email_subject || ! $email_message ) {
			$email_subject = wpj_get_option( 'uz_email_' . $reason . '_' . $default_lang . '_subject' );
			$email_message = wpj_get_option( 'uz_email_' . $reason . '_' . $default_lang . '_message' );

			if ( ! $email_subject || ! $email_message) { return false; }
		}

		$email_subject = wpj_replace_coded_word_with_value( array_keys( $params ), array_values( $params ), $email_subject );
		$email_message = wpj_replace_coded_word_with_value( array_keys( $params ), array_values( $params ), $email_message );

		if ( $params_multiple ) { // list shortcode
			$email_message = wpj_get_message_with_params_multiple( $email_message, $params_multiple );
		}

		return array(
			'subject' => apply_filters( 'wpj_email_subject_filter', stripslashes( $email_subject ), $reason, $receiver, $params, $params_multiple ),
			'message' => apply_filters( 'wpj_email_message_filter', stripslashes( $email_message ), $reason, $receiver, $params, $params_multiple )
		);

	}
}

if ( ! function_exists( 'wpj_get_sms_content' ) ) {
	function wpj_get_sms_content( $reason = '', $receiver = '', $params = '', $params_multiple = '' ) {

		$default_lang = trim( wpj_get_option( 'wpjobster_language_1' ) );
		$lang = wpj_get_language_by_uid( $receiver, $default_lang );

		$sms_message = wpj_get_option( 'uz_sms_' . $reason . '_' . $lang . '_message' );
		if ( ! $sms_message ) {
			$sms_message = wpj_get_option( 'uz_sms_' . $reason . '_' . $default_lang . '_message' );
			if ( ! $sms_message) { return false; }
		}
		$sms_message = wpj_replace_coded_word_with_value( array_keys( $params ), array_values( $params ), $sms_message );

		if ( $params_multiple ) { // list shortcode
			$sms_message = wpj_get_message_with_params_multiple( $sms_message, $params_multiple );
		}

		return apply_filters( 'wpj_sms_message_filter', stripslashes( $sms_message ), $reason, $receiver, $params, $params_multiple );

	}
}

if ( ! function_exists( 'wpj_send_email' ) ) {
	function wpj_send_email( $recipients, $subject = '', $message = '' ) {

		$wpjobster_email_addr_from = wpj_get_option( 'wpjobster_email_addr_from' );
		$wpjobster_email_name_from = wpj_get_option( 'wpjobster_email_name_from' );

		if ( empty( $wpjobster_email_name_from ) ) {
			$wpjobster_email_name_from = get_bloginfo( 'name' );
		}

		if ( empty( $wpjobster_email_addr_from ) ) {
			$wpjobster_email_addr_from = get_bloginfo( 'admin_email' );
		}

		$headers = 'From: ' . $wpjobster_email_name_from . ' <' . $wpjobster_email_addr_from . '>' . PHP_EOL;

		if ( wpj_get_option( 'wpjobster_allow_html_emails' ) == 'yes' && ! is_plugin_active( 'wp-better-emails/wpbe.php' ) ) {

			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: " . get_bloginfo( 'html_type' ) . "; charset=\"" . get_bloginfo( 'charset' ) . "\"\r\n";

			$mailtext = "<html><head><title>" . $subject . "</title></head><body>" . $message . "</body></html>";

			return wp_mail( $recipients, $subject, nl2br( $mailtext ), $headers );

		} else {

			$headers .= "MIME-Version: 1.0\n";
			$headers .= "Content-Type: text/plain; charset=\"" . get_bloginfo( 'charset' ) . "\"\n";

			$mailtext = wpj_get_option( 'wpjobster_allow_html_emails' ) == 'yes' ? nl2br( $message ) : strip_tags( $message );

			return wp_mail( $recipients, $subject, $mailtext, $headers );

		}
	}
}

if ( ! function_exists( 'wpj_send_sms' ) ) {
	function wpj_send_sms( $sms_receiver, $sms_message ) {
		if ( ! wpj_is_sms_allowed() ) { return false; }

		// general options
		$sms_gateway = wpj_get_option( 'wpjobster_sms_gateways_enable' );

		$admin_number = stripslashes( wpj_get_option( 'wpjobster_sms_admin_numb_from' ) );

		$user_number = get_user_meta( $sms_receiver, 'cell_number', true );
		$user_number = wpj_format_phone_number( $sms_receiver, $user_number );

		$receiver_number = $sms_receiver == 'admin' ? $admin_number : $user_number;

		// gateway switch
		switch ( $sms_gateway ) {
			case 'twilio':
				$sid   = wpj_get_option( "wpjobster_theme_accountsid" );
				$token = wpj_get_option( "wpjobster_theme_authtoken" );

				if ( $sid && $token ) {

					include_once get_template_directory() . '/vendor/twilio/autoload.php';

					$client = new Twilio\Rest\Client( $sid, $token );

					$sender_number = stripslashes( wpj_get_option( 'wpjobster_sms_numb_twilio_from' ) );

					$response = "";

					if ( $receiver_number && $sender_number ) {
						try {
							$response = $client->messages->create(
								$receiver_number,
								array(
									'from' => $sender_number,
									'body' => $sms_message,
								)
							);
						} catch ( Exception $e ) {
							$response = $e->getMessage();
						}

						try {
							$whatsapp = $client->messages->create(
								'whatsapp:' . $sender_number,
								array(
									'from' => 'whatsapp:' . $sender_number,
									'body' => $sms_message,
								)
							);
						} catch ( Exception $e ) {
							$whatsapp = $e->getMessage();
						}
					}

				}

				break;

			case 'cafe24':
				$cafeId         = wpj_get_option( "wpjobster_theme_cafe_userid" );
				$cafeKey        = wpj_get_option( "wpjobster_theme_cafe_secure" );
				$sender_number  = wpj_get_option( "wpjobster_sms_numb_cafe_from" );

				if ( $cafeId && $cafeKey && $sender_number ) {
					include_once get_template_directory() . '/vendor/cafetwentyfour.php';

					$cafe     = new ServicesCafe( $cafeId, $cafeKey );
					$response = $cafe->send( $sms_message, $receiver_number, $sender_number );
				}

				break;
		}
	}
}

if ( ! function_exists( 'wpj_get_message_with_params_multiple' ) ) {
	function wpj_get_message_with_params_multiple( $message = '', $params = array() ) {

		if ( strpos( $message, '[start_list]' ) !== false ) {

			$message_start_arr = explode( '[start_list]', $message );
			$message_end_arr   = explode( '[end_list]', $message );

			$completed_message = $message_start_arr[0];

			if ( $params ) {
				foreach ( $params as $key => $value ) {
					$completed_message .= wpj_get_string_between( wpj_replace_coded_word_with_value( array_keys( $value ), array_values( $value ), $message ), '[start_list]', '[end_list]' ) . PHP_EOL;
				}
			}

			$completed_message .= $message_end_arr[1];

			return $completed_message;

		}

		return $message;

	}
}

if ( ! function_exists( 'wpj_replace_coded_word_with_value' ) ) {
	function wpj_replace_coded_word_with_value( $find, $replace, $subject ) {
		$i = 0;
		if ( $find ) {
			foreach ( $find as $item ) {
				$subject = str_replace( $item, $replace[$i], $subject ); $i++;
			}
		}

		return $subject;
	}
}

// ARRAY FOR NOTIFICATIONS
if ( ! function_exists( 'wpj_notification_key_exists' ) ) {
	function wpj_notification_key_exists( $key ) {
		$reasons = wpj_get_notifications_array();

		foreach ( $reasons as $reason ) {
			if ( array_key_exists( $key, $reason['items'] ) ) {
				return true;
			}
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_get_notifications_array' ) ) {
	function wpj_get_notifications_array() {
		$reasons = array(
			"admin" => array(
				"title" => "Admin Notifications",
				"items" => array(
					"user_admin_new" => array(
						"title"       => __( "New User", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when a new user registers on the website.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##user_email##</strong>",
					),
					"job_admin_new" => array(
						"title"       => __( "New Job Not-Approved", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when someone posts a job on the website if the job is not automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##job_name##</strong>",
					),
					"job_admin_acc" => array(
						"title"       => __( "New Job Approved", "wpjobster" ),
						"description" =>
							"This email will be received by the admin when someone posts a job on the website if the the job is automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##job_link##<br />##job_name##</strong>",
					),
					"job_edit" => array(
						"title"       => __( "Edit Job", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when a user edit a job and the job is not automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##user_email##</strong>",
					),
					"job_admin_purchased" => array(
						"title"       => __( "New Job Purchased", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when a user buys a new job.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##job_link##<br />##job_name##</strong>",
					),
					"featured_admin_new" => array(
						"title"       => __( "New Job Featured", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when someone features a job on the website.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##job_link##<br />##job_name##<br />##all_featured_info##</strong>",
					),
					"request_admin_new" => array(
						"title"       => __( "New Request Not-Approved", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when someone posts a request on the website if the request is not automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##request_name##</strong>",
					),
					"request_admin_acc" => array(
						"title"       => __( "New Request Approved", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when someone posts a request on the website if the the job is automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##request_link##<br />##request_name##</strong>",
					),
					"request_edit" => array(
						"title"       => __( "Edit Request", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when an user edits a request and the request is not automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##user_email##</strong>",
					),
					"custom_extra_paid_admin_new" => array(
						"title"       => __( "New Custom Extra Paid", "wpjobster" ),
						"description" =>
							"This notification will be received by admin when a custom extra is bought.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##username##<br />##transaction_page_link##</strong>",
					),
					"balance_admin_down" => array(
						"title"       => __( "Balance Down", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when an user's credits are decreased by an admin.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##amount_updated##</strong>",
					),
					"balance_admin_up" => array(
						"title"       => __( "Balance Up", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when an user's credits are increased by an admin.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##amount_updated##</strong>",
					),
					"balance_admin_up_paypal" => array(
						"title"       => __( "Balance Up via Paypal", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when an user's credits are increased via Paypal.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##amount_updated##</strong>",
					),
					"balance_admin_up_topup" => array(
						"title"       => __( "Balance Up via Top Up", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when an user's credits are increased via Top Up.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##amount_updated##<br />##payment_gateway##</strong>",
					),
					"admin_payment_completed_by_admin" => array(
						"title"       => __( "Admin Mark Payment Complete", "wpjobster" ),
						"description" =>
							"This notification will be received by admin when admin marks as completed any job payment.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_page_link##<br />##job_name##</strong>",
					),
					"new_bank_transfer_pending" => array(
						"title"       => __( "New Bank Transfer Pending", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when user purchases via bank transfer.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##payment_type##<br />##payment_amount##<br />##admin_orders_url##</strong>",
					),
					"admin_arbitration" => array(
						"title"       => __( "Arbitration", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when new arbitration is requested.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##username##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"admin_new_subscription" => array(
						"title"       => __( "New Subscription", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when a user subscribes for any level
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##current_subscription_level##<br />##next_subscription_amount##<br />##next_billing_date##<br />##next_subscription_level##<br />##current_subscription_period##<br />##current_subscription_amount##</strong>",
					),
					"admin_upgrade_subscription" => array(
						"title"       => __( "Upgrade Subscription", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when a user upgrade his subscription.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##current_subscription_level##<br />##next_subscription_amount##<br />##next_billing_date##<br />##next_subscription_level##<br />##current_subscription_period##<br />##current_subscription_amount##</strong>",
					),
					"admin_cancel_subscription" => array(
						"title"       => __( "Cancel subscription", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when a user cancel his subscription.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##current_subscription_level####current_subscription_period##<br />##current_subscription_amount##</strong>",
					),
					"admin_new_withdrawal_request" => array(
						"title"       => __( "New withdrawal request", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when he has a new  withdrawal request
							<br /><br />Available shortcodes:
							<br /><br /><strong>##withdrawal_username##<br />##withdrawal_amount##<br />##withdrawal_method##</strong>",
					),
					"admin_openexchangerates_not_responding" => array(
						"title"       => __( "OpenExchangeRates not responding", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when OpenExchangeRates.org is not responding
							<br /><br />Available shortcodes: <br />",
					),
					"admin_openexchangerates_higher" => array(
						"title"       => __( "Currency drop higher than x%", "wpjobster" ),
						"description" =>
							"This notification will be received by the admin when currency drop is higher than x%
							<br /><br />Available shortcodes:
							<br /><br /><strong>##main_currency##<br />##old_price##<br />##new_price##<br />##percent_difference##</strong>",
					),
				),
			),
			"registration" => array(
				"title" => "Registration",
				"items" => array(
					"user_new" => array(
						"title"       => __( "New User", "wpjobster" ),
						"description" =>
							"This notification will be received by all new users who register on your website using the Ajax form and social login options (most of them).
							<br /><br />Available shortcodes:
							<br /><br /><strong>##receiver_email##<br />##email_verification##</strong>",
					),
					"user_verification" => array(
						"title"       => __( "User Email Verification", "wpjobster" ),
						"description" =>
							"This notification will be received by an user who wants to verify his email and he didn't receive the verification link into the registration email.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##receiver_email##<br />##email_verification##</strong>",
					),
					"user_forgot_password" => array(
						"title"       => __( "User Forgot Password", "wpjobster" ),
						"description" =>
							"This notification will be received by an user who requests forgot / reset password on your website.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##receiver_email##<br/>##password_reset_link##</strong>",
					),
				),
			),
			"levels" => array(
				"title" => "User Levels",
				"items" => array(
					"level_down" => array(
						"title"       => __( "Level Down", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when his level gets downgraded.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##current_level##</strong>",
					),
					"level_up" => array(
						"title"       => __( "Level Up", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when his level gets upgraded.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##current_level##</strong>",
					),
				),
			),
			"messages" => array(
				"title" => "Messages",
				"items" => array(
					"new_message" => array(
						"title"       => __( "New Message", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when they receive a private message in their account.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##private_message_link##<br />##private_message_excerpt##<br />##private_message_content##</strong>",
					),
				),
			),
			"jobs" => array(
				"title" => "Jobs",
				"items" => array(
					"job_new" => array(
						"title"       => __( "New Job Not Approved", "wpjobster" ),
						"description" =>
							"This notification will be received by your users after posting a new job on your website if the job is not automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_name##</strong>",
					),
					"job_acc" => array(
						"title"       => __( "New Job Approved", "wpjobster" ),
						"description" =>
							"This notification will be received by your users after posting a new job on your website if the job is automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##</strong>",
					),
					"job_decl" => array(
						"title"       => __( "New Job Rejected", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when you reject a job by marking it as pending.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_name##</strong>",
					),
					"featured_new" => array(
						"title"       => __( "New Job Featured", "wpjobster" ),
						"description" =>
							"This notification will be received by your users after featuring a job on your website.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_name##<br />##job_link##<br />##all_featured_info##</strong>",
					)
				),
			),
			"job_orders" => array(
				"title" => "Job Orders",
				"items" => array(
					"order_accepted"  => array(
						"title"       => __( "Accepted order", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when the seller accept the order.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"order_rejected"  => array(
						"title"       => __( "Rejected order", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when the seller reject the order.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"purchased_buyer" => array(
						"title"       => __( "Job Purchased (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when they purchase a new job.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##mc_gross##<br />##processing_fees##<br />##tax_amount##<br />##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"purchased_seller" => array(
						"title"       => __( "Job Sold (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when they sell one of their jobs.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##mc_gross##<br />##processing_fees##<br />##tax_amount##<br />##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"order_message" => array(
						"title"       => __( "Transaction Message", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when they receive a new message on a transaction page.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_buyer" => array(
						"title"       => __( "Cancellation Requested (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the job when the buyer requests a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_seller" => array(
						"title"       => __( "Cancellation Requested (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the job when the seller requests a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_acc_buyer" => array(
						"title"       => __( "Cancellation Accepted (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the job when the buyer accepts a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_acc_seller" => array(
						"title"       => __( "Cancellation Accepted (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the job when the seller accepts a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_decl_buyer" => array(
						"title"       => __( "Cancellation Declined (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the job when the buyer declines a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_decl_seller" => array(
						"title"       => __( "Cancellation Declined (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the job when the seller declines a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_abort_buyer" => array(
						"title"       => __( "Cancellation Aborted (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the job when the buyer aborts a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_abort_seller" => array(
						"title"       => __( "Cancellation Aborted (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the job when the seller aborts a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_admin" => array(
						"title"       => __( "Cancelled by Admin", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller and the buyer when the admin cancels the job.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_ord_expired_seller" => array(
						"title"       => __( "Order Expired (seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when the buyer cancel the job because delivery time has expired.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_ord_expired_buyer" => array(
						"title"       => __( "Order Expired (buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when canceling the job because delivery time has expired.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"ord_expires_soon" => array(
						"title"       => __( "Order Expires Soon", "wpjobster" ),
						"description" =>
							"This notification will be received by the users 24 hours before the order expires.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"mod_buyer" => array(
						"title"       => __( "Modification Request (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the job when the buyer requests a modification.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"extend_delivery_request" => array(
						"title"       => __( "Extend Delivery Time Request (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the job when the seller requests an extension of the delivery time.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"extend_delivery_abort" => array(
						"title"       => __( "Extend Delivery Time Aborted (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the job when the seller cancels the request for an extension of the delivery time.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"extend_delivery_accept" => array(
						"title"       => __( "Extend Delivery Time Accepted (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the job when the buyer accepts to extend the delivery time.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"extend_delivery_decline" => array(
						"title"       => __( "Extend Delivery Time Declined (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the job when the buyer refuses to extend the delivery time.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"order_delivered" => array(
						"title"       => __( "Job Delivered (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when the seller marks the job as done/delivered.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"order_complete" => array(
						"title"       => __( "Job Completed (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when the buyer accepts the delivered job.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"new_feedback" => array(
						"title"       => __( "New Feedback (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when he received feedback from the buyer.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##job_link##<br />##job_name##<br />##transaction_number##<br />##transaction_page_link##</strong>",
					),
				),
			),
			"arbitration" => array(
				"title" => "Arbitration",
				"items" => array(
					"arb_new_request" => array(
						"title"       => __( "New Arbitration Request", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when arbitration has been opened.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##transaction_number##<br />##job_name##<br />##job_link##<br />##transaction_page_link##</strong>",
					),
					"arb_request_closed_buyer" => array(
						"title"       => __( "Arbitration Request Closed (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when arbitration request has been closed in favor of buyer.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##transaction_number##<br />##job_name##<br />##job_link##<br />##transaction_page_link##</strong>",
					),
					"arb_request_closed_seller" => array(
						"title"       => __( "Arbitration Request Closed (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when arbitration request has been closed in favor of seller.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##transaction_number##<br />##job_name##<br />##job_link##<br />##transaction_page_link##</strong>",
					),
					"arb_request_aborted" => array(
						"title"       => __( "Arbitration Request Aborted", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when arbitration request has been aborted.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##username##<br />##transaction_number##<br />##job_name##<br />##job_link##<br />##transaction_page_link##</strong>",
					),
				),
			),
			"requests" => array(
				"title" => "Requests",
				"items" => array(
					"request_new" => array(
						"title"       => __( "New Request Not Approved", "wpjobster" ),
						"description" =>
							"This notification will be received by your users after posting a new job on your website if the request is not automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##request_name##</strong>",
					),
					"request_acc" => array(
						"title"       => __( "New Request Approved", "wpjobster" ),
						"description" =>
							"This notification will be received by your users after posting a new request on your website if the job is automatically approved.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##request_link##<br />##request_name##</strong>",
					),
					"request_decl" => array(
						"title"       => __( "New Request Rejected (Pending)", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when you reject a job by marking it as pending.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##request_name##</strong>",
					),
					"withdraw_req" => array(
						"title"       => __( "Withdraw Request", "wpjobster" ),
						"description" =>
							"This notification will be received by the user after he requests a withdrawal.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_withdrawn##<br />##withdraw_method##</strong>",
					),
					"withdraw_compl" => array(
						"title"       => __( "Withdraw Processed (Accepted)", "wpjobster" ),
						"description" =>
							"This notification will be received by the user after his withdrawal request has been processed.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_withdrawn##<br />##withdraw_method##</strong>",
					),
					"withdraw_decl" => array(
						"title"       => __( "Withdraw Rejected", "wpjobster" ),
						"description" =>
							"This notification will be received by the user after his withdrawal request has been rejected.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_withdrawn##<br />##withdraw_method##</strong>",
					),
				),
			),
			"custom_offers" => array(
				"title" => "Custom Offers",
				"items" => array(
					"new_request" => array(
						"title"       => __( "New Request (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when they receive a custom offer request.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##private_message_link##</strong>",
					),
					"new_offer" => array(
						"title"       => __( "New Offer (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when they receive a custom offer.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##private_message_link##</strong>",
					),
					"offer_acc_buyer" => array(
						"title"       => __( "Offer Accepted (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when he accepted a custom offer.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##private_message_link##<br />##transaction_page_link##<br />##transaction_number##</strong>",
					),
					"offer_acc_seller" => array(
						"title"       => __( "Offer Accepted (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when his custom offer was accepted.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##private_message_link##<br />##transaction_page_link##<br />##transaction_number##</strong>",
					),
					"offer_decl" => array(
						"title"       => __( "Offer Declined (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when their custom offer was declined.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##private_message_link##</strong>",
					),
					"offer_withdr" => array(
						"title"       => __( "Offer Withdrawn (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when their custom offer was withdrawn.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##private_message_link##</strong>",
					),
					"offer_exp" => array(
						"title"       => __( "Offer Expired (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by your users when their custom offer expired.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##private_message_link##</strong>",
					),
				),
			),
			"custom_offer_orders" => array(
				"title" => "Custom Offer Orders",
				"items" => array(
					"cancel_offer_buyer" => array(
						"title"       => __( "Offer Cancellation Requested (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the custom offer when the buyer requests a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_offer_seller" => array(
						"title"       => __( "Offer Cancellation Requested (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the custom offer when the seller requests a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_offer_acc_buyer" => array(
						"title"       => __( "Offer Cancellation Accepted (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the custom offer when the buyer accepts a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_offer_acc_seller" => array(
						"title"       => __( "Offer Cancellation Accepted (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the custom offer when the seller accepts a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_offer_decl_buyer" => array(
						"title"       => __( "Offer Cancellation Declined (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the custom offer when the buyer declines a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_offer_decl_seller" => array(
						"title"       => __( "Offer Cancellation Declined (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the custom offer when the seller declines a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_offer_abort_buyer" => array(
						"title"       => __( "Offer Cancellation Aborted (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the custom offer when the buyer aborts a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_offer_abort_seller" => array(
						"title"       => __( "Offer Cancellation Aborted (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of the custom offer when the seller aborts a mutual cancellation.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"cancel_offer_admin" => array(
						"title"       => __( "Offer Cancelled by Admin", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller and the buyer when the admin cancels the custom offer.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"mod_offer_buyer" => array(
						"title"       => __( "Offer Modification Request (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller of the custom offer when the buyer requests a modification.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"order_offer_delivered" => array(
						"title"       => __( "Offer Job Delivered (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when the seller marks the custom offer as done.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"order_offer_complete" => array(
						"title"       => __( "Offer Job Completed (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when the buyer accepts the custom offer as delivered.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
					"new_offer_feedback" => array(
						"title"       => __( "Offer New Feedback (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when he received feedback from the buyer.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##transaction_number##<br />##transaction_page_link##</strong>",
					),
				),
			),
			"custom_extras" => array(
				"title" => "Custom Extras",
				"items" => array(
					"new_custom_extra" => array(
						"title"       => __( "New Custom Extra (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when a new custom extra is added.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
					"cancel_custom_extra" => array(
						"title"       => __( "Custom Extra Cancelled (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when a custom extra is cancelled by seller.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
					"decline_custom_extra" => array(
						"title"       => __( "Custom Extra Declined (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when a custom extra is declined by buyer.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
					"custom_extra_paid_new" => array(
						"title"       => __( "Custom Extra Paid (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer of a custom extra.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
					"custom_extra_paid_new_seller" => array(
						"title"       => __( "Custom Extra Paid (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when a custom extra is bought.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
					"custom_extra_cancelled_by_admin" => array(
						"title"       => __( "BT Custom Extra Cancelled (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when a Bank Transfer custom extra is cancelled by admin.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
					"custom_extra_cancelled_by_admin_seller" => array(
						"title"       => __( "BT Custom Extra Cancelled (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when a Bank Transfer custom extra is cancelled by admin.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
				),
			),
			"tips" => array(
				"title" => "Tips",
				"items" => array(
					"new_tips" => array(
						"title"       => __( "New Tips (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when a new tips is added.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
					"cancel_tips" => array(
						"title"       => __( "Tips Cancelled (Buyer)", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when a tips order is cancelled.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
					"tips_paid_new" => array(
						"title"       => __( "Tips Paid (Seller)", "wpjobster" ),
						"description" =>
							"This notification will be received by the seller when a tips is paid.
							<br /><br /> Available shortcodes:
							<br /><br /> <strong>##transaction_page_link##</strong>",
					),
				),
			),
			"subscriptions" => array(
				"title" => "Subscriptions",
				"items" => array(
					"price_update_subscription" => array(
						"title"       => __( "Subscription Price Update", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when admin updates the subscription price.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##subscription_url##</strong>",
					),
					"balance_down_subscription" => array(
						"title"       => __( "New Subscription", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when he subscribes for any level.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##current_subscription_level##<br />##next_subscription_amount##<br />##next_billing_date##<br />##next_subscription_level##<br />##current_subscription_period##<br />##current_subscription_amount##</strong>",
					),
					"balance_down_subscription_change" => array(
						"title"       => __( "Subscription Change", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when he changes his subscription level with immediate effect.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##current_subscription_level##<br />##next_subscription_amount##<br />##next_billing_date##<br /><br />##current_subscription_period##<br />##current_subscription_amount##</strong>",
					),
					"wpjobster_subscription_prior_notification" => array(
						"title"       => __( "Prior Subscription Renewal", "wpjobster" ),
						"description" =>
							"This notification will be received by the user few days before his subscription renewal.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##current_subscription_level##<br />##next_subscription_amount##<br />##next_billing_date##<br />##next_subscription_level##<br />##current_subscription_period##<br />##current_subscription_amount##<br />##no_of_days_subscription_left##</strong>",
					),
					"subscription_cancel" => array(
						"title"       => __( "Subscription Cancel (Manual)", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when he cancels his subscription.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##current_subscription_level##<br />##current_subscription_period##<br />##current_subscription_amount##</strong>",
					),
					"subscription_cancel_lowbalance" => array(
						"title"       => __( "Subscription Cancel (Low Balance)", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when his subscription was cancelled due to low credits balance.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##current_subscription_level##<br />##next_subscription_amount##<br />##next_billing_date##<br />##next_subscription_level##<br />##current_subscription_period##<br />##current_subscription_amount##</strong>",
					),
					"subscription_schedule" => array(
						"title"       => __( "Subscription Schedule", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when he schedules his subscription.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##current_subscription_level##<br />##next_subscription_amount##<br />##next_billing_date##<br />##next_subscription_level##<br />##current_subscription_period##<br />##current_subscription_amount##</strong>",
					),
				),
			),
			"user_balance" => array(
				"title" => "User Balance",
				"items" => array(
					"balance_down" => array(
						"title"       => __( "Balance Down", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when his credits are decreased by an admin.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##</strong>",
					),
					"balance_up" => array(
						"title"       => __( "Balance Up", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when his credits are increased by an admin.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##</strong>",
					),
					"balance_up_paypal" => array(
						"title"       => __( "Balance Up via Paypal", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when his credits are increased by payment via PayPal.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##amount_updated_in_currency##</strong>",
					),
					"balance_up_topup" => array(
						"title"       => __( "Balance Up via Top Up", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when credits are increased via Topup.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##<br />##amount_updated_in_currency##<br />##payment_gateway##</strong>",
					),
					"balance_negative" => array(
						"title"       => __( "Balance Negative", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when his credits are gone negative.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##amount_updated##</strong>",
					),
				),
			),
			"various_payments" => array(
				"title" => "Various Payments",
				"items" => array(
					"payment_completed_by_admin" => array(
						"title"       => __( "Admin mark Payment Complete", "wpjobster" ),
						"description" =>
							"This notification will be received by the buyer when admin marks the payment completed.
							<br /><br />Available shortcodes:
							<br /><br /><strong><br />##transaction_page_link##<br />##job_name##</strong>",
					),
					"send_bankdetails_to_buyer" => array(
						"title"       => __( "Send Bank Details", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when they choose to pay using the bank transfer payment menthod.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##bank_details##<br />##job_name##<br />##transaction_page_link##</strong>",
					),
					"send_bankdetails_to_topup_buyer" => array(
						"title"       => __( "Send Bank Details (Top Up)", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when they choose to pay using the bank transfer payment menthod.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##bank_details##<br />##job_name##<br />##transaction_page_link##</strong>",
					),
					"send_bankdetails_to_feature_buyer" => array(
						"title"       => __( "Send Bank Details (Feature)", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when they choose to pay using the bank transfer payment menthod.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##bank_details##<br />##job_name##<br />##transaction_page_link##</strong>",
					),
					"send_bankdetails_to_custom_extra_buyer" => array(
						"title"       => __( "Send Bank Details (Custom Extra)", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when they choose to pay using the bank transfer payment menthod.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##bank_details##<br />##job_name##<br />##transaction_page_link##</strong>",
					),
					"send_bankdetails_to_tips_buyer" => array(
						"title"       => __( "Send Bank Details (Tips)", "wpjobster" ),
						"description" =>
							"This notification will be received by the user when they choose to pay using the bank transfer payment menthod.
							<br /><br />Available shortcodes:
							<br /><br /><strong>##bank_details##<br />##job_name##<br />##transaction_page_link##</strong>",
					),
				),
			),
		);

		$reasons = apply_filters( 'wpjobster_admin_menu_email_templates', $reasons );

		$general_shortcodes = '<strong><br />##receiver_username##<br />##sender_username##<br />##my_account_url##<br />##your_site_name##<br />##your_site_url##</strong>';

		foreach ( $reasons as $r_key => $reason ) {
			foreach ( $reason["items"] as $i_key => $item ) {
				$reasons[$r_key]["items"][$i_key]["description"] .= $general_shortcodes;
			}
		}

		return $reasons;
	}
}