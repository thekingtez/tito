<?php
if ( ! function_exists( 'wpj_get_seller_id' ) ) {
	function wpj_get_seller_id( $order = '' ) {
		global $wp_query;

		if ( ! $order && isset( $wp_query->query_vars['oid'] ) ) $order = $wp_query->query_vars['oid'];

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		$post_id   = isset( $order->pid ) ? $order->pid : 0;
		$seller_id = $post_id ? get_post_field( 'post_author', $post_id ) : 0;

		return $seller_id;
	}
}

if ( ! function_exists( 'wpj_get_buyer_id' ) ) {
	function wpj_get_buyer_id( $order = '' ) {
		global $wp_query;

		if ( ! $order && isset( $wp_query->query_vars['oid'] ) ) $order = $wp_query->query_vars['oid'];

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		$buyer_id = isset( $order->uid ) ? $order->uid : 0;

		return $buyer_id;
	}
}

if ( ! function_exists( 'wpj_get_buyer_by_payment_type' ) ) {
	function wpj_get_buyer_by_payment_type( $oid = '', $payment_type = '' ) {
		global $wp_query;

		if ( ! $oid && isset( $wp_query->query_vars['oid'] ) )
			$oid = esc_sql( $wp_query->query_vars['oid'] );

		if ( $payment_type == 'topup' ) {
			$order = wpj_get_topup_order_by( 'id', $oid );
			return $order->user_id;
		} elseif ( $payment_type == 'feature' ) {
			$order = wpj_get_featured_order_by( 'id', $oid );
			return $order->user_id;
		} elseif ( $payment_type == 'custom_extra' ) {
			$order = wpj_get_custom_extras( $oid );
			return $order->user_id;
		} elseif ( $payment_type == 'tips' ) {
			$order = wpj_get_tips( $oid );
			return $order->user_id;
		} elseif ( $payment_type == 'subscription' ) {
			$order = wpj_get_subscription_order_by( 'id', $oid, 'all' );
			return $order->user_id;
		} else {
			$order = wpj_get_order( $oid );
			return $order->uid;
		}
	}
}

if ( ! function_exists( 'wpj_users_have_transactions' ) ) {
	function wpj_users_have_transactions( $usr1 = '', $usr2 = '' ) {
		if ( $usr1 && $usr2 ) {
			global $wpdb;

			$r = $wpdb->get_results( "
				SELECT *
				FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
				WHERE orders.pid = posts.ID
				AND ( orders.uid = '{$usr1}' AND posts.post_author = '{$usr2}' )
				OR ( orders.uid = '{$usr2}' AND posts.post_author = '{$usr1}' )
			" );

			if ( isset( $r[0] ) ) { return true; }
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_get_order' ) ) {
	function wpj_get_order( $oid = '', $return = '' ) {
		global $wp_query;

		if ( ! $oid && isset( $wp_query->query_vars['oid'] ) )
			$oid = esc_sql( $wp_query->query_vars['oid'] );

		if ( is_numeric( $oid ) ) {
			global $wpdb;

			$query = $wpdb->prepare( "SELECT DISTINCT * FROM {$wpdb->prefix}job_orders WHERE id = %d", $oid );
			$row   = $wpdb->get_row( $query );

			return $return && isset( $row->$return ) ? $row->$return : $row;
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_get_order_status' ) ) {
	function wpj_get_order_status( $oid = '', $include_parentheses = true ) {
		global $wp_query;

		if ( ! $oid && isset( $wp_query->query_vars['oid'] ) )
			$oid = esc_sql( $wp_query->query_vars['oid'] );

		$order = wpj_get_order( $oid );

		if ( $order ) {
			if ( $order->payment_status == 'pending' ) {
				$order_status = __( 'Deposit Waiting', 'wpjobster' );

			} elseif ( $order->payment_status == 'failed' ) {
				$order_status = __( 'Failed', 'wpjobster' );

			} elseif ( $order->payment_status == 'processing' ) {
				$order_status = __( 'Processing', 'wpjobster' );

			} elseif ( $order->payment_status == 'cancelled' ) {
				$order_status = __( 'Cancelled', 'wpjobster' );

			} elseif ( $order->payment_status == 'expired' ) {
				$order_status = __( 'Expired', 'wpjobster' );

			} elseif ( $order->payment_status != 'completed' && $order->payment_status ) {
				$order_status = wpj_translate_string( $order->payment_status );

			} else {
				$order_status = __( 'Paid', 'wpjobster' );

			}

			return $order_status ? ( $include_parentheses && $include_parentheses != 'false' ? ' (' . $order_status . ')' : $order_status ) : false;
		}
	}
}

if ( ! function_exists( 'wpj_get_order_by_payment_type' ) ) {
	function wpj_get_order_by_payment_type( $payment_type = '', $oid = '', $return = '' ) {
		if ( is_numeric( $oid ) ) {
			global $wpdb;

			if ( $payment_type == 'topup' )
				$order = wpj_get_topup_order_by( 'id', $oid );

			elseif ( $payment_type == 'feature' )
				$order = wpj_get_featured_order_by( 'id', $oid );

			elseif ( $payment_type == 'custom_extra' )
				$order = wpj_get_custom_extra_order_by( 'id', $oid );

			elseif ( $payment_type == 'tips' )
				$order = wpj_get_tips_order_by( 'id', $oid );

			elseif ( $payment_type == 'subscription' )
				$order = wpj_get_subscription_order_by( 'id', $oid, 'all' );

			else
				$order = wpj_get_order( $oid );

			return $return && isset( $order->$return ) ? $order->$return : $order;
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_get_orders_in_queue_count' ) ) {
	function wpj_get_orders_in_queue_count( $pid ) {
		$fake_queue      = get_post_meta( get_the_ID(), "fake_queue", true );
		$fake_queue_rand = get_post_meta( get_the_ID(), "fake_queue_rand", true );
		$fake_queue_exp  = get_post_meta( get_the_ID(), "fake_queue_exp", true );

		if ( $fake_queue ) {
			if ( $fake_queue_exp > current_time( 'timestamp', 1 ) ) {
				return $fake_queue_rand;
			} else {
				$rand = $fake_queue + rand( 0, round( $fake_queue / 3 ) );

				update_post_meta( $pid, 'fake_queue_exp', strtotime( "+3 days" ) );
				update_post_meta( $pid, 'fake_queue_rand', $rand );

				return $rand;
			}
		} else {
			return 0;
		}
	}
}

if ( ! function_exists( 'wpj_update_order_meta' ) ) {
	function wpj_update_order_meta( $oid = '', $meta_key = '', $meta_value = '' ) {
		global $wp_query, $wpdb;

		if ( ! $oid && isset( $wp_query->query_vars['oid'] ) )
			$oid = esc_sql( $wp_query->query_vars['oid'] );

		$meta_key   = esc_sql( $meta_key );
		$meta_value = esc_sql( maybe_serialize( wpj_encode_emoji( $meta_value ) ) );

		if ( is_numeric( $oid ) && wpj_get_order( $oid ) ) {
			$result = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}job_orders SET $meta_key = '$meta_value' WHERE id = %d", $oid ) );

			if ( $result === false ) return false;
			return true;
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_camouflage_oid' ) ) {
	function wpj_camouflage_oid( $oid = '', $date = '' ) {
		global $wp_query;

		if ( ! $oid && isset( $wp_query->query_vars['oid'] ) )
			$oid = esc_sql( $wp_query->query_vars['oid'] );

		if ( ! $date ) {
			$order = wpj_get_order( $oid );
			$date  = isset( $order->date_made ) ? $order->date_made : '';
		}

		if ( $date ) {

			$ret = 'I';
			$ret = $ret . date( "j", $date );
			$ret = $ret . date( "n", $date );
			$ret = $ret . 'D';

			$half = round( strlen( $oid ) / 2 );
			$end  = strlen( $oid );
			$ids  = str_split( $oid );

			for ( $i = 0; $i < $half; $i++ ) $ret = $ret . $ids[$i];

			$ret = $ret . date( "y", $date );

			for ( $i = $half; $i < $end; $i++ ) $ret = $ret . $ids[$i];

			return $ret;
		}

		return __( 'unknown', 'wpjobster' );
	}
}

if ( ! function_exists( 'wpj_get_checkout_total_price' ) ) {
	function wpj_get_checkout_total_price( $payment_type ) {
		$order_price = 0;

		if ( $payment_type == 'badge' ) {
			$badges_data = wpj_get_option( 'badge-list-settings' );
			$order_price = min( $badges_data['wpj_badge_price'] );

		} elseif ( $payment_type == 'job_purchase' ) {
			$order_price = get_post_meta( wpj_get_post_id(), 'price', true );

		} elseif ( $payment_type == 'featured' ) {
			$order_price = min( array( wpj_get_option( 'wpjobster_featured_price_homepage' ), wpj_get_option( 'wpjobster_featured_price_category' ), wpj_get_option( 'wpjobster_featured_price_subcategory' ) ) );

		} elseif ( $payment_type == 'topup' ) {
			$topup_data  = wpj_get_option( 'topup-packages-settings' );
			$order_price = min( $topup_data['topup_cost'] );

		} elseif ( $payment_type == 'subscription' ) {
			$order_price = min( array( wpj_get_subscription_min_price_by_level( 1 ), wpj_get_subscription_min_price_by_level( 2 ), wpj_get_subscription_min_price_by_level( 3 ) ) );

		} elseif ( $payment_type == 'custom_extra' ) {
			$custom_extra = wpj_get_payment_info_by_url( 'custom_extra' );
			$order_price  = $custom_extra->price;

		} elseif ( $payment_type == 'tips' ) {
			$tip         = wpj_get_payment_info_by_url( 'tip' );
			$order_price = $tip->amount;

		}

		return $order_price;
	}
}

if ( ! function_exists( 'wpj_get_order_total_price' ) ) {
	function wpj_get_order_total_price( $order = '', $return = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		if ( $order ) {

			$raw_amount      = $order->mc_gross;
			$processing_fees = $order->processing_fees;
			$tax_amount      = $order->tax_amount;

			// shipping
			$shipping = get_post_meta( $order->pid, 'shipping', true );
			if ( ! $shipping ) $shipping = 0;

			// extras
			$extras_price = 0;
			if ( $order->extra_fast != 0 ) $extras_price += $order->extra_fast_price * $order->extra_fast;
			if ( $order->extra_revision != 0 ) $extras_price += $order->extra_revision_price * $order->extra_revision;
			for ( $i = 1; $i <= 10; $i++ ) {
				if ( $order->{'extra' . $i} != 0 ) $extras_price += $order->{'extra' . $i . '_price'} * $order->{'extra' . $i};
			}

			// check custom extra
			$custom_extras = json_decode( $order->custom_extras );
			if ( $custom_extras ) { $i = 0;
				foreach ( $custom_extras as $custom_extra ) {
					if ( $custom_extra->paid ) {
						$custom_extra_order = wpj_get_custom_extra( $order->id, $i );
						if ( $custom_extra_order ) {
							$raw_amount      += isset( $custom_extra->price ) ? $custom_extra->price : 0;
							$processing_fees += isset( $custom_extra->processing_fees ) ? $custom_extra->processing_fees : 0;
							$tax_amount      += isset( $custom_extra->tax ) ? $custom_extra->tax : 0;
						} $i++;
					}
				}
			}

			// check tips
			$tips = json_decode( $order->tips );
			if ( $tips ) { $j = 0;
				foreach ( $tips as $tip ) {
					if ( $tip->paid ) {
						$tips_order = wpj_get_tip( $order->id, $j );
						if ( $tips_order ) {
							$raw_amount      += isset( $tip->amount ) ? $tip->amount : 0;
							$processing_fees += isset( $tip->processing_fees ) ? $tip->processing_fees : 0;
							$tax_amount      += isset( $tip->tax ) ? $tip->tax : 0;
						} $j++;
					}
				}
			}

			$admin_fee = wpj_get_site_fee_by_amount( $raw_amount, $order->id, wpj_get_seller_id( $order ) );

			$total_order_price = $raw_amount + $processing_fees + $tax_amount;

			$data = array(
				'amount'            => $raw_amount,
				'shipping'          => $shipping,
				'extras'            => $extras_price,
				'admin_commission'  => $admin_fee,
				'seller_commission' => $raw_amount - $admin_fee,
				'buyer_fee'         => $processing_fees,
				'tax'               => $tax_amount,
				'total'             => $total_order_price,
			);

			if ( $return && isset( $data[$return] ) ) return $data[$return];

			return $data;

		}

		return 0;
	}
}