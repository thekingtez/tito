<?php
if ( ! function_exists( 'wpj_is_subcategory' ) ) {
	function wpj_is_subcategory( $post_type = 'job_cat' ) {
		$term = get_term_by( 'slug', get_query_var( 'term' ), $post_type );

		return ( $term && $term->parent != '0' ) ? true : false;
	}
}

if ( ! function_exists( 'wpj_get_category_link' ) ) {
	function wpj_get_category_link( $category = 0, $taxonomy = 'job_cat' ) {

		// if id
		if ( ctype_digit( $category ) || is_int( $category ) ) {
			return get_category_link( $category );
		}

		// if slug
		$this_term = get_term_by( 'slug', $category, $taxonomy );

		// if name
		if ( ! $this_term ) {
			$this_term = get_term_by( 'name', $category, $taxonomy );
		}

		// avoid warnings
		if ( isset( $this_term->term_id ) && is_numeric( $this_term->term_id ) ) {
			$category_id = $this_term->term_id;
		} else {
			$category_id = 0;
		}

		return get_category_link( $category_id );
	}
}