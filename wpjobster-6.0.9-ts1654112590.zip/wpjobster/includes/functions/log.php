<?php
if ( ! function_exists( 'wpj_maintain_log' ) ) {
	function wpj_maintain_log( $order = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		$orderid               = $order->id;
		$job_title             = $order->job_title;
		$mc_gross              = $order->mc_gross;
		$uid                   = $order->uid;
		$pid                   = $order->pid;
		$seller_id             = wpj_get_seller_id( $order );
		$buyer_processing_fees = $order->processing_fees;
		$wpjobster_tax_amount  = $order->tax_amount;

		$order_url = wpj_get_order_link( $orderid );
		$reason    = __( 'Payment made for', 'wpjobster' ) . ': <a href="' . $order_url . '">' . $job_title . '</a>';
		wpj_add_history_log( array( 'tp' => '0', 'reason' => $reason, 'amount' => $mc_gross, 'uid' => $uid, 'oid' => $orderid, 'rid' => 3 ) );

		do_action( 'wpj_after_payment_made_for_log', $order );

		if ( $buyer_processing_fees > 0 ) {
			$reason = __( 'Processing fee for', 'wpjobster' ) . ': <a href="' . $order_url . '">' . $job_title . '</a>';
			wpj_add_history_log( array( 'tp' => '0', 'reason' => $reason, 'amount' => $buyer_processing_fees, 'uid' => $uid, 'oid' => $orderid, 'rid' => 13 ) );

			do_action( 'wpj_after_processing_fee_for_log', $order );
		}

		if ( $wpjobster_tax_amount > 0 ) {
			$reason = __( 'Tax for', 'wpjobster' ) . ': <a href="' . $order_url . '">' . $job_title . '</a>';
			wpj_add_history_log( array( 'tp' => '0', 'reason' => $reason, 'amount' => $wpjobster_tax_amount, 'uid' => $uid, 'oid' => $orderid, 'rid' => 14 ) );

			do_action( 'wpj_after_tax_for_log', $order );
		}

		$reason = __( 'Payment collected for', 'wpjobster' ) . ': <a href="' . $order_url . '">' . $job_title . '</a>';
		wpj_add_history_log( array( 'tp' => '2', 'reason' => $reason, 'amount' => $mc_gross, 'uid' => $seller_id, 'oid' => $orderid, 'rid' => 4 ) );

		do_action( 'wpj_after_payment_collected_for_log', $order );

		$instant = get_post_meta( $pid, 'instant', true );
		$allow_auto_delivered = wpj_get_option( 'wpjobster_seller_order_rejection_enable' ) == 'yes' ? false : true;

		if ( $instant == "1" && $order->payment_gateway != 'cod' && $allow_auto_delivered ) {

			global $wpdb;

			$tm = current_time( 'timestamp', 1 );

			$wpdb->query( "UPDATE {$wpdb->prefix}job_orders SET done_seller = '1', date_finished = '{$tm}' WHERE id = '{$orderid}'" );

			// Insert to chatbox
			$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -1 AND oid = %d", current_time( 'timestamp', 1 ), $orderid ) );

			if ( ! $row_exist ) {
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade' => current_time( 'timestamp', 1 ),
						'uid'      => -1,
						'oid'      => $orderid,
						'content'  => __( 'Paid', 'wpjobster' )
					),
					array( '%d', '%d', '%d', '%s' )
				);

				$this_notification = $wpdb->insert_id;

				wpj_update_user_notifications( array(
					'user1'       => $uid,
					'user2'       => $seller_id,
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'order_delivered',
					'order_id'    => $orderid
				) );

				if ( wpj_is_custom_offer( $pid ) ) {
					wpj_deliver_custom_offer( $pid, $orderid, $uid );

				} else {
					wpj_notify_user_translated( 'order_delivered', $uid, array(
						'##sender_username##'       => wpj_get_user_display_type( $seller_id ),
						'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
						'##transaction_page_link##' => wpj_get_order_link( $orderid ),
						'##job_name##'              => $order->job_title,
						'##job_link##'              => urldecode( get_permalink( $pid ) )
					) );

				}
			}

		}

		wpj_notify_user_translated( 'job_admin_purchased', 'admin', array(
			'##username##' => wpj_get_user_display_type( $seller_id ),
			'##job_name##' => $job_title,
			'##job_link##' => get_post_permalink( $pid )
		) );

	}
}

if ( ! function_exists( 'wpj_add_history_log' ) ) {
	function wpj_add_history_log( $args = array() ) {

		// $tp == 1     => (+) Money received
		// $tp == 0     => (-) Money paid
		// $tp == 2     => ( ) Money Pending

		// $rid == 1    => Payment received from Site Admin
		// $rid == 2    => Payment withdrawn by Site Admin
		// $rid == 3    => Payment made for:                   #ORDER_URL
		// $rid == 4    => Payment collected for:              #ORDER_URL
		// $rid == 5    => Payment cleared for:                #ORDER_URL
		// $rid == 6    => Fee charged for:                    #ORDER_URL
		// $rid == 7    => Payment refunded for:               #ORDER_URL
		// $rid == 8    => Payment refunded for:               #ORDER_URL
		// $rid == 9    => Withdrawal to                       #METHOD: #DETAILS
		// $rid == 10   => Feature job:                        $details = $pid
		// $rid == 11   => Payment for subscription            weekly-level1-new|change|renew
		// $rid == 12   => Top Up account balance
		// $rid == 13   => Processing fee for:                 #ORDER_URL
		// $rid == 14   => Tax for:                            #ORDER_URL
		// $rid == 15   => Payment received from Affiliate System
		// $rid == 16   => Processing fee for custom extra:    #ORDER_URL
		// $rid == 17   => Tax for custom extra:               #ORDER_URL
		// $rid == 18   => Custom extra:                       #ORDER_URL
		// $rid == 19   => Payment collected for custom extra: #ORDER_URL
		// $rid == 20   => Payoneer fee for:                   #ORDER_URL
		// $rid == 21   => Discount for:                       #ORDER_URL
		// $rid == 22   => Processing fee for tips:            #ORDER_URL
		// $rid == 23   => Tax for tips:                       #ORDER_URL
		// $rid == 24   => Tips:                               #ORDER_URL
		// $rid == 25   => Payment collected for tips:         #ORDER_URL

		$defaults = array(
			'tp'        => '',
			'reason'    => '',
			'amount'    => 0,
			'uid'       => '',
			'oid'       => '',
			'rid'       => '',
			'details'   => '',
			'payed_amt' => ''
		);

		$args = wp_parse_args( $args, $defaults );

		extract( $args );

		global $wpdb, $wpjobster_currencies_array;

		if ( $payed_amt != '' ) {
			$payedamount = $payed_amt;

		} elseif ( $oid > 0 ) {
			$r = $wpdb->get_row( $wpdb->prepare( "SELECT payedamount, mc_gross FROM {$wpdb->prefix}job_orders WHERE id = %d LIMIT 1", $oid ) );

			$currency    = WPJ_Form::post( 'mc_currency', wpj_get_site_curreny() );

			$pricearray  = explode( '|', $r->payedamount );
			$currency    = $pricearray[0];

			$payedamount = $r->mc_gross > 0 ? ( $amount * $pricearray[1] / $r->mc_gross ) : 0;
			$payedamount = $currency . '|' . wpj_number_format_special( $payedamount, 2 );

		} else {
			$payedamount = $wpjobster_currencies_array[0] . '|' . wpj_number_format_special( $amount, 2 );

		}

		$wpdb->insert(
			$wpdb->prefix . 'job_payment_transactions',
			array(
				'uid'         => $uid,
				'oid'         => $oid,
				'rid'         => $rid,
				'details'     => esc_sql( $details ),
				'reason'      => esc_sql( $reason ),
				'datemade'    => current_time( 'timestamp', 1 ),
				'amount'      => $amount,
				'tp'          => $tp,
				'payedamount' => $payedamount
			),
			array( '%d', '%d', '%d', '%s', '%s', '%d', '%d', '%d', '%s' )
		);

		wpj_update_user_credit_log( $wpdb->insert_id, $uid );

	}
}

if ( ! function_exists( 'wpj_save_log_file' ) ) {
	function wpj_save_log_file( $path, $text ) {
		$fp = fopen( $path, 'a' ); // open for writing only
		fwrite( $fp, $text . "\n" );
		fclose( $fp );
	}
}