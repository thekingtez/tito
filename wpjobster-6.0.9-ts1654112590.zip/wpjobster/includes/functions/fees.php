<?php
if ( ! function_exists( 'wpj_get_site_processing_fees_percent' ) ) {
	function wpj_get_site_processing_fees_percent() {
		return wpj_get_option( 'wpjobster_buyer_processing_fees_percent' );
	}
}

if ( ! function_exists( 'wpj_get_site_fee_by_amount' ) ) {
	function wpj_get_site_fee_by_amount( $raw_amount, $order_id = '', $uid = '' ) {

		$amount_fee = 0;

		// keep consistent if already calculated for job
		if ( $order_id ) {
			$order = wpj_get_order( $order_id );
			if ( $order && $order->mc_gross == $raw_amount ) {
				return apply_filters( 'wpj_site_fee_filter', $order->site_fees, $order->id, $raw_amount );
			}
		}

		// get seller ID
		if ( ! $uid && isset( $order->pid ) ) {
			$post = get_post( $order->pid );
			$uid  = $post->post_author;
		}

		// calculate by level or subscription
		$wpjobster_subscription_info = wpj_get_subscription_info( $uid );
		extract( $wpjobster_subscription_info );

		if ( $wpjobster_subscription_enabled == 'yes' && $wpjobster_fees_for_subscriber_enabled == 'yes' ) { // subscription

			if ( $wpjobster_subscription_fees && is_numeric( $wpjobster_subscription_fees ) ) {
				$percent_taken = $wpjobster_subscription_fees;
			} else {
				$percent_taken = 0;
			}

			$amount_fee = ( floatval( $percent_taken ) * floatval( $raw_amount ) ) / 100;

		} else { // level

			$wpjobster_enable_site_fee = wpj_get_option( 'wpjobster_enable_site_fee' );

			if ( $wpjobster_enable_site_fee == 'percent' ) { // percent

				$percent_taken = wpj_get_option( 'wpjobster_percent_fee_taken' );
				if ( ! is_numeric( $percent_taken ) ) {
					$percent_taken = 0;
				}

				$amount_fee = ( floatval( $percent_taken ) * floatval( $raw_amount ) ) / 100;

			} elseif ( $wpjobster_enable_site_fee == 'fixed' ) { // fixed

				$solid_fee_taken = wpj_get_option( 'wpjobster_solid_fee_taken' );
				if ( is_numeric( $solid_fee_taken ) ) {
					$amount_fee = $solid_fee_taken;
				} else {
					$amount_fee = 0;
				}

			} elseif ( $wpjobster_enable_site_fee == 'flexible' ) { // flexible

				if ( $uid != 0 ) {
					$user_level = wpj_get_user_level( $uid );
					$raw_amount_default = $raw_amount;

					$flexible_fee = wpj_get_option( 'flexible-fee-settings' );

					$wpjobster_percent_fee_taken_range1_base = isset( $flexible_fee['flexible_fee_over'][1] ) ? $flexible_fee['flexible_fee_over'][1] : 0;
					$wpjobster_percent_fee_taken_range2_base = isset( $flexible_fee['flexible_fee_over'][2] ) ? $flexible_fee['flexible_fee_over'][2] : 0;
					$wpjobster_percent_fee_taken_range3_base = isset( $flexible_fee['flexible_fee_over'][3] ) ? $flexible_fee['flexible_fee_over'][3] : 0;

					if ( ! is_numeric( $wpjobster_percent_fee_taken_range1_base ) ) {
						$wpjobster_percent_fee_taken_range1_base = 0;
					}

					if ( ! is_numeric( $wpjobster_percent_fee_taken_range2_base ) ) {
						$wpjobster_percent_fee_taken_range2_base = 0;
					}

					if ( ! is_numeric( $wpjobster_percent_fee_taken_range3_base ) ) {
						$wpjobster_percent_fee_taken_range3_base = 0;
					}


					if ( $wpjobster_percent_fee_taken_range3_base
						&& $raw_amount_default > $wpjobster_percent_fee_taken_range3_base ) {
						$amount_range = 3;

					} elseif ( $wpjobster_percent_fee_taken_range2_base
						&& $raw_amount_default > $wpjobster_percent_fee_taken_range2_base ) {
						$amount_range = 2;

					} elseif ( $wpjobster_percent_fee_taken_range1_base
						&& $raw_amount_default > $wpjobster_percent_fee_taken_range1_base ) {
						$amount_range = 1;

					} else {
						$amount_range = 0;

					}

					if ( isset( $flexible_fee['level' . $user_level . '_flexible_fee'][$amount_range] ) ) {
						$percent_taken = $flexible_fee['level' . $user_level . '_flexible_fee'][$amount_range];
						if ( ! is_numeric( $percent_taken ) ) {
							$percent_taken = $flexible_fee['level0_flexible_fee'][$amount_range];
							if ( ! is_numeric( $percent_taken ) ) {
								$percent_taken = 0;
							}
						}

					} else $percent_taken = 0;

				} else $percent_taken = 0;

				$amount_fee = ( $percent_taken * $raw_amount ) / 100;
			}
		}

		$amount_fee = apply_filters( 'wpj_site_fee_filter', $amount_fee, $order_id, $raw_amount );

		return round( $amount_fee, 2 );
	}
}

if ( ! function_exists( 'wpj_get_site_tax_percent' ) ) {
	function wpj_get_site_tax_percent( $country_code = '' ) {

		$wpjobster_tax_percent = 0;

		if ( wpj_get_option( 'wpjobster_enable_site_tax' ) == 'yes' ) {

			if ( ! $country_code )
				$country_code = get_user_meta( get_current_user_id(), 'country_code', true );

			$wpjobster_country_taxes_percentage = wpj_get_option( 'country-tax-settings' );

			$indx = array_search( strtolower( $country_code ), $wpjobster_country_taxes_percentage['country_name'] );

			if ( wpj_multidimensional_array_has_value( $wpjobster_country_taxes_percentage['country_name'] ) && isset( $wpjobster_country_taxes_percentage['country_tax'][$indx] ) ) {

				$wpjobster_tax_percent = $wpjobster_country_taxes_percentage['country_tax'][$indx];

			} else {

				$wpjobster_tax_percent = wpj_get_option( 'wpjobster_tax_percent' );

			}

		}

		$wpjobster_tax_percent = apply_filters( 'wpj_apply_fees_by_category', $wpjobster_tax_percent );

		return ( float )$wpjobster_tax_percent;
	}
}

if ( ! function_exists( 'wpj_get_site_tax_by_amount' ) ) {
	function wpj_get_site_tax_by_amount( $price, $extr_ttl = 0, $shipping = 0, $buyer_processing_fees = 0 ) {

		$tax_amount = 0;

		if ( wpj_bool_option( 'wpjobster_enable_site_tax' ) ) {

			if ( wpj_bool_option( 'wpjobster_enable_processingfee_tax' ) && $buyer_processing_fees > 0 ) {

				$total_taxable_amount = floatval( $price ) + floatval( $extr_ttl ) + floatval( $shipping ) + floatval( $buyer_processing_fees );

			} else {

				$total_taxable_amount = floatval( $price ) + floatval( $extr_ttl ) + floatval( $shipping );

			}

			$tax_amount = $total_taxable_amount * wpj_get_site_tax_percent() / 100;

		}

		return wpj_number_format_special( $tax_amount );
	}
}

if ( ! function_exists( 'wpj_get_site_processing_fee_by_amount' ) ) {
	function wpj_get_site_processing_fee_by_amount( $price, $extr_ttl, $shipping ) {

		$buyer_processing_fees_percent_amount = 0;

		$buyer_processing_fees_enabled = wpj_get_option( 'wpjobster_enable_buyer_processing_fees' );

		if ( $buyer_processing_fees_enabled == 'percent' ) {

			$buyer_processing_fees_percent = wpj_get_option( 'wpjobster_buyer_processing_fees_percent' );

			if ( $buyer_processing_fees_percent > 0 ) {

				$total_processing_amount = floatval( $price ) + floatval( $extr_ttl ) + floatval( $shipping );

				if ( $total_processing_amount > 0 ) {

					$buyer_processing_fees_percent_amount = $total_processing_amount * $buyer_processing_fees_percent / 100;

				} else {

					$buyer_processing_fees_percent_amount = 0;
				}

			} else {

				$buyer_processing_fees_percent_amount = 0;

			}
		}

		if ( $buyer_processing_fees_enabled == 'fixed' ) {

			$buyer_processing_fees_percent_amount = wpj_get_option( 'wpjobster_buyer_processing_fees' );

		}

		return wpj_number_format_special( $buyer_processing_fees_percent_amount );
	}
}