<?php
if ( ! function_exists( 'wpj_get_payment' ) ) {
	function wpj_get_payment( $args ) {

		$defaults = array(
			'id'              => false,
			'payment_type'    => 'job_purchase',
			'payment_type_id' => false,
		);

		$args = wp_parse_args( $args, $defaults );

		$id              = $args['id'];
		$payment_type    = $args['payment_type'];
		$payment_type_id = $args['payment_type_id'];

		global $wpdb;

		if ( $id ) {
			$payment = $wpdb->get_row( $wpdb->prepare(
				"
				SELECT * FROM {$wpdb->prefix}job_payment_received
				WHERE id = %d
				",
				$id
			) );

			return $payment;

		} elseif ( $payment_type_id ) {
			$payment = $wpdb->get_row( $wpdb->prepare(
				"
				SELECT * FROM {$wpdb->prefix}job_payment_received
				WHERE payment_type = %s
					AND payment_type_id = %d
				",
				$payment_type, $payment_type_id
			) );

			return $payment;

		}

		return false;
	}
}

if ( ! function_exists( 'wpj_get_query_payments' ) ) {
	function wpj_get_query_payments( $query_type, $query_status, $function_name, $class_name, $posts_per_page = '' ) {
		if ( ! $posts_per_page )
			$posts_per_page = wpj_get_option( 'posts_per_page' ) ? wpj_get_option( 'posts_per_page' ) : 12;

		$data = new WPJ_Load_More_Queries(
			array(
				'query_type'        => $query_type,
				'query_status'      => $query_status,
				'function_name'     => $function_name,
				'posts_per_page'    => $posts_per_page,
				'row_extra_classes' => $class_name
			)
		);

		return $data;
	}
}

if ( ! function_exists( 'wpj_get_payment_info_by_url' ) ) {
	function wpj_get_payment_info_by_url( $var = '' ) {
		global $wp_query;

		$pid = $payment_type = $order = $custom_extra = $tip = false;

		$oid = WPJ_Form::request( 'oid' );
		if ( ! $oid && isset( $wp_query->query_vars['oid'] ) ) $oid = $wp_query->query_vars['oid'];

		$redirect_link = get_bloginfo( 'url' );

		$jobid = isset( $_REQUEST['jobid'] ) ? $_REQUEST['jobid'] : '';
		if ( ! $jobid && isset( $wp_query->query_vars['jobid'] ) ) $jobid = $wp_query->query_vars['jobid'];

		// Job purchase
		if ( $jobid ) {
			$payment_type  = 'job_purchase';
			$pid           = WPJ_Form::request( 'jobid' );
			$redirect_link = get_permalink( $pid );
		}

		// Custom extra purchase
		if ( $oid && isset( $_REQUEST['custom_extra'] ) ) {
			$payment_type    = 'custom_extra';
			$order           = wpj_get_order( $oid );
			$pid             = $order->pid;

			$custom_extra_id = WPJ_Form::request( 'custom_extra', '' );
			$custom_extras   = json_decode( $order->custom_extras );
			$custom_extra    = $custom_extras[$custom_extra_id];

			$redirect_link   = wpj_get_order_link( $oid );
		}

		// Tips purchase
		if ( $oid && isset( $_REQUEST['tips'] ) ) {
			$payment_type  = 'tips';
			$order         = wpj_get_order( $oid );
			$pid           = $order->pid;

			$tips_id       = WPJ_Form::request( 'tips', '' );
			$tips          = json_decode( $order->tips );
			$tip           = $tips[$tips_id];

			$redirect_link = wpj_get_order_link( $oid );
		}

		$vars_arr = array(
			'payment_type'  => $payment_type,
			'pid'           => $pid,
			'post'          => ! empty( $pid ) ? get_post( $pid ) : array(),
			'order'         => $order,
			'oid'           => $oid,
			'custom_extra'  => $custom_extra,
			'tip'           => $tip,
			'redirect_link' => $redirect_link
		);

		return $var ? $vars_arr[$var] : $vars_arr;
	}
}

if ( ! function_exists( 'wpj_update_user_earned_amount' ) ) {
	function wpj_update_user_earned_amount( $uid = '', $order_price = 0, $force_recheck = false ) {

		if ( ! $uid ) { $uid = get_current_user_id(); }

		global $wpdb;

		$user_total_earnings = get_user_meta( $uid, 'user_total_earnings', true );

		if ( $user_total_earnings && $order_price && ! $force_recheck ) {
			update_user_meta( $uid, 'user_total_earnings', $user_total_earnings + $order_price );
		} else {
			$query = "
				SELECT SUM(mc_gross) AS total_earnings
				FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
				WHERE posts.post_author        = {$uid}
					AND posts.ID               = orders.pid
					AND orders.done_seller     = '1'
					AND orders.done_buyer      = '1'
					AND orders.completed       = '1'
					AND orders.closed          = '0'
					AND ( orders.clearing_period = '1' || orders.clearing_period = '2' )
			";

			$result = $wpdb->get_results( $query , OBJECT );

			if ( isset( $result[0] ) ) {
				update_user_meta( $uid, 'user_total_earnings', $result[0]->total_earnings );
			}
		}
	}
}

if ( ! function_exists( 'wpj_update_completed_orders_amount' ) ) {
	function wpj_update_completed_orders_amount( $uid = '', $order_price = 0, $force_recheck = false ) {

		if ( ! $uid ) { $uid = get_current_user_id(); }

		global $wpdb;

		$user_total_spendings = get_user_meta( $uid, 'user_total_spendings', true );

		if ( $user_total_spendings && $order_price && ! $force_recheck ) {
			update_user_meta( $uid, 'user_total_spendings', $user_total_spendings + $order_price );
		} else {
			$query = "
				SELECT SUM(mc_gross) AS total_spendings
				FROM {$wpdb->prefix}job_orders orders
				WHERE orders.uid = {$uid}
					AND orders.completed   = '1'
					AND orders.done_buyer  = '1'
					AND orders.done_seller = '1'
					AND orders.closed      = '0'
			";

			$result = $wpdb->get_results( $query, OBJECT );

			if ( isset( $result[0] ) ) {
				update_user_meta( $uid, 'user_total_spendings', $result[0]->total_spendings );
			}
		}

	}
}

if ( ! function_exists( 'wpj_get_sales_orders' ) ) {
	function wpj_get_sales_orders( $uid = '', $order_status = 'active', $ret_type = 'count' ) {

		if ( ! $uid ) $uid = wpj_get_user_id();

		global $wpdb;

		if ( $order_status ) {
			if ( $order_status == 'active' ) {

				$query = "
					SELECT DISTINCT orders.id
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.post_author      = '{$uid}'
						AND posts.ID             = orders.pid
						AND orders.done_seller   = '0'
						AND orders.done_buyer    = '0'
						AND orders.date_finished = '0'
						AND orders.closed        = '0'
						AND payment_status      != 'pending'
					ORDER BY orders.id DESC
				";

			} elseif ( $order_status == 'pending-confirmation' ) {

				$query = $wpdb->prepare(
					"
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders,
						 {$wpdb->prefix}posts posts
					WHERE posts.post_author = %d
						AND posts.ID = orders.pid
						AND orders.done_seller = '0'
						AND orders.done_buyer = '0'
						AND orders.date_finished = '0'
						AND orders.closed = '0'
						AND orders.seller_confirmation = '0'
						AND orders.payment_status != 'pending'
					ORDER BY orders.id DESC
					",
					$uid
				);

			} elseif ( $order_status == 'pending-payment' ) {

				$query = "
					SELECT DISTINCT orders.id
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.post_author      = '{$uid}'
						AND posts.ID             = orders.pid
						AND orders.done_seller   = '0'
						AND orders.done_buyer    = '0'
						AND orders.date_finished = '0'
						AND orders.closed        = '0'
						AND ( payment_status     = 'pending'
							OR payment_status    = 'processing' )
					ORDER BY orders.id DESC
				";

			} elseif ( $order_status == 'delivered' ) {

				$query = "
					SELECT DISTINCT orders.id
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.post_author    = '{$uid}'
						AND posts.ID           = orders.pid
						AND orders.done_seller = '1'
						AND orders.done_buyer  = '0'
						AND orders.closed      = '0'
					ORDER BY orders.id DESC
				";

			} elseif ( $order_status == 'completed' ) {

				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.post_author    = '{$uid}'
						AND posts.ID           = orders.pid
						AND orders.done_seller = '1'
						AND orders.done_buyer  = '1'
						AND orders.closed      = '0'
					ORDER BY orders.id DESC
				";

			} elseif ( $order_status == 'cancelled' ) {

				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.post_author = '{$uid}'
						AND posts.ID        = orders.pid
						AND orders.closed   = '1'
					ORDER BY orders.id DESC
				";

			} elseif ( $order_status == 'delivered_on_time_percent' ) {

				$query = "
					SELECT AVG( CASE WHEN date_finished <= expected_delivery THEN 100.0 ELSE 0.0 END ) AS delivered_on_time_percent
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.post_author    = '{$uid}'
						AND posts.ID           = orders.pid
						AND orders.done_seller = '1'
						AND orders.done_buyer  = '0'
						AND orders.closed      = '0'
				";

			} elseif ( $order_status == 'completed_percent' ) {

				$query = "
					SELECT AVG( CASE WHEN completed = 1 THEN 100.0 ELSE 0.0 END ) AS completed_percent
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.post_author    = '{$uid}'
						AND posts.ID           = orders.pid
						AND orders.done_seller = '1'
						AND orders.done_buyer  = '1'
						AND orders.closed      = '0'
				";

			} elseif ( $order_status == 'response_rate' ) {

				$query = "
					SELECT AVG( CASE WHEN force_cancellation != 7 THEN 100.0 ELSE 0.0 END ) AS response_rate
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.post_author    = '{$uid}'
						AND posts.ID           = orders.pid
				";

			}

			if ( isset( $query ) ) {

				if ( $ret_type == 'query' )
					return apply_filters( 'wpj_sales_' . $order_status . '_orders_query_filter', $query );

				if ( $ret_type == 'result' )
					return apply_filters( 'wpj_sales_' . $order_status . '_orders_result_filter', $wpdb->get_results( $query ) );

				if ( $ret_type == 'row' )
					return apply_filters( 'wpj_sales_' . $order_status . '_orders_result_filter', $wpdb->get_row( $query ) );

				if ( $ret_type == 'var' )
					return apply_filters( 'wpj_sales_' . $order_status . '_orders_result_filter', $wpdb->get_var( $query ) );

				if ( $ret_type == 'count' )
					return apply_filters( 'wpj_sales_' . $order_status . '_orders_count_filter', count( $wpdb->get_results( $query ) ) );

			}
		}

		return 0;

	}
}

if ( ! function_exists( 'wpj_get_shopping_orders_count' ) ) {
	function wpj_get_shopping_orders_count( $uid = '', $order_status = 'active' ) {

		if ( ! $uid ) $uid = wpj_get_user_id();

		global $wpdb;

		if ( $order_status ) {
			if ( $order_status == 'active' ) {

				$query = "
					SELECT id
					FROM {$wpdb->prefix}job_orders
					WHERE uid               = {$uid}
						AND done_seller     = '0'
						AND done_buyer      = '0'
						AND date_finished   = '0'
						AND closed          = '0'
						AND payment_status != 'pending'
				";

			} elseif ( $order_status == 'pending-confirmation' ) {

				$query = $wpdb->prepare(
					"
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders,
						 {$wpdb->prefix}posts posts
					WHERE orders.uid = %d
						AND posts.ID = orders.pid
						AND orders.done_seller = '0'
						AND orders.done_buyer = '0'
						AND orders.date_finished = '0'
						AND orders.closed = '0'
						AND orders.seller_confirmation = '0'
						AND orders.payment_status != 'pending'
					ORDER BY orders.id DESC
					",
					$uid
				);

			} elseif ( $order_status == 'pending-review' ) {

				$query = "
					SELECT id
					FROM {$wpdb->prefix}job_orders
					WHERE uid           = {$uid}
						AND done_seller = '1'
						AND done_buyer  = '0'
						AND closed      = '0'
				";

			} elseif ( $order_status == 'completed' ) {

				$query = "
					SELECT id
					FROM {$wpdb->prefix}job_orders
					WHERE uid           = {$uid}
						AND completed   = '1'
						AND done_seller = '1'
						AND done_buyer  = '1'
						AND closed      = '0'
					ORDER BY id DESC
				";

			} elseif ( $order_status == 'pending-payment' ) {

				$query = "
					SELECT id
					FROM {$wpdb->prefix}job_orders
					WHERE uid                 = {$uid}
						AND done_seller       = '0'
						AND done_buyer        = '0'
						AND date_finished     = '0'
						AND closed            = '0'
						AND ( payment_status  = 'pending'
							OR payment_status = 'processing' )
				";

			} elseif ( $order_status == 'cancelled' ) {

				$query = "
					SELECT id
					FROM {$wpdb->prefix}job_orders
					WHERE uid      = {$uid}
						AND closed = '1'
					ORDER BY id DESC
				";

			} elseif ( $order_status == 'active_custom_offer' ) {

				$query = "
					SELECT orders.id
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE orders.pid               = posts.ID
						AND orders.uid             = {$uid}
						AND orders.done_seller     = '0'
						AND orders.done_buyer      = '0'
						AND orders.date_finished   = '0'
						AND orders.closed          = '0'
						AND orders.payment_status != 'pending'
						AND posts.post_type        = 'offer'
				";

			} elseif ( $order_status == 'completed_custom_offer' ) {

				$query = "
					SELECT orders.id
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE orders.pid           = posts.ID
						AND orders.uid         = {$uid}
						AND orders.completed   = '1'
						AND orders.done_seller = '1'
						AND orders.done_buyer  = '1'
						AND orders.closed      = '0'
						AND posts.post_type    = 'offer'
					ORDER BY orders.id DESC
				";

			} elseif ( $order_status == 'cancelled_custom_offer' ) {

				$query = "
					SELECT orders.id
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE orders.pid        = posts.ID
					AND orders.uid          = {$uid}
						AND orders.closed   = '1'
						AND posts.post_type = 'offer'
					ORDER BY orders.id DESC
				";

			}

			if ( isset( $query ) ) {
				return apply_filters( 'wpj_shopping_' . $order_status . '_orders_count_filter', count( $wpdb->get_results( $query ) ) );
			}
		}

		return 0;

	}
}

if ( ! function_exists( 'wpj_get_total_amount_spent' ) ) {
	function wpj_get_total_amount_spent( $by_user = '' ) {
		if ( $by_user ) {
			return wpj_get_total_spent_price( get_current_user_id() );

		} else {
			global $wpdb;

			$query = "
				SELECT * FROM {$wpdb->prefix}job_orders WHERE done_seller = '0' AND done_buyer = '0' AND date_finished = '0' AND closed = '0' AND payment_status != 'pending'
				UNION ALL
				SELECT * FROM {$wpdb->prefix}job_orders WHERE completed = '1' OR done_seller = '1'
			";

			$total_spent_results = $wpdb->get_results( $query );

			$transaction_amount_total = 0;

			if ( $total_spent_results ) {
				foreach ( $total_spent_results as $key => $row ) {

					$trans_amount = explode( '|', $row->final_paidamount );

					if ( $trans_amount[0] && $trans_amount[0] != wpj_get_site_default_curreny() ) {
						$currency_from = $trans_amount[0];
						$currency_to   = wpj_get_site_default_curreny();

						$transaction_amount = wpj_get_exchanged_value( $trans_amount[1], $currency_from, $currency_to );
					} else {
						$transaction_amount = $trans_amount[1];
					}

					$transaction_amount_total += floatval( $transaction_amount );
				}
			}

			return $transaction_amount_total > 0 ? wpj_show_price( $transaction_amount_total ) : "0";
		}
	}
}

if ( ! function_exists( 'wpj_get_total_completed_orders' ) ) {
	function wpj_get_total_completed_orders( $by_user = '' ) {
		if ( $by_user ) {

			if ( $by_user != 'sales' ) {
				return wpj_get_shopping_orders_count( get_current_user_id(), 'completed' ) ? intval( wpj_get_shopping_orders_count( get_current_user_id(), 'completed' ) ) : __( 'None', 'wpjobster' );
			} else {
				return wpj_get_sales_orders( get_current_user_id(), 'completed' ) ? intval( wpj_get_sales_orders( get_current_user_id(), 'completed' ) ) : __( 'None', 'wpjobster' );
			}

		} else {

			global $wpdb;
			return count( $wpdb->get_results( "SELECT id FROM {$wpdb->prefix}job_orders WHERE completed = '1'" ) );

		}
	}
}

if ( ! function_exists( 'wpj_save_withdrawal_request' ) ) {
	function wpj_save_withdrawal_request() {
		global $wpdb, $wpjobster_currencies_array;

		$post_exist = false;
		if ( wpj_get_withdrawals_payment_gateways() ) {
			foreach ( wpj_get_withdrawals_payment_gateways() as $key => $value ) {
				if ( $_POST['method'] == $value . '_withdraw' ) {
					$post_exist = true;
				}
			}
		}

		$uid = get_current_user_id();

		$currency = wpj_get_site_curreny();

		$details = '';
		if ( $post_exist ) {
			$details = isset( $_POST['details'] ) ? esc_sql( trim( $_POST['details'] ) ) : '';

			if ( $_POST['method'] == 'banktransfer_withdraw' ) { // bank transfer
				$details = '';

				foreach ( array(
					"bank_bank_name"        => __( 'Bank Name', 'wpjobster' ),
					"bank_bank_address"     => __( 'Bank Address', 'wpjobster' ),
					"bank_account_name"     => __( 'Account Name', 'wpjobster' ),
					"bank_account_number"   => __( 'Account Number', 'wpjobster' ),
					"bank_account_currency" => __( 'Account Currency', 'wpjobster' ),
					"bank_additional_info"  => __( 'Additional Info', 'wpjobster' ),
				) as $field_key => $field_name ) {
					if ( apply_filters( 'wpj_payments_display_' . $field_key . '_field', true ) ) {
						$details .= $field_name . ': ' . get_user_meta( $uid, $field_key, true ) . '<br>';
					}
				}

				$details = esc_sql( wpj_get_allowed_html_tags_for_wysiwyg( $details ) );
			}
		}

		$email  = isset( $_POST['email'] ) ? esc_sql( trim( $_POST['email'] ) ) : '';

		$amount = isset( $_POST['amount'] ) ? trim( $_POST['amount'] ) : '';

		$amount_default = wpj_get_exchanged_value( $amount, $currency, $wpjobster_currencies_array[0] );

		$wpjobster_withdraw_limit = wpj_get_option( 'wpjobster_withdraw_limit' );
		if ( empty( $wpjobster_withdraw_limit ) OR ! is_numeric( $wpjobster_withdraw_limit ) ) $wpjobster_withdraw_limit = 10;

		$tm = current_time( 'timestamp', 1 );

		$err_content = '';
		if ( ! is_numeric( $amount ) || $amount < 0 ) {
			$err_content = __( 'Provide a well formated amount.', 'wpjobster' );

		} elseif ( ! empty( $_POST['email'] ) && wpj_is_email_valid( $email ) == false ) {
			$err_content =  __( 'Invalid email provided.', 'wpjobster' );

		} elseif ( $amount_default < $wpjobster_withdraw_limit ) {
			$err_content = sprintf( __( 'The amount must be higher than: %s.', 'wpjobster' ), wpj_show_price( $wpjobster_withdraw_limit ) );

		} elseif ( wpj_get_user_credit( get_current_user_id() ) < $amount_default ) {
			$err_content = __( 'Your balance is smaller than the amount requested.', 'wpjobster' );

		}

		if ( ! $err_content ) {
			$method = '';

			if ( $_POST['method'] == 'paypal_withdraw' )       $method = "PayPal";
			if ( $_POST['method'] == 'payoneer_withdraw' )     $method = "Payoneer";
			if ( $_POST['method'] == 'banktransfer_withdraw' ) $method = "Bank";

			$method = apply_filters( 'wpjobster_withdraw_method_filter', $method );

			if ( $method ) {

				$tm = current_time( 'timestamp', 1 );

				$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_withdraw WHERE uid = '{$uid}' AND datemade = '{$tm}'" );

				if ( count( $r ) == 0 ) {
					$payedamount = $currency . '|' . wpj_number_format_special( $amount, 1 );

					if ( wpj_get_option( 'wpjobster_enable_withdraw_email_verification' ) == 'yes' ) {
						$act_key = md5( uniqid( mt_rand(), true ) );
					} else {
						$act_key = '';
					}

					$wpdb->query( "INSERT INTO {$wpdb->prefix}job_withdraw ( payeremail, methods, amount, datemade, uid, payedamount, activation_key ) VALUES( '{$details}', '{$method}', '{$amount_default}', '{$tm}', '{$uid}', '{$payedamount}', '{$act_key}' )" );

					$cr = wpj_get_user_credit( $uid );
					wpj_update_user_credit( $uid, $cr - $amount_default );

					do_action( 'wpj_after_withdrawal_request', $details, $method, $amount_default, $tm, $uid, $payedamount, $act_key );

					$user_data = get_userdata( $uid );

					$withdrawal_email_verification = get_permalink( wpj_get_option( 'wpjobster_verify_email_page_id' ) ) . "?username=" . $user_data->user_nicename . "&key=" . $act_key . "&action=withdrawal";

					wpj_notify_user_translated( 'withdraw_req', $uid, array( '##amount_withdrawn##' => wpj_show_price_precise( $amount, 2, $currency ), '##withdraw_method##' => wpj_translate_string( $method ), '##withdrawal_email_verification##' => $withdrawal_email_verification ) );

					// Email the admin
					if ( wpj_get_option( 'wpjobster_enable_withdraw_email_verification' ) != 'yes' ) {
						wpj_notify_user_translated( 'admin_new_withdrawal_request', 'admin', array( '##withdrawal_username##' => wpj_get_user_display_type( $uid ), '##withdrawal_amount##' => wpj_show_price_precise( $amount, 2, $currency ), '##withdrawal_method##' => wpj_translate_string( $method ) ) );
					}

				}

			}

			echo json_encode( array( 'status' => 'success' ) );

		} else {
			echo json_encode( array( 'status' => 'error', 'error' => $err_content ) );

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}