<?php
if ( ! function_exists( 'wpj_fnc_to_shortcode' ) ) {
	function wpj_fnc_to_shortcode( $atts = '', $function_name = '', $args = array() ) {
		ob_start();

		$array_params = isset( $args['args'] ) ? true : false; // functions with array params

		if ( $array_params ) $args = $args['args'];

		$args = wp_parse_args( $atts, $args );

		if ( $array_params ) $args = array( $args );

		if ( function_exists( $function_name ) ) {
			if ( $args ) call_user_func_array( $function_name, $args );
			else call_user_func( $function_name );
		}

		return ob_get_clean();
	}
}

if ( ! function_exists( 'wpj_get_shortcode_args' ) ) {
	function wpj_get_shortcode_args( $atts = '' ) {
		if ( wpj_is_page( 'wpjobster_post_new_page_id' ) || ( isset( $atts['parent'] ) && $atts['parent'] == 'job' ) ) {
			$atts['parent']  = 'job';
			$atts['item_id'] = WPJ_Form::get( 'jobid' );

			$value = empty( $_POST[$atts['name']] ) ? get_post_meta( $atts['item_id'], $atts['name'], true ) : $_POST[$atts['name']];

			$atts['value'] = is_array( $value ) ? $value : stripslashes( wpj_validate_input_content( $value ) );

		} elseif ( wpj_is_page( 'wpjobster_new_request_page_id' ) || ( isset( $atts['parent'] ) && $atts['parent'] == 'request' ) ) {
			$atts['parent']  = 'request';
			$atts['item_id'] = WPJ_Form::get( 'requestid' );

			$value = empty( $_POST[$atts['name']] ) ? get_post_meta( $atts['item_id'], $atts['name'], true ) : $_POST[$atts['name']];

			$atts['value'] = is_array( $value ) ? $value : stripslashes( wpj_validate_input_content( $value ) );

		} else {
			$atts['parent']  = 'up';
			$atts['item_id'] = get_current_user_id();

			$value = empty( $_POST[$atts['name']] ) ? wpj_user( $atts['item_id'], $atts['name'] ) : $_POST[$atts['name']];

			$atts['value'] = is_array( $value ) ? $value : stripslashes( wpj_validate_input_content( $value ) );

		}

		return $atts;
	}
}

if ( ! function_exists( 'wpj_get_email_shortcode_attr_value' ) ) {
	function wpj_get_email_shortcode_attr_value( $shortcode = array(), $param = '' ) {
		if ( isset( $shortcode[1] ) ) {

			$shortcode_atts = explode( ' ', $shortcode[1] );

			if ( $shortcode_atts ) {
				foreach ( $shortcode_atts as $key => $value ) {

					if ( strpos( $value, $param ) !== false ) {
						$val_arr = explode( '=', $value );
						return ! empty( $val_arr[1] ) ? $val_arr[1] : false;
					}

				}
			}

		}

		return false;
	}
}

/**
 * List Latest Jobs - Email Shortcode {job_listings}
 *
 * arguments      | accepts         | default
 * ----------------------------------------------------
 * category       | (id/slug/name)  | all
 * featured       | true/false      | false
 * posts_per_page | (int)           | 12
 */
if ( ! function_exists( 'wpj_email_job_listings_shortcode' ) ) {
	function wpj_email_job_listings_shortcode( $text = '', $user_data = '', $email = '' ) {

		$user    = isset( $user_data->email ) ? get_user_by( 'email', $user_data->email ) : ( $email ? get_user_by( 'email', $email ) : '' );
		$user_id = is_object( $user ) ? $user->ID : get_current_user_id();

		/* LATEST JOBS */
		if ( strpos( $text, '{job_listings' ) !== false ) {

			preg_match( '~\{job_listings([^}]*)\}~', $text, $shortcode );
			$shortcode = array_map( 'trim', $shortcode );

			$posts_per_page = wpj_get_email_shortcode_attr_value( $shortcode, 'posts_per_page' );
			$posts_per_page = $posts_per_page ? intval( $posts_per_page ) : 12;

			$category = wpj_get_email_shortcode_attr_value( $shortcode, 'category' );
			$featured = wpj_get_email_shortcode_attr_value( $shortcode, 'featured' );

			// Category
			$this_term = ctype_digit( $category ) || is_int( $category ) ? get_term_by( 'id', $category, 'job_cat' ) : false;
			$this_term = ! $this_term ? get_term_by( 'slug', $category, 'job_cat' ) : $this_term;
			$this_term = ! $this_term ? get_term_by( 'name', $category, 'job_cat' ) : $this_term;

			$category_id = isset( $this_term->term_id ) && is_numeric( $this_term->term_id ) ? $this_term->term_id : 0;

			$tax_query = $category_id ? array(
				array(
					'taxonomy' => 'job_cat',
					'field'    => 'term_id',
					'terms'    => array( $category_id ),
				),
			) : array();

			// Query
			$args = array(
				'post_status'    =>'publish',
				'posts_per_page' => $posts_per_page,
				'post_type'      => 'job',
				'tax_query'      => $tax_query,
				'order'          => 'DESC',
				'meta_query'     => array(
					array(
						'key'     => 'active',
						'value'   => '1',
						'compare' => '='
					)
				)
			);

			// Featured
			if ( $featured && wpj_get_option( 'wpjobster_featured_enable' ) == 'yes' ) {
				$args['meta_key'] = 'home_featured_now';
				$args['orderby']  = array( 'meta_value' => 'ASC', 'date' => 'DESC' );
			} else {
				$args['orderby']  = 'date';
			}

			ob_start();
			wpj_display_card_email_layout( get_posts( $args ) );
			$jobs_list = ob_get_contents();
			ob_end_clean();

			$text = str_replace( $shortcode[0], $jobs_list, $text );
		}

		/* JOBS VIEWED */
		if ( strpos( $text, '{job_viewed_listings' ) !== false ) {

			preg_match( '~\{job_viewed_listings([^}]*)\}~', $text, $shortcode );
			$shortcode = array_map( 'trim', $shortcode );

			$user_id_param = wpj_get_email_shortcode_attr_value( $shortcode, 'user_id' );
			$user_id = $user_id_param ? intval( $user_id_param ) : $user_id;

			$posts_per_page = wpj_get_email_shortcode_attr_value( $shortcode, 'posts_per_page' );
			$posts_per_page = $posts_per_page ? intval( $posts_per_page ) : 12;

			$args = array(
				'post_type'           => 'job',
				'posts_per_page'      => $posts_per_page,
				'post__in'            => get_user_meta( $user_id, 'last_viewed', true ),
				'ignore_sticky_posts' => true,
				'orderby'             => 'post__in'
			);

			$results = get_user_meta( $user_id, 'last_viewed', true ) ? get_posts( $args ) : '';

			ob_start();
			wpj_display_card_email_layout( $results );
			$jobs_list = ob_get_contents();
			ob_end_clean();

			$text = str_replace( $shortcode[0], $jobs_list, $text );

		}

		/* JOBS CHECKOUT VIEWED */
		if ( strpos( $text, '{job_checkout_viewed_listings' ) !== false ) {

			preg_match( '~\{job_checkout_viewed_listings([^}]*)\}~', $text, $shortcode );
			$shortcode = array_map( 'trim', $shortcode );

			$user_id_param = wpj_get_email_shortcode_attr_value( $shortcode, 'user_id' );
			$user_id = $user_id_param ? intval( $user_id_param ) : $user_id;

			$posts_per_page = wpj_get_email_shortcode_attr_value( $shortcode, 'posts_per_page' );
			$posts_per_page = $posts_per_page ? intval( $posts_per_page ) : 12;

			$args = array(
				'post_type'           => 'job',
				'posts_per_page'      => $posts_per_page,
				'post__in'            => get_user_meta( $user_id, 'last_checkout_viewed', true ),
				'ignore_sticky_posts' => true,
				'orderby'             => 'post__in'
			);

			$results = get_user_meta( $user_id, 'last_checkout_viewed', true ) ? get_posts( $args ) : '';

			ob_start();
			wpj_display_card_email_layout( $results );
			$jobs_list = ob_get_contents();
			ob_end_clean();

			$text = str_replace( $shortcode[0], $jobs_list, $text );

		}

		return apply_filters( 'wpj_email_job_listings_filter', $text, $user_data );
	}
}