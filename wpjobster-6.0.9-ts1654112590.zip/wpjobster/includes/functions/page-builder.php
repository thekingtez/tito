<?php

/**
 * Returns true if currently editing the page with a known page builder
 * Supports Brizy and Visual Composer (WPBakery)
 *
 * Undefined if called too early, for example in hooks before wp_load!
 */
if ( ! function_exists( 'wpj_is_pagebuilder_editor' ) ) {
	function wpj_is_pagebuilder_editor() {
		global $pagenow;

		if ( wpj_is_visual_composer_editor()
			|| wpj_is_brizy_editor()
			|| ( $pagenow == 'post.php' && isset( $_GET['action'] ) && $_GET['action'] == 'edit' )
		) {
			return true;
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_is_brizy_editor' ) ) {
	function wpj_is_brizy_editor(){
		if ( isset( $_GET['brizy-edit'] ) || isset( $_GET['brizy-edit-iframe'] ) || ( isset( $_POST['action'] ) && $_POST['action'] == 'brizy_shortcode_content' ) )
			return true;

		return false;
	}
}

if ( ! function_exists( 'wpj_is_visual_composer_editor' ) ) {
	function wpj_is_visual_composer_editor(){
		global $vc_is_inline;

		if ( function_exists( 'vc_is_inline' ) ) {
			if ( vc_is_inline() ) return true;
			else return false;

		} else return false;
	}
}