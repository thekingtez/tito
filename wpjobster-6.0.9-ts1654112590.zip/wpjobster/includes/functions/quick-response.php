<?php
if ( ! function_exists( 'wpj_save_quick_response' ) ) {
	function wpj_save_quick_response( $uid = '', $id = '', $name = '', $content = '' ) {

		$uid     = $uid ? $uid : WPJ_Form::post( 'uid' );
		$id      = $id ? $id : WPJ_Form::post( 'id' );
		$name    = $name ? $name : WPJ_Form::post( 'name' );
		$content = $content ? $content : WPJ_Form::post( 'content' );

		if ( $id && $name && $content ) {

			$quick_responses = get_user_meta( get_current_user_id(), 'quick_responses', true );

			if ( ! $quick_responses || ! is_array( $quick_responses ) ) $quick_responses = array();

			$quick_responses[$id] = array( 'name' => $name, 'content' => $content );

			update_user_meta( get_current_user_id(), 'quick_responses', $quick_responses );

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_delete_quick_response' ) ) {
	function wpj_delete_quick_response( $uid = '', $id = '' ) {

		$uid = $uid ? $uid : WPJ_Form::post( 'uid' );
		$id  = $id ? $id : WPJ_Form::post( 'id' );

		if ( $id ) {
			$quick_responses = get_user_meta( get_current_user_id(), 'quick_responses', true );
			unset( $quick_responses[$id] );

			update_user_meta( get_current_user_id(), 'quick_responses', $quick_responses );
		}

		if ( wpj_is_ajax_call() ) wp_die();

	}
}

if ( ! function_exists( 'wpj_delete_all_quick_responses' ) ) {
	function wpj_delete_all_quick_responses() {
		delete_user_meta( get_current_user_id(), 'quick_responses' );

		if ( wpj_is_ajax_call() ) wp_die();
	}
}