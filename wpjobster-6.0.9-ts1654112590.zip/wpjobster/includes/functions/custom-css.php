<?php
if ( ! function_exists( 'wpj_get_custom_colour' ) ) {
	function wpj_get_custom_colour( $colour = '' ) {
		return $colour ? 'style="color: ' . $colour . '"' : '';
	}
}

if ( ! function_exists( 'wpj_apply_custom_css' ) ) {
	function wpj_apply_custom_css() {
		global $jobster_design;

		$primary_color = ! empty( $jobster_design['site_primary_color'] ) ? $jobster_design['site_primary_color'] : '#20c497';

		$logo_spacing = ! empty( $jobster_design['logo_spacing'] ) ? $jobster_design['logo_spacing'] : array( 'padding-top' => 10, 'padding-bottom' => 10 );
		$logo_height  = ! empty( $jobster_design['logo_height']['height'] ) ? intval( $jobster_design['logo_height']['height'] ) : 45;

		$wrapper = $logo_height + intval( $logo_spacing['padding-top'] ) + intval( $logo_spacing['padding-bottom'] ); ?>

		<style>

			/* Site width */
			<?php if ( empty( $jobster_design['site_width']['units'] ) || ( ! empty( $jobster_design['site_width']['units'] ) && $jobster_design['site_width']['units'] != '%' ) ) { ?>

				<?php if ( ! empty( $jobster_design['site_width']['width'] ) ) { ?>

					.main-content {
						--width: <?php echo intval( $jobster_design['site_width']['width'] ); ?>px;
					}

				<?php } ?>

			<?php } ?>

			/* Header bg image */
			<?php if ( isset( $jobster_design['header_background_type'] ) && $jobster_design['header_background_type'] == 'image' && ! empty( $jobster_design['header_background_image'] ) ) { ?>

				.header-wrapper,
				.header-wrapper .fixed {
					background-image: url( "<?php echo $jobster_design['header_background_image']['url']; ?>" );
					background-size: cover;
					background-position: center center;
					background-repeat: no-repeat;
				}

			<?php } ?>

			/* Header hover menu item bottom line */
			<?php if ( ! empty ( $jobster_design['header_links_color']['hover'] ) ) { ?>

				.ui.segments.middle-menu > div > ul > li:hover:after {
					background-color: <?php echo $jobster_design['header_links_color']['hover']; ?>;
				}

			<?php } ?>

			/* Left mobile menu icon text-shadow */
			.header-wrapper.header-mobile i.thick.bars.icon {
				text-shadow: 0 0.1em 0 <?php echo $jobster_design['left_mobile_menu_colour_icon_options_header']; ?>;
			}

			/* Video play icon Slider */
			<?php if ( $jobster_design['enable_video_icon_cards'] != true ) { ?>

				.wpj-card-style-3.ui.card .wpj-carousel.owl-carousel .owl-video-play-icon {
					display: none;
				}

			<?php } ?>

			/* Footer bg image */
			<?php if ( isset( $jobster_design['footer_background_type'] ) && $jobster_design['footer_background_type'] == 'image' && ! empty( $jobster_design['footer_background_image'] ) ) { ?>

				.footer-wrapper {
					background-image: url( '<?php echo $jobster_design['footer_background_image']['url']; ?>' );
					background-size: cover;
					background-position: center center;
					background-repeat: no-repeat;
				}

			<?php } ?>

			/* Footer logo grayscale */
			<?php if ( $jobster_design['logo_grayscale_enable'] == true ) { ?>

				.footer-wrapper .logo-holder img {
					-webkit-filter: grayscale(100%);
					filter: grayscale(100%);
					opacity: .7;
				}

			<?php } ?>

			<?php if ( $logo_height > 0 ) { ?>

				.header-wrapper-top {
					height: <?php echo $wrapper. 'px'; ?>;
				}

				.home:not(.logged-in) .header-wrapper .logo-holder img {
					height: calc( <?php echo $logo_height . 'px'; ?> + 16px );
				}

				.home:not(.logged-in) .header-wrapper-top.fixed .logo-holder img,
				.home:not(.logged-in) .header-mobile .header-wrapper-top .logo-holder img {
					height: calc( <?php echo $logo_height . 'px'; ?> - 4px );
				}

				/* Private message */
				@media only screen and (min-width:992px) {
					.ui.segment.wpj-messenger,
					.wpj-messenger {
						height: calc(100vh - <?php echo $wrapper. 'px'; ?> - 101px); /* Fallback */
						height: calc((var(--vh, 1vh) * 100) - <?php echo $wrapper. 'px'; ?> - 101px);
					}
				}

			<?php } ?>

			/* Chat */

			<?php if ( ! empty ( $jobster_design['chat_box_footer_buttons_color']['hover'] ) ) { ?>

				.message-box-container .message-box-footer .emojionearea-button:hover * {
					color: <?php echo $jobster_design['chat_box_footer_buttons_color']['hover']; ?>;
				}

			<?php } ?>

			<?php if ( ! empty ( $jobster_design['chat_box_head_buttons_color']['focus'] ) ) { ?>

				.message-box-container .message-box-wrapper.has-focus .message-box-head .message-box-head-content .message-box-head-buttons i,
				.message-box-container .message-box-wrapper.has-focus .message-box-head .message-box-head-content .message-box-head-buttons span {
					color: <?php echo $jobster_design['chat_box_head_buttons_color']['focus']; ?>;
				}

			<?php } ?>

			<?php if ( ! empty ( $jobster_design['chat_box_head_buttons_color']['hover'] ) ) { ?>

				.message-box-container .message-box-wrapper .message-box-head .message-box-head-content .message-box-head-buttons i:hover,
				.message-box-container .message-box-wrapper .message-box-head .message-box-head-content .message-box-head-buttons span:hover {
					color: <?php echo $jobster_design['chat_box_head_buttons_color']['hover']; ?>;
				}

			<?php } ?>

			<?php if ( ! empty ( $jobster_design['chat_box_footer_message_option_btn_text_color']['hover'] ) ) { ?>

				.message-box-container .message-box-footer .message-box-footer-options .option-wrapper > div:hover > i {
					color: <?php echo $jobster_design['chat_box_footer_message_option_btn_text_color']['hover']; ?>;
				}

			<?php } ?>

			/* Semantic UI Progress */
			.ui.progress.success .bar {
				background-color: <?php echo $primary_color; ?> !important;
			}

		</style>

		<?php do_action( 'wpj_after_custom_colours_define' );
	}
}
