<?php if ( ! function_exists( 'wpj_get_packages_custom_fields' ) ) {
	function wpj_get_packages_custom_fields( $pid = '' ) {

		$pid = wpj_get_post_id();

		$package_custom_fields = get_post_meta( $pid, 'package_custom_fields', true );

		$packages = array( 'name', 'basic', 'standard', 'premium' );

		foreach ( $packages as $key => $pck ) {

			if ( $pck == 'name' ) {
				${ 'pck_' . $pck } = isset( $_POST['pck-inp-custom-name'] ) ? $_POST['pck-inp-custom-name'] : '';
			} else {
				${ 'pck_' . $pck } = isset( $_POST['pck-chk-value'][$pck] ) ? $_POST['pck-chk-value'][$pck] : '';
			}

			if ( ! ${ 'pck_' . $pck } ) {
				${ 'pck_' . $pck } = $package_custom_fields;
			}

			${ 'pck_cf_' . $pck } = array();

			if ( ${'pck_' . $pck} ) {

				foreach ( ${ 'pck_' . $pck } as $key2 => $cf ) {
					if ( $cf ) {
						if ( $pck != 'name' && ( $cf == 'on' || ( is_array( $cf ) && $cf[$pck] == 'on' ) ) ) {
							if ( is_array( $cf ) ) {
								${ 'pck_cf_' . $pck }[] = $cf[$pck];
							} else {
								${ 'pck_cf_' . $pck }[] = $cf;
							}
						} elseif ( $pck == 'name' ) {
							if ( is_array( $cf ) ) {
								${ 'pck_cf_' . $pck }[] = $cf['name'];
							} else {
								${ 'pck_cf_' . $pck }[] = $cf;
							}
						} else {
							${ 'pck_cf_' . $pck }[] = '';
						}
					} else {
						${ 'pck_cf_' . $pck }[] = '';
					}
				}

			}

		}

		return array(
			'pck_name'        => $pck_name,
			'pck_cf_name'     => $pck_cf_name,
			'pck_basic'       => $pck_basic,
			'pck_cf_basic'    => $pck_cf_basic,
			'pck_standard'    => $pck_standard,
			'pck_cf_standard' => $pck_cf_standard,
			'pck_premium'     => $pck_premium,
			'pck_cf_premium'  => $pck_cf_premium,
		);

	}
}