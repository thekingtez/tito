<?php
if ( ! function_exists( 'wpj_refresh_user_notifications_cron' ) ) {
	function wpj_refresh_user_notifications_cron() {
		global $current_user;

		$current_user = wp_get_current_user();

		if ( $current_user->ID ) {

			$current_time = current_time( 'timestamp', 1 );

			$timeout = get_user_meta( $current_user->ID, 'notifications_cron_timeout', true );

			if ( $current_time > $timeout || 0 == 0 ) {

				wpj_refresh_user_notifications( $current_user->ID );

				$new_timeout = $current_time + 3600; // + 1h * 60m * 60s

				update_user_meta( $current_user->ID, 'notifications_cron_timeout', $new_timeout );

			}
		}

	}
}

if ( ! function_exists( 'wpj_update_user_level_cron' ) ) {
	function wpj_update_user_level_cron() {
		global $wpdb;

		$all_users = get_users();

		if ( $all_users ) {
			foreach ( $all_users as $_user ) {

				$uid = $_user->ID;
				$tm = current_time( 'timestamp', 1 );

				if ( $tm > get_user_meta( $uid, 'date_toclear', true ) ) {

					$datebefore = wpj_get_start_date_for_active_period( $uid, 1 );
					$datemax    = strtotime( '+1 day', time() );

					$s = "
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
						WHERE posts.post_author = '{$uid}'
							AND posts.ID = orders.pid
							AND orders.done_seller = '1'
							AND orders.done_buyer = '1'
							AND orders.closed = '0'
							AND orders.date_completed > '{$datebefore}'
							AND orders.date_completed < '{$datemax}'
							ORDER BY orders.id DESC
					";
					$r = $wpdb->get_results( $s );

					$add = 0;
					if ( count( $r ) >= 0 ) {
						foreach ( $r as $row ) {
							$add += $row->mc_gross;
						}
					}

					$total1 = $add;

					$s = "
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_ratings ratings, {$wpdb->prefix}posts posts, {$wpdb->prefix}job_orders orders
						WHERE posts.post_author = '{$uid}'
							AND posts.ID = ratings.pid
							AND ratings.awarded = '1'
							AND ratings.datemade > '{$datebefore}'
							AND orders.date_made < '{$datemax}'
							ORDER BY ratings.id DESC
					";
					$r = $wpdb->get_results( $s );

					$ratings_sum      = 0;
					$ratings_count    = 0;
					$ratings_average1 = 0;

					if ( count( $r ) > 0 ) {
						foreach ( $r as $row ) {
							$ratings_sum += $row->grade;
							$ratings_count++;
						}
						$ratings_average1 = ( $ratings_sum / $ratings_count ) * 20;
					}

					$datebefore = wpj_get_start_date_for_active_period( $uid, 2 );
					$datemax    = strtotime( '+ 1 day', time() );

					$s = "
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
						WHERE posts.post_author = '{$uid}'
							AND posts.ID = orders.pid
							AND orders.done_seller = '1'
							AND orders.done_buyer = '1'
							AND orders.closed = '0'
							AND orders.date_completed > '{$datebefore}'
							AND orders.date_completed < '{$datemax}'
							ORDER BY orders.id DESC
					";

					$r = $wpdb->get_results( $s );

					$level1 = 0;
					$level2 = 0;
					$add    = 0;
					if ( count( $r ) >= 0 ) {
						foreach ( $r as $row ) {
							$add += $row->mc_gross;
						}
					}

					$total2 = $add;

					$s = "
						SELECT DISTINCT *
						FROM {$wpdb->prefix}job_ratings ratings, {$wpdb->prefix}posts posts, {$wpdb->prefix}job_orders orders
						WHERE posts.post_author = '{$uid}'
							AND posts.ID = ratings.pid
							AND ratings.awarded = '1'
							AND ratings.datemade > '{$datebefore}'
							AND orders.date_made < '{$datemax}'
							ORDER BY ratings.id DESC
					";

					$r = $wpdb->get_results( $s );

					$ratings_sum      = 0;
					$ratings_count    = 0;
					$ratings_average2 = 0;
					if ( count( $r ) > 0 ) {
						foreach ( $r as $row ) {
							$ratings_sum += $row->grade;
							$ratings_count++;
						}
						$ratings_average2 = ( $ratings_sum / $ratings_count ) * 20;
					}

					if ( ! isset( $wpjobster_level2_upgrade_rating ) ) $wpjobster_level2_upgrade_rating = wpj_get_option( "wpjobster_level2_upgrade_rating" );

					if ( $wpjobster_level2_upgrade_rating > 1 ) {
						//do nothing
					} else {
						$wpjobster_level2_upgrade_rating = 95;
					}

					if ( $total2 >= wpj_get_option( 'wpjobster_level2_min' ) && $ratings_average2 >= $wpjobster_level2_upgrade_rating ) {
						$level2 = 1;
					}

					if ( ! isset( $wpjobster_level1_upgrade_rating ) ) $wpjobster_level1_upgrade_rating = wpj_get_option( "wpjobster_level1_upgrade_rating" );

					if ( $wpjobster_level1_upgrade_rating > 1 ) {
						//do nothing
					} else {
						$wpjobster_level1_upgrade_rating = 90;
					}

					if ( $total1 >= wpj_get_option( 'wpjobster_level1_min' ) && $ratings_average1 >= $wpjobster_level1_upgrade_rating ) {
						$level1 = 1;
					}

					$current_level = get_user_meta( $uid, 'user_level', true );
					$lvl           = $current_level;

					if ( $current_level != 3 ) {
						if ( ! isset( $wpjobster_level0_recheck_interval ) ) {
							$wpjobster_level0_recheck_interval = wpj_get_option( "wpjobster_level0_recheck_interval" );
						}
						if ( ! isset( $wpjobster_level1_recheck_interval ) ) {
							$wpjobster_level1_recheck_interval = wpj_get_option( "wpjobster_level1_recheck_interval" );
						}
						if ( ! isset( $wpjobster_level2_recheck_interval ) ) {
							$wpjobster_level2_recheck_interval = wpj_get_option( "wpjobster_level2_recheck_interval" );
						}

						if ( $wpjobster_level2_recheck_interval == '' || !is_numeric( $wpjobster_level2_recheck_interval ) || $wpjobster_level2_recheck_interval <= 1 ) {
							$wpjobster_level2_recheck_interval = 2;
						}

						if ( $level2 ) {
							$current_level = 2;
							update_user_meta( $uid, 'date_toclear', strtotime( '+' . $wpjobster_level2_recheck_interval . ' month', time() ) );
						} elseif ( $level1 ) {
							$current_level = 1;
							update_user_meta( $uid, 'date_toclear', strtotime( '+' . $wpjobster_level1_recheck_interval . ' month', time() ) );
						} else {
							$current_level = 0;
							update_user_meta( $uid, 'date_toclear', strtotime( '+' . $wpjobster_level0_recheck_interval . ' month', time() ) );
						}
					}

					if ( ! isset( $wpjobster_auto_upgrade_user_level ) ) {
						$wpjobster_auto_upgrade_user_level = wpj_get_option( "wpjobster_auto_upgrade_user_level" );
					}
					if ( ! isset( $wpjobster_auto_downgrade_user_level ) ) {
						$wpjobster_auto_downgrade_user_level = wpj_get_option( "wpjobster_auto_downgrade_user_level" );
					}

					if ( $current_level > $lvl && $wpjobster_auto_upgrade_user_level != 'no' ) {
						update_user_meta( $uid, 'user_level', $current_level );
						wpj_notify_user_translated( 'level_up', $uid, array( '##current_level##' => get_user_meta( $uid, 'user_level', true ) ) );
					} elseif ( $current_level < $lvl && $wpjobster_auto_downgrade_user_level != 'no' ) {
						update_user_meta( $uid, 'user_level', $current_level );
						wpj_notify_user_translated( 'level_down', $uid, array( '##current_level##' => get_user_meta( $uid, 'user_level', true ) ) );
					}

				}

				wpj_do_user_level_extras_check( $uid );

			}
		}
	}
}

if ( ! function_exists( 'wpj_vacation_check_cron' ) ) {
	function wpj_vacation_check_cron() {

		global $wpdb;

		$today = current_time( 'timestamp', 1 );

		$inactive_vacations = $wpdb->get_results(
			"
			SELECT *
			FROM {$wpdb->prefix}job_uservacation
			WHERE vacation_mode = '0'
				AND duration_start_ts <= {$today}
				AND duration_end_ts >= {$today}
			"
		);

		if ( $inactive_vacations > 0 ) {
			foreach ( $inactive_vacations as $index => $vacation ) {
				$id = $vacation->id;

				$wpdb->query(
					"
					UPDATE {$wpdb->prefix}job_uservacation
					SET vacation_mode = '1'
					WHERE id = '$id'
					"
				);
			}
		}

		$active_vacations = $wpdb->get_results(
			"
			SELECT *
			FROM {$wpdb->prefix}job_uservacation
			WHERE vacation_mode = '1'
				AND duration_end_ts <= {$today}
			"
		);

		if ( $active_vacations > 0 ) {
			foreach ( $active_vacations as $index => $vacation ) {
				$id = $vacation->id;

				$wpdb->query(
					"
					UPDATE {$wpdb->prefix}job_uservacation
					SET duration_end_actual_ts = duration_end_ts,
						duration_end_actual = duration_end,
						vacation_mode = '0'
					WHERE id = '$id'
					"
				);
			}
		}
	}
}

if ( ! function_exists( 'wpj_check_subscription_cron' ) ) {
	function wpj_check_subscription_cron() {
		if ( wpj_get_option( 'wpjobster_subscription_enabled' ) == 'yes' ) {
			global $wpdb;

			// Get active subscriptions
			$subscriptions = $wpdb->get_results( "
				SELECT * FROM {$wpdb->prefix}job_subscriptions
				WHERE next_billing_date <= '" . time() . "'
					AND next_billing_date != '0000-00-00'
					AND next_billing_date != ''
					AND next_billing_date != 0
			" );

			if ( is_array( $subscriptions ) ) {
				foreach ( $subscriptions as $subscription ) {
					$uid = $subscription->user_id;

					// Check scheduled subscriptions
					$sub_level = $subscription->next_subscription_level;
					$sub_type  = $subscription->next_subscription_type;

					$sub_id         = 'wpjobster_subscription_' . $sub_type . '_amount_' . $sub_level;
					$payable_amount = wpj_get_option( $sub_id );

					$subscription_order = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}job_subscription_orders WHERE user_id = %d AND subscription_status = 'active' LIMIT 1", $uid ) );

					$order_id = $subscription_order->id;

					if ( $subscription_order->payment_gateway_name == 'credits' ) {

						$user_credit = wpj_get_user_credit( $uid );
						if ( $payable_amount > 0 && $payable_amount > $user_credit ) {
							do_action( 'wpj_before_subscription_activation', 'schedule', $order_id, $sub_type, $sub_level );

							// Update user credits
							wpj_update_user_credit( $uid, $user_credit - $payable_amount );

							// Update subscription table
							$wpdb->update(
								$wpdb->prefix . 'job_subscriptions',
								array(
									"subscription_level"  => $sub_level,
									"subscription_type"   => $sub_type,
									"subscription_amount" => $payable_amount,
									"next_billing_date"   => wpj_get_subscription_next_billing_date( $sub_type )
								),
								array( "user_id" => $uid )
							);

							// Update subscription order table
							$wpdb->update(
								$wpdb->prefix . 'job_subscription_orders',
								array(
									'payment_gateway_transaction_id' => $order_id,
									'payment_response'               => json_encode( $subscription_order ),
									'profile_id'                     => $uid,
									'payment_date'                   => current_time( 'timestamp', 1 )
								),
								array(
									'id' => $order_id
								)
							);

							// Insert payment to database
							$currency = apply_filters( 'wpjobster_take_allowed_currency_' . $payment_gateway, '' );
							if ( empty( $currency ) ) $currency = wpj_get_site_curreny();

							$wpdb->insert(
								$wpdb->prefix . 'job_payment_received',
								array(
									'payment_status'         => 'completed',
									'payment_gateway'        => $subscription_order->payment_gateway_name,
									'payment_response'       => json_encode( $subscription_order ),
									'payment_details'        => 'Subscription renewal',
									'payment_type'           => 'subscription',
									'payment_type_id'        => $order_id,
									'currency'               => wpj_get_site_default_curreny(),
									'amount'                 => $payable_amount,
									'tax'                    => 0,
									'fees'                   => 0,
									'final_amount'           => $payable_amount,
									'final_amount_exchanged' => wpj_number_format_special_exchange( $payable_amount, 2, $currency ),
									'final_amount_currency'  => $currency,
									'datemade'               => current_time( 'timestamp', 1 ),
									'payment_made_on'        => current_time( 'timestamp', 1 )
								),
								array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%f', '%f', '%f', '%f', '%f', '%s', '%d', '%d' )
							);

							// Save log
							$reason  = __( "Payment for subscription renewal", "wpjobster" );
							$details = $sub_type . "_" . $sub_level . "_" . "renew";

							wpj_add_history_log( array(
								'tp'      => '0',
								'reason'  => $reason,
								'amount'  => $payable_amount,
								'uid'     => $uid,
								'oid'     => $order_id,
								'rid'     => 11,
								'details' => $details
							) );


							// Delete email meta
							delete_user_meta( $uid, "wpjobster_subscription_prior_email_notification_sent" );

							// Send email
							wpj_notify_user_translated( 'balance_down_subscription', $uid, array(
								'##username##'                    => wpj_get_user_display_type( $uid ),
								'##amount_updated##'              => $payable_amount,
								'##current_subscription_level##'  => wpj_translate_string( $sub_level ),
								'##current_subscription_period##' => wpj_translate_string( $sub_type ),
								'##current_subscription_amount##' => $payable_amount,
								'##next_billing_date##'           => wpj_get_subscription_next_billing_date( $sub_type ),
								'##next_subscription_level##'     => wpj_translate_string( $sub_level ),
								'##next_subscription_type##'      => wpj_translate_string( $sub_type ),
								'##next_subscription_amount##'    => $payable_amount
							) );

						} else {

							// Send email
							wpj_notify_user_translated( 'subscription_cancel_lowbalance', $uid, array(
								'##username##'                    => wpj_get_user_display_type( $uid ),
								'##amount_updated##'              => $payable_amount,
								'##current_subscription_level##'  => wpj_translate_string( $sub_level ),
								'##current_subscription_period##' => wpj_translate_string( $sub_type ),
								'##current_subscription_amount##' => $payable_amount,
								'##next_billing_date##'           => wpj_get_subscription_next_billing_date( $sub_type ),
								'##next_subscription_level##'     => wpj_translate_string( $sub_level ),
								'##next_subscription_type##'      => wpj_translate_string( $sub_type ),
								'##next_subscription_amount##'    => $payable_amount
							) );

							// Remove subscription
							wpj_remove_subscription( $order_id );

						}

						// Checks
						wpj_do_user_level_extras_check( $uid );
						wpj_do_user_level_extras_price_check( $uid );
						wpj_do_user_level_job_price_check( $uid );

						// Send reminder email
						$total_seconds_prior = wpj_get_option( 'wpjobster_subscription_prior_notification' ) * 60 * 60 * 24;

						if ( $total_seconds_prior + time() > $subscription->next_billing_date && get_user_meta( $uid, "wpjobster_subscription_prior_email_notification_sent", true ) != '1' ) {

							// Update email meta
							update_user_meta( $uid, "wpjobster_subscription_prior_email_notification_sent", "1" );

							// Send email
							wpj_notify_user_translated( 'wpjobster_subscription_prior_notification', $uid, array(
								'##amount_updated##'               => $subscription->subscription_amount,
								'##current_subscription_level##'   => wpj_translate_string( $subscription->subscription_level ),
								'##current_subscription_period##'  => wpj_translate_string( $subscription->subscription_type ),
								'##current_subscription_amount##'  => $subscription->subscription_amount,
								'##next_billing_date##'            => $subscription->next_billing_date,
								'##next_subscription_level##'      => wpj_translate_string( $subscription->next_subscription_level ),
								'##next_subscription_type##'       => wpj_translate_string( $subscription->next_subscription_type ),
								'##next_subscription_amount##'     => $subscription->next_subscription_amount,
								'##no_of_days_subscription_left##' => wpj_get_option( 'wpjobster_subscription_prior_notification' )
							) );
						}

					}
				}
			}
		}
	}
}

if ( ! function_exists( 'wpj_inactive_expired_requests_cron' ) ) {
	function wpj_inactive_expired_requests_cron() {
		$args = array(
			'posts_per_page' => '-1',
			'post_type'      => 'request',
			'post_status'    => array( 'publish' ),
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					array(
						'key'     => 'active',
						'value'   => '1',
						'compare' => '='
					)
				),
				array(
					'relation' => 'OR',
					array(
						'relation' => 'AND',
						array(
							'key'     => 'request_end_date',
							'compare' => 'EXISTS'
						),
						array(
							'key'     => 'request_end_date',
							'compare' => '!=',
							'value'   => ''
						),
						array(
							'key'     => 'request_end_date',
							'value'   => current_time( 'timestamp', 1 ),
							'compare' => '<=',
						)
					),
					array(
						'relation' => 'AND',
						array(
							'key'     => 'request_deadline',
							'compare' => 'EXISTS'
						),
						array(
							'key'     => 'request_deadline',
							'compare' => '!=',
							'value'   => ''
						),
						array(
							'key'     => 'request_deadline',
							'value'   => current_time( 'timestamp', 1 ),
							'compare' => '<=',
						)
					)
				)
			)
		);

		$result = get_posts( $args );

		if ( $result ) {
			foreach ( $result as $key => $value ) {
				update_post_meta( $value->ID, 'active', 0 );
			}
		}
	}
}

if ( ! function_exists( 'wpj_update_exchange_rates_cron' ) ) {
	function wpj_update_exchange_rates_cron() {

		// Get current exchange rates
		$current_json = get_option( 'exchange_rates' );
		$current_json_decoded = json_decode( $current_json, true );

		// Get API ID
		$appid = wpj_get_option( 'openexchangerates_appid' );

		// If no API KEY, do it weekly
		if ( ! $appid
			&& isset( $current_json_decoded['timestamp'] )
			&& time() - $current_json_decoded['timestamp'] < 604800
		) {
			return false;
		}

		// Add fallback API KEY
		if ( ! $appid ) { $appid = 'c9cee23bf1094de1a34b46ead5c9d02d'; }

		// Call the API
		$file = 'latest.json';
		$ch = curl_init( "http://openexchangerates.org/api/{$file}?app_id={$appid}&show_alternative=1" );

		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
		$json_received = curl_exec( $ch );
		curl_close( $ch );

		$json_received_decoded = json_decode( $json_received, true );

		// Send email empty response
		if ( empty( $json_received_decoded['rates'] ) ) {

			wpj_notify_user_translated( 'admin_openexchangerates_not_responding', 'admin' );

			return false;
		}

		// Get exchange difference
		$percent = wpj_get_option( 'wpjobster_exchange_drop_percent' );
		if ( ! $percent || ! is_numeric( $percent ) ) { $percent = 5; }

		$exchange_differences = array();
		if ( $current_json_decoded ) {

			global $wpjobster_currencies_array;

			$exchange_currencies = $wpjobster_currencies_array;
			foreach ( $exchange_currencies as $ex_c ) {
				if ( ! empty( $json_received_decoded['rates'][$ex_c] ) && ! empty( $current_json_decoded['rates'][$ex_c] ) ) {
					if ( abs( ( ( $json_received_decoded['rates'][$ex_c] / $current_json_decoded['rates'][$ex_c] ) - 1 ) * 100 ) > $percent ) {
						array_push( $exchange_differences, $ex_c );
					}
				}
			}
		}

		// Send exchange difference email
		if ( wpj_get_option( 'wpjobster_enable_open_exchange_api_rate' ) == 'yes' && ! empty( $exchange_differences ) ) {

			$params = array();
			foreach ( $exchange_differences as $ex_d ) {
				$params[] = array(
					'##main_currency##'      => $ex_d,
					'##old_price##'          => $current_json_decoded['rates'][$ex_d],
					'##new_price##'          => $json_received_decoded['rates'][$ex_d],
					'##percent_difference##' => abs( ( ( $json_received_decoded['rates'][$ex_d] / $current_json_decoded['rates'][$ex_d] ) - 1 ) * 100 )
				);
			}

			wpj_notify_user_translated( 'admin_openexchangerates_higher', 'admin', '', $params );

			return false;
		}

		// Update exchange with received json
		update_option( 'exchange_rates', $json_received );

	}
}

if ( ! function_exists( 'wpj_order_completed_cron' ) ) {
	function wpj_order_completed_cron() {
		global $wpdb;

		$ending = array(
			'relation' => 'AND',
			array (
				'key'     => 'home_featured_until',
				'value'   => time(),
				'type'    => 'meta_value_num',
				'compare' => '<'
			),
			array (
				'key'     => 'home_featured_now',
				'value'   => 'y',
				'type'    => 'meta_value',
				'compare' => '='
			)
		);

		$args = array(
			'posts_per_page' =>'-1',
			'post_type'      => 'job',
			'post_status'    => 'publish',
			'meta_query'     => array( $ending )
		);

		$the_query = new WP_Query( $args );

		if ( $the_query->have_posts() ) {
			while ( $the_query->have_posts() ) { $the_query->the_post();
				update_post_meta( get_the_ID(), 'home_featured_until', 'z' );
				update_post_meta( get_the_ID(), 'home_featured_now', 'z' );
			}
		}

		$ending = array(
			'relation' => 'AND',
			array (
				'key'     => 'category_featured_until',
				'value'   => time(),
				'type'    => 'meta_value_num',
				'compare' => '<'
			),
			array (
				'key'     => 'category_featured_now',
				'value'   => 'y',
				'type'    => 'meta_value',
				'compare' => '='
			)
		);

		$args = array(
			'posts_per_page' =>'-1',
			'post_type'      => 'job',
			'post_status'    => 'publish',
			'meta_query'     => array( $ending )
		);

		$the_query = new WP_Query( $args );

		if ( $the_query->have_posts() ) {
			while ( $the_query->have_posts() ) { $the_query->the_post();

				$pid      = get_the_ID();
				$taxonomy = 'job_cat';
				$terms    = get_the_terms( $pid, $taxonomy );
				$t        = $terms[0];
				$term     = get_term_by( 'id', $t->term_id, $taxonomy );
				$p        = get_term( $term->parent, $taxonomy );

				if ( ! isset( $p->term_id ) || $p->term_id == "" ) {
					$t              = $terms[0];
					$category_id    = $t->term_id;
					$t              = $terms[1];
					$subcategory_id = $t->term_id;

				} else {
					$t              = $terms[1];
					$category_id    = $t->term_id;
					$t              = $terms[0];
					$subcategory_id = $t->term_id;

				}

				update_post_meta( $pid, 'category_featured_until', 'z' );
				update_post_meta( $pid, 'category_featured_now', 'z' );
			}
		}

		$ending = array(
			'relation' => 'AND',
			array (
				'key'     => 'subcategory_featured_until',
				'value'   => time(),
				'type'    => 'meta_value_num',
				'compare' => '<'
			),
			array (
				'key'     => 'subcategory_featured_now',
				'value'   => 'y',
				'type'    => 'meta_value',
				'compare' => '='
			)
		);

		$args = array(
			'posts_per_page' =>'-1',
			'post_type'      => 'job',
			'post_status'    => 'publish',
			'meta_query'     => array( $ending )
		);

		$the_query = new WP_Query( $args );

		if ( $the_query->have_posts() ) {
			while ( $the_query->have_posts() ) { $the_query->the_post();

				$pid      = get_the_ID();
				$taxonomy = 'job_cat';
				$terms    = get_the_terms( $pid, $taxonomy );
				$t        = $terms[0];
				$term     = get_term_by( 'id', $t->term_id, $taxonomy );
				$p        = get_term( $term->parent, $taxonomy );

				if ( ! isset( $p->term_id ) || $p->term_id == "" ) {
					$t              = $terms[0];
					$category_id    = $t->term_id;
					$t              = $terms[1];
					$subcategory_id = $t->term_id;

				} else {
					$t              = $terms[1];
					$category_id    = $t->term_id;
					$t              = $terms[0];
					$subcategory_id = $t->term_id;

				}

				update_post_meta( $pid, 'subcategory_featured_until', 'z' );
				update_post_meta( $pid, 'subcategory_featured_now', 'z' );
			}
		}

		if ( wpj_get_option( 'wpjobster_featured_enable' ) == 'yes' ) {

			if ( wpj_get_option( 'wpjobster_homepage_featured_enable' ) == 'yes' ) {

				$starting = array(
					'relation' => 'AND',
					array (
						'key'     => 'home_featured_until',
						'value'   => strtotime( '+' . ( wpj_get_option( 'wpjobster_featured_interval' ) - 1 ) . ' day', time() ),
						'type'    => 'meta_value_num',
						'compare' => '<='
					),
					array (
						'key'     => 'home_featured_now',
						'value'   => 'z',
						'type'    => 'meta_value',
						'compare' => '='
					),
					array (
						'key'     => 'home_featured_until',
						'value'   => time(),
						'type'    => 'meta_value_num',
						'compare' => '>'
					),
				);

				$args = array(
					'posts_per_page' =>'-1',
					'post_type'      => 'job',
					'post_status'    => 'publish',
					'meta_query'     => array( $starting )
				);

				$the_query = new WP_Query( $args );

				if ( $the_query->have_posts() ) {
					while ( $the_query->have_posts() ) { $the_query->the_post();
						update_post_meta( get_the_ID(), 'home_featured_now', 'y' );
					}
				}

			}

			if ( wpj_get_option( 'wpjobster_category_featured_enable' ) == 'yes' ) {

				$starting = array(
					'relation' => 'AND',
					array (
						'key'     => 'category_featured_until',
						'value'   => strtotime( '+' . ( wpj_get_option( 'wpjobster_featured_interval' ) - 1 ) . ' day', time() ),
						'type'    => 'meta_value_num',
						'compare' => '<='
					),
					array (
						'key'     => 'category_featured_now',
						'value'   => 'z',
						'type'    => 'meta_value',
						'compare' => '='
					),
					array (
						'key'     => 'category_featured_now',
						'value'   => time(),
						'type'    => 'meta_value_num',
						'compare' => '>'
					),
				);

				$args = array(
					'posts_per_page' =>'-1',
					'post_type'      => 'job',
					'post_status'    => 'publish',
					'meta_query'     => array( $starting )
				);

				$the_query = new WP_Query( $args );

				if ( $the_query->have_posts() ) {
					while ( $the_query->have_posts() ) { $the_query->the_post();

						$pid      = get_the_ID();
						$taxonomy = 'job_cat';
						$terms    = get_the_terms( $pid, $taxonomy );
						$t        = $terms[0];
						$term     = get_term_by( 'id', $t->term_id, $taxonomy );
						$p        = get_term( $term->parent, $taxonomy );

						if ( ! isset( $p->term_id ) || $p->term_id == "" ) {
							$t              = $terms[0];
							$category_id    = $t->term_id;
							$t              = $terms[1];
							$subcategory_id = $t->term_id;

						} else {
							$t              = $terms[1];
							$category_id    = $t->term_id;
							$t              = $terms[0];
							$subcategory_id = $t->term_id;

						}

						update_post_meta( $pid, 'category_featured_now', 'y' );
					}
				}

			}

			if ( wpj_get_option( 'wpjobster_subcategory_featured_enable' ) == 'yes' ) {

				$starting = array(
					'relation' => 'AND',
					array (
						'key'     => 'subcategory_featured_until',
						'value'   => strtotime( '+' . ( wpj_get_option( 'wpjobster_featured_interval' ) - 1 ) . ' day', time() ),
						'type'    => 'meta_value_num',
						'compare' => '<='
					),
					array (
						'key'     => 'subcategory_featured_now',
						'value'   => 'z',
						'type'    => 'meta_value',
						'compare' => '='
					),
					array (
						'key'     => 'subcategory_featured_now',
						'value'   => time(),
						'type'    => 'meta_value_num',
						'compare' => '>'
					),
				);

				$args = array(
					'posts_per_page' =>'-1',
					'post_type'      => 'job',
					'post_status'    => 'publish',
					'meta_query'     => array( $starting )
				);

				$the_query = new WP_Query( $args );

				if ( $the_query->have_posts() ) {
					while ( $the_query->have_posts() ) { $the_query->the_post();

						$pid      = get_the_ID();
						$taxonomy = 'job_cat';
						$terms    = get_the_terms( $pid, $taxonomy );
						$t        = $terms[0];
						$term     = get_term_by( 'id', $t->term_id, $taxonomy );
						$p        = get_term( $term->parent, $taxonomy );

						if ( ! isset( $p->term_id ) || $p->term_id == "" ) {
							$t              = $terms[0];
							$category_id    = $t->term_id;
							$t              = $terms[1];
							$subcategory_id = $t->term_id;

						} else {
							$t              = $terms[1];
							$category_id    = $t->term_id;
							$t              = $terms[0];
							$subcategory_id = $t->term_id;

						}

						update_post_meta( $pid, 'subcategory_featured_now', 'y' );
					}
				}

			}

		}

		$wpjobster_max_time_to_wait = wpj_get_option( 'wpjobster_max_time_to_wait' );

		if ( empty( $wpjobster_max_time_to_wait ) ) $wpjobster_max_time_to_wait = 72;

		$scm = current_time( 'timestamp', 1 ) - $wpjobster_max_time_to_wait * 3600;

		$r = $wpdb->get_results( "SELECT * from {$wpdb->prefix}job_orders WHERE done_seller = '1' AND completed = '0' AND closed = '0' AND date_finished < '{$scm}'" );

		foreach ( $r as $row ) {
			wpj_mark_order_as_completed( $row->id );
		}

	}
}

if ( ! function_exists( 'wpj_order_cleared_cron' ) ) {
	function wpj_order_cleared_cron() {
		global $wpdb;

		$tm = current_time( 'timestamp', 1 );

		$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_orders WHERE clearing_period = '2'" );

		foreach ( $r as $row ) {

			if ( $row->date_to_clear <= $tm ) {

				$wpdb->query( "UPDATE {$wpdb->prefix}job_orders SET clearing_period = '1' WHERE id = '{$row->id}'" );

				wpj_mark_order_as_cleared( $row->id );

			}

		}

	}
}

if ( ! function_exists( 'wpj_order_expire_soon_notify_cron' ) ) {
	function wpj_order_expire_soon_notify_cron() {

		global $wpdb;

		$r = $wpdb->get_results(
			"
			SELECT *
			FROM {$wpdb->prefix}job_orders
			WHERE payment_status  = 'completed'
				AND completed     = '0'
				AND closed        = '0'
				AND date_closed   = '0'
				AND date_finished = '0'
			"
		);

		if ( $r ) {
			foreach ( $r as $row ) {
				$orderid = $row->id;

				$date_made         = $row->date_made;
				$expected_delivery = $row->expected_delivery;
				$current_time      = current_time( 'timestamp', 1 );

				$diff  = $expected_delivery - $current_time;

				$hours = round( $diff / ( 60 * 60 ) );

				if ( $hours < 24 && $current_time < $expected_delivery ) {

					$email_shortcodes = array(
						'##job_name##'              => $row->job_title,
						'##job_link##'              => urldecode( get_permalink( $row->pid ) ),
						'##transaction_page_link##' => wpj_get_order_link( $orderid ),
						'##transaction_number##'    => wpj_camouflage_oid( $orderid, $date_made )
					);

					wpj_notify_user_translated( 'ord_expires_soon', $row->uid, $email_shortcodes );
					wpj_notify_user_translated( 'ord_expires_soon', wpj_get_seller_id( $row ), $email_shortcodes );

				}
			}
		}

	}
}

if ( ! function_exists( 'wpj_order_expired_or_failed_cron' ) ) {
	function wpj_order_expired_or_failed_cron() {

		global $wpdb;

		$no_of_days = wpj_get_option( 'wpjobster_pending_jobs_days' );
		if ( $no_of_days == 0 || $no_of_days == '' ) $no_of_days = 7;

		$x_days_before = strtotime( "- $no_of_days days" );

		$r = $wpdb->get_results( "
			SELECT id
			FROM {$wpdb->prefix}job_orders
			WHERE done_seller      = '0'
				AND done_buyer     = '0'
				AND date_finished  = '0'
				AND closed         = '0'
				AND payment_status = 'pending'
				AND date_made < {$x_days_before}
		" );

		foreach ( $r as $row ) {
			$payment_details = "Expired on " . time() ;

			wpj_update_order_meta( $row->id, 'payment_status', 'expired' );
			wpj_update_order_meta( $row->id, 'payment_details', $payment_details );

			$timestamp_now = current_time( 'timestamp', 1 );

			$wpdb->query( "
				UPDATE {$wpdb->prefix}job_orders
				SET closed = '1',
					date_closed = '{$timestamp_now}'
				WHERE id = '{$row->id}'
				LIMIT 1
			" );

			$date_now = date( "Y-d-m" );

			$wpdb->query( "
				UPDATE {$wpdb->prefix}job_payment_received
				SET payment_status   = 'expired',
					payment_response = 'Transaction Cancelled by Cron job on {$date_now}',
					payment_details  = '{$payment_details}'
				WHERE payment_type_id = {$row->id}
					AND payment_type  = 'job_purchase'
			" );
		}

		$wpdb->query(
			"
			UPDATE {$wpdb->prefix}job_orders
			SET closed          = '1',
				date_closed     = UNIX_TIMESTAMP(),
				payment_details = 'Failed payment, closed by cron.'
			WHERE done_seller      = '0'
				AND done_buyer     = '0'
				AND date_finished  = '0'
				AND closed         = '0'
				AND payment_status = 'failed'
			"
		);

	}
}

if ( ! function_exists( 'wpj_autoreject_order_cron' ) ) {
	function wpj_autoreject_order_cron() {
		if ( wpj_get_option( 'wpjobster_seller_order_rejection_enable' ) == 'yes' ) {

			global $wpdb;

			$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_orders WHERE seller_confirmation = '0' and payment_status = 'completed'" );

			if ( $r ) {
				foreach ( $r as $row ) {
					$orderid      = $row->id;
					$date_made    = $row->date_made;
					$current_time = current_time( 'timestamp', 1 );

					$diff = $current_time - $date_made;

					$hours = round( $diff / ( 60 * 60 ) );

					if ( $hours > 24 ) {

						// Insert to orders
						$wpdb->query( "
							UPDATE {$wpdb->prefix}job_orders
							SET seller_confirmation = '2'
							WHERE id = '{$orderid}'
						" );

						// Cancel order and refund buyer
						wpj_cancel_order_by_id( $orderid, 'autoclose', true );

						// Insert to chatbox
						$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -47 AND oid = %d", current_time( 'timestamp', 1 ), $orderid ) );

						if ( ! $row_exist ) {
							$wpdb->insert(
								$wpdb->prefix . 'job_chatbox',
								array(
									'datemade' => current_time( 'timestamp', 1 ),
									'uid'      => -47,
									'oid'      => $orderid,
									'content'  => __( 'Rejected by Seller (autoclose)', 'wpjobster' )
								),
								array( '%d', '%d', '%d', '%s' )
							);

							// Update notifications
							$this_notification = $wpdb->insert_id;

							wpj_update_user_notifications( array(
								'user1'       => $row->uid,
								'user2'       => wpj_get_seller_id( $row ),
								'type'        => 'notifications',
								'number'      => +1,
								'notify_id'   => $this_notification,
								'notify_type' => 'order_rejected',
								'order_id'    => $orderid
							) );

							// Send emails
							wpj_notify_user_translated( 'order_rejected', $row->uid, array( '##transaction_page_link##' => wpj_get_order_link( $orderid ), '##transaction_number##' => wpj_camouflage_oid( $orderid, $date_made ) ) );
						}
					}
				}
			}

		}
	}
}