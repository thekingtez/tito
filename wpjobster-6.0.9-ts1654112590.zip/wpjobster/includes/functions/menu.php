<?php

// Get menu object by location
if ( ! function_exists( 'wpj_get_menu_by_location' ) ) {
	function wpj_get_menu_by_location( $location ) {

		$ret_menu = array();

		$locations = get_nav_menu_locations(); // get all locations
		if ( isset( $locations[$location] ) ) {
			$object    = wp_get_nav_menu_object( $locations[$location] ); // get object id by location
			$main_menu = isset( $object->name ) ? wp_get_nav_menu_items( $object->name ) : ''; // get menu items by menu name

			if ( $main_menu ) { $i = 0; $ord = 9;
				foreach ( $main_menu as $index => $item ) {
					if ( $item->menu_item_parent != 0 ) {
						foreach ( $main_menu as $index2 => $item2 ) {
							if ( $item2->ID == $item->menu_item_parent ) {
								$main_menu[$index2]->has_child = true;

								if ( ! isset( $main_menu[$index2]->children ) ) {
									$main_menu[$index2]->children = array();
								}
								$main_menu[$index2]->children[] = $item;
							}
						}
						unset( $main_menu[$index] );
					}
				}

				foreach ( $main_menu as $key => $val ) {
					$classes = '';
					if ( ! empty( $val->classes ) ) { foreach ( $val->classes as $key => $class ) { $classes .= $class . ' '; } }

					$ret_menu[$i] = array(
						'id'      => $val->ID,
						'label'   => $val->title,
						'url'     => $val->url,
						'childs'  => array(),
						'classes' => trim( $classes ),
						'order'   => $ord . 'a',
					);

					if ( $val->has_child == 1 ) { $ord_child = 1;
						foreach ( $val->children as $key2 => $val2 ) {

							$child_classes = '';
							if ( ! empty( $val2->classes ) ) { foreach ( $val2->classes as $key3 => $class_ch ) { $child_classes .= $class_ch . ' '; } }

							$ret_menu[$i]['childs'][] = array(
								'id'      => $val2->ID,
								'label'   => $val2->title,
								'url'     => $val2->url,
								'classes' => trim( $child_classes ),
								'order'   => $ord_child . 'a'
							); $ord_child++;
						}
					}

					$i++; $ord++;
				}
			}
		}


		$ret_menu = apply_filters( 'wp_nav_menu_args', $ret_menu );
		$ret_menu = apply_filters( 'wpj_' . $location . '_filter', $ret_menu );

		return $ret_menu;
	}
}

// Get menu id by slug
if ( ! function_exists( 'wpj_get_menu_id_by_slug' ) ) {
	function wpj_get_menu_id_by_slug( $menu ) {
		$menu_object = wp_get_nav_menu_object( $menu );
		return $menu_object->term_id;
	}
}

// Get menu id by location
if ( ! function_exists( 'wpj_get_menu_id_by_location' ) ) {
	function wpj_get_menu_id_by_location( $location ) {
		$locations = get_nav_menu_locations();
		if ( in_array( $location, $locations ) ) {
			$menu_id = $locations[ $location ];
			return $menu_id;
		} else {
			return false;
		}
	}
}

// Sort menu
if ( ! function_exists( 'wpj_sort_menu' ) ) {
	function wpj_sort_menu( $array, $order ) {
		if ( strtolower( $order ) == strtolower( 'asc' ) ) {

			usort( $array, function ( $item1, $item2 ) {
				return $item1['order'] < $item2['order'] ? 1 : -1;
			});

		} else {

			usort( $array, function ( $item1, $item2 ) {
				return $item1['order'] > $item2['order'] ? 1 : -1;
			});

		}

		return $array;
	}
}

/* WP */
if ( ! function_exists( 'wpj_add_custom_class_to_nav_menu' ) ) {
	function wpj_add_custom_class_to_nav_menu( $classes, $item ) {
		$classes[] = "custom-class-" . $item->menu_order;
		return $classes;
	}
}

if ( ! function_exists( 'wpj_add_custom_class_to_last_item_nav_menu' ) ) {
	function wpj_add_custom_class_to_last_item_nav_menu( $strHTML ) {
		$intPos = strripos( $strHTML, 'menu-item' );
		printf( "%s last_item %s",
			substr( $strHTML, 0, $intPos ),
			substr( $strHTML, $intPos, strlen( $strHTML ) )
		);
	}
}

if ( ! function_exists( 'wpj_add_custom_class_to_first_last_item_nav_menu' ) ) {
	function wpj_add_custom_class_to_first_last_item_nav_menu( $output ) {
		$output = preg_replace( '/class="menu-item/', 'class="first-menu-item menu-item', $output, 1 );
		$output = substr_replace( $output, strripos( $output, 'class="menu-item' ), strlen( 'class="menu-item' ) );

		return $output;
	}
}

if ( ! function_exists( 'wpj_add_class_to_parent_nav_menu' ) ) {
	function wpj_add_class_to_parent_nav_menu( $classes, $item ) {
		global $dd_depth, $dd_children;

		$classes[] = 'depth' . $dd_depth;

		if ( $dd_children ) {
			$classes[] = 'parent';
		}

		return $classes;
	}
}

if ( ! function_exists( 'wpj_add_active_class_to_nav_menu' ) ) {
	function wpj_add_active_class_to_nav_menu( $nav_menu, $args ) {
		if ( in_array( $args->theme_location, array(
				'wpjobster_responsive_left_menu',
				'wpjobster_responsive_right_menu',
		) ) ) {
			return preg_replace( '/<a /', '<a class="item" ', $nav_menu );
		} else {
			return $nav_menu;
		}
	}
}

class WalkerMainNavMenu extends Walker_Nav_Menu {
	public $total_children;
	public $current_element;

	function start_lvl( &$output, $depth = 0, $args = array() ) {
		global $jobster_design;


		$menu_elements = wp_get_nav_menu_items( $args->menu );
		if ( $menu_elements ) {

			$total_parents = 0;
			foreach ( $menu_elements as $el ) {
				if ( $el->menu_item_parent === '0' ) $total_parents++;
			}

			$current_item_number = 0;
			$menu_open_postition = array();
			foreach ( $menu_elements as $menu_key => $menu ) {
				if ( $menu->menu_item_parent === '0' ) {
					$current_item_number++;
					$total_items_half = ceil( $total_parents / 2 );
					$menu_open_postition[$menu->menu_order] = $current_item_number <= $total_items_half ? ' left0' : ' right0 mr10';
				}
			}

		}

		$split_class = isset( $jobster_design['menu_style'] ) && $jobster_design['menu_style'] == '2' && $this->total_children >= 6 ? ' ul-two-columns' : ' ul-one-columns';

		$indent = str_repeat( "\t", $depth );
		$output .= "\n" . $indent . '<ul class="sub-menu' . $split_class . $menu_open_postition[$this->current_element->menu_order] . '">' . "\n";
	}

	public function display_element( $element, &$children_elements, $max_depth, $depth, $args, &$output ) {
		if ( ! $element ) return;

		$this->current_element = $element;

		$id_field = $this->db_fields['id'];
		$id       = $element->$id_field;

		$this->total_children = 0;
		if ( ! empty( $children_elements[ $id ] ) )
			$this->total_children = count( $children_elements[ $id ] );

		parent::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
	}
}