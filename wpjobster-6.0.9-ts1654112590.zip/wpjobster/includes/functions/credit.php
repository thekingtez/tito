<?php
if ( ! function_exists( 'wpj_get_user_credit' ) ) {
	function wpj_get_user_credit( $uid = '' ) {
		if ( ! $uid ) $uid = get_current_user_id();

		$c = get_user_meta( $uid, 'credits', true );

		if ( empty( $c ) ) {
			update_user_meta( $uid, 'credits', '0' );
			return 0;
		}

		return $c;
	}
}

if ( ! function_exists( 'wpj_update_user_credit' ) ) {
	function wpj_update_user_credit( $uid = '', $amount = '' ) {

		if ( ! $uid ) $uid = get_current_user_id();

		update_user_meta( $uid, 'credits', $amount );

	}
}

if ( ! function_exists( 'wpj_get_user_credit_log' ) ) {
	function wpj_get_user_credit_log( $uid = '', $from_balance = '' ) {
		global $wpdb;

		if ( ! $uid ) $uid = get_current_user_id();

		$s = "
			SELECT credit_balance AS sum_amount, from_unixtime({$from_balance}) AS fromdt
			FROM {$wpdb->prefix}job_credits_balance_log logs
			WHERE logs.uid = {$uid} AND datemade <= {$from_balance}
			ORDER BY datemade DESC
			LIMIT 1
		";

		$result_data = $wpdb->get_results( $s );

		if ( $result_data ) {
			return $result_data[0];
		} else {
			return 0;
		}
	}
}

if ( ! function_exists( 'wpj_update_user_credit_log' ) ) {
	function wpj_update_user_credit_log( $payment_transaction_id, $uid = '' ) {
		global $wpdb;

		if ( ! $uid ) $uid = get_current_user_id();

		$balance = wpj_get_user_credit( $uid );
		$time    = current_time( 'timestamp', 1 );

		$sql_credit_update = "
			INSERT INTO {$wpdb->prefix}job_credits_balance_log
			SET datemade                   = '{$time}',
				uid                        = '{$uid}',
				credit_balance             = '{$balance}',
				job_payment_transaction_id = '{$payment_transaction_id}'
		";

		$wpdb->query( $sql_credit_update );

		return $wpdb->insert_id;
	}
}