<?php
if ( ! function_exists( 'wpj_request_modification' ) ) {
	function wpj_request_modification() {

		global $wpdb, $wp_rewrite, $wp_query;

		$orderid = ( isset( $_POST['oid'] ) && $_POST['oid'] ) ? $_POST['oid'] : '';
		$tm      = current_time( 'timestamp', 1 );
		$message = ( isset( $_POST['message_request_modification'] ) && $_POST['message_request_modification'] ) ? addslashes( $_POST['message_request_modification'] ) : '';

		if ( $orderid ) {

			$row = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}job_orders WHERE id = '{$orderid}'" );
			if ( $row && ! is_demo_user() ) {
				if ( $row->request_modification != 1 ) {
					// Insert to orders
					$wpdb->query( "UPDATE {$wpdb->prefix}job_orders SET message_request_modification = '{$message}', request_modification = '1', date_request_modification = '{$tm}', done_seller = '0', date_finished = '0' WHERE id = '{$orderid}'" );

					// Insert to chatbox
					$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -15 AND oid = %d", current_time( 'timestamp', 1 ), $orderid ) );

					if ( ! $row_exist ) {
						$wpdb->insert(
							$wpdb->prefix . 'job_chatbox',
							array(
								'datemade' => current_time( 'timestamp', 1 ),
								'uid'      => -15,
								'oid'      => $orderid,
								'content'  => $message
							),
							array( '%d', '%d', '%d', '%s' )
						);

						// Update notifications
						$this_notification = $wpdb->insert_id;

						wpj_update_user_notifications( array(
							'user1'       => wpj_get_seller_id( $row ),
							'user2'       => get_current_user_id(),
							'type'        => 'notifications',
							'number'      => +1,
							'notify_id'   => $this_notification,
							'notify_type' => 'mod_buyer',
							'order_id'    => $orderid
						) );

						// Send emails
						if ( wpj_is_custom_offer( $row->pid ) ) {
							wpj_modify_custom_offer( $row->pid, $orderid, wpj_get_seller_id( $row ) );

						} else {
							$order = wpj_get_order( $orderid );

							wpj_notify_user_translated( 'mod_buyer', wpj_get_seller_id( $row ), array(
								'##sender_username##'       => wpj_get_user_display_type( get_current_user_id() ),
								'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
								'##transaction_page_link##' => wpj_get_order_link( $orderid ),
								'##job_name##'              => $order->job_title,
								'##job_link##'              => urldecode( get_permalink( $row->pid ) )
							) );

						}
					}
				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}