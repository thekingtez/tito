<?php
if ( ! function_exists( 'wpj_get_extended_delivery_by_oid' ) ) {
	function wpj_get_extended_delivery_by_oid( $oid = '', $status = '' ) {
		if ( $oid ) {
			global $wpdb;

			$query = "SELECT * FROM {$wpdb->prefix}job_orders_extended_delivery_time WHERE order_id = {$oid}";

			if ( $status || ( is_numeric( $status ) && $status == 0 ) ) {
				$query .= " AND status = {$status}";
			}

			$result = $wpdb->get_row( $query );

			return $result;
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_get_extended_delivery_by_message' ) ) {
	function wpj_get_extended_delivery_by_message( $oid = '', $message = '', $date = '' ) {
		if ( $oid ) {
			global $wpdb;

			$query = "SELECT * FROM {$wpdb->prefix}job_orders_extended_delivery_time WHERE order_id = {$oid}";

			if ( $message ) { $query .= " AND message = '{$message}'"; }
			if ( $date ) { $query .= " AND date_request = {$date}"; }

			$result = $wpdb->get_row( $query );

			return $result;
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_request_extend_order_delivery_time' ) ) {
	function wpj_request_extend_order_delivery_time() {

		global $wpdb;

		$table = $wpdb->prefix . 'job_orders_extended_delivery_time';

		$time_now = current_time( 'timestamp', 1 );

		$uid = get_current_user_id();

		$data = array(
			'order_id'     => $_POST['oid'],
			'user_id'      => $uid,
			'date_request' => $time_now,
			'message'      => $_POST['extended_days_message'],
			'days'         => $_POST['extended_days_selector']
		);

		$format = array( '%d', '%d', '%d', '%s' );

		$order_exist = $wpdb->get_results( "
			SELECT *
			FROM {$table}
			WHERE order_id            = '{$_POST['oid']}'
				AND user_id           = '{$uid}'
				AND date_request      = '{$time_now}'
				AND days              = '{$_POST['extended_days_selector']}'
				AND message           = '{$_POST['extended_days_message']}'
				AND status            = 0
				AND date_modification = 0
		" );

		if ( ! $order_exist ) {

			$wpdb->insert( $table, $data, $format );

			// Insert to chatbox
			$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -49 AND oid = %d", current_time( 'timestamp', 1 ), $_POST['oid'] ) );

			if ( ! $row_exist ) {
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade' => current_time( 'timestamp', 1 ),
						'uid'      => -49,
						'oid'      => $_POST['oid'],
						'content'  => $_POST['extended_days_message']
					),
					array( '%d', '%d', '%d', '%s' )
				);

				$order = wpj_get_order( $_POST['oid'] );

				// Update notifications
				$this_notification = $wpdb->insert_id;

				wpj_update_user_notifications( array(
					'user1'       => $order->uid,
					'user2'       => wpj_get_seller_id( $order ),
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'extend_delivery_request',
					'order_id'    => $order->id
				) );

				// Send emails
				wpj_notify_user_translated( 'extend_delivery_request', $order->uid, array(
					'##transaction_number##'      => wpj_camouflage_oid( $_POST['oid'], $order->date_made ),
					'##transaction_page_link##'   => wpj_get_order_link( $_POST['oid'] ),
					'##sender_username##'         => wpj_get_user_display_type( wpj_get_seller_id( $order ) ),
					'##job_name##'                => $order->job_title,
					'##job_link##'                => urldecode( get_permalink( $order->pid ) ),
					'##extend_delivery_message##' => $_POST['extended_days_message'],
					'##extend_delivery_days##'    => $_POST['extended_days_selector']
				) );

			}

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_abort_extend_delivery_time' ) ) {
	function wpj_abort_extend_delivery_time() {
		global $wpdb;

		$required_days_results = wpj_get_extended_delivery_by_oid( $_POST['oid'], 0 );

		$table = $wpdb->prefix . 'job_orders_extended_delivery_time';

		$time_now = current_time( 'timestamp', 1 );

		$data = array(
			'order_id'          => $_POST['oid'],
			'date_modification' => $time_now,
			'status'            => 3
		);

		$where = array( 'order_id' => $_POST['oid'], 'status' => 0 );

		$updated = $wpdb->update( $table, $data, $where );

		if ( false === $updated ) {} else {

			// Insert to chatbox
			$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -50 AND oid = %d", current_time( 'timestamp', 1 ), $_POST['oid'] ) );

			if ( ! $row_exist ) {
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade' => current_time( 'timestamp', 1 ),
						'uid'      => -50,
						'oid'      => $_POST['oid'],
						'content'  => __( 'Aborting the extension of the delivery time', 'wpjobster' )
					),
					array( '%d', '%d', '%d', '%s' )
				);

				$order = wpj_get_order( $_POST['oid'] );

				// Update notifications
				$this_notification = $wpdb->insert_id;

				wpj_update_user_notifications( array(
					'user1'       => $order->uid,
					'user2'       => wpj_get_seller_id( $order ),
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'extend_delivery_abort',
					'order_id'    => $order->id
				) );

				// Send emails
				wpj_notify_user_translated( 'extend_delivery_abort', $order->uid, array(
					'##transaction_number##'      => wpj_camouflage_oid( $_POST['oid'], $order->date_made ),
					'##transaction_page_link##'   => wpj_get_order_link( $_POST['oid'] ),
					'##sender_username##'         => wpj_get_user_display_type( wpj_get_seller_id( $order ) ),
					'##job_name##'                => $order->job_title,
					'##job_link##'                => urldecode( get_permalink( $order->pid ) ),
					'##extend_delivery_message##' => $required_days_results->message,
					'##extend_delivery_days##'    => $required_days_results->days
				) );

			}

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_accept_extend_delivery_time' ) ) {
	function wpj_accept_extend_delivery_time() {
		global $wpdb;

		$required_days_results = wpj_get_extended_delivery_by_oid( $_POST['oid'], 0 );

		$table = $wpdb->prefix . 'job_orders_extended_delivery_time';

		$time_now = current_time( 'timestamp', 1 );

		$data = array(
			'order_id'          => $_POST['oid'],
			'date_modification' => $time_now,
			'status'            => 1
		);

		$where = array( 'order_id' => $_POST['oid'], 'status' => 0 );

		$updated = $wpdb->update( $table, $data, $where );

		if ( false === $updated ) {} else {

			// Insert to chatbox
			$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -51 AND oid = %d", current_time( 'timestamp', 1 ), $_POST['oid'] ) );

			if ( ! $row_exist ) {

				// Add days
				wpj_update_expected_delivery_add_days( $_POST['oid'], $required_days_results->days );

				// Insert to chatbox
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade' => current_time( 'timestamp', 1 ),
						'uid'      => -51,
						'oid'      => $_POST['oid'],
						'content'  => __( 'Accepted the extension of the delivery time', 'wpjobster' )
					),
					array( '%d', '%d', '%d', '%s' )
				);

				$order = wpj_get_order( $_POST['oid'] );

				// Update notifications
				$this_notification = $wpdb->insert_id;

				wpj_update_user_notifications( array(
					'user1'       => wpj_get_seller_id( $order ),
					'user2'       => $order->uid,
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'extend_delivery_accept',
					'order_id'    => $order->id
				) );

				// Send emails
				wpj_notify_user_translated( 'extend_delivery_accept', wpj_get_seller_id( $order ), array(
					'##transaction_number##'      => wpj_camouflage_oid( $_POST['oid'], $order->date_made ),
					'##transaction_page_link##'   => wpj_get_order_link( $_POST['oid'] ),
					'##sender_username##'         => wpj_get_user_display_type( $order->uid ),
					'##job_name##'                => $order->job_title,
					'##job_link##'                => urldecode( get_permalink( $order->pid ) ),
					'##extend_delivery_message##' => $required_days_results->message,
					'##extend_delivery_days##'    => $required_days_results->days
				) );

			}

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_deny_extend_delivery_time' ) ) {
	function wpj_deny_extend_delivery_time() {
		global $wpdb;

		$required_days_results = wpj_get_extended_delivery_by_oid( $_POST['oid'], 0 );

		$table = $wpdb->prefix . 'job_orders_extended_delivery_time';

		$time_now = current_time( 'timestamp', 1 );

		$data = array(
			'order_id'          => $_POST['oid'],
			'date_modification' => $time_now,
			'status'            => 2
		);

		$where = array( 'order_id' => $_POST['oid'], 'status' => 0 );

		$updated = $wpdb->update( $table, $data, $where );

		if ( false === $updated ) {} else {

			// Insert to chatbox
			$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -52 AND oid = %d", current_time( 'timestamp', 1 ), $_POST['oid'] ) );

			if ( ! $row_exist ) {

				// Insert to chatbox
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade' => current_time( 'timestamp', 1 ),
						'uid'      => -52,
						'oid'      => $_POST['oid'],
						'content'  => __( 'Declined the extension of the delivery time', 'wpjobster' )
					),
					array( '%d', '%d', '%d', '%s' )
				);

				$order = wpj_get_order( $_POST['oid'] );

				// Update notifications
				$this_notification = $wpdb->insert_id;

				wpj_update_user_notifications( array(
					'user1'       => wpj_get_seller_id( $order ),
					'user2'       => $order->uid,
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'extend_delivery_decline',
					'order_id'    => $order->id
				) );

				// Send emails
				wpj_notify_user_translated( 'extend_delivery_decline', wpj_get_seller_id( $order ), array(
					'##transaction_number##'      => wpj_camouflage_oid( $_POST['oid'], $order->date_made ),
					'##transaction_page_link##'   => wpj_get_order_link( $_POST['oid'] ),
					'##sender_username##'         => wpj_get_user_display_type( $order->uid ),
					'##job_name##'                => $order->job_title,
					'##job_link##'                => urldecode( get_permalink( $order->pid ) ),
					'##extend_delivery_message##' => $required_days_results->message,
					'##extend_delivery_days##'    => $required_days_results->days
				) );

			}

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}