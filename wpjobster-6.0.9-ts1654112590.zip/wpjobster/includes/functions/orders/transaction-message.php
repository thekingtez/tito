<?php
if ( ! function_exists( 'wpj_get_chatbox_message' ) ) {
	function wpj_get_chatbox_message( $id = '' ) {

		global $wpdb;
		$message = $wpdb->get_row( $wpdb->prepare(
			"
			SELECT DISTINCT *
			FROM {$wpdb->prefix}job_chatbox
			WHERE id = %d
			",
			$id
		) );

		return $message;
	}
}

if ( ! function_exists( 'wpj_send_transaction_message' ) ) {
	function wpj_send_transaction_message() {

		$uid = get_current_user_id();

		$orderid = $_POST['order_id'];
		$order   = wpj_get_order( $orderid );

		$pid  = $order->pid;

		$wpjobster_characters_message_max = wpj_get_option( "wpj_private_message_character_limits" )[1];
		$wpjobster_characters_message_max = ( empty( $wpjobster_characters_message_max ) || $wpjobster_characters_message_max == 0 ) ? 1200 : $wpjobster_characters_message_max;
		$wpjobster_characters_message_min = wpj_get_option( "wpj_private_message_character_limits" )[2];
		$wpjobster_characters_message_min = ( empty( $wpjobster_characters_message_min ) ) ? 0 : $wpjobster_characters_message_min;

		$message  = trim( nl2br( strip_tags( htmlspecialchars( wpj_encode_emoji( $_POST['message'] ) ) ) ) );
		$datemade = current_time( 'timestamp', 1 );

		global $wpdb;

		// attach files
		$attachment = $_POST['hidden_files_chat_box_attachments'] ? $_POST['hidden_files_chat_box_attachments'] : '';
		if ( ! is_demo_user() ) {

			// Insert to chatbox
			$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = %d AND oid = %d", current_time( 'timestamp', 1 ), $uid, $orderid ) );

			if ( ! $row_exist ) {
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade'   => current_time( 'timestamp', 1 ),
						'uid'        => $uid,
						'oid'        => $orderid,
						'content'    => $message,
						'attachment' => $attachment
					),
					array( '%d', '%d', '%d', '%s', '%s' )
				);
			}

			$this_notification = $wpdb->insert_id;

			$attachments = explode( ',', $attachment );

			wpj_save_attachemtns( $attachments, $this_notification, 'message_id', 'new', 'post' );
		}

		if ( ! is_demo_user() ) {
			if ( is_super_admin( $uid ) && $uid != $order->uid && $uid != wpj_get_seller_id( $order ) ) {
				wpj_update_user_notifications( array(
					'user1'       => $order->uid,
					'user2'       => get_current_user_id(),
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'order_message',
					'order_id'    => $orderid
				) );

				wpj_notify_user_translated( 'order_message', $order->uid, array(
					'##sender_username##'       => wpj_get_user_display_type( get_current_user_id() ),
					'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
					'##transaction_page_link##' => wpj_get_order_link( $orderid ),
					'##job_name##'              => $order->job_title,
					'##job_link##'              => urldecode( get_permalink( $pid ) )
				) );
			}

			$uid_to_send = $uid == wpj_get_seller_id( $order ) ? $order->uid : wpj_get_seller_id( $order );
			$uid_sender  = $uid == wpj_get_seller_id( $order ) ? wpj_get_seller_id( $order ) : $order->uid;

			wpj_update_user_notifications( array(
				'user1'       => $uid_to_send,
				'user2'       => $uid_sender,
				'type'        => 'notifications',
				'number'      => +1,
				'notify_id'   => $this_notification,
				'notify_type' => 'order_message',
				'order_id'    => $orderid
			) );

			wpj_notify_user_translated( 'order_message', $uid_to_send, array(
				'##sender_username##'       => wpj_get_user_display_type( get_current_user_id() ),
				'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
				'##transaction_page_link##' => wpj_get_order_link( $orderid ),
				'##job_name##'              => $order->job_title,
				'##job_link##'              => urldecode( get_permalink( $pid ) )
			) );
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}