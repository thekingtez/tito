<?php
if ( ! function_exists( 'wpj_cancel_pending_order' ) ) {
	function wpj_cancel_pending_order() {
		global $wpdb;

		$order_id = isset( $_POST['order_id'] ) ? $_POST['order_id'] : '';
		$process  = isset( $_POST['process'] ) ? $_POST['process'] : '';

		$order = wpj_get_order( $order_id );

		if ( $order_id
			&& $process == 'cancel'
			&& $order->uid == get_current_user_id()
			&& $order->payment_status == 'pending'
		) {
			$message = __( 'Pending cancelled', 'wpjobster' );

			// Cancel the order
			wpj_cancel_order_by_id( $order_id, 'pending' );

			// Insert order to chatbox
			$row_exist1 = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -21 AND oid = %d", current_time( 'timestamp', 1 ), $order_id ) );

			if ( ! $row_exist1 ) {
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade' => current_time( 'timestamp', 1 ),
						'uid'      => -21,
						'oid'      => $order_id,
						'content'  => $message
					),
					array( '%d', '%d', '%d', '%s' )
				);

				// Update notifications
				$this_notification = $wpdb->insert_id;

				wpj_update_user_notifications( array(
					'user1'       => wpj_get_seller_id( $order ),
					'user2'       => $order->uid,
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'cancel_ord_pending',
					'order_id'    => $order_id
				) );
			}

			// Insert order to chatbox
			$row_exist2 = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -22 AND oid = %d", current_time( 'timestamp', 1 ), $order_id ) );

			if ( ! $row_exist2 ) {
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade' => current_time( 'timestamp', 1 ),
						'uid'      => -22,
						'oid'      => $order_id,
						'content'  => $message
					),
					array( '%d', '%d', '%d', '%s' )
				);

				// Update notifications
				$this_notification = $wpdb->insert_id;

				wpj_update_user_notifications( array(
					'user1'       => $order->uid,
					'user2'       => wpj_get_seller_id( $order ),
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'cancel_ord_pending',
					'order_id'    => $order_id
				) );
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_cancel_expired_order' ) ) {
	function wpj_cancel_expired_order() {
		global $wpdb;

		$orderid = isset( $_POST['oid'] ) ? $_POST['oid'] : '';

		if ( $orderid ) {

			// Select current order
			$order = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}job_orders WHERE id = {$orderid}" );

			if ( wpj_is_order_time_up( $orderid ) == 1 && ( wpj_get_seller_id( $order ) == get_current_user_id() || $order->uid == get_current_user_id() ) ) {

				// Cancel the order
				wpj_cancel_order_by_id( $orderid, 'expired' );

				// Insert order to chatbox
				$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -35 AND oid = %d", current_time( 'timestamp', 1 ), $orderid ) );

				if ( ! $row_exist ) {
					$wpdb->insert(
						$wpdb->prefix . 'job_chatbox',
						array(
							'datemade' => current_time( 'timestamp', 1 ),
							'uid'      => -35,
							'oid'      => $orderid,
							'content'  => __( 'Expired', 'wpjobster' )
						),
						array( '%d', '%d', '%d', '%s' )
					);

					// Update notifications
					$this_notification = $wpdb->insert_id;

					wpj_update_user_notifications( array(
						'user1'       => $order->uid,
						'user2'       => wpj_get_seller_id( $order ),
						'type'        => 'notifications',
						'number'      => +1,
						'notify_id'   => $this_notification,
						'notify_type' => 'cancel_ord_expired',
						'order_id'    => $orderid
					) );

					// Send email
					if ( wpj_is_custom_offer( $order->pid ) ) {
						wpj_notify_user_translated( 'cancel_offer_acc_seller', $order->uid, array(
							'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
							'##transaction_page_link##' => wpj_get_order_link( $orderid ),
							'##sender_username##'       => wpj_get_user_display_type( wpj_get_seller_id( $order ) ),
							'##job_name##'              => $order->job_title,
							'##job_link##'              => urldecode( get_permalink( $order->pid ) )
						) );

					} else {
						wpj_notify_user_translated( 'cancel_ord_expired_seller', wpj_get_seller_id( $order ), array(
							'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
							'##transaction_page_link##' => wpj_get_order_link( $orderid ),
							'##sender_username##'       => wpj_get_user_display_type( $buyer_data->ID ),
							'##job_name##'              => $order->job_title,
							'##job_link##'              => urldecode( get_permalink( $order->pid ) )
						) );

						wpj_notify_user_translated( 'cancel_ord_expired_buyer', $order->uid, array(
							'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
							'##transaction_page_link##' => wpj_get_order_link( $orderid ),
							'##sender_username##'       => wpj_get_user_display_type( wpj_get_seller_id( $order ) ),
							'##job_name##'              => $order->job_title,
							'##job_link##'              => urldecode( get_permalink( $order->pid ) )
						) );

					}
				}
			}

		}

		if ( wpj_is_ajax_call() ) wp_die();

	}
}

 /* Force cancellation
 *
 * 0 - active/completed order
 * 1 - closed from admin
 * 2 - delivery time expired
 * 3 - mutual cancellation
 * 4 - arbitration
 * 5 - user ban
 * 6 - rejected by seller
 * 7 - autoclose
 */
if ( ! function_exists( 'wpj_get_cancellation_number_by_type' ) ) {
	function wpj_get_cancellation_number_by_type( $cancel_type ) {
		$force_cancellation = 0;

		if ( $cancel_type ) {
			if ( $cancel_type == 'closed' )      { $force_cancellation = 1; }
			if ( $cancel_type == 'expired' )     { $force_cancellation = 2; }
			if ( $cancel_type == 'mutual' )      { $force_cancellation = 3; }
			if ( $cancel_type == 'arbitration' ) { $force_cancellation = 4; }
			if ( $cancel_type == 'ban' )         { $force_cancellation = 5; }
			if ( $cancel_type == 'rejected' )    { $force_cancellation = 6; }
			if ( $cancel_type == 'autoclose' )   { $force_cancellation = 7; }
			if ( $cancel_type == 'pending' )     { $force_cancellation = 8; }
		}

		return $force_cancellation;
	}
}

if ( ! function_exists( 'wpj_get_order_cancellation_message' ) ) {
	function wpj_get_order_cancellation_message( $order = '', $return = '' ) {
		global $wp_query;

		if ( ! $order ) {
			if ( ! empty ( $wp_query->query_vars['oid'] ) ) {
				$order = wpj_get_order( $wp_query->query_vars['oid'] );
			}
		}

		if ( ! is_object( $order ) ) {
			$order = wpj_get_order( $order );
		}

		$cancelled_by = '';
		$reason       = '';

		if ( $order ) {

			if ( $order->force_cancellation == 1 ) {
				$cancelled_by = __( 'Order cancelled by Admin', 'wpjobster' );
				$reason       = __( 'Order Closed', 'wpjobster' );

			} elseif ( $order->force_cancellation == 2 ) {
				$cancelled_by = __( 'Order cancelled by Buyer', 'wpjobster' );
				$reason       = __( 'Order Expired', 'wpjobster' );

			} elseif ( $order->force_cancellation == 3 ) {
				$cancelled_by = __( 'Order cancelled by User', 'wpjobster' );
				$reason       = __( 'Mutual Cancellation', 'wpjobster' );

			} elseif ( $order->force_cancellation == 4 ) {
				$cancelled_by = __( 'Order cancelled by Admin', 'wpjobster' );
				$reason       = __( 'Arbitration', 'wpjobster' );

			} elseif ( $order->force_cancellation == 5 ) {
				$cancelled_by = __( 'Order cancelled by Admin', 'wpjobster' );
				$reason       = __( 'User Ban', 'wpjobster' );

			} elseif ( $order->force_cancellation == 6 ) {
				$cancelled_by = __( 'Order cancelled by Seller', 'wpjobster' );
				$reason       = __( 'Order Rejected', 'wpjobster' );

			} elseif ( $order->force_cancellation == 7 ) {
				$cancelled_by = __( 'Order cancelled by System', 'wpjobster' );
				$reason       = __( 'Autoclosed because the seller didn\'t respond', 'wpjobster' );

			} elseif ( $order->force_cancellation == 8 ) {
				$cancelled_by = __( 'Order cancelled by Buyer', 'wpjobster' );
				$reason       = __( 'Buyer cancelled the order', 'wpjobster' );

			} else {
				$cancelled_by = __( 'Order cancelled', 'wpjobster' );
				$reason       = '';

			}

		}

		if ( ! $reason && $order ) {
			$payment_row = wpj_get_payment( array( 'payment_type_id' => $order->id, 'payment_type' => 'job_purchase' ) );
			$reason      = $payment_row->payment_details ? $payment_row->payment_details : '-';
		}

		if ( $return == 'message' ) return $cancelled_by;

		if ( $return == 'reason' ) return $reason;

		return array( 'message' => $cancelled_by, 'reason' => $reason );
	}
}

/* Cancel order by id */
if ( ! function_exists( 'wpj_cancel_order_by_id' ) ) {
	function wpj_cancel_order_by_id( $orderid = '', $cancel_type = '', $from_cron = false ) {
		if ( $orderid && $cancel_type ) {

			global $wpdb;

			// Action before
			do_action( 'wpj_before_order_is_cancelled', $orderid, 'job_purchase' );

			// Order row
			$order = wpj_get_order( $orderid );

			// Force cancellation
			$force_cancellation = wpj_get_cancellation_number_by_type( $cancel_type );

			if ( $order ) {

				// Time
				$timestamp = current_time( 'timestamp', 1 );

				// Refund
				wpj_refund_payment( $order, $orderid, $from_cron );

				// Mutual columns
				if ( $cancel_type == 'mutual' ) {
					$more_columns = ", accept_cancellation_request = '1', date_accept_cancellation = '{$timestamp}'";
				} else {
					$more_columns = ", request_cancellation_from_seller = '0', request_cancellation_from_buyer = '0'";
				}

				// Insert to orders
				$query = "
					UPDATE {$wpdb->prefix}job_orders
					SET
						closed = '1',
						force_cancellation = '{$force_cancellation}',
						date_closed = '{$timestamp}',
						payment_status = 'cancelled'
						{$more_columns}
					WHERE id = '{$orderid}'
				";

				$wpdb->query( $query );

				// Custom offer
				if ( wpj_is_custom_offer( $order->pid ) ) {
					wpj_deactivate_custom_offer( $cancel_type, $order->pid, wpj_get_seller_id( $order ) );
				}

			}

			// Action after
			do_action( 'wpj_after_order_is_cancelled', $orderid, 'job_purchase' );
		}

		return false;
	}
}

/* Cancel all user orders */
if ( ! function_exists( 'wpj_cancel_all_orders_by_user' ) ) {
	function wpj_cancel_all_orders_by_user( $uid ) {
		global $wpdb;

		$results = $wpdb->get_results( "
			SELECT orders.id as order_id
				FROM {$wpdb->prefix}job_orders orders
			INNER JOIN {$wpdb->prefix}posts posts
				ON posts.ID = orders.pid
			WHERE closed = 0
				AND completed = 0
				AND ( orders.uid = {$uid}
					OR posts.post_author = {$uid} )
			GROUP BY orders.ID
		" );

		foreach ( $results as $key => $order ) {
			wpj_cancel_order_by_id( $order->order_id, 'ban' );
		}
	}
}