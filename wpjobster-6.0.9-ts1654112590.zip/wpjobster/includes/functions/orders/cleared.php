<?php
/*
 * clearing_period='0' - initial order
 * clearing_period='1' - completed
 * clearing_period='2' - pending clearing
 * clearing_period='3' - clearing blocked by admin
 */
if ( ! function_exists( 'wpj_mark_order_as_cleared' ) ) {
	function wpj_mark_order_as_cleared( $orderid ) {
		global $wpdb;

		$row  = $wpdb->get_row( $wpdb->prepare( "SELECT DISTINCT * FROM {$wpdb->prefix}job_orders WHERE id = %d LIMIT 1", $orderid ) );

		$post = get_post( $row->pid );
		$tm   = current_time( 'timestamp', 1 );

		$raw_amount            = $row->mc_gross;
		$buyer_processing_fees = $row->processing_fees;
		$wpjobster_tax_amount  = $row->tax_amount;

		$current_cash          = wpj_get_user_credit( $post->post_author );
		$payment_gateway       = $row->payment_gateway;

		// check custom extras
		$custom_extras = json_decode( $row->custom_extras );
		if ( $custom_extras ) {
			$i = 0;
			foreach ( $custom_extras as $custom_extra ) {
				if ( $custom_extra->paid ) {
					$custom_extra_order   = wpj_get_custom_extra( $row->id, $i );
					$custom_extra_payment = wpj_get_payment( array(
						'payment_type'    => 'custom_extra',
						'payment_type_id' => $custom_extra_order->id,
					) );

					$raw_amount            += $custom_extra_payment->amount;
					$buyer_processing_fees += $custom_extra_payment->fees;
					$wpjobster_tax_amount  += $custom_extra_payment->tax;
				}
				$i++;
			}
		}

		// check tips
		$tips = json_decode( $row->tips );
		if ( $tips ) {
			$j = 0;
			foreach ( $tips as $tip ) {
				if ( $tip->paid ) {
					$tips_order   = wpj_get_tip( $row->id, $j );
					$tips_payment = wpj_get_payment( array(
						'payment_type'    => 'tips',
						'payment_type_id' => $tips_order->id,
					) );

					$raw_amount            += $tips_payment->amount;
					$buyer_processing_fees += $tips_payment->fees;
					$wpjobster_tax_amount  += $tips_payment->tax;
				}
				$j++;
			}
		}

		$raw_amount = apply_filters( 'wpj_raw_amount_update_filter', $raw_amount, $orderid );
		$amount_fee = wpj_get_site_fee_by_amount( $raw_amount, $orderid, $post->post_author );

		if ( $payment_gateway == 'cod' ) {
			$seller_credit_remain = $current_cash - ( $amount_fee + $wpjobster_tax_amount + $buyer_processing_fees );

		} else {
			$seller_credit_remain = $current_cash + ( $raw_amount - $amount_fee );

		}

		$seller_credit_remain = apply_filters( 'wpj_clearance_amount_filter', $seller_credit_remain, $orderid, $raw_amount );

		wpj_update_user_credit( $post->post_author, $seller_credit_remain );

		wpj_update_user_earned_amount( $post->post_author, $raw_amount );
		wpj_update_completed_orders_amount( $row->uid, $raw_amount );

		// this runs for regular gateways
		do_action( 'wpj_after_job_payment_is_completed', $orderid, 'cleared' );

		$order_url = wpj_get_order_link( $orderid );

		do_action( 'wpj_after_job_cleared', $orderid, $post->post_author );

		if ( $payment_gateway != 'cod' ) {
			$reason = __( 'Payment cleared for', 'wpjobster' ) . ': <a href="' . $order_url . '">' . $post->post_title . '</a>';
			wpj_add_history_log( array( 'tp' => '1', 'reason' => $reason, 'amount' => $raw_amount, 'uid' => $post->post_author, 'oid' => $orderid, 'rid' => 5 ) );

		} else {
			$seller_credit_remain = wpj_get_user_credit( $seller_id );

			if ( $seller_credit_remain < 0 ) {
				wpj_notify_user_translated( 'balance_negative', $seller_id, array( '##amount_updated##' => $seller_credit_remain ) );
			}

			if ( $buyer_processing_fees > 0 ) {
				$reason = __( 'Processing fee for', 'wpjobster' ) . ': <a href="' . $order_url . '">' . $post->post_title . '</a>';
				wpj_add_history_log( array( 'tp' => '0', 'reason' => $reason, 'amount' => $buyer_processing_fees, 'uid' => $post->post_author, 'oid' => $orderid, 'rid' => 13 ) );
			}

			if ( $wpjobster_tax_amount > 0 ) {
				$reason = __( 'Tax for', 'wpjobster' ) . ': <a href="' . $order_url . '">' . $post->post_title . '</a>';
				wpj_add_history_log( array( 'tp' => '0', 'reason' => $reason, 'amount' => $wpjobster_tax_amount, 'uid' => $post->post_author, 'oid' => $orderid, 'rid' => 14 ) );
			}

		}

		$reason = __( 'Fee charged for', 'wpjobster' ) . ': <a href="' . $order_url . '">' . $post->post_title . '</a>';
		wpj_add_history_log( array( 'tp' => '0', 'reason' => $reason, 'amount' => $amount_fee, 'uid' => $post->post_author, 'oid' => $orderid, 'rid' => 6 ) );

		$wpdb->query( "UPDATE {$wpdb->prefix}job_orders SET admin_fee = '{$amount_fee}' WHERE id = '{$orderid}'" );
	}
}