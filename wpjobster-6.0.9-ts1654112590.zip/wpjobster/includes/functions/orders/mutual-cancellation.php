<?php
if ( ! function_exists( 'wpj_request_mutual_cancelation' ) ) {
	function wpj_request_mutual_cancelation() {

		$orderid = isset( $_POST['oid'] ) ? $_POST['oid'] : '';

		if ( $orderid && is_user_logged_in() ) {

			global $wpdb, $wp_rewrite, $wp_query;

			$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_orders WHERE id = '{$orderid}'" );
			if ( $r ) {

				$pid     = $r[0]->pid;
				$message = isset( $_POST['message_to_buyer'] ) ? addslashes( $_POST['message_to_buyer'] ) : '';
				$tm      = current_time( 'timestamp', 1 );

				if ( isset( $_POST['process_action'] ) ) {
					if ( $_POST['process_action'] == 'confirm_cancellation_from_seller' ) { // Seller
						$uid_val            = -8;
						$to_user            = $r[0]->uid;
						$from_user          = wpj_get_seller_id( $r[0] );
						$email_reason       = 'cancel_seller';
						$email_offer_reason = 'cancel_offer_seller';
						$db_message_to      = 'message_to_buyer';
						$db_request_from    = 'request_cancellation_from_seller';

					} elseif ( $_POST['process_action'] == 'confirm_cancellation_from_buyer' ) { // Buyer
						$uid_val            = -9;
						$to_user            = wpj_get_seller_id( $r[0] );
						$from_user          = $r[0]->uid;
						$email_reason       = 'cancel_buyer';
						$email_offer_reason = 'cancel_offer_buyer';
						$db_message_to      = 'message_to_seller';
						$db_request_from    = 'request_cancellation_from_buyer';

					}
				}

				if ( isset( $uid_val ) && ! is_demo_user() ) {
					// Insert to orders
					$wpdb->query( "UPDATE {$wpdb->prefix}job_orders SET {$db_message_to} = '{$message}', {$db_request_from} = '1', accept_cancellation_request = '0', date_request_cancellation = '{$tm}' WHERE id = '{$orderid}'" );

					// Insert to chatbox
					$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = %d AND oid = %d", current_time( 'timestamp', 1 ), $uid_val, $orderid ) );

					if ( ! $row_exist ) {
						$wpdb->insert(
							$wpdb->prefix . 'job_chatbox',
							array(
								'datemade' => current_time( 'timestamp', 1 ),
								'uid'      => $uid_val,
								'oid'      => $orderid,
								'content'  => $message
							),
							array( '%d', '%d', '%d', '%s' )
						);

						// Update notifications
						$this_notification = $wpdb->insert_id;

						wpj_update_user_notifications( array(
							'user1'       => $to_user,
							'user2'       => $from_user,
							'type'        => 'notifications',
							'number'      => +1,
							'notify_id'   => $this_notification,
							'notify_type' => 'mutual_cancellation_request',
							'order_id'    => $orderid
						) );

						// Send emails
						if ( wpj_is_custom_offer( $pid ) ) {
							wpj_cancel_custom_offer( $email_offer_reason, $pid, $orderid, $to_user );

						} else {
							wpj_notify_user_translated( $email_reason, $to_user, array(
								'##transaction_number##'    => wpj_camouflage_oid( $orderid, $r[0]->date_made ),
								'##transaction_page_link##' => wpj_get_order_link( $orderid ),
								'##sender_username##'       => wpj_get_user_display_type( $from_user ),
								'##job_name##'              => $r[0]->job_title,
								'##job_link##'              => urldecode( get_permalink( $pid ) )
							) );

						}
					}
				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_abort_mutual_cancelation' ) ) {
	function wpj_abort_mutual_cancelation() {

		$orderid = isset( $_POST['oid'] ) ? $_POST['oid'] : '';

		if ( $orderid && is_user_logged_in() ) {

			global $wpdb, $wp_query;

			$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_orders WHERE id = '{$orderid}'" );
			if ( $r ) {

				$row  = $r[0];
				$pid  = $row->pid;
				$tm   = current_time( 'timestamp', 1 );

				if ( wpj_get_seller_id( $row ) == get_current_user_id() && $row->request_cancellation_from_seller == 1  ) { // Seller
					$uid_val            = -16;
					$to_user            = $row->uid;
					$from_user          = wpj_get_seller_id( $row );
					$email_reason       = 'cancel_abort_seller';
					$email_offer_reason = 'cancel_offer_abort_seller';
					$db_request_from    = 'request_cancellation_from_seller';

				} elseif ( $row->uid == get_current_user_id() && $row->request_cancellation_from_buyer == 1 ) { // Buyer
					$uid_val            = -17;
					$to_user            = wpj_get_seller_id( $row );
					$from_user          = $row->uid;
					$email_reason       = 'cancel_abort_buyer';
					$email_offer_reason = 'cancel_offer_abort_buyer';
					$db_request_from    = 'request_cancellation_from_buyer';

				}

				if ( isset( $uid_val ) && ! is_demo_user() ) {
					// Insert to orders
					$wpdb->query( "UPDATE {$wpdb->prefix}job_orders SET {$db_request_from} = '0' WHERE id = '{$orderid}'" );

					// Insert to chatbox
					$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = %d AND oid = %d", current_time( 'timestamp', 1 ), $uid_val, $orderid ) );

					if ( ! $row_exist ) {
						$wpdb->insert(
							$wpdb->prefix . 'job_chatbox',
							array(
								'datemade' => current_time( 'timestamp', 1 ),
								'uid'      => $uid_val,
								'oid'      => $orderid,
								'content'  => __( 'Mutual Cancellation Aborted', 'wpjobster' )
							),
							array( '%d', '%d', '%d', '%s' )
						);

						// Update notifications
						$this_notification = $wpdb->insert_id;

						wpj_update_user_notifications( array(
							'user1'       => $to_user,
							'user2'       => $from_user,
							'type'        => 'notifications',
							'number'      => +1,
							'notify_id'   => $this_notification,
							'notify_type' => 'mutual_cancellation_abort',
							'order_id'    => $orderid
						) );

						// Send emails
						if ( wpj_is_custom_offer( $pid ) ) {
							wpj_cancel_custom_offer( $email_offer_reason, $pid, $orderid, $to_user );

						} else {
							wpj_notify_user_translated( $email_reason, $to_user, array(
								'##transaction_number##'    => wpj_camouflage_oid( $orderid, $row->date_made ),
								'##transaction_page_link##' => wpj_get_order_link( $orderid ),
								'##sender_username##'       => wpj_get_user_display_type( $from_user ),
								'##job_name##'              => $row->job_title,
								'##job_link##'              => urldecode( get_permalink( $pid ) )
							) );

						}
					}
				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_answer_mutual_cancellation' ) ) {
	function wpj_answer_mutual_cancellation() {

		$orderid = isset( $_POST['oid'] ) ? $_POST['oid'] : '';
		$accept  = isset( $_POST['accept'] ) ? $_POST['accept'] : '';

		if ( $orderid && $accept && is_user_logged_in() ) {

			global $wpdb, $wp_query;

			$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_orders WHERE id = '{$orderid}'" );
			if ( $r ) {
				$row       = $r[0];
				$pid       = $row->pid;
				$date_made = $row->date_made;
				$tm        = current_time( 'timestamp', 1 );
				$message   = __( 'Mutual cancellation', 'wpjobster' );

				if ( $row->uid == get_current_user_id() && $row->request_cancellation_from_seller == 1 ) { // Buyer
					if ( $accept == 'yes' ) {
						$uid_val            = -10;
						$email_reason       = 'cancel_acc_buyer';
						$email_offer_reason = 'cancel_offer_acc_buyer';

					} elseif ( $accept == 'no' ) {
						$uid_val             = -11;
						$email_reason        = 'cancel_decl_buyer';
						$email_offer_reason  = 'cancel_offer_decl_buyer';

					}

					$to_user   = wpj_get_seller_id( $row );
					$from_user = $row->uid;

				} elseif ( wpj_get_seller_id( $row ) == get_current_user_id() && $row->request_cancellation_from_buyer == 1 ) { // Seller
					if ( $accept == 'yes' ) {
						$uid_val            = -12;
						$email_reason       = 'cancel_acc_seller';
						$email_offer_reason = 'cancel_offer_acc_seller';

					} elseif ( $accept == 'no' ) {
						$uid_val             = -13;
						$email_reason        = 'cancel_decl_seller';
						$email_offer_reason  = 'cancel_offer_decl_seller';

					}

					$from_user = wpj_get_seller_id( $row );
					$to_user   = $row->uid;

				}

				if ( isset( $uid_val ) && ! is_demo_user() ) {

					if ( $accept == 'yes' ) {

						// Cancel the order
						wpj_cancel_order_by_id( $orderid, 'mutual' );

					} else {

						// Insert to orders
						$wpdb->query( "UPDATE {$wpdb->prefix}job_orders SET request_cancellation_from_seller = '0', request_cancellation_from_buyer = '0', accept_cancellation_request = '-1' WHERE id = '{$orderid}'" );
					}

					// Insert to chatbox
					$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = %d AND oid = %d", current_time( 'timestamp', 1 ), $uid_val, $orderid ) );

					if ( ! $row_exist ) {
						$wpdb->insert(
							$wpdb->prefix . 'job_chatbox',
							array(
								'datemade' => current_time( 'timestamp', 1 ),
								'uid'      => $uid_val,
								'oid'      => $orderid,
								'content'  => $message
							),
							array( '%d', '%d', '%d', '%s' )
						);

						// Update notifications
						$this_notification = $wpdb->insert_id;

						wpj_update_user_notifications( array(
							'user1'       => $to_user,
							'user2'       => $from_user,
							'type'        => 'notifications',
							'number'      => +1,
							'notify_id'   => $this_notification,
							'notify_type' => 'mutual_cancellation_answer',
							'order_id'    => $orderid
						) );

						// Send emails
						if ( wpj_is_custom_offer( $pid ) ) {
							wpj_cancel_custom_offer( $email_offer_reason, $pid, $orderid, $to_user );

						} else {
							wpj_notify_user_translated( $email_reason, $to_user, array(
								'##transaction_number##'    => wpj_camouflage_oid( $orderid, $row->date_made ),
								'##transaction_page_link##' => wpj_get_order_link( $orderid ),
								'##sender_username##'       => wpj_get_user_display_type( $from_user ),
								'##job_name##'              => $row->job_title,
								'##job_link##'              => urldecode( get_permalink( $pid ) )
							) );

						}
					}
				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}