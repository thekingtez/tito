<?php // CUSTOM EXTRA

if ( ! function_exists( 'wpj_accept_custom_extra' ) ) {
	function wpj_accept_custom_extra() {

		$order = wpj_get_order( $_POST['oid'] );

		if ( isset( $_POST['custom_extra'] ) && get_current_user_id() == wpj_get_seller_id( $order ) ) {
			$ind = $_POST['custom_extra'];

			$custom_extra_arr = wpj_get_custom_extra( $order->id, $ind );
			if ( $custom_extra_arr ) {
				if ( $custom_extra_arr->payment_gateway_name == 'cod' && $custom_extra_arr->payment_gateway_transaction_id == '-1' ) {
					global $wpdb;

					$query = "
						UPDATE {$wpdb->prefix}job_custom_extra_orders
						SET payment_gateway_transaction_id = ''
						WHERE order_id = {$order->id}
							AND custom_extra_id = {$ind}
					";
					$wpdb->query( $query );
				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_deny_custom_extra' ) ) {
	function wpj_deny_custom_extra() {

		$order = wpj_get_order( $_POST['oid'] );

		if ( isset( $_POST['custom_extra'] ) && get_current_user_id() == $order->uid ) {
			$ind = $_POST['custom_extra'];

			$custom_extras            = json_decode( $order->custom_extras );
			$current_custom_extra_arr = wpj_get_custom_extra( $order->id, $ind );

			if ( $custom_extras[$ind]->declined == false && $custom_extras[$ind]->declined == false && $custom_extras[$ind]->paid == false && wpj_is_order_completed( $order->id ) != 1 && $order->closed != 1 ) {
				$custom_extras[$ind]->declined = true;

				wpj_update_order_meta( $order->id, 'custom_extras', json_encode( $custom_extras ) );

				wpj_notify_user_translated( apply_filters( 'wpj_decline_custom_extra_reason_filter', 'decline_custom_extra', $order->id ), wpj_get_seller_id( $order ), array(
					'##sender_username##'       => wpj_get_user_display_type( $order->uid ),
					'##transaction_number##'    => wpj_camouflage_oid( $order->id, $order->date_made ),
					'##transaction_page_link##' => wpj_get_order_link( $order->id ),
					'##job_name##'              => $order->job_title,
					'##job_link##'              => urldecode( get_permalink( $order->pid ) )
				) );

				global $wpdb;

				// Insert to chatbox
				$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -33 AND oid = %d", current_time( 'timestamp', 1 ), $order->id ) );

				if ( ! $row_exist ) {
					$wpdb->insert(
						$wpdb->prefix . 'job_chatbox',
						array(
							'datemade' => current_time( 'timestamp', 1 ),
							'uid'      => -33,
							'oid'      => $order->id,
							'content'  => $ind
						),
						array( '%d', '%d', '%d', '%s' )
					);

					// Update notifications
					$this_notification = $wpdb->insert_id;

					wpj_update_user_notifications( array(
						'user1'       => wpj_get_seller_id( $order ),
						'user2'       => $order->uid,
						'type'        => 'notifications',
						'number'      => +1,
						'notify_id'   => $this_notification,
						'notify_type' => 'decline_custom_extra',
						'order_id'    => $order->id
					) );
				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_cancel_custom_extra' ) ) {
	function wpj_cancel_custom_extra( $order_id = '', $custom_extra_id = '' ) {
		$order = wpj_get_order( WPJ_Form::post( 'oid', $order_id ) );

		if ( strpos( $_SERVER['HTTP_REFERER'], 'admin.php' ) ) {
			wpj_notify_user_translated( 'custom_extra_cancelled_by_admin', $order->uid, array(
				'##transaction_page_link##' => wpj_get_order_link( $order->id )
			) );

			wpj_notify_user_translated( 'custom_extra_cancelled_by_admin_seller', wpj_get_seller_id( $order ), array(
				'##transaction_page_link##' => wpj_get_order_link( $order->id )
			) );
		}

		if ( ( isset( $_POST['custom_extra'] ) && get_current_user_id() != $order->uid ) || is_numeric( $custom_extra_id ) ) {
			$ind = WPJ_Form::post( 'custom_extra', $custom_extra_id );

			$custom_extras            = json_decode( $order->custom_extras );
			$current_custom_extra_arr = wpj_get_custom_extra( $order->id, $ind );

			if ( $custom_extras[$ind]->cancelled == false && $custom_extras[$ind]->declined == false && $custom_extras[$ind]->paid == false && wpj_is_order_completed( $order->id ) != 1 && $order->closed != 1 ) {

				global $wpdb;

				$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_custom_extra_orders WHERE order_id = '{$order->id}' AND custom_extra_id = '{$ind}'" );

				if ( ! $r ) {
					$custom_extras[$ind]->cancelled = true;

					wpj_update_order_meta( $order->id, 'custom_extras', json_encode( $custom_extras ) );

					wpj_notify_user_translated( apply_filters( 'wpj_cancel_custom_extra_reason_filter', 'cancel_custom_extra', $order->id ), $order->uid, array(
						'##sender_username##'       => wpj_get_user_display_type( $order->uid ),
						'##transaction_number##'    => wpj_camouflage_oid( $order->id, $order->date_made ),
						'##transaction_page_link##' => wpj_get_order_link( $order->id ),
						'##job_name##'              => $order->job_title,
						'##job_link##'              => urldecode( get_permalink( $order->pid ) )
					) );

					$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -32 AND oid = %d", current_time( 'timestamp', 1 ), $order->id ) );

					if ( ! $row_exist ) {
						$wpdb->insert(
							$wpdb->prefix . 'job_chatbox',
							array(
								'datemade' => current_time( 'timestamp', 1 ),
								'uid'      => -32,
								'oid'      => $order->id,
								'content'  => $ind
							),
							array( '%d', '%d', '%d', '%s' )
						);

						$this_notification = $wpdb->insert_id;

						wpj_update_user_notifications( array(
							'user1'       => $order->uid,
							'user2'       => wpj_get_seller_id( $order ),
							'type'        => 'notifications',
							'number'      => +1,
							'notify_id'   => $this_notification,
							'notify_type' => 'cancel_custom_extra',
							'order_id'    => $order->id
						) );
					}
				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

// HELPERS
if ( ! function_exists( 'wpj_insert_custom_extra_order' ) ) {
	function wpj_insert_custom_extra_order( $args = array() ) {
		global $wpdb, $wp_query;

		// Order info
		$oid = ! empty( $args['oid'] ) ? $args['oid'] : WPJ_Form::request( 'oid' );
		if ( ! $oid && isset( $wp_query->query_vars['oid'] ) ) $oid = $wp_query->query_vars['oid'];

		$order = wpj_get_order( $oid );

		// Payment info
		$payment_status  = ! empty( $args['payment_status'] ) ? $args['payment_status'] : 'pending';
		$payment_gateway = ! empty( $args['payment_gateway'] ) ? $args['payment_gateway'] : WPJ_Form::get( 'pay_for_item' );

		// Currency
		$currency = ! empty( $args['currency'] ) ? $args['currency'] : apply_filters( 'wpjobster_take_allowed_currency_' . $payment_gateway, '' );
		if ( empty( $currency ) ) $currency = wpj_get_site_curreny();

		// Custom extra id
		$custom_extra_id = isset( $args['custom_extra'] ) && is_numeric( $args['custom_extra'] ) ? $args['custom_extra'] : WPJ_Form::request( 'custom_extra' );
		if ( ! is_numeric( $custom_extra_id ) ) $custom_extra_id = 0;

		// User info
		$user_id = ! empty( $args['user_id'] ) ? $args['user_id'] : get_current_user_id();

		// Custom extra amount
		$custom_extra_amount = isset( $args['custom_extra_amount'] ) && is_numeric( $args['custom_extra_amount'] ) ? $args['custom_extra_amount'] : '';
		if ( ! is_numeric( $custom_extra_amount ) ) {
			$custom_extras       = json_decode( $order->custom_extras );
			$custom_extra_amount = $custom_extras[$custom_extra_id]->price;
		}
		if ( ! is_numeric( $custom_extra_amount ) ) $custom_extra_amount = 0;

		$custom_extra_amount_exchanged = wpj_number_format_special_exchange( $custom_extra_amount, '1', $currency );

		// Date info
		$added_on = ! empty( $args['added_on'] ) ? $args['added_on'] : current_time( 'timestamp', 1 );

		// Buyer Fee
		$processing_fees = ! empty( $args['processing_fees'] ) ? $args['processing_fees'] : '';
		if ( ! $processing_fees )
			$processing_fees = wpj_get_site_processing_fee_by_amount( $custom_extra_amount, 0, 0 );
		$processing_fees_exchanged = wpj_number_format_special_exchange( $processing_fees, '1', $currency );

		// Tax
		$tax = ! empty( $args['tax'] ) ? $args['tax'] : '';
		if ( ! $tax )
			$tax = wpj_get_site_tax_by_amount( $custom_extra_amount, 0, 0, $processing_fees );
		$tax_exchanged = wpj_number_format_special_exchange( $tax, '1', $currency );

		// Final order price
		$payable_amount = ! empty( $args['payable_amount'] ) ? $args['payable_amount'] : '';
		if ( ! $payable_amount )
			$payable_amount = $custom_extra_amount + $tax + $processing_fees;
		$payable_amount_exchanged = $custom_extra_amount_exchanged + $processing_fees_exchanged + $tax_exchanged;

		// Decrease credits if payment method is Account Balance
		if ( $payment_gateway == 'credits' ) {
			$user_credit = wpj_get_user_credit( $user_id );

			if ( $payable_amount > $user_credit ) {
				wp_redirect( wpj_get_payment_link() . 'topup?no_credits=1' ); exit;
			}

			wpj_update_user_credit( $user_id, $user_credit - $payable_amount );
		}

		// Insert order to database
		$wpdb->insert(
			$wpdb->prefix . 'job_custom_extra_orders',
			array(
				'order_id'             => $oid,
				'custom_extra_id'      => $custom_extra_id,
				'user_id'              => $user_id,
				'custom_extra_amount'  => $custom_extra_amount,
				'added_on'             => $added_on,
				'payment_status'       => $payment_status,
				'payment_gateway_name' => $payment_gateway,
				'tax'                  => $tax_exchanged,
				'payable_amount'       => $payable_amount_exchanged,
				'currency'             => $currency,
			),
			array( '%d', '%d', '%d', '%f', '%d', '%s', '%s', '%f', '%f', '%s' )
		);

		$orderid = $wpdb->insert_id;

		do_action( 'wpj_after_insert_custom_extra_order', $orderid );

		// Insert payment to database
		$wpdb->insert(
			$wpdb->prefix . 'job_payment_received',
			array(
				'payment_status'         => $payment_status == 'completed' ? 1 : 0,
				'payment_gateway'        => $payment_gateway,
				'payment_type'           => 'custom_extra',
				'payment_type_id'        => $orderid,
				'fees'                   => $processing_fees,
				'amount'                 => $custom_extra_amount,
				'datemade'               => current_time( 'timestamp', 1 ),
				'tax'                    => $tax,
				'currency'               => wpj_get_site_default_curreny(),
				'final_amount'           => $payable_amount,
				'final_amount_exchanged' => $payable_amount_exchanged,
				'final_amount_currency'  => $currency,
			),
			array( '%d', '%s', '%s', '%d', '%f', '%f', '%d', '%f', '%s', '%f', '%f', '%s' )
		);

		return $orderid;
	}
}

if ( ! function_exists( 'wpj_get_custom_extras' ) ) {
	function wpj_get_custom_extras( $order ) {
		if ( is_object( $order ) ) $order_id = $order->id;
		else $order_id = $order;

		global $wpdb;
		$custom_extras = $wpdb->get_results( $wpdb->prepare(
			"
			SELECT * FROM {$wpdb->prefix}job_custom_extra_orders
			WHERE order_id = %d
			ORDER BY custom_extra_id ASC
			",
			$order_id
		) );

		return $custom_extras;
	}
}

if ( ! function_exists( 'wpj_get_custom_extra' ) ) {
	function wpj_get_custom_extra( $order, $custom_extra_id ) {
		if ( is_object( $order ) ) $order_id = $order->id;
		else $order_id = $order;

		global $wpdb;
		$custom_extra = $wpdb->get_row( $wpdb->prepare(
			"
			SELECT * FROM {$wpdb->prefix}job_custom_extra_orders
			WHERE order_id = %d
				AND custom_extra_id = %d
			",
			$order_id, $custom_extra_id
		) );

		return $custom_extra;
	}
}

if ( ! function_exists( 'wpj_get_custom_extra_order_by' ) ) {
	function wpj_get_custom_extra_order_by( $column_name = '', $val = '' ) {
		global $wpdb;

		$val = esc_sql( $val );

		if ( is_numeric( $val ) )
			return $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}job_custom_extra_orders WHERE " . $column_name . " = " . $val );

		return false;
	}
}

if ( ! function_exists( 'wpj_get_custom_extras_amount' ) ) {
	function wpj_get_custom_extras_amount( $row = '', $ret = '' ) {
		$total_amount = 0;
		$total_fees   = 0;
		$total_tax    = 0;

		if ( $row->custom_extras ) {
			$custom_extras = json_decode( $row->custom_extras );
			if ( $custom_extras ) {
				$i = 0;
				foreach ( $custom_extras as $custom_extra ) {
					if ( $custom_extra->paid ) {
						$custom_extra_ord = wpj_get_custom_extra( $row->id, $i );
						if ( $custom_extra_ord ) {
							$custom_extra_payment = wpj_get_payment( array(
								'payment_type'    => 'custom_extra',
								'payment_type_id' => $custom_extra_ord->id,
							) );

							$total_amount += $custom_extra_payment->amount;
							$total_fees   += $custom_extra_payment->fees;
							$total_tax    += $custom_extra_payment->tax;
						}
					}
					$i++;
				}
			}
		}

		if ( $ret == 'amount' ) return $total_amount;
		elseif ( $ret == 'fees' ) return $total_fees;
		elseif ( $ret == 'tax' ) return $total_tax;
		else return $total_amount + $total_fees + $total_tax;
	}
}