<?php
if ( ! function_exists( 'wpj_is_order_completed' ) ) {
	function wpj_is_order_completed( $order = '' ) {
		global $wp_query;

		if ( ! $order ) $order = $wp_query->query_vars['oid'];

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		$job_post = get_post( $order->pid );

		$completed = 0;

		if ( get_current_user_id() != $job_post->post_author ) {
			if ( $order->done_buyer == 1 ) $completed = 1;
		}

		if ( get_current_user_id() == $job_post->post_author ) {
			if ( $order->done_buyer == 1 ) $completed = 1;
			if ( $order->done_buyer == -1 ) $completed = -1;
		}

		return $completed;

	}
}

if ( ! function_exists( 'wpj_order_can_be_closed' ) ) {
	function wpj_order_can_be_closed( $order = '', $action = 'closed' ) {
		global $wp_query;

		if ( ! $order ) $order = $wp_query->query_vars['oid'];

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		$job_post = get_post( $order->pid );

		$can_be_closed      = 0;
		$can_request_closed = 0;

		if ( get_current_user_id() != $job_post->post_author ) {

			$can_be_closed      = 0;
			$can_request_closed = 1;

			if ( get_current_user_id() == $order->uid && $order->expected_delivery < current_time( 'timestamp', 1 ) )
				$can_be_closed = 1;

			if ( $order->closed == 1 ) {
				$can_be_closed      = 0;
				$can_request_closed = 0;
			}

			if ( $order->completed == 1 ) {
				$can_be_closed      = 0;
				$can_request_closed = 0;
			}
		}

		if ( get_current_user_id() == $job_post->post_author ) {

			$can_request_closed = 1;

			if ( $order->closed == 1 ) $can_request_closed = 0;

			if ( $order->completed == 1 ) {
				$can_be_closed      = 0;
				$can_request_closed = 0;
			}
		}

		$can_request_closed = apply_filters( 'wpj_order_can_be_closed_filter', $can_request_closed, $order );

		return $action == 'request' ? $can_request_closed : $can_be_closed;
	}
}

if ( ! function_exists( 'wpj_mark_order_as_completed' ) ) {
	function wpj_mark_order_as_completed( $orderid = '' ) {
		if ( ! is_user_logged_in() ) { die(); }

		if ( ! $orderid ) { $orderid = $_POST['oid']; }

		$order = wpj_get_order( $orderid );

		do_action( 'wpj_before_order_marked_as_completed', $orderid );

		if ( ! is_demo_user() ) {

			global $wpdb;

			$clearing_period = wpj_get_option( 'wpjobster_clearing_period' );

			$clear_now   = 0;
			$timestamp14 = strtotime( '+14 days', current_time( 'timestamp', 1 ) );

			if ( is_numeric( $clearing_period ) ) {
				if ( $clearing_period == 0 || $order->payment_gateway == 'cod' ) {
					$clear_now   = 1;
					$timestamp14 = current_time( 'timestamp', 1 );

				} else {
					$timestamp14 = strtotime( '+' . $clearing_period . ' days', current_time( 'timestamp', 1 ) );

				}
			}

			if ( $order->completed == 0 && $order->done_seller == 1 && $order->closed != 1 ) {

				$wpdb->update(
					$wpdb->prefix . 'job_orders',
					array(
						'clearing_period' => 2,
						'date_to_clear'   => $timestamp14
					),
					array(
						'id' => $orderid
					)
				);

				if ( $order->uid == get_current_user_id() ) {

					$wpdb->update(
						$wpdb->prefix . 'job_orders',
						array(
							'done_buyer'     => 1,
							'completed'      => 1,
							'date_completed' => current_time( 'timestamp', 1 )
						),
						array(
							'id' => $orderid
						)
					);

					if ( wpj_is_custom_offer( $order->pid ) ) {
						wpj_complete_custom_offer( $order->pid, $orderid, wpj_get_seller_id( $order ) );

					} else {
						wpj_notify_user_translated( 'order_complete', wpj_get_seller_id( $order ), array(
							'##sender_username##'       => wpj_get_user_display_type( get_current_user_id() ),
							'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
							'##transaction_page_link##' => wpj_get_order_link( $orderid ),
							'##job_name##'              => $order->job_title,
							'##job_link##'              => urldecode( get_permalink( $order->pid ) )
						) );

					}

					/* Calculate FEE */

					$raw_amount = $order->mc_gross;

					// check custom extra
					$custom_extras = json_decode( $order->custom_extras );
					if ( $custom_extras ) { $i = 0;
						foreach ( $custom_extras as $custom_extra ) {
							if ( $custom_extra->paid ) {
								$custom_extra_order   = wpj_get_custom_extra( $order->id, $i );
								$custom_extra_payment = wpj_get_payment( array( 'payment_type' => 'custom_extra', 'payment_type_id' => $custom_extra_order->id ) );

								$raw_amount += $custom_extra_payment->amount;
							} $i++;
						}
					}

					// check tips
					$tips = json_decode( $order->tips );
					if ( $tips ) { $j = 0;
						foreach ( $tips as $tip ) {
							if ( $tip->paid ) {
								$tips_order   = wpj_get_tip( $order->id, $j );
								$tips_payment = wpj_get_payment( array( 'payment_type' => 'tips', 'payment_type_id' => $tips_order->id ) );

								$raw_amount += $tips_payment->amount;
							} $j++;
						}
					}

					$row_exist1 = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_admin_earnings WHERE orderid = %d AND pid = %d AND datemade = %d", $orderid, $order->pid, current_time( 'timestamp', 1 ) ) );

					if ( ! $row_exist1 ) {
						$wpdb->insert(
							$wpdb->prefix . 'job_admin_earnings',
							array(
								'orderid'   => $orderid,
								'pid'       => $order->pid,
								'admin_fee' => wpj_get_site_fee_by_amount( $raw_amount, $orderid, wpj_get_seller_id( $order ) ),
								'datemade'  => current_time( 'timestamp', 1 )
							),
							array( '%d', '%d', '%s', '%d' )
						);
					}

					// insert to chatbox
					$row_exist2 = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -2 AND oid = %d", current_time( 'timestamp', 1 ), $orderid ) );

					if ( ! $row_exist2 ) {
						$wpdb->insert(
							$wpdb->prefix . 'job_chatbox',
							array(
								'datemade' => current_time( 'timestamp', 1 ),
								'uid'      => -2,
								'oid'      => $orderid,
								'content'  => __( 'Completed', 'wpjobster' )
							),
							array( '%d', '%s', '%d', '%s' )
						);

						// update notifications
						$this_notification = $wpdb->insert_id;

						wpj_update_user_notifications( array(
							'user1'       => wpj_get_seller_id( $order ),
							'user2'       => $order->uid,
							'type'        => 'notifications',
							'number'      => +1,
							'notify_id'   => $this_notification,
							'notify_type' => 'order_complete',
							'order_id'    => $order->id
						) );
					}

					if ( $clear_now ) {

						$wpdb->update(
							$wpdb->prefix . 'job_orders',
							array(
								'clearing_period' => 1
							),
							array(
								'id' => $orderid
							)
						);

						wpj_mark_order_as_cleared( $order->id );

					}

				}

			}

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}