<?php
if ( ! function_exists( 'wpj_is_order_delivered' ) ) {
	function wpj_is_order_delivered( $order = '' ) {
		global $wp_query;

		if ( ! $order ) $order = $wp_query->query_vars['oid'];

		if ( ! is_object( $order ) ) $order = wpj_get_order( $order );

		$delivered = 0;

		if ( get_current_user_id() != wpj_get_seller_id( $order ) ) {
			if ( $order->done_seller == 1 ) $delivered = 1;
		}

		if ( get_current_user_id() == wpj_get_seller_id( $order ) ) {
			if ( $order->done_seller == 1 ) $delivered = 1;
			if ( $order->done_seller == -1 ) $delivered = -1;
		}

		return $delivered;
	}
}

if ( ! function_exists( 'wpj_mark_order_as_delivered' ) ) {
	function wpj_mark_order_as_delivered( $oid = '' ) {
		global $wp_query;

		if ( ! is_user_logged_in() ) die();

		$oid = WPJ_Form::post( 'oid', $oid );

		if ( ! $oid ) $oid = $wp_query->query_vars['oid'];

		$order = wpj_get_order( $oid );

		if (
			( wpj_get_seller_id( $order ) == get_current_user_id() )
			&& $order->closed != 1
			&& $order->request_cancellation_from_seller != 1
			&& $order->request_cancellation_from_buyer != 1
		) {

			global $wpdb;

			do_action( 'wpj_before_order_marked_as_delivered', $order->id );

			if ( ! is_demo_user() ) {

				if ( $order->done_seller != 1 ) {

					$wpdb->update(
						$wpdb->prefix . 'job_orders',
						array(
							'done_seller'   => 1,
							'date_finished' => current_time( 'timestamp', 1 )
						),
						array(
							'id' => $order->id
						)
					);

					// Insert to chatbox
					$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -1 AND oid = %d", current_time( 'timestamp', 1 ), $order->id ) );

					if ( ! $row_exist ) {
						$wpdb->insert(
							$wpdb->prefix . 'job_chatbox',
							array(
								'datemade' => current_time( 'timestamp', 1 ),
								'uid'      => -1,
								'oid'      => $order->id,
								'content'  => __( 'Delivered', 'wpjobster' )
							),
							array( '%d', '%s', '%d', '%s' )
						);

						// Update notifications
						$this_notification = $wpdb->insert_id;

						wpj_update_user_notifications( array(
							'user1'       => $order->uid,
							'user2'       => get_current_user_id(),
							'type'        => 'notifications',
							'number'      => +1,
							'notify_id'   => $this_notification,
							'notify_type' => 'order_delivered',
							'order_id'    => $order->id
						) );

						if ( wpj_is_custom_offer( $order->pid ) ) {
							wpj_deliver_custom_offer( $order->pid, $order->id, $order->uid );

						} else {
							wpj_notify_user_translated( 'order_delivered', $order->uid, array(
								'##sender_username##'       => wpj_get_user_display_type( get_current_user_id() ),
								'##transaction_number##'    => wpj_camouflage_oid( $order->id, $order->date_made ),
								'##transaction_page_link##' => wpj_get_order_link( $order->id ),
								'##job_name##'              => $order->job_title,
								'##job_link##'              => urldecode( get_permalink( $order->pid ) )
							) );

						}
					}

				}
			}

			do_action( 'wpj_after_order_marked_as_delivered', $order->id );

		}

		if ( wpj_is_ajax_call() ) wp_die();

	}
}