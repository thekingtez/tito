<?php // TIPS

if ( ! function_exists( 'wpj_add_new_tip' ) ) {
	function wpj_add_new_tip() {
		global $wpdb;

		$reason = trim( nl2br( strip_tags( htmlspecialchars( wpj_encode_emoji( WPJ_Form::post( 'tips_reason', 0 ) ) ) ) ) );
		$user   = WPJ_Form::post( 'user', '' );
		$amount = WPJ_Form::post( 'tips_amount', 0 );
		$oid    = WPJ_Form::post( 'oid', 0 );

		if ( get_current_user_id() != $user ) {
			$msg = array(
				'description' => __( 'Yo\'re not the buyer!', 'wpjobster' ),
				'cssClass'    => 'negative',
				'code'        => 'error'
			);
		} elseif ( ! $amount || ! is_numeric( $amount ) || $amount <= 0 ) {
			$msg = array(
				'description' => __( 'Amount is wrong', 'wpjobster' ),
				'cssClass'    => 'negative',
				'code'        => 'error'
			);
		} else {
			$msg = array(
				'description' => __( 'Your tips was successfully sent.', 'wpjobster' ),
				'cssClass'    => 'success',
				'code'        => 'success'
			);

			$order = wpj_get_order( $oid );

			$new_tips['reason']    = $reason;
			$new_tips['amount']    = $amount;
			$new_tips['time']      = current_time( 'timestamp', 1 );
			$new_tips['paid']      = false;
			$new_tips['cancelled'] = false;

			if ( ! $order->tips )
				$order->tips = array();
			else
				$order->tips = json_decode( $order->tips );

			array_push( $order->tips, $new_tips );

			wpj_update_order_meta( $oid, 'tips', json_encode( $order->tips ) );

			$count = count( $order->tips ) - 1;

			$wpdb->insert(
				$wpdb->prefix . 'job_chatbox',
				array(
					'datemade' => current_time( 'timestamp', 1 ),
					'uid'      => -36,
					'oid'      => $oid,
					'content'  => $count
				),
				array( '%d', '%d', '%d', '%s' )
			);

			wpj_notify_user_translated( 'new_tips', $order->uid, array( '##transaction_page_link##' => wpj_get_order_link( $oid ) ) );

			$msg['oid']     = $oid;
			$msg['tips_id'] = $count;
		}

		wp_send_json( $msg );

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_cancel_tips' ) ) {
	function wpj_cancel_tips() {
		global $wpdb;

		$order = wpj_get_order( $_POST['oid'] );
		$uid   = get_current_user_id();

		if ( isset( $_POST['tips'] ) && $uid == $order->uid ) {
			$ind  = $_POST['tips'];
			$tips = json_decode( $order->tips );

			if ( $tips[$ind]->cancelled == false && $tips[$ind]->paid == false ) {

				$r = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}job_tips_orders WHERE order_id = {$order->id} AND tips_id = {$ind}" );

				if ( ( ! isset( $r[0] ) && ! $r[0] ) || $r[0]->payment_gateway_name == 'banktransfer' ) {
					$tips[$ind]->cancelled = true;

					wpj_update_order_meta( $order->id, 'tips', json_encode( $tips ) );

					wpj_notify_user_translated( 'cancel_tips', $order->uid, array( '##transaction_page_link##' => wpj_get_order_link( $order->id ) ) );

					$datemade = current_time( 'timestamp', 1 );

					// Insert to chatbox
					$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -38 AND oid = %d", current_time( 'timestamp', 1 ), $order->id ) );

					if ( ! $row_exist ) {
						$wpdb->insert(
							$wpdb->prefix . 'job_chatbox',
							array(
								'datemade' => current_time( 'timestamp', 1 ),
								'uid'      => -38,
								'oid'      => $order->id,
								'content'  => $ind
							),
							array( '%d', '%d', '%d', '%s' )
						);
					}

					$wpdb->query( "UPDATE {$wpdb->prefix}job_tips_orders SET payment_status = 'cancelled' WHERE order_id = {$order->id} AND tips_id = {$ind}" );
				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

// HELPERS

if ( ! function_exists( 'wpj_insert_tips_order' ) ) {
	function wpj_insert_tips_order( $args = array() ) {
		global $wpdb, $wp_query;

		// Order info
		$oid = ! empty( $args['oid'] ) ? $args['oid'] : WPJ_Form::request( 'oid' );
		if ( ! $oid && isset( $wp_query->query_vars['oid'] ) ) $oid = $wp_query->query_vars['oid'];

		$order = wpj_get_order( $oid );

		// Payment info
		$payment_status  = ! empty( $args['payment_status'] ) ? $args['payment_status'] : 'pending';
		$payment_gateway = ! empty( $args['payment_gateway'] ) ? $args['payment_gateway'] : WPJ_Form::get( 'pay_for_item' );

		// Currency
		$currency = ! empty( $args['currency'] ) ? $args['currency'] : apply_filters( 'wpjobster_take_allowed_currency_' . $payment_gateway, '' );
		if ( empty( $currency ) ) $currency = wpj_get_site_curreny();

		// Tips id
		$tips_id = isset( $args['tips'] ) && is_numeric( $args['tips'] ) ? $args['tips'] : WPJ_Form::request( 'tips' );
		if ( ! is_numeric( $tips_id ) ) $tips_id = 0;

		// User info
		$user_id = ! empty( $args['user_id'] ) ? $args['user_id'] : get_current_user_id();

		// Tips amount
		$tips       = json_decode( $order->tips );
		$tip_amount = $tips[$tips_id]->amount;
		if ( ! is_numeric( $tip_amount ) ) $tip_amount = 0;
		$tip_amount_exchanged = wpj_number_format_special_exchange( $tip_amount, '1', $currency );

		// Date info
		$added_on = ! empty( $args['added_on'] ) ? $args['added_on'] : current_time( 'timestamp', 1 );

		// Buyer Fee
		$processing_fees = ! empty( $args['processing_fees'] ) ? $args['processing_fees'] : '';
		if ( ! $processing_fees )
			$processing_fees = wpj_get_site_processing_fee_by_amount( $tip_amount, 0, 0 );
		$processing_fees_exchanged = wpj_number_format_special_exchange( $processing_fees, '1', $currency );

		// Tax
		$tax = ! empty( $args['tax'] ) ? $args['tax'] : '';
		if ( ! $tax )
			$tax = wpj_get_site_tax_by_amount( $tip_amount, 0, 0, $processing_fees );
		$tax_exchanged = wpj_number_format_special_exchange( $tax, '1', $currency );

		// Final order price
		$payable_amount = ! empty( $args['payable_amount'] ) ? $args['payable_amount'] : '';
		if ( ! $payable_amount )
			$payable_amount = $tip_amount + $tax + $processing_fees;
		$payable_amount_exchanged = $tip_amount_exchanged + $processing_fees_exchanged + $tax_exchanged;

		// Decrease credits if payment method is Account Balance
		if ( $payment_gateway == 'credits' ) {
			$user_credit = wpj_get_user_credit( $user_id );

			if ( $payable_amount > $user_credit ) {
				wp_redirect( wpj_get_payment_link() . 'topup?no_credits=1' ); exit;
			}

			wpj_update_user_credit( $user_id, $user_credit - $payable_amount );
		}

		// Insert order to database
		$wpdb->insert(
			$wpdb->prefix . 'job_tips_orders',
			array(
				'order_id'             => $oid,
				'tips_id'              => $tips_id,
				'user_id'              => $user_id,
				'tips_amount'          => $tip_amount,
				'added_on'             => $added_on,
				'payment_status'       => $payment_status,
				'payment_gateway_name' => $payment_gateway,
				'tax'                  => $tax_exchanged,
				'payable_amount'       => $payable_amount_exchanged,
				'currency'             => $currency,
			),
			array( '%d', '%d', '%d', '%f', '%d', '%s', '%s', '%f', '%f', '%s' )
		);

		$orderid = $wpdb->insert_id;

		do_action( 'wpj_after_insert_tips_order', $orderid );

		// Insert payment to database
		$wpdb->insert(
			$wpdb->prefix . 'job_payment_received',
			array(
				'payment_status'         => $payment_status == 'completed' ? 1 : 0,
				'payment_gateway'        => $payment_gateway,
				'payment_type'           => 'tips',
				'payment_type_id'        => $orderid,
				'fees'                   => $processing_fees,
				'amount'                 => $tip_amount,
				'datemade'               => current_time( 'timestamp', 1 ),
				'tax'                    => $tax,
				'currency'               => wpj_get_site_default_curreny(),
				'final_amount'           => $payable_amount,
				'final_amount_exchanged' => $payable_amount_exchanged,
				'final_amount_currency'  => $currency,
			),
			array( '%d', '%s', '%s', '%d', '%f', '%f', '%d', '%f', '%s', '%f', '%f', '%s' )
		);

		return $orderid;
	}
}

/**
 * Retrieve tips object for a particular order
 *
 * @since Jobster v5.3.0
 *
 * @param object|int
 * @return object
 */
if ( ! function_exists( 'wpj_get_tips' ) ) {
	function wpj_get_tips( $order ) {
		if ( is_object( $order ) ) {
			$order_id = $order->id;
		} else {
			$order_id = $order;
		}

		global $wpdb;
		$tips = $wpdb->get_results( $wpdb->prepare(
			"
			SELECT * FROM {$wpdb->prefix}job_tips_orders
			WHERE order_id = %d
			ORDER BY tips_id ASC
			",
			$order_id
		) );

		return $tips;
	}
}

/**
 * Retrieve single tips for a particular order
 *
 * @since Jobster v5.3.0
 *
 * @param object|int
 * @param int
 * @return object
 */
if ( ! function_exists( 'wpj_get_tip' ) ) {
	function wpj_get_tip( $order, $tips_id ) {
		if ( is_object( $order ) ) {
			$order_id = $order->id;
		} else {
			$order_id = $order;
		}

		global $wpdb;
		$tips = $wpdb->get_row( $wpdb->prepare(
			"
			SELECT * FROM {$wpdb->prefix}job_tips_orders
			WHERE order_id = %d
				AND tips_id = %d
			",
			$order_id, $tips_id
		) );

		return $tips;
	}
}

// GET TIPS ORDER
if ( ! function_exists( 'wpj_get_tips_order_by' ) ) {
	function wpj_get_tips_order_by( $column_name = '', $val = '' ) {
		global $wpdb;

		$val = esc_sql( $val );

		if ( is_numeric( $val ) )
			return $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}job_tips_orders WHERE " . $column_name . " = " . $val );

		return false;
	}
}
