<?php
if ( ! function_exists( 'wpj_get_arbitration_details_by_id' ) ) {
	function wpj_get_arbitration_details_by_id( $id = '' ) {
		if ( $id ) {
			global $wpdb;
			return $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}job_orders_arbitration WHERE id = '{$id}'" );
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_get_arbitration_details_by_order_id' ) ) {
	function wpj_get_arbitration_details_by_order_id( $order_id = '' ) {
		if ( $order_id ) {
			global $wpdb;
			return $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}job_orders_arbitration WHERE order_id = '{$order_id}'" );
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_get_arbitration_in_review_number' ) ) {
	function wpj_get_arbitration_in_review_number() {
		global $wpdb;

		$results = $wpdb->get_results( "
			SELECT * FROM {$wpdb->prefix}job_orders_arbitration
			WHERE seller_arbitration = 0
				AND buyer_arbitration = 0
				AND ( request_from_seller = 1 || request_from_buyer = 1 )
		" );

		return $results ? count( $results ) : 0;
	}
}

if ( ! function_exists( 'wpj_order_has_arbitration' ) ) {
	function wpj_order_has_arbitration( $order_id = '' ) {
		if ( $order_id ) {
			$arbitration_order = wpj_get_arbitration_details_by_order_id( $order_id );

			if ( $arbitration_order ) {
				if ( $arbitration_order->request_from_buyer == 0 && $arbitration_order->request_from_seller == 0 ) {
					return false;

				} elseif ( $arbitration_order->seller_arbitration == 0 && $arbitration_order->buyer_arbitration == 0 ) {
					return true;

				} elseif ( $arbitration_order->seller_arbitration == 1 ) {
					return false;

				} elseif ( $arbitration_order->buyer_arbitration == 1 ) {
					return true;

				}
			}
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_request_arbitration' ) ) {
	function wpj_request_arbitration() {
		global $wpdb;

		$uid = get_current_user_id();

		$orderid          = isset( $_POST['oid'] ) ? $_POST['oid'] : '';
		$message_to_admin = isset( $_POST['message_to_admin'] ) ? addslashes( $_POST['message_to_admin'] ) : '';

		if ( $orderid ) {
			$order = wpj_get_order( $orderid );

			$seller_id = wpj_get_seller_id( $order );
			$buyer_id  = $order->uid;

			$date_made = $order->date_made;

			if ( $uid == $seller_id ) {
				$query_uid           = -39;
				$message_dest        = 'message_to_buyer';
				$request_from_buyer  = 0;
				$request_from_seller = 1;
				$notify_uid          = $buyer_id;
				$notify_sender_uid   = $seller_id;

			} elseif ( $uid == $buyer_id ) {
				$query_uid           = -40;
				$message_dest        = 'message_to_seller';
				$request_from_buyer  = 1;
				$request_from_seller = 0;
				$notify_uid          = $seller_id;
				$notify_sender_uid   = $buyer_id;

			}

			if ( isset( $query_uid ) ) {

				if ( ! is_demo_user() ) {

					$tm = current_time( 'timestamp', 1 );

					$query_exist = "SELECT * FROM {$wpdb->prefix}job_orders_arbitration WHERE order_id = {$orderid}";
					$results = $wpdb->get_results( $query_exist );

					$arbitration_exist = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}job_orders_arbitration WHERE order_id = %d", $orderid ) );
					if ( ! $arbitration_exist || ( $arbitration_exist && $arbitration_exist->request_from_buyer == 0 && $arbitration_exist->request_from_seller == 0 ) ) {
						if ( $message_to_admin ) {

							if ( $arbitration_exist ) {
								$wpdb->query( "
									UPDATE {$wpdb->prefix}job_orders_arbitration
									SET request_from_buyer = {$request_from_buyer},
										request_from_seller = {$request_from_seller},
										date_request = {$tm},
										message_to_support = '{$message_to_admin}'
									WHERE order_id = {$orderid}
								" );

							} else {
								$order_ar_query = "INSERT INTO {$wpdb->prefix}job_orders_arbitration VALUES( '', {$orderid}, {$request_from_buyer}, {$request_from_seller}, {$tm}, '{$message_to_admin}', '', 0, 0, 0)";
								$wpdb->query( $order_ar_query );

							}

							// Insert to chatbox
							$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = %d AND oid = %d", current_time( 'timestamp', 1 ), $query_uid, $orderid ) );

							if ( ! $row_exist ) {
								$wpdb->insert(
									$wpdb->prefix . 'job_chatbox',
									array(
										'datemade' => current_time( 'timestamp', 1 ),
										'uid'      => $query_uid,
										'oid'      => $orderid,
										'content'  => $message_to_admin
									),
									array( '%d', '%d', '%d', '%s' )
								);

								// Update notifications
								$this_notification = $wpdb->insert_id;

								wpj_update_user_notifications( array(
									'user1'       => $notify_uid,
									'user2'       => $notify_sender_uid,
									'type'        => 'notifications',
									'number'      => +1,
									'notify_id'   => $this_notification,
									'notify_type' => 'arb_new_request',
									'order_id'    => $orderid
								) );

								// Send emails
								wpj_notify_user_translated( 'admin_arbitration', 'admin', array(
									'##username##'              => wpj_get_user_display_type( $uid ),
									'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
									'##job_name##'              => $order->job_title,
									'##job_link##'              => urldecode( get_permalink( $order->pid ) ),
									'##transaction_page_link##' => wpj_get_order_link( $orderid )
								) );

								wpj_notify_user_translated( 'arb_new_request', $buyer_id, array(
									'##username##'              => wpj_get_user_display_type( $buyer_id ),
									'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
									'##job_name##'              => $order->job_title,
									'##job_link##'              => urldecode( get_permalink( $order->pid ) ),
									'##transaction_page_link##' => wpj_get_order_link( $orderid )
								) );

								wpj_notify_user_translated( 'arb_new_request', $seller_id, array(
									'##username##'              => wpj_get_user_display_type( $seller_id ),
									'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
									'##job_name##'              => $order->job_title,
									'##job_link##'              => urldecode( get_permalink( $order->pid ) ),
									'##transaction_page_link##' => wpj_get_order_link( $orderid )
								) );
							}

							$arbitration_arr['msg'] = __( "The request for arbitration has been sent to admin. You will be notified when the support has made a decision!", "wpjobster" );
							$arbitration_arr['err'] = 0;

						} else {
							$arbitration_arr['msg'] = __( "The message can not be empty!", "wpjobster" );
							$arbitration_arr['err'] = 1;

						}

					} else {
						$arbitration_arr['msg'] = __( "There is already an arbitration for this order. You can't request multiple arbitration for the same order!", "wpjobster" );
						$arbitration_arr['err'] = 1;

					}

				} else {
					$arbitration_arr['msg'] = __( "You're not allowed to request arbitration because you are a demo user!", "wpjobster" );
					$arbitration_arr['err'] = 1;

				}

			} else {
				$arbitration_arr['msg'] = __( "You're not the buyer or the seller of this order!", "wpjobster" );
				$arbitration_arr['err'] = 1;

			}

		} else {
			$arbitration_arr['msg'] = __( "Invalid Order ID!", "wpjobster" );
			$arbitration_arr['err'] = 1;

		}

		if ( wpj_is_ajax_call() ) {
			echo json_encode( $arbitration_arr );
			wp_die();

		} else {
			return $arbitration_arr;

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_abort_arbitration' ) ) {
	function wpj_abort_arbitration() {

		global $wpdb;

		$uid = get_current_user_id();

		$orderid = WPJ_Form::post( 'oid' );
		$order   = wpj_get_order( $orderid );

		$order_arbitration = wpj_get_arbitration_details_by_order_id( $orderid );

		$seller_id = wpj_get_seller_id( $order );
		$buyer_id  = $order->uid;

		if ( $uid == $seller_id ) {
			$is_seller   = 1;
			$is_buyer    = 0;
			$uid_to_send = $buyer_id;
			$uid_sender  = $seller_id;
			$query_uid   = -45;

		} elseif ( $uid == $buyer_id ) {
			$is_seller   = 0;
			$is_buyer    = 1;
			$uid_to_send = $seller_id;
			$uid_sender  = $buyer_id;
			$query_uid   = -46;

		} else {
			$is_seller   = 0;
			$is_buyer    = 0;
			$uid_to_send = '';
			$uid_sender  = '';
			$query_uid   = '';

		}

		if ( is_object( $order_arbitration ) && $query_uid ) {
			if ( ( $order_arbitration->request_from_seller == 1 && $is_seller == 1 ) || ( $order_arbitration->request_from_buyer == 1 && $is_buyer == 1 ) ) {
				if ( ! is_demo_user() ) {
					$wpdb->query( "UPDATE {$wpdb->prefix}job_orders_arbitration SET request_from_buyer = 0, request_from_seller = 0 WHERE order_id = {$orderid}" );

					if ( $uid_to_send ) {

						// Insert to chatbox
						$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = %d AND oid = %d", current_time( 'timestamp', 1 ), $query_uid, $orderid ) );

						if ( ! $row_exist ) {
							$wpdb->insert(
								$wpdb->prefix . 'job_chatbox',
								array(
									'datemade' => current_time( 'timestamp', 1 ),
									'uid'      => $query_uid,
									'oid'      => $orderid,
									'content'  => __( 'Arbitration Aborted', 'wpjobster' )
								),
								array( '%d', '%d', '%d', '%s' )
							);

							// Update notifications
							$this_notification = $wpdb->insert_id;

							wpj_update_user_notifications( array(
								'user1'       => $uid_to_send,
								'user2'       => $uid_sender,
								'type'        => 'notifications',
								'number'      => +1,
								'notify_id'   => $this_notification,
								'notify_type' => 'arb_request_aborted',
								'order_id'    => $orderid
							) );

							// Send emails
							wpj_notify_user_translated( 'arb_request_aborted', $buyer_id, array(
								'##username##'              => wpj_get_user_display_type( $uid ),
								'##username_aborting##'     => wpj_get_user_display_type( $uid_to_send ),
								'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
								'##job_name##'              => $order->job_title,
								'##job_link##'              => urldecode( get_permalink( $order->pid ) ),
								'##transaction_page_link##' => wpj_get_order_link( $orderid )
							) );

							wpj_notify_user_translated( 'arb_request_aborted', $seller_id, array(
								'##username##'              => wpj_get_user_display_type( $uid ),
								'##username_aborting##'     => wpj_get_user_display_type( $uid_to_send ),
								'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
								'##job_name##'              => $order->job_title,
								'##job_link##'              => urldecode( get_permalink( $order->pid ) ),
								'##transaction_page_link##' => wpj_get_order_link( $orderid )
							) );
						}
					}
				}
			}
		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}