<?php
function wpj_mark_order_as_accepted() {
	if ( isset( $_POST['oid'] ) && wpj_get_option( 'wpjobster_seller_order_rejection_enable' ) == 'yes' ) {

		global $wpdb;

		$orderid = $_POST['oid'];
		$order   = wpj_get_order( $orderid );

		if ( $order ) {
			if ( ! $order->seller_confirmation || $order->seller_confirmation == 0 ) {

				// Add extra time to timer
				$extra_time = current_time( 'timestamp', 1 ) - $order->date_made;
				$expected   = wpj_get_expected_delivery( $orderid ) + $extra_time;

				// Insert to orders
				$wpdb->query( "
					UPDATE {$wpdb->prefix}job_orders
					SET seller_confirmation = '1',
						expected_delivery = '{$expected}'
					WHERE id = '{$orderid}'
				" );

				// Insert to chatbox
				$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -47 AND oid = %d", current_time( 'timestamp', 1 ), $orderid ) );

				if ( ! $row_exist ) {
					$wpdb->insert(
						$wpdb->prefix . 'job_chatbox',
						array(
							'datemade' => current_time( 'timestamp', 1 ),
							'uid'      => -47,
							'oid'      => $orderid,
							'content'  => __( 'Accepted by Seller', 'wpjobster' )
						),
						array( '%d', '%d', '%d', '%s' )
					);

					// Update notifications
					$this_notification = $wpdb->insert_id;

					wpj_update_user_notifications( array(
						'user1'       => $order->uid,
						'user2'       => wpj_get_seller_id( $order ),
						'type'        => 'notifications',
						'number'      => +1,
						'notify_id'   => $this_notification,
						'notify_type' => 'order_accepted',
						'order_id'    => $orderid
					) );

					// Send emails
					wpj_notify_user_translated( 'order_accepted', $order->uid, array(
						'##job_name##'              => $order->job_title,
						'##job_link##'              => urldecode( get_permalink( $order->pid ) ),
						'##transaction_page_link##' => wpj_get_order_link( $orderid ),
						'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made )
					) );
				}

			}
		}
	}

	if ( wpj_is_ajax_call() ) wp_die();
}

function wpj_mark_order_as_rejected() {
	if ( isset( $_POST['oid'] ) && wpj_get_option( 'wpjobster_seller_order_rejection_enable' ) == 'yes' ) {

		global $wpdb;

		$orderid = $_POST['oid'];
		$order   = wpj_get_order( $orderid );

		if ( $order ) {
			if ( ! $order->seller_confirmation || $order->seller_confirmation == 0 ) {

				// Insert to orders
				$wpdb->query( "
					UPDATE {$wpdb->prefix}job_orders
					SET seller_confirmation = '2'
					WHERE id = '{$orderid}'
				" );

				// Cancel order and refund buyer
				wpj_cancel_order_by_id( $orderid, 'rejected' );

				// Insert to chatbox
				$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -47 AND oid = %d", current_time( 'timestamp', 1 ), $orderid ) );

				if ( ! $row_exist ) {
					$wpdb->insert(
						$wpdb->prefix . 'job_chatbox',
						array(
							'datemade' => current_time( 'timestamp', 1 ),
							'uid'      => -48,
							'oid'      => $orderid,
							'content'  => __( 'Rejected by Seller', 'wpjobster' )
						),
						array( '%d', '%d', '%d', '%s' )
					);

					// Update notifications
					$this_notification = $wpdb->insert_id;

					wpj_update_user_notifications( array(
						'user1'       => $order->uid,
						'user2'       => wpj_get_seller_id( $order ),
						'type'        => 'notifications',
						'number'      => +1,
						'notify_id'   => $this_notification,
						'notify_type' => 'order_rejected',
						'order_id'    => $orderid
					) );

					// Send emails
					wpj_notify_user_translated( 'order_rejected', $order->uid, array(
						'##job_name##'              => $order->job_title,
						'##job_link##'              => urldecode( get_permalink( $order->pid ) ),
						'##transaction_page_link##' => wpj_get_order_link( $orderid ),
						'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made )
					) );
				}
			}
		}
	}

	if ( wpj_is_ajax_call() ) wp_die();
}