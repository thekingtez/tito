<?php
if ( ! function_exists( 'wpj_get_distance_to_job_location' ) ) {
	function wpj_get_distance_to_job_location( $type, $id ) {
		if ( $type == 'post' || $type == 'job' || $type == 'request' ) {
			$lat = get_post_meta( $id, 'lat', true );
			$lng = get_post_meta( $id, 'long', true );

		} elseif ( $type == 'user' ) {
			$lat = get_user_meta( $id, 'wpj_user_latitude', true );
			$lng = get_user_meta( $id, 'wpj_user_longitude', true );

		} else return false;

		$q_lat = WPJ_Form::get( 'latitude', WPJ_Form::cookie( 'wpj_lat', '' ) );
		$q_lng = WPJ_Form::get( 'longitude', WPJ_Form::cookie( 'wpj_lng', '' ) );

		if ( ! $q_lat || ! $q_lng ) return false;

		if ( false !== $distance = wpj_calculate_distance(
			array( $lat, $lng ),
			array( $q_lat, $q_lng )
		) ) {
			$dec_sep = wpj_get_option( 'wpjobster_decimal_sum_separator' );
			if ( empty( $dec_sep ) ) { $dec_sep = '.'; }

			$tho_sep = wpj_get_option( 'wpjobster_thousands_sum_separator' );
			if ( empty( $tho_sep ) ) { $tho_sep = ','; }

			if ( wpj_get_option( 'wpjobster_locations_unit' ) == 'miles' )
				return sprintf( __( '%s miles away', 'wpjobster' ), number_format( round( $distance, 1 ), 1, $dec_sep, $tho_sep ) );
			else
				return sprintf( __( '%s km away', 'wpjobster' ), number_format( round( $distance, 1 ), 1, $dec_sep, $tho_sep ) );
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_get_distance_between' ) ) {
	function wpj_get_distance_between( $p1, $p2 ) {
		if ( isset( $p1[0] ) && is_numeric( $p1[0] )
			&& isset( $p1[1] ) && is_numeric( $p1[1] )
			&& isset( $p2[0] ) && is_numeric( $p2[0] )
			&& isset( $p2[1] ) && is_numeric( $p2[1] )
		) {
			if ( $distance = wpj_calculate_distance(
				array( $p1[0], $p1[1] ),
				array( $p2[0], $p2[1] )
			) ) {
				$dec_sep = wpj_get_option( 'wpjobster_decimal_sum_separator' );
				if ( empty( $dec_sep ) ) { $dec_sep = '.'; }

				$tho_sep = wpj_get_option( 'wpjobster_thousands_sum_separator' );
				if ( empty( $tho_sep ) ) { $tho_sep = ','; }

				if ( wpj_get_option( 'wpjobster_locations_unit' ) == 'miles' )
					return sprintf( __( '%s miles', 'wpjobster' ), number_format( round( $distance, 1 ), 1, $dec_sep, $tho_sep ) );
				else
					return sprintf( __( '%s km', 'wpjobster' ), number_format( round( $distance, 1 ), 1, $dec_sep, $tho_sep ) );
			}
		}

		return false;
	}
}

if ( ! function_exists( 'wpj_calculate_distance' ) ) {
	function wpj_calculate_distance( $p1, $p2 ) {
		if ( isset( $p1[0] ) && is_numeric( $p1[0] )
			&& isset( $p1[1] ) && is_numeric( $p1[1] )
			&& isset( $p2[0] ) && is_numeric( $p2[0] )
			&& isset( $p2[1] ) && is_numeric( $p2[1] )
		) {
			$units = wpj_get_option( 'wpjobster_locations_unit' ) == 'kilometers' ? 6371 : 3959;

			global $wpdb;
			$result = $wpdb->get_row( "SELECT {$units} * acos( cos( radians( {$p1[0]} ) ) * cos( radians( {$p2[0]} ) ) * cos( radians ( {$p2[1]} ) - radians( {$p1[1]} ) ) + sin( radians({$p1[0]}) ) * sin( radians ( {$p2[0]} ) ) ) as distance" );

			return $result->distance;
		}

		return false;
	}
}