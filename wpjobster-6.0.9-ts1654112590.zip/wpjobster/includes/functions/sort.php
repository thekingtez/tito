<?php
if ( ! function_exists( 'wpj_get_current_post_sort_order' ) ) {
	function wpj_get_current_post_sort_order() {
		return WPJ_Form::cookie( 'switch_filter', wpj_get_option( 'wpjobster_default_sort_by' ) );
	}
}

if ( ! function_exists( 'wpj_set_sort_cookie' ) ) {
	function wpj_set_sort_cookie() {
		if ( isset( $_GET['switch_filter'] ) ) {
			$_COOKIE['switch_filter'] = $_GET['switch_filter']; // fallback until next page reload
			setcookie( 'switch_filter', $_GET['switch_filter'], time() + 86400, '/' ); // 24h
		}
	}
}

if ( ! function_exists( 'wpj_change_post_list_order' ) ) {
	function wpj_change_post_list_order( $new_order_by, $order_by, $query ) {
		return $order_by;
	}
}