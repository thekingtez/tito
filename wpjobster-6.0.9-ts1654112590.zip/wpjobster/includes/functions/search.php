<?php
if ( ! function_exists( 'wpj_get_main_search_url' ) ) {
	function wpj_get_main_search_url() {

		$default_search = wpj_get_option( 'wpjobster_default_advanced_search' );

		if ( $default_search == 'users' ) {
			$url_for_search = get_permalink( wpj_get_option( 'wpjobster_search_user_page_id' ) );

		} elseif ( $default_search == 'requests' ) {
			$url_for_search = get_permalink( wpj_get_option( 'wpjobster_advanced_search_request_page_id' ) );

		} else {
			$url_for_search = get_permalink( wpj_get_option( 'wpjobster_advanced_search_id' ) );

		}

		return $url_for_search;
	}
}

if ( ! function_exists( 'wpj_search_autocomplete_ajax' ) ) {
	function wpj_search_autocomplete_ajax() {
		global $wpdb;

		$input = wpj_validate_input_content( $_POST['input'] );
		$input = strtolower( $input );
		$input = esc_sql( $input );

		$job_array     = array();
		$request_array = array();
		$user_array    = array();
		$company_array = array();

		if ( $input != '' && $input != ' ' ) {

			// search jobs
			$job_query = $wpdb->get_results(
				"
				SELECT ID, post_title, post_content
				FROM {$wpdb->prefix}posts p
				LEFT JOIN {$wpdb->prefix}postmeta AS wpm ON ( p.ID = wpm.post_ID AND wpm.meta_key = 'active' )
				WHERE ( ( post_title LIKE '%" . $input . "%' )
						OR ( post_content LIKE '%" . $input . "%' ) )
					AND post_type = 'job'
					AND post_status = 'publish'
					AND wpm.meta_value = '1'
				ORDER BY post_title ASC
				LIMIT 6
				"
			);

			foreach ( $job_query as $job ) {
				preg_match( "/\b(\w*" . $input . "\w*)\b/", strtolower( $job->post_title ), $matches );
				preg_match( "/\b(\w*" . $input . "\w*)\b/", strtolower( $job->post_content ), $matches2 );
				if ( isset( $matches[0] ) && ! in_array( $matches[0], $job_array ) ) {
					$job_array[] = $matches[0];
					if ( count( $job_array ) >= 6 ) {
						break;
					}
				}
				if ( isset( $matches2[0] ) && ! in_array( $matches2[0], $job_array ) ) {
					$job_array[] = $matches2[0];
					if ( count( $job_array ) >= 6 ) {
						break;
					}
				}
			}

			// search requests
			$request_query = $wpdb->get_results(
				"
				SELECT ID, post_title, post_content
				FROM {$wpdb->prefix}posts wp_posts
				WHERE ( ( post_title LIKE '%" . $input . "%' )
						OR ( post_content LIKE '%" . $input . "%' ) )
					AND post_type = 'request'
					AND post_status = 'publish'
				ORDER BY post_title ASC
				LIMIT 6
				"
			);

			foreach ( $request_query as $request ) {
				preg_match( "/\b(\w*" . $input . "\w*)\b/", strtolower( $request->post_title ), $matches );
				preg_match( "/\b(\w*" . $input . "\w*)\b/", strtolower( $request->post_content ), $matches2 );
				if ( isset( $matches[0] ) && ! in_array( $matches[0], $request_array ) ) {
					$request_array[] = $matches[0];
					if ( count( $request_array ) >= 6 ) {
						break;
					}
				}
				if ( isset( $matches2[0] ) && ! in_array( $matches2[0], $request_array ) ) {
					$request_array[] = $matches2[0];
					if ( count( $request_array ) >= 6 ) {
						break;
					}
				}
			}

			$user_table      = defined( 'CUSTOM_USER_TABLE' ) ? CUSTOM_USER_TABLE : $wpdb->prefix . 'users';
			$user_meta_table = defined( 'CUSTOM_USER_META_TABLE' ) ? CUSTOM_USER_META_TABLE : $wpdb->prefix . 'usermeta';

			// search users
			$user_query = "
				SELECT *
				FROM {$user_table} wu, {$user_meta_table} wum
				WHERE wu.ID = wum.user_ID
					AND (
						( wum.meta_key = 'first_name' AND wum.meta_value LIKE '%{$input}%' )
						OR ( wum.meta_key = 'last_name' AND wum.meta_value LIKE '%{$input}%' )
						OR ( wum.meta_key = 'description' AND wum.meta_value LIKE '%{$input}%' )
						OR ( wum.meta_key = 'user_company' AND wum.meta_value LIKE '%{$input}%' )
						OR wu.user_login LIKE '%{$input}%'
					)
				GROUP BY user_login
				ORDER BY wum.meta_key = 'completed_sales' DESC
				LIMIT 3
			";

			$user_query = apply_filters( 'wpj_suggested_users_query_filter', $user_query, $input );

			$user_results = $wpdb->get_results( $user_query );

			foreach ( $user_results as $user ) {
				$user_array[] = $user->user_login;

				// add company if enabled, ready to display
				if ( wpj_bool_option( 'wpjobster_enable_user_company' ) ) {
					$user_company = get_user_meta( $user->ID, 'user_company', true );
					if ( $user_company ) {
						$company_array[] = ' <span class="user-company">(' . $user_company . ')</span>';
					} else {
						$company_array[] = '';
					}
				}

				if ( count( $user_array ) >= 3 ) {
					break;
				}
			}
		}

		// return

		$return = array();

		$return['jobs']      = $job_array;
		$return['requests']  = $request_array;
		$return['users']     = $user_array;
		$return['companies'] = $company_array;

		echo json_encode( $return );

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_autosuggest_it' ) ) {
	function wpj_autosuggest_it() {
		include_once get_template_directory() . '/vendor/stem.php';
		include_once get_template_directory() . '/vendor/cleaner.php';

		global $wpdb;

		$string = $_POST['queryString'];

		$stemmer        = new Stemmer;
		$stemmed_string = $stemmer->stem( $string );

		$clean_string   = new jSearchString();
		$stemmed_string = $clean_string->parseString ( $stemmed_string );

		$new_string = '';
		foreach ( array_unique ( split ( " ",$stemmed_string ) ) as $array => $value ) {
			if ( strlen( $value ) >= 1 ) {
				$new_string .= '' . $value . ' ';
			}
		}

		$new_string = htmlspecialchars( $_POST['queryString'] );

		if ( strlen ( $new_string ) > 0 ) {

			$split_stemmed = split ( " ", $new_string );

			$sql = "
				SELECT DISTINCT COUNT(*) as occurences, {$wpdb->prefix}posts.post_title, {$wpdb->prefix}posts.ID
				FROM {$wpdb->prefix}posts, {$wpdb->prefix}postmeta
				WHERE {$wpdb->prefix}posts.post_status = 'publish'
					AND {$wpdb->prefix}posts.post_type = 'job'
					AND {$wpdb->prefix}posts.ID = {$wpdb->prefix}postmeta.post_id
					AND {$wpdb->prefix}postmeta.meta_key = 'closed'
					AND {$wpdb->prefix}postmeta.meta_value = '0'

			AND (";

				while ( list ( $key,$val ) = each ( $split_stemmed ) ) {
					if ( $val != '' && strlen ( $val ) > 0 ) {
						$sql .= "(" . $wpdb->prefix . "posts.post_title LIKE '%" . $val . "%' OR " . $wpdb->prefix . "posts.post_content LIKE '%" . $val . "%' ) OR";
					}
				}

				$sql = substr ( $sql,0, ( strlen ( $sql )-3 ) ); //this will eat the last OR

			$sql .= ") GROUP BY " . $wpdb->prefix . "posts.post_title ORDER BY occurences DESC LIMIT 10";

			$r = $wpdb->get_results( $sql, ARRAY_A );

			if ( count( $r ) > 0 ) {
				foreach ( $r as $row ) {
					echo '<ul id="sk_auto_suggest" class="reset">';
							$prm = get_permalink( $row['ID'] );

							echo '<li onClick="window.location=\'' . $prm . '\';">' . wpj_wrap_title( $row['post_title'], $row['ID'] ) . '</li>';

					echo '</ul>';

				}

			} else {
				echo '<ul>';
					echo '<li onClick="fill(\'' . $new_string . '\');">' . __( 'No results found', 'wpjobster' ) . '</li>';
				echo '</ul>';
			}
		}
	}
}

if ( ! function_exists( 'wpj_get_job_search_query' ) ) {
	function wpj_get_job_search_query( $args = array() ) {

		$uid = ! empty( $args['uid'] ) ? $args['uid'] : '';

		$post_not_in = ! empty( $args['query_params']['post__not_in'] ) ? $args['query_params']['post__not_in'] : '';
		if ( $post_not_in ) $post_not_in = implode( ',', $post_not_in );

		$featured = isset( $args['query_params']['featured'] ) && is_numeric( $args['query_params']['featured'] ) ? $args['query_params']['featured'] : 1;

		$order = ! empty( $args['query_params']['order'] ) ? $args['query_params']['order'] : wpj_get_current_post_sort_order();

		$location_default = $lat_default = $lng_default = '';
		if ( wpj_get_option( 'wpjobster_html5_geolocation_enable' ) == 'yes' ) {
			$location_default = WPJ_Form::cookie( 'wpj_location', '' );
			$lat_default      = WPJ_Form::cookie( 'wpj_lat', '' );
			$lng_default      = WPJ_Form::cookie( 'wpj_lng', '' );
		}

		$category     = ! empty( $args['query_params']['category'] ) ? $args['query_params']['category'] : '';
		$archive_val  = isset( get_queried_object()->slug ) ? get_queried_object()->slug : $category;
		$category_get = WPJ_Form::get( 'category', $archive_val );

		$term_get       = WPJ_Form::get( 'term' );
		$tag_get        = WPJ_Form::get( 'tag' );
		$min_price_get  = WPJ_Form::get( 'min_price' );
		$max_price_get  = WPJ_Form::get( 'max_price' );
		$radius_get     = WPJ_Form::get( 'radius' );
		$location_get   = WPJ_Form::get( 'location', $location_default );
		$latitude_get   = WPJ_Form::get( 'latitude', $lat_default );
		$longitude_get  = WPJ_Form::get( 'longitude', $lng_default );
		$rating_get     = WPJ_Form::get( 'min_rating' );
		$price_type_get = WPJ_Form::get( 'price_type' );
		$max_days_get   = WPJ_Form::get( 'max_days' );
		$no_deliv_get   = WPJ_Form::get( 'without_delivery' );

		$units  = wpj_get_option( 'wpjobster_locations_unit' ) == 'kilometers' ? 6371 : 3959;
		$radius = ! empty( $radius_get ) ? $radius_get : wpj_get_option( 'wpj_locations_radius_default', '10' );

		$feature_enabled = $featured && wpj_get_option( 'wpjobster_featured_enable' ) == 'yes' ? true : false;

		if ( $category_get ) {
			$cat_childrens = array();

			if ( is_numeric( $category_get ) ) $cats = get_term_by( 'term_id', $category_get, 'job_cat' );
			else $cats = get_term_by( 'slug', $category_get, 'job_cat' );

			$featured_meta_key = 'category_featured_now';
			if ( isset( $cats->parent ) && $cats->parent > 0 ) $featured_meta_key = 'subcategory_featured_now';

			if ( ! empty( $cats->term_id ) ) {
				$cat_childrens   = get_terms( $cats->taxonomy, array( 'parent' => $cats->term_id, 'hide_empty' => false, 'fields' => 'ids' ) );
				$cat_childrens[] = $cats->term_id;
				$categories      = implode( ',', $cat_childrens );
			}

		} else $featured_meta_key = 'home_featured_now';

		if ( $tag_get ) {

			if ( ! is_array( $tag_get ) ) $tag_get = array( $tag_get );

			$tag_childrens = array();
			foreach ( $tag_get as $key => $tag ) {
				$tgs = get_term_by( 'slug', $tag, 'post_tag' );
				if ( ! empty( $tgs->term_id ) ) {
					$tag_childrens[] = $tgs->term_id;
				}
			}

			if ( $tag_childrens ) {
				$tags = implode( ',', $tag_childrens );
			}
		}

		$min_price = $min_price_get ? str_replace( ",", ".", $min_price_get ) : 0;
		$max_price = $max_price_get ? str_replace( ",", ".", $max_price_get ) : '';

		$delivery_comparator = $no_deliv_get ? '=' : '<>';
		$delivery_logical_op = $no_deliv_get ? 'OR' : 'AND';

		/* BUILD QUERY */

		global $wpdb;

		$query = "SELECT p.ID, p.post_title, p.post_content, p.post_author";

		if ( $order == 'price_lowest' || $order == 'price_highest' )
			$query .= ", MIN( CAST( pm_price.meta_value AS UNSIGNED ) ) AS min_price ";

		if ( $location_get || ( $order == 'distance' && $latitude_get && $longitude_get ) )
			$query .= ", {$units} * acos( cos( radians( {$latitude_get} ) ) * cos( radians( pm_lat.meta_value ) ) * cos( radians ( pm_long.meta_value ) - radians( {$longitude_get} ) ) + sin( radians( {$latitude_get} ) ) * sin( radians ( pm_lat.meta_value ) ) ) AS distance";

		$query .= " FROM {$wpdb->prefix}posts p, {$wpdb->prefix}postmeta pm ";

		if ( $location_get || ( $order == 'distance' && $latitude_get && $longitude_get ) ) {
			$query .= " INNER JOIN {$wpdb->prefix}postmeta pm_lat ON ( pm.post_id = pm_lat.post_id AND pm_lat.meta_key = 'lat' ) ";
			$query .= " INNER JOIN {$wpdb->prefix}postmeta pm_long ON ( pm.post_id = pm_long.post_id AND pm_long.meta_key = 'long' ) ";

		}

		if ( $category_get )
			$query .= " INNER JOIN {$wpdb->prefix}term_relationships tr_c ON tr_c.object_id = pm.post_id ";

		if ( $tag_get )
			$query .= " INNER JOIN {$wpdb->prefix}term_relationships tr_t ON tr_t.object_id = pm.post_id ";

		if ( $rating_get || $order == 'rating' )
			$query .= " INNER JOIN {$wpdb->prefix}postmeta pm_rating ON pm.post_id = pm_rating.post_id AND pm_rating.meta_key = 'job_rating' ";

		if ( $max_days_get )
			$query .= " INNER JOIN {$wpdb->prefix}postmeta pm_max_days ON pm.post_id = pm_max_days.post_id AND pm_max_days.meta_key = 'max_days' ";

		if ( $order == 'price_lowest' || $order == 'price_highest' || $price_type_get == 'package' || $min_price_get || $max_price_get )
			$query .= " INNER JOIN {$wpdb->prefix}postmeta pm_package ON pm.post_id = pm_package.post_id ";

		if ( $price_type_get )
			$query .= " LEFT JOIN {$wpdb->prefix}postmeta pm_pricetype ON pm.post_id = pm_pricetype.post_id AND pm_pricetype.meta_key = 'price_type' ";

		if ( $order == 'price_lowest' || $order == 'price_highest' || $min_price_get || $max_price_get ) {
			$include_price_sql = $price_type_get != 'package' ? " pm_price.meta_key = 'price' OR " : '';

			$query .= " INNER JOIN {$wpdb->prefix}postmeta pm_price ON pm.post_id = pm_price.post_id AND ( {$include_price_sql} pm_price.meta_key = 'package_price_1' OR pm_price.meta_key = 'package_price_2' OR pm_price.meta_key = 'package_price_3' ) ";

		}

		if ( $order == 'views' )
			$query .= " INNER JOIN {$wpdb->prefix}postmeta pm_views ON pm.post_id = pm_views.post_id AND pm_views.meta_key = 'job_views_counter' ";

		if ( $feature_enabled )
			$query .= " INNER JOIN {$wpdb->prefix}postmeta pm_featured ON pm.post_id = pm_featured.post_id AND pm_featured.meta_key = '{$featured_meta_key}' ";

		$query .= " WHERE p.ID = pm.post_id AND p.post_type = 'job' AND p.post_status = 'publish' AND ( pm.meta_key = 'active' AND pm.meta_value = '1' ) ";

			if ( $uid )
				$query .= " AND p.post_author = {$uid} ";

			if ( $post_not_in )
				$query .= " AND p.ID NOT IN ({$post_not_in}) ";

			if ( $term_get )
				$query .= " AND ( p.post_title LIKE '%{$term_get}%' OR p.post_content LIKE '%{$term_get}%' ) ";

			if ( $category_get && ! empty( $categories ) )
				$query .= " AND tr_c.term_taxonomy_id IN ({$categories}) ";

			if ( $tag_get && ! empty( $tags ) )
				$query .= " AND tr_t.term_taxonomy_id IN ({$tags}) ";

			if ( $rating_get )
				$query .= " AND ( pm_rating.meta_key = 'job_rating' AND pm_rating.meta_value >= {$rating_get} ) ";

			if ( $price_type_get ) {
				if ( $price_type_get == 'fixed' )
					$query .= " AND ( pm_pricetype.post_id IS NULL OR pm_pricetype.meta_value = 'fixed' OR pm_pricetype.meta_value = '' ) ";

				elseif ( $price_type_get == 'package' )
					$query .= " AND ( pm_package.meta_key = 'job_packages' AND pm_package.meta_value = 'yes' ) ";

				else
					$query .= " AND ( pm_pricetype.meta_value = '{$price_type_get}' ) ";

			}

			if ( ! $min_price && is_numeric( $max_price ) ) {

				$query .= " AND ( ";

					if ( $price_type_get != 'package' )
						$query .= " (
							pm_package.meta_key = 'job_packages' AND pm_package.meta_value <> 'yes' AND pm_price.meta_key = 'price'
							AND ( pm_price.meta_value <= {$max_price} OR pm_price.meta_value = '' OR pm_price.meta_value = 0 )
						) ";

					if ( ! $price_type_get ) { $query .= " OR ( "; }

						if ( ! $price_type_get || $price_type_get == 'package' )
							$query .= "
								( pm_package.meta_key = 'job_packages' AND pm_package.meta_value = 'yes' )
								AND (
									( pm_price.meta_key = 'package_price_1' AND pm_price.meta_value <= {$max_price} )
									OR ( pm_price.meta_key = 'package_price_2' AND pm_price.meta_value <= {$max_price} )
									OR ( pm_price.meta_key = 'package_price_3' AND pm_price.meta_value <= {$max_price} )
								)
							";

					if ( ! $price_type_get ) { $query .= " ) "; }

				$query .= " ) ";

			} elseif ( $min_price_get && is_numeric( $min_price ) && ! $max_price ) {

				$include_empty_sql = $min_price == 0 ? " OR pm_price.meta_value = '' OR pm_price.meta_value = 0 " : "";

				$query .= " AND ( ";

					if ( $price_type_get != 'package' )
						$query .= " (
							pm_package.meta_key = 'job_packages' AND pm_package.meta_value <> 'yes' AND pm_price.meta_key = 'price'
							AND ( pm_price.meta_value >= {$min_price} {$include_empty_sql} )
						) ";

					if ( ! $price_type_get ) { $query .= " OR ( "; }

						if ( ! $price_type_get || $price_type_get == 'package' )
							$query .= "
								( pm_package.meta_key = 'job_packages' AND pm_package.meta_value = 'yes' )
								AND (
									( pm_price.meta_key = 'package_price_1' AND pm_price.meta_value >= {$min_price} )
									OR ( pm_price.meta_key = 'package_price_2' AND pm_price.meta_value >= {$min_price} )
									OR ( pm_price.meta_key = 'package_price_3' AND pm_price.meta_value >= {$min_price} )
								)
							";

					if ( ! $price_type_get ) { $query .= " ) "; }

				$query .= " ) ";

			} elseif ( is_numeric( $min_price ) && is_numeric( $max_price ) ) {

				$query .= " AND ( ";

					if ( $price_type_get != 'package' )
						$query .= " (
							pm_package.meta_key = 'job_packages' AND pm_package.meta_value <> 'yes' AND pm_price.meta_key = 'price'
							AND ( pm_price.meta_value BETWEEN {$min_price} AND {$max_price} )
						) ";

					if ( ! $price_type_get ) { $query .= " OR ( "; }

						if ( ! $price_type_get || $price_type_get == 'package' )
							$query .= "
								( pm_package.meta_key = 'job_packages' AND pm_package.meta_value = 'yes' )
								AND (
									( pm_price.meta_key = 'package_price_1' AND pm_price.meta_value BETWEEN {$min_price} AND {$max_price} )
									OR ( pm_price.meta_key = 'package_price_2' AND pm_price.meta_value BETWEEN {$min_price} AND {$max_price} )
									OR ( pm_price.meta_key = 'package_price_3' AND pm_price.meta_value BETWEEN {$min_price} AND {$max_price} )
								)
							";

					if ( ! $price_type_get ) { $query .= " ) "; }

				$query .= " ) ";

			}

			if ( $max_days_get )
				$query .= "
					AND (
						pm_max_days.meta_value <= {$max_days_get}
						{$delivery_logical_op} pm_max_days.meta_value {$delivery_comparator} 0
						{$delivery_logical_op} pm_max_days.meta_value {$delivery_comparator} ''
					)
				";

			if ( $order == 'price_lowest' || $order == 'price_highest' ) {

				$query .= " AND ( ";

					if ( $price_type_get != 'package' )
						$query .= " ( pm_package.meta_key = 'job_packages' AND pm_package.meta_value <> 'yes' AND pm_price.meta_key = 'price' ) ";

					if ( ! $price_type_get ) { $query .= " OR ( "; }

						if ( ! $price_type_get || $price_type_get == 'package' )
							$query .= " ( pm_package.meta_key = 'job_packages' AND pm_package.meta_value = 'yes' )
								AND ( pm_price.meta_key = 'package_price_1' OR pm_price.meta_key = 'package_price_2' OR pm_price.meta_key = 'package_price_3' ) ";

					if ( ! $price_type_get ) { $query .= " ) "; }

				$query .= " ) ";

			}

		$query .= " GROUP BY p.ID ";

		if ( $location_get && ! $uid )
			$query .= " HAVING distance < {$radius} ";

		if ( $order == 'new' ) {
			$query .= " ORDER BY";
			if ( $feature_enabled ) $query .= " pm_featured.meta_value ASC,";
			$query .= " p.post_date DESC";

		} elseif ( $order == 'old' ) {
			$query .= " ORDER BY";
			if ( $feature_enabled ) $query .= " pm_featured.meta_value ASC,";
			$query .= " p.post_date ASC";

		} elseif ( $order == 'rating' )
			$query .= " ORDER BY ( pm_rating.meta_value + 0 ) DESC";

		elseif ( $order == 'views' )
			$query .= " ORDER BY ( pm_views.meta_value + 0 ) DESC";

		elseif ( $order == 'distance' && $latitude_get && $longitude_get )
			$query .= " ORDER BY distance ASC";

		elseif ( $order == 'price_lowest' || $order == 'price_highest' ) {
			if ( $order == 'price_lowest' )
				$query .= " ORDER BY min_price ASC, ( pm_price.meta_value + 0 ) ASC";

			else
				$query .= " ORDER BY min_price DESC, ( pm_price.meta_value + 0 ) DESC";

		} else {
			$query .= " ORDER BY";
			if ( $feature_enabled ) $query .= " pm_featured.meta_value ASC,";
			$query .= " RAND()";

		}

		return $query;
	}
}

if ( ! function_exists( 'wpj_get_user_search_query' ) ) {
	function wpj_get_user_search_query() {

		global $wpdb;

		$term_get      = WPJ_Form::request( 'term' );
		$location_get  = WPJ_Form::request( 'location' );
		$radius_get    = WPJ_Form::request( 'radius' );
		$latitude_get  = WPJ_Form::request( 'latitude' );
		$longitude_get = WPJ_Form::request( 'longitude' );

		$units = wpj_get_option( 'wpjobster_locations_unit' ) == 'kilometers' ? 6371 : 3959;

		if ( empty( $radius_get ) ) $radius_get = wpj_get_option( 'wpj_locations_radius_default', '10' );

		if ( ! $location_get ) {
			$latitude_get  = '';
			$longitude_get = '';
			$radius_get    = '';
		}

		$user_table      = defined( 'CUSTOM_USER_TABLE' ) ? CUSTOM_USER_TABLE : $wpdb->prefix . 'users';
		$user_meta_table = defined( 'CUSTOM_USER_META_TABLE' ) ? CUSTOM_USER_META_TABLE : $wpdb->prefix . 'usermeta';

		$query = "SELECT *";

		if ( $latitude_get && $longitude_get ) {

			$query .= ", {$units} * acos( cos( radians( {$latitude_get} ) ) * cos( radians( um_lat.meta_value ) ) * cos( radians ( um_long.meta_value ) - radians( {$longitude_get} ) ) + sin( radians( {$latitude_get} ) ) * sin( radians ( um_lat.meta_value ) ) ) AS distance";

		}

		$query .= " FROM {$user_table} u, {$user_meta_table} um ";

		if ( $latitude_get && $longitude_get ) {

			$query .= " INNER JOIN {$user_meta_table} um_lat ON ( um.user_id = um_lat.user_ID AND um_lat.meta_key = 'wpj_user_latitude' ) ";

			$query .= " INNER JOIN {$user_meta_table} um_long ON ( um.user_id = um_long.user_ID AND um_long.meta_key = 'wpj_user_longitude' ) ";

		}

		if ( ! preg_match( '/,/', $location_get ) && $location_get ) {

			$query .= " INNER JOIN {$user_meta_table} um_location ON ( um.user_id = um_location.user_ID AND ( um_location.meta_key = 'city' OR um_location.meta_key = 'country' ) ) ";

		}

		$query .= " WHERE u.ID = um.user_id ";

		if ( $term_get ) {

			$query .= " AND ( u.user_login LIKE '%{$term_get}%'
				OR u.display_name LIKE '%{$term_get}%'
				OR ( um.meta_key IN ( 'first_name', 'last_name', 'description', 'user_company' ) AND um.meta_value LIKE '%{$term_get}%' )
			) ";

		}

		if ( ! preg_match( '/,/', $location_get ) && $location_get ) {

			$query .= " AND um_location.meta_value LIKE '%{$location_get}%' ";

		}

		$query .= apply_filters( 'wpj_user_search_before_group_by_query_filter', " GROUP BY u.ID " );

		if ( $latitude_get && $longitude_get ) {

			$query .= " HAVING distance < {$radius_get} ";

		}

		$query .= " ORDER BY u.ID ASC ";

		return $query;

	}
}