<?php
if ( ! function_exists( 'wpj_get_rating_number' ) ) {
	function wpj_get_rating_number( $r, $return = '' ) {

		$grades  = 0;
		$percent = 0;
		$avg     = 0;

		if ( $r ) {
			foreach ( $r as $row ) { $grades += $row->grade; }
		}

		$total = count( $r );

		if ( $total > 0 ) {
			$avg     = round( $grades / $total, 2 );
			$percent = round( ( 100 * $avg ) / 5 );
		}

		if ( $return == 'grade' ) return $grades;
		if ( $return == 'percent' ) return $percent;
		if ( $return == 'avg' ) return $avg;

		return array( 'grade' => $grades, 'percent' => $percent, 'avg' => $avg );
	}
}

if ( ! function_exists( 'wpj_save_inserted_review' ) ) {
	function wpj_save_inserted_review() {
		global $wpdb;

		$tm     = current_time( 'timestamp', 1 );
		$reason = isset( $_POST['reason'] ) ? esc_sql( urldecode( $_POST['reason'] ) ) : '';

		// Check if user is logged in
		if ( ! is_user_logged_in() ) { wp_die(); }

		if ( $_POST['user_type'] == 'seller' && get_current_user_id() == wpj_get_seller_id( $_POST['orderid'] ) ) { // SELLER rating
			$grade   = $_POST['uprating'];
			$id      = $_POST['ids'];
			$pid     = $_POST['pid'];
			$orderid = $_POST['orderid'];
			$buyer   = $_POST['buyer'];

			if ( ! is_demo_user() ) {

				// Avoid duplicated entry
				$order_already_has_feedback = $wpdb->get_row( $wpdb->prepare(
					"
					SELECT COUNT(*)
					AS cnt
					FROM {$wpdb->prefix}job_ratings_by_seller
					WHERE orderid = %d
						AND uid = %d
						AND pid = %d
					",
					$orderid, $buyer, $pid
				) );

				if ( $order_already_has_feedback->cnt >= 1 ) { wp_die(); }

				// Add review to database
				$wpdb->query( $wpdb->prepare(
					"
					INSERT INTO {$wpdb->prefix}job_ratings_by_seller
					SET orderid = %d,
						uid = %d,
						pid = %d,
						grade = %d,
						reason = %s,
						awarded = '1',
						datemade = %d
					",
					$orderid, $buyer, $pid, $grade, $reason, $tm
				) );

				// Review ID
				$id = $wpdb->insert_id;

				// Get order by review ID
				$r_sql = $wpdb->get_row( $wpdb->prepare(
					"
					SELECT *
					FROM {$wpdb->prefix}job_ratings_by_seller ratings,
						 {$wpdb->prefix}job_orders orders
					WHERE ratings.id = %d
						AND orders.id = ratings.orderid
					",
					$id
				) );

				$order = wpj_get_order( $orderid );

				// Update job rating value
				$rating = get_post_meta( $r_sql->pid, 'rating', true );
				if ( empty( $rating ) ) $rating = 0;
				$rating = $rating + 1;

				update_post_meta( $r_sql->pid, 'rating', $rating );

				// Add new notification
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade' => current_time( 'timestamp', 1 ),
						'uid'      => -19,
						'oid'      => $orderid,
						'content'  => __( 'Reviewed by the seller', 'wpjobster' )
					),
					array( '%d', '%d', '%d', '%s' )
				);

				$this_notification = $wpdb->insert_id;

				wpj_update_user_notifications( array(
					'user1'       => $buyer,
					'user2'       => wpj_get_seller_id( $order ),
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'new_feedback',
					'order_id'    => $orderid
				) );

				// Send emails
				if ( wpj_is_custom_offer( $r_sql->pid ) ) {
					wpj_rate_custom_offer( $r_sql->pid, $orderid, $buyer, wpj_get_seller_id( $order ) );

				} else {
					wpj_notify_user_translated( 'new_feedback', $buyer, array(
						'##transaction_number##'    => wpj_camouflage_oid( $orderid, $order->date_made ),
						'##transaction_page_link##' => wpj_get_order_link( $orderid ),
						'##sender_username##'       => wpj_get_user_display_type( wpj_get_seller_id( $order ) ),
						'##job_name##'              => $r_sql->job_title,
						'##job_link##'              => urldecode( get_permalink( $r_sql->pid ) )
					) );

				}
			}

		} elseif ( $_POST['user_type'] == 'buyer' && get_current_user_id() == wpj_get_buyer_id( $_POST['orderid'] ) ) { // BUYER rating
			$grade  = $_POST['uprating'];
			$id     = $_POST['ids'];
			$pid    = $_POST['pid'];
			$sample = ! empty( $_POST['sample'] ) ? $_POST['sample'] : '';

			if ( ! is_demo_user() ) {

				// reupload so we can apply watermark without breaking the delivered image
				if ( wpj_get_option( 'wpjobster_enable_review_work_samples' ) == 'yes' && $sample ) {
					require_once( ABSPATH . "wp-admin" . '/includes/file.php' );
					require_once( ABSPATH . "wp-admin" . '/includes/media.php' );
					require_once( ABSPATH . "wp-admin" . '/includes/image.php' );

					$image_path = get_attached_file( $sample );
					$uploaded_bits = wp_upload_bits(
						basename( $image_path ),
						null, //deprecated
						file_get_contents( $image_path )
					);

					if ( ! $pid ) { $pid = 0; }

					$file_array = array(
						'name'     => basename( $image_path ),
						'tmp_name' => $uploaded_bits['file']
					);

					$attach_id = media_handle_sideload( $file_array, $pid );
					if ( is_wp_error( $attach_id ) ) {
						@unlink( $file_array['tmp_name'] );
						$attach_id = '';
					} else {
						$attach_data = wp_get_attachment_metadata( $attach_id );
						update_post_meta( $attach_id, 'is_review', 1 );
						do_action( 'wpj_after_file_complete_upload_action', $attach_data, $attach_id );
					}

				} else {
					$attach_id = ''; // initialize for the query below

				}

				// Add review to database
				$wpdb->query( $wpdb->prepare(
					"
					UPDATE {$wpdb->prefix}job_ratings
					SET grade    = %d,
						reason   = %s,
						awarded  = '1',
						datemade = %d,
						sample   = %s
					WHERE id     = %d
					",
					$grade, $reason, $tm, $attach_id, $id
				) );

				// Get order by review ID
				$r_sql = $wpdb->get_row( $wpdb->prepare(
					"
					SELECT *
					FROM {$wpdb->prefix}job_ratings ratings,
						 {$wpdb->prefix}job_orders orders
					WHERE ratings.id  = %d
						AND orders.id = ratings.orderid
					",
					$id
				) );

				$order = wpj_get_order( $r_sql->orderid );

				$vote_skills = ! empty( $_POST['skills'] ) ? $_POST['skills'] : '';
				if ( $vote_skills )
					foreach ( $vote_skills as $tag_key => $tag_value ) {{
						$current_arr = get_user_meta( wpj_get_seller_id( $order ), 'user_skills_thumbsup', true );
						if ( ! $current_arr ) {
							update_user_meta( wpj_get_seller_id( $order ), 'user_skills_thumbsup', array( $tag_value => 1 ) );

						} else {
							if ( isset( $current_arr[$tag_value] ) )
								$current_arr[$tag_value] += 1;
							else
								$current_arr[$tag_value] = 1;

							update_user_meta( wpj_get_seller_id( $order ), 'user_skills_thumbsup', $current_arr );
						}
					}

				}

				// Update job rating value
				$rating = get_post_meta( $r_sql->pid, 'rating', true );
				wpj_save_rating_avg_jobmeta( $r_sql->pid );

				if ( empty( $rating ) ) $rating = 0;
				$rating = $rating + 1;

				update_post_meta( $r_sql->pid, 'rating', $rating );

				// Update parent rating value
				$wpdb->query( $wpdb->prepare(
					"
					UPDATE {$wpdb->prefix}job_ratings
					SET uid  = %d,
						pid  = %d
					WHERE id = %d
					",
					wpj_get_seller_id( $order ), $r_sql->pid, $id
				) );

				// Add new notification
				$wpdb->insert(
					$wpdb->prefix . 'job_chatbox',
					array(
						'datemade' => current_time( 'timestamp', 1 ),
						'uid'      => -18,
						'oid'      => $r_sql->orderid,
						'content'  => __( 'Reviewed by the buyer', 'wpjobster' )
					),
					array( '%d', '%d', '%d', '%s' )
				);

				// Send emails
				$this_notification = $wpdb->insert_id;

				wpj_update_user_notifications( array(
					'user1'       => wpj_get_seller_id( $order ),
					'user2'       => get_current_user_id(),
					'type'        => 'notifications',
					'number'      => +1,
					'notify_id'   => $this_notification,
					'notify_type' => 'new_feedback',
					'order_id'    => $r_sql->orderid
				) );

				if ( wpj_is_custom_offer( $r_sql->pid ) ) {
					wpj_rate_custom_offer( $r_sql->pid, $r_sql->orderid, wpj_get_seller_id( $order ), get_current_user_id() );

				} else {
					wpj_notify_user_translated( 'new_feedback', wpj_get_seller_id( $order ), array(
						'##transaction_number##'    => wpj_camouflage_oid( $r_sql->orderid, $order->date_made ),
						'##transaction_page_link##' => wpj_get_order_link( $r_sql->orderid ),
						'##sender_username##'       => wpj_get_user_display_type( get_current_user_id() ),
						'##job_name##'              => $r_sql->job_title,
						'##job_link##'              => urldecode( get_permalink( $r_sql->pid ) )
					) );

				}

			}

		}

		if ( wpj_is_ajax_call() ) wp_die();
	}
}

if ( ! function_exists( 'wpj_save_rating_avg_jobmeta' ) ) {
	function wpj_save_rating_avg_jobmeta( $pid ) {
		global $wpdb;

		$r = $wpdb->get_results( "
			SELECT DISTINCT ratings.grade, ratings.id ratid
			FROM {$wpdb->prefix}job_ratings ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
			WHERE posts.ID = orders.pid
				AND ( posts.ID = {$pid}
				OR ratings.pid IN (
					SELECT custom_offer
					FROM {$wpdb->prefix}job_pm pm, {$wpdb->prefix}job_ratings jr
					WHERE associate_job_id = {$pid}
					AND custom_offer = jr.pid
				)
			)
			AND ratings.awarded = '1'
			AND orders.id = ratings.orderid
		" );

		$rating = wpj_get_rating_number( $r, 'avg' );

		update_post_meta( $pid, 'job_rating', $rating );

		return $rating;
	}
}

if ( ! function_exists( 'wpj_get_job_rating_percent' ) ) {
	function wpj_get_job_rating_percent( $pid ) {
		global $wpdb;

		$r = $wpdb->get_results( "
			SELECT DISTINCT ratings.grade, ratings.id ratid
			FROM {$wpdb->prefix}job_ratings ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
			WHERE posts.ID = orders.pid
				AND ( posts.ID = {$pid}
				OR ratings.pid IN (
					SELECT custom_offer
					FROM {$wpdb->prefix}job_pm pm, {$wpdb->prefix}job_ratings jr
					WHERE associate_job_id = {$pid}
					AND custom_offer = jr.pid
				)
			)
			AND ratings.awarded = '1'
			AND orders.id = ratings.orderid
		" );

		return wpj_get_rating_number( $r, 'percent' );
	}
}

if ( ! function_exists( 'wpj_get_seller_rating_percent' ) ) {
	function wpj_get_seller_rating_percent( $uid = '' ) {
		global $wpdb;

		$uid = $uid ? $uid : get_current_user_id();

		$ratings_table = apply_filters( 'wpj_seller_reviews_database_table_filter', $wpdb->prefix . 'job_ratings', $uid );

		$r = $wpdb->get_results( "
			SELECT DISTINCT ratings.grade, ratings.id ratid
			FROM {$ratings_table} ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
			WHERE posts.ID = orders.pid
				AND ratings.awarded = '1'
				AND orders.id = ratings.orderid
				AND posts.post_author = '{$uid}'
		" );

		return wpj_get_rating_number( $r, 'percent' );
	}
}

if ( ! function_exists( 'wpj_get_seller_rating_avg' ) ) {
	function wpj_get_seller_rating_avg( $uid ) {
		global $wpdb;

		$ratings_table = apply_filters( 'wpj_seller_reviews_database_table_filter', $wpdb->prefix . 'job_ratings', $uid );

		$r = $wpdb->get_results( $wpdb->prepare( "SELECT AVG(ratings.grade) FROM {$ratings_table} ratings WHERE awarded = 1 AND ratings.uid = %d", $uid ) );
		$rating = $r[0]->{'AVG(ratings.grade)'};

		return ( float )$rating;
	}
}

if ( ! function_exists( 'wpj_get_job_rating_avg' ) ) {
	function wpj_get_job_rating_avg( $pid ) {
		global $wpdb;

		$r = $wpdb->get_results( "
			SELECT AVG(ratings.grade)
			FROM {$wpdb->prefix}job_ratings ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
			WHERE posts.ID = orders.pid
			AND ( posts.ID = {$pid}
				OR ratings.pid IN (
					SELECT custom_offer
					FROM {$wpdb->prefix}job_pm pm, {$wpdb->prefix}job_ratings jr
					WHERE associate_job_id = {$pid}
					AND custom_offer = jr.pid
				)
			)
			AND ratings.awarded = '1'
			AND orders.id = ratings.orderid
		" );

		$rating = $r[0]->{'AVG(ratings.grade)'};

		return $rating;
	}
}

if ( ! function_exists( 'wpj_get_seller_reviews_number' ) ) {
	function wpj_get_seller_reviews_number( $uid ) {
		global $wpdb;

		$ratings_table = apply_filters( 'wpj_seller_reviews_database_table_filter', $wpdb->prefix . 'job_ratings', $uid );

		$r = $wpdb->get_results( "
			SELECT DISTINCT ratings.grade, ratings.id ratid
			FROM {$ratings_table} ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
			WHERE posts.ID = orders.pid
				AND ratings.awarded = '1'
				AND orders.id = ratings.orderid
				AND posts.post_author = '{$uid}'
		" );

		return count( $r );
	}
}

if ( ! function_exists( 'wpj_get_job_reviews_number' ) ) {
	function wpj_get_job_reviews_number( $pid ) {
		global $wpdb;

		$r = $wpdb->get_results( "
			SELECT DISTINCT ratings.grade, ratings.id ratid
			FROM {$wpdb->prefix}job_ratings ratings, {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
			WHERE posts.ID = orders.pid
				AND ( posts.ID = {$pid}
				OR ratings.pid IN (
					SELECT custom_offer
					FROM {$wpdb->prefix}job_pm pm, {$wpdb->prefix}job_ratings jr
					WHERE associate_job_id = {$pid}
					AND custom_offer = jr.pid
				)
			)
			AND ratings.awarded = '1'
			AND orders.id = ratings.orderid
		" );

		return count( $r );
	}
}