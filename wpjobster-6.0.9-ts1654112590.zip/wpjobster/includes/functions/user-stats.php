<?php
if ( ! function_exists( 'wpj_get_user_earned_amount' ) ) {
	function wpj_get_user_earned_amount( $uid ) {
		if ( ! $uid ) { $uid = get_current_user_id(); }

		global $wpdb;

		$order_results = $wpdb->get_results( "
			SELECT *
			FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
			WHERE posts.post_author = '{$uid}'
				AND posts.ID = orders.pid
				AND payment_status = 'completed'
				AND seller_confirmation = '1'
				AND clearing_period = '1'
		" );

		$gross_value = 0;
		if ( $order_results ) {
			foreach ( $order_results as $key => $row ) {
				$gross_value += apply_filters( 'wpj_total_gross_sales_filter', wpj_get_order_total_price( $row )['amount'], $row, 'gross' );
			}
		}

		$net_value = 0;
		if ( $order_results ) {
			foreach ( $order_results as $key => $row ) {
				$net_value += apply_filters( 'wpj_total_net_sales_filter', wpj_get_order_total_price( $row )['seller_commission'], $row, 'net' );
			}
		}

		return array( 'gross' => $gross_value, 'net' => $net_value );
	}
}

if ( ! function_exists( 'wpj_get_withdrawal_amount' ) ) {
	function wpj_get_withdrawal_amount( $uid = '' ) {

		if ( ! $uid ) { $uid = get_current_user_id(); }

		global $wpdb;

		$query = "
			SELECT SUM(amount) AS total_withdrawals
			FROM {$wpdb->prefix}job_withdraw withdrawals
			WHERE withdrawals.uid    = {$uid}
				AND withdrawals.done = '1'
		";
		$g_total_withdrawals = $wpdb->get_results( $query , OBJECT );

		return $g_total_withdrawals[0]->total_withdrawals > 0 ? wpj_show_price( $g_total_withdrawals[0]->total_withdrawals ) : "0";

	}
}

if ( ! function_exists( 'wpj_get_pending_clearance_amount' ) ) {
	function wpj_get_pending_clearance_amount( $uid = '' ) {

		if ( ! $uid ) { $uid = get_current_user_id(); }

		global $wpdb;

		$query = "
			SELECT *, mc_gross AS pending_clearance, orders.id AS oid, orders.tips AS tips, orders.custom_extras AS custom_extras
			FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
			WHERE posts.post_author        = {$uid}
				AND posts.ID               = orders.pid
				AND orders.done_seller     = '1'
				AND orders.done_buyer      = '1'
				AND orders.completed       = '1'
				AND orders.closed          = '0'
				AND orders.clearing_period = '2'
		";
		$g_pending_clearance = $wpdb->get_results( $query , OBJECT );

		$pending_clearance = 0;

		foreach ( $g_pending_clearance as $gpc ) {
			$total_pending_clearance = apply_filters( 'wpj_pending_clearance_seller_update_filter', $gpc->pending_clearance, $gpc );

			// custom extras total
			$total_custom_extras = 0;
			$custom_extras = json_decode( $gpc->custom_extras );
			if ( $custom_extras ) { $i = 0;
				foreach ( $custom_extras as $custom_extra ) {
					if ( $custom_extra->paid ) {
						$custom_extra_ord     = wpj_get_custom_extra( $gpc->oid, $i );
						if ( isset( $custom_extra_ord->id ) ) {
							$custom_extra_payment = wpj_get_payment( array(
								'payment_type'    => 'custom_extra',
								'payment_type_id' => $custom_extra_ord->id
							) );

							$total_custom_extras += $custom_extra_payment->amount;
						}
					} $i++;
				}
			}

			// tips
			$total_tips = 0;
			$tips = json_decode( $gpc->tips );
			if ( $tips ) { $i = 0;
				foreach ( $tips as $tip ) {
					if ( $tip->paid ) {
						$tips_ord     = wpj_get_tip( $gpc->oid, $i );
						$tips_payment = wpj_get_payment( array(
							'payment_type'    => 'tips',
							'payment_type_id' => $tips_ord->id,
						) );

						$total_tips += $tips_payment->amount;
					} $i++;
				}
			}

			$total_amount = $total_pending_clearance + $total_custom_extras + $total_tips;
			$pending_clearance += ( $total_amount - wpj_get_site_fee_by_amount( $total_amount, $gpc->oid, $uid ) );
		}

		return $pending_clearance > 0 ? wpj_show_price( $pending_clearance ) : "0";

	}
}

if ( ! function_exists( 'wpj_get_total_spent_price' ) ) {
	function wpj_get_total_spent_price( $uid = '' ) {

		if ( ! $uid ) { $uid = get_current_user_id(); }

		global $wpdb;

		$query = "
			SELECT * FROM {$wpdb->prefix}job_orders WHERE uid = {$uid} AND done_seller = '0' AND done_buyer = '0' AND date_finished = '0' AND closed = '0' AND payment_status != 'pending'

			UNION ALL

			SELECT * FROM {$wpdb->prefix}job_orders WHERE uid = {$uid} AND ( completed = '1' OR done_seller = '1' )
		";

		$total_spent_results = $wpdb->get_results( $query );

		$transaction_amount_total = 0;

		if ( $total_spent_results ) {
			foreach ( $total_spent_results as $key => $row ) {

				$trans_amount = explode( '|', $row->final_paidamount );

				if ( isset( $trans_amount[0] ) && $trans_amount[0] != wpj_get_site_default_curreny() ) {
					$currency_from = $trans_amount[0];
					$currency_to   = wpj_get_site_default_curreny();

					$transaction_amount = isset( $trans_amount[1] ) ? wpj_get_exchanged_value( $trans_amount[1], $currency_from, $currency_to ) : 0;
				} else {
					$transaction_amount = $trans_amount[1];
				}

				$transaction_amount_total += floatval( $transaction_amount );
			}
		}

		return $transaction_amount_total > 0 ? wpj_show_price( $transaction_amount_total ) : "0";

	}
}

if ( ! function_exists( 'wpj_get_active_orders_price' ) ) {
	function wpj_get_active_orders_price( $uid = '' ) {

		if ( ! $uid ) { $uid = get_current_user_id(); }

		global $wpdb;

		$query = "
			SELECT *
			FROM {$wpdb->prefix}job_orders orders
			WHERE orders.uid           = {$uid}
				AND orders.done_seller = '0'
				AND orders.done_buyer  = '0'
				AND orders.closed      = '0'
		";
		$result = $wpdb->get_results( $query );

		$pending_clearance = 0;
		if ( $result ) {
			foreach ( $result as $key => $row ) {
				$pending_clearance += apply_filters( 'wpj_pending_clearance_buyer_update_filter', $row->mc_gross, $row );
			}
		}

		return $pending_clearance > 0 ? wpj_show_price( $pending_clearance ) : "0";

	}
}

if ( ! function_exists( 'wpj_get_ongoing_jobs_count' ) ) {
	function wpj_get_ongoing_jobs_count( $ret = '', $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		$is_seller = apply_filters( 'hide_for_buyers', true, $uid );

		$as_seller = wpj_get_sales_orders( $uid, 'active' ) ? intval( wpj_get_sales_orders( $uid, 'active' ) ) : __( 'None', 'wpjobster' );
		$as_buyer  = wpj_get_shopping_orders_count( $uid, 'active' ) ? intval( wpj_get_shopping_orders_count( $uid, 'active' ) ) : __( 'None', 'wpjobster' );

		$value = intval( wpj_get_sales_orders( $uid, 'active' ) ) + intval( wpj_get_shopping_orders_count( $uid, 'active' ) );
		if ( ! $value ) { $value = __( 'None', 'wpjobster' ); }

		$tooltip = sprintf( __( 'As buyer: %s', 'wpjobster' ), $as_buyer );
		if ( $is_seller ) {
			$tooltip .= '<br>';
			$tooltip .= sprintf( __( 'As seller: %s', 'wpjobster' ), $as_seller );
		}

		$args = array(
			'as_seller' => $as_seller,
			'as_buyer'  => $as_buyer,
			'total'     => $value,
			'tooltip'   => $tooltip
		);

		return $ret && isset( $args[$ret] ) ? $args[$ret] : $args;
	}
}

if ( ! function_exists( 'wpj_get_completed_jobs_count' ) ) {
	function wpj_get_completed_jobs_count( $ret = '', $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		$is_seller = apply_filters( 'hide_for_buyers', true, $uid );

		$as_seller = wpj_get_sales_orders( $uid, 'completed' ) ? intval( wpj_get_sales_orders( $uid, 'completed' ) ) : __( 'None', 'wpjobster' );
		$as_buyer  = wpj_get_shopping_orders_count( $uid, 'completed' ) ? intval( wpj_get_shopping_orders_count( $uid, 'completed' ) ) : __( 'None', 'wpjobster' );

		$value = intval( wpj_get_sales_orders( $uid, 'completed' ) ) + intval( wpj_get_shopping_orders_count( $uid, 'completed' ) );
		if ( ! $value ) { $value = __( 'None', 'wpjobster' ); }

		$tooltip = sprintf( __( 'As buyer: %s', 'wpjobster' ), $as_buyer );
		if ( $is_seller ) {
			$tooltip .= '<br>';
			$tooltip .= sprintf( __( 'As seller: %s', 'wpjobster' ), $as_seller );
		}

		$args = array(
			'as_seller' => $as_seller,
			'as_buyer'  => $as_buyer,
			'total'     => $value,
			'tooltip'   => $tooltip
		);

		return $ret && isset( $args[$ret] ) ? $args[$ret] : $args;
	}
}

if ( ! function_exists( 'wpj_get_cancelled_jobs_count' ) ) {
	function wpj_get_cancelled_jobs_count( $ret = '', $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		$is_seller = apply_filters( 'hide_for_buyers', true, $uid );

		$as_seller = wpj_get_sales_orders( $uid, 'cancelled' ) ? intval( wpj_get_sales_orders( $uid, 'cancelled' ) ) : __( 'None', 'wpjobster' );
		$as_buyer  = wpj_get_shopping_orders_count( $uid, 'cancelled' ) ? intval( wpj_get_shopping_orders_count( $uid, 'cancelled' ) ) : __( 'None', 'wpjobster' );

		$value = intval( wpj_get_sales_orders( $uid, 'cancelled' ) ) + intval( wpj_get_shopping_orders_count( $uid, 'cancelled' ) );
		if ( ! $value ) { $value = __( 'None', 'wpjobster' ); }

		$tooltip = sprintf( __( 'As buyer: %s', 'wpjobster' ), $as_buyer );
		if ( $is_seller ) {
			$tooltip .= '<br>';
			$tooltip .= sprintf( __( 'As seller: %s', 'wpjobster' ), $as_seller );
		}

		$args = array(
			'as_seller' => $as_seller,
			'as_buyer'  => $as_buyer,
			'total'     => $value,
			'tooltip'   => $tooltip
		);

		return $ret && isset( $args[$ret] ) ? $args[$ret] : $args;
	}
}

if ( ! function_exists( 'wpj_get_posted_jobs_count' ) ) {
	function wpj_get_posted_jobs_count( $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		$posted_jobs_section = apply_filters( 'hide_for_buyers', true, $uid );
		if ( $posted_jobs_section ) {
			$value = wpj_get_user_jobs_count( $uid, 'active' ) ? intval( wpj_get_user_jobs_count( $uid, 'active' ) ) : __( 'None', 'wpjobster' );
		} else {
			$value = __( 'None', 'wpjobster' );
		}

		return $value;
	}
}

if ( ! function_exists( 'wpj_get_ongoing_requests_count' ) ) {
	function wpj_get_ongoing_requests_count( $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		return wpj_get_shopping_orders_count( $uid, 'active_custom_offer' ) ? intval( wpj_get_shopping_orders_count( $uid, 'active_custom_offer' ) ) : __( 'None', 'wpjobster' );
	}
}

if ( ! function_exists( 'wpj_get_completed_requests_count' ) ) {
	function wpj_get_completed_requests_count( $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		return wpj_get_shopping_orders_count( $uid, 'completed_custom_offer' ) ? intval( wpj_get_shopping_orders_count( $uid, 'completed_custom_offer' ) ) : __( 'None', 'wpjobster' );
	}
}

if ( ! function_exists( 'wpj_get_cancelled_requests_count' ) ) {
	function wpj_get_cancelled_requests_count( $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		return wpj_get_shopping_orders_count( $uid, 'cancelled_custom_offer' ) ? intval( wpj_get_shopping_orders_count( $uid, 'cancelled_custom_offer' ) ) : __( 'None', 'wpjobster' );
	}
}

if ( ! function_exists( 'wpj_get_posted_requests_count' ) ) {
	function wpj_get_posted_requests_count( $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		return wpj_get_user_requests( $uid, 'active', 'count' ) ? intval( wpj_get_user_requests( $uid, 'active', 'count' ) ) : __( 'None', 'wpjobster' );
	}
}

if ( ! function_exists( 'wpj_get_user_avg_response_time' ) ) {
	function wpj_get_user_avg_response_time( $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		global $wpdb;

		$art_query = "
			SELECT AVG( TIMESTAMPDIFF( SECOND, FROM_UNIXTIME( datemade ), FROM_UNIXTIME( readdate ) ) )
			AS total
			FROM {$wpdb->prefix}job_pm
			WHERE FROM_UNIXTIME( datemade ) BETWEEN (CURRENT_DATE() - INTERVAL 1 MONTH) AND CURRENT_DATE()
			AND readdate != 0
			AND user = '{$uid}'
		";

		$results = $wpdb->get_results( $art_query );

		return ! empty( $results ) && isset( $results[0]->total ) && $results[0]->total != 0 ? wpj_seconds_to_words( $results[0]->total ) : __( 'Not enough messages', 'wpjobster' );
	}
}

if ( ! function_exists( 'wpj_get_user_recent_delivery' ) ) {
	function wpj_get_user_recent_delivery( $uid = '' ) {
		if ( ! $uid ) $uid = wpj_get_user_id();

		global $wpdb;

		$rd_query = "
			SELECT MAX( date_finished ) AS recent_delivery
			FROM {$wpdb->prefix}job_orders orders,
				 {$wpdb->prefix}posts posts
			WHERE posts.post_author = '{$uid}'
				AND posts.ID = orders.pid
				AND orders.done_seller = '1'
			ORDER BY orders.id DESC
		";

		$results = $wpdb->get_results( $rd_query );

		return ! empty( $results ) && isset( $results[0]->recent_delivery ) && $results[0]->recent_delivery != 0 ? wpj_seconds_to_words( time() - $results[0]->recent_delivery, false, true ) : __( 'No delivery', 'wpjobster' );
	}
}