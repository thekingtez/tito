<?php

if ( ! function_exists( 'wpj_setup_hourly_event' ) ) {
	function wpj_setup_hourly_event() {
		if ( ! wp_next_scheduled( 'wpj_hourly_event' ) ) {
			wp_schedule_event( time(), 'hourly', 'wpj_hourly_event' );
		}
	}
}

if ( ! function_exists( 'wpj_setup_daily_event' ) ) {
	function wpj_setup_daily_event() {
		if ( ! wp_next_scheduled( 'wpj_daily_event' ) ) {
			wp_schedule_event( time(), 'daily', 'wpj_daily_event' );
		}
	}
}

if ( ! function_exists( 'wpj_setup_twicedaily_event' ) ) {
	function wpj_setup_twicedaily_event() {
		if ( ! wp_next_scheduled( 'wpj_twicedaily_event' ) ) {
			wp_schedule_event( time(), 'twicedaily', 'wpj_twicedaily_event' );
		}
	}
}