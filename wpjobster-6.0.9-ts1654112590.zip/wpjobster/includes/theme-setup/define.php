<?php
if ( ! function_exists( 'wpj_show_code_errors' ) ) {

	add_action( 'init', 'wpj_show_code_errors' );
	function wpj_show_code_errors() {
		// add the following to wp-config.php to enable debug:
		// define( 'WPJ_DEBUG', true );

		if ( ( defined( 'WP_JOBSTER_DEBUG' ) && WP_JOBSTER_DEBUG == true ) || ( defined( 'WPJ_DEBUG' ) && WPJ_DEBUG == true ) ) {

			ini_set( 'display_errors',1 );
			ini_set( 'display_startup_errors',1 );
			error_reporting( -1 );

		} else {

			ini_set( 'display_errors',0 );
			ini_set( 'display_startup_errors',0 );
			error_reporting( 0 );

		}
	}

}

if ( ! function_exists( 'wpj_disable_updates' ) ) {

	add_filter( 'pre_site_transient_update_themes', 'wpj_disable_updates', 10, 1 );
	function wpj_disable_updates( $array ) {
		// add the following to wp-config.php to disable theme updates:
		// define( 'WPJ_DISABLE_UPDATES', true );

		if ( defined( 'WPJ_DISABLE_UPDATES' ) && WPJ_DISABLE_UPDATES == true ) {

			global $wp_version;

			return( object ) array( 'last_checked' => time(), 'version_checked' => $wp_version );

		} else {

			return $array;

		}
	}

}