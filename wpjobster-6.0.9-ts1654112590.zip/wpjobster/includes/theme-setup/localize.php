<?php
add_action( 'admin_enqueue_scripts', 'wpj_localize_vars', 11 );
add_action( 'wp_enqueue_scripts', 'wpj_localize_vars', 11 );
if ( ! function_exists( 'wpj_localize_vars' ) ) {
	function wpj_localize_vars() {
		/* Globals */
		global $wp, $post, $wp_query, $jobster_design;

		/* Packages & Extras */
		if ( is_page( wpj_get_option( 'wpjobster_post_new_page_id' ) ) ) {
			$JobsNewEditClass = new WPJJobsNewEdit();
			$pck_vars   = wpj_get_packages_custom_fields();
			$extra_vars = $JobsNewEditClass->getExtrasInfo();
		}

		/* Mime types */
		$allowed_mime_types = wpj_get_option( 'wpjobster_allowed_mime_types' );
		if ( is_string( $allowed_mime_types ) ) $allowed_mime_types = explode( ',', $allowed_mime_types );

/* VARS */

		$theme_vars = array(
			'is_rtl'           => is_rtl() ? 'true' : 'false',
			'h_margin_name'    => is_rtl() ? 'left' : 'right',
			'is_in_app'        => ( wpj_is_handheld() && wpj_is_iframe_previous_pageload() !== false ) ? 'true' : 'false',
			'starting_day'     => wpj_get_option( 'start_of_week' ),
			'language_code'    => substr( get_bloginfo ( 'language' ), 0, 2 ),
			'live_notify'      => wpj_get_option( 'wpjobster_enable_live_notifications' ),
			'max_default_days' => isset( $post->post_type ) && $post->post_type == 'request' ? wpj_get_option( 'wpjobster_request_max_delivery_days' ) : wpj_get_option( 'wpjobster_job_max_delivery_days' ),
			'is_demo_admin'    => is_demo_admin(),
		);

		$page_transition_vars = array(
			'page_transition'           => ! empty( $jobster_design['site_page_transition'] ) ? $jobster_design['site_page_transition'] : 'regular',
			'page_transition_effect'    => ! empty( $jobster_design['site_page_transition_effect'] ) ? $jobster_design['site_page_transition_effect'] : 'fade',
			'page_transition_direction' => ! empty( $jobster_design['site_page_transition_effect_direction'] ) ? $jobster_design['site_page_transition_effect_direction'] : 'down',
			'page_transition_colour'    => ! empty( $jobster_design['site_page_transition_effect_color'] ) ? $jobster_design['site_page_transition_effect_color'] : '#20c497',
		);

		$wp_url_vars = array(
			'home_url'       => get_site_URL(),
			'blog_url'       => get_bloginfo( 'url' ),
			'page_url'       => home_url( $wp->request ),
			'parent_url'     => isset( $wp->query_vars['pagename'] ) ? home_url( $wp->query_vars['pagename'] ) : '',
			'page_url_args'  => home_url( add_query_arg( array( $_GET ), $wp->request . '/' ) ),
			'theme_path'     => get_template_directory_uri(),
			'admin_url'      => get_admin_url(),
			'is_admin'       => is_admin(),
			'is_user_admin'  => current_user_can( 'administrator' ),
			'ajaxurl'        => admin_url( 'admin-ajax.php' ),
			'light_ajax_url' => get_template_directory_uri() . '/includes/light-ajax.php',
			'_ajax_nonce'    => wp_create_nonce( 'modals' ),
			'url_params'     => $_SERVER['QUERY_STRING'],
		);

		$theme_url_vars = array(
			'home_loggedin_url'   => get_permalink( wpj_get_option( 'main_page_url_user' ) ),
			'search_jobs_url'     => get_permalink( wpj_get_option( 'wpjobster_advanced_search_id' ) ),
			'search_requests_url' => get_permalink( wpj_get_option( 'wpjobster_advanced_search_request_page_id' ) ),
			'search_users_url'    => get_permalink( wpj_get_option( 'wpjobster_search_user_page_id' ) ),
			'subscr_page_id'      => get_permalink( wpj_get_option( 'wpjobster_subscriptions_page_id' ) ),
			'my_account_url'      => get_permalink( wpj_get_option( 'wpjobster_my_account_page_id' ) ),
			'my_requests_url'     => get_permalink( wpj_get_option( 'wpjobster_my_requests_page_id' ) ),
			'checkout_url'        => get_permalink( wpj_get_option( 'wpjobster_checkout_page_id' ) ),
			'pm_url'              => wpj_get_pm_link(),
			'user_profile_url'    => wpj_get_user_profile_link(),
			'semantic_file_url'   => get_template_directory_uri() . '/vendor/semantic-ui/src/app.php'
		);

		$page_id_vars = array(
			'my_account_page_id'    => wpj_get_option( 'wpjobster_my_account_page_id' ),
			'my_sales_page_id'      => wpj_get_option( 'wpjobster_my_account_sales_page_id' ),
			'my_shopping_page_id'   => wpj_get_option( 'wpjobster_my_account_shopping_page_id' ),
			'my_payments_page_id'   => wpj_get_option( 'wpjobster_my_account_payments_page_id' ),
			'order_page_id'         => wpj_get_option( 'wpjobster_order_page_id' ),
			'topup_order_page_id'   => wpj_get_option( 'wpjobster_topup_order_page_id' ),
			'new_request_page_id'   => wpj_get_option( 'wpjobster_new_request_page_id' ),
			'new_job_page_id'       => wpj_get_option( 'wpjobster_post_new_page_id' ),
			'user_settings_page_id' => wpj_get_option( 'wpjobster_my_account_personal_info_page_id' ),
			'proposal_page_id'      => wpj_get_option( 'wpjobster_all_proposals_page_id' ),
			'user_profile_page_id'  => wpj_get_option( 'wpjobster_user_profile_page_id' ),
			'badge_page_id'         => wpj_get_option( 'wpjobster_badges_page_id' ),
			'subscription_page_id'  => wpj_get_option( 'wpjobster_subscriptions_page_id' ),
			'featured_page_id'      => wpj_get_option( 'wpjobster_feature_page_id' ),
			'checkout_page_id'      => wpj_get_option( 'wpjobster_checkout_page_id' )
		);

		$key_vars = array(
			'tomtom_api_key'    => wpj_get_option( 'wpjobster_tomtom_search_api_key' ),
			'reCaptcha_api_key' => wpj_get_option( 'wpjobster_recaptcha_api_key' ),
		);

		$header_vars = array(
			'long_menu_arrows' => ! empty( $jobster_design['enable_long_menu_arrows'] ) ? $jobster_design['enable_long_menu_arrows'] : false,
			'header_style'     => ! empty( $jobster_design['header_style'] ) ? $jobster_design['header_style'] : 'fixed_top',
		);

		$currency_vars = array(
			'position' => wpj_get_option( 'wpjobster_currency_position' ),
			'space'    => wpj_get_option( 'wpjobster_currency_symbol_space' ),
			'symbol'   => wpj_get_currency_symbol_by_name( wpj_get_site_curreny() ),
		);

		$fees_vars = array(
			'enable_site_fee'   => wpj_get_option( 'wpjobster_enable_site_fee' ),
			'percent_fee_taken' => wpj_get_option( 'wpjobster_percent_fee_taken' ),
			'solid_fee_taken'   => wpj_get_option( 'wpjobster_solid_fee_taken' )
		);

		$post_data_vars = array(
			'pid'            => wpj_get_post_id(),
			'posts_per_page' => wpj_get_option( 'posts_per_page' ) ? wpj_get_option( 'posts_per_page' ) : 12,
		);

		$attachment_vars = array(
			'allowed_mime_types'      => json_encode( $allowed_mime_types ),
			'attachment_filesize_max' => wpj_get_media_max_upload_size( 'attachment' ),
			'avatar_filesize_max'     => wpj_get_media_max_upload_size( 'avatar' ),
			'avatar_filesize_msg'     => sprintf( __( "Maximum file size is %s MB!", "wpjobster" ), wpj_get_media_max_upload_size( 'avatar' ) ),
			'banner_filesize_max'     => wpj_get_media_max_upload_size( 'banner' ),
			'banner_filesize_msg'     => sprintf( __( "Maximum file size is %s MB!", "wpjobster" ), wpj_get_media_max_upload_size( 'banner' ) ),
			'skill_filesize_max'      => wpj_get_media_max_upload_size( 'skill' ),
			'skill_filesize_msg'      => sprintf( __( "Maximum file size is %s MB!", "wpjobster" ), wpj_get_media_max_upload_size( 'skill' ) ),
			'user_filetype_msg'       => __( 'Allowed file types: .jpg, .jpeg, .png, .gif', 'wpjobster' ),
			'user_filesize_min_msg'   => __( 'Minimum file size: 250px x 250px', 'wpjobster' ),
			'message_filesize_max'    => wpj_get_media_max_upload_size( 'message' ),
			'message_pics_nr_max'     => wpj_get_media_max_upload_number( 'message' ),
			'attachments_audio'       => ! empty( $post->ID ) ? json_encode( wpj_get_job_audio_details( $post->ID ) ) : '',
			'audio_nr_max'            => wpj_get_media_max_upload_number( 'audio' ),
			'audio_filetype_msg'      => __( 'Allowed file types: .mp3, .wav', 'wpjobster' ),
			'audio_filesize_max'      => wpj_get_media_max_upload_size( 'audio' ),
			'audio_filesize_msg'      => sprintf( __( "Maximum file size is %s MB!", "wpjobster" ), wpj_get_media_max_upload_size( 'audio' ) ),
		);

		$media_vars = array(
			'preferred_image_uploader' => wpj_get_option( 'wpjobster_preferred_image_uploader' ),
			'lazy_loading_enabled'     => isset( $jobster_design['enable_lazy_loading'] ) && $jobster_design['enable_lazy_loading'] == '0' ? false : true,
			'wysiwyg_enabled'          => wpj_get_option( 'wpjobster_wysiwyg_for_profile' ),
		);

		$location_vars = array(
			'locations_api_key' => wpj_get_option( 'wpjobster_google_maps_api_key' ),
			'locations_api'     => wpj_get_option( 'wpjobster_location_api_provider' ),
			'locations_country' => wpj_get_option( 'wpjobster_location_restrict_country' ) ? array_map( 'trim', explode( ',', wpj_get_option( 'wpjobster_location_restrict_country' ) ) ) : '',
			'locations_types'   => array_map( 'trim', array( wpj_get_option( 'wpjobster_location_restrict_type', '(cities)' ) ) ),
			'location_fields'   => wpj_get_option( 'wpjobster_location_fields' ) ? json_encode( array_map( 'trim', explode( ',', wpj_get_option( 'wpjobster_location_fields' ) ) ) ) : '',
			'html5_geolocation' => wpj_get_option( 'wpjobster_html5_geolocation_enable' ),
		);

		$emoji_vars = array(
			'pm_emoji_enabled'          => wpj_get_option( 'wpjobster_pm_emoji_enable' ),
			'chat_emoji_enabled'        => wpj_get_option( 'wpjobster_chat_emoji_enable' ),
			'transaction_emoji_enabled' => wpj_get_option( 'wpjobster_transaction_emoji_enable' ),
		);

		$notify_vars = array(
			'chat_enabled'    => wpj_get_option( 'wpjobster_chat_enable' ),
			'quick_responses' => get_user_meta( get_current_user_id(), 'quick_responses', true ),
			'resend_sms_time' => wpj_get_option( 'wpj_resend_sms_time' ) > 0 ? wpj_get_option( 'wpj_resend_sms_time' ) : 0,
		);

		$job_vars = array(
			'max_days_enabled'       => wpj_get_option( 'wpjobster_enable_delivery_time' ),
			'op_enable_shipping'     => wpj_get_option( 'wpjobster_enable_shipping' ),
			'op_mandatory_job_image' => wpj_get_option( 'wpjobster_mandatory_pics_for_jbs' ),
			'op_mandatory_job_audio' => wpj_get_option( 'wpjobster_mandatory_audio_for_jbs' ),
			'op_enable_audio'        => wpj_get_option( 'wpjobster_audio' ),
			'op_enable_tos'          => wpj_get_option( 'wpjobster_tos_type' ),
			'total_jobs_count'       => wpj_get_site_jobs_count(),
			'no_days_price_types'    => json_encode( wpj_get_job_no_days_price_types() ),
			'extra_enable'           => ! empty( $extra_vars ) ? json_encode( $extra_vars['extra_enable'] ) : '',
			'extra_description'      => ! empty( $extra_vars ) ? json_encode( $extra_vars['extra_description'] ) : '',
			'extra_price'            => ! empty( $extra_vars ) ? json_encode( $extra_vars['extra_price'] ) : '',
			'extra_max_days'         => ! empty( $extra_vars ) ? json_encode( $extra_vars['extra_max_days'] ) : '',
			'extra_multiple'         => ! empty( $extra_vars ) ? json_encode( $extra_vars['extra_multiple'] ) : '',
			'rej_comment'            => ! empty( $extra_vars ) ? json_encode( $extra_vars['rej_comment'] ) : ''
		);

		$job_featured_vars = array(
			'h_date_start' => ! empty( wpj_get_option( 'wpjobster_feature_page_id' ) ) ? wpj_get_featured_start_date( 'homepage', wpj_get_post_id() ) : '',
			'c_date_start' => ! empty( wpj_get_option( 'wpjobster_feature_page_id' ) ) ? wpj_get_featured_start_date( 'category', wpj_get_post_id() ) : '',
			's_date_start' => ! empty( wpj_get_option( 'wpjobster_feature_page_id' ) ) ? wpj_get_featured_start_date( 'subcategory', wpj_get_post_id() ) : '',
		);

		$job_package_vars = array(
			'pck_cf_name'     => ! empty( $pck_vars ) ? json_encode( $pck_vars['pck_cf_name'] ) : '',
			'pck_cf_basic'    => ! empty( $pck_vars ) ? json_encode( $pck_vars['pck_cf_basic'] ) : '',
			'pck_cf_standard' => ! empty( $pck_vars ) ? json_encode( $pck_vars['pck_cf_standard'] ) : '',
			'pck_cf_premium'  => ! empty( $pck_vars ) ? json_encode( $pck_vars['pck_cf_premium'] ) : '',
		);

		$request_vars = array(
			'request_multiple' => wpj_get_option( 'wpjobster_display_request_multiple_categories' ) == 'yes' ? true : false,
			'deliv_max'        => wpj_get_option( 'wpjobster_request_max_delivery_days' ),
		);

		$user_vars = array(
			'uid'               => get_current_user_id(),
			'current_role'      => wpj_get_current_user_role(),
			'is_user_logged_in' => is_user_logged_in() ? 1 : 0,
			'desc_content'      => get_user_meta( get_current_user_id(), 'description', true ),
			'user_credits'      => wpj_get_user_credit( get_current_user_id() ),
			'user_level'        => wpj_get_user_level( get_current_user_id() )
		);

		$order_vars = array(
			'extra_prch_page'         => wpj_get_option( 'wpjobster_checkout_extra_enabled' ),
			'force_allow'             => apply_filters( 'wpj_force_allow_filter', false ),
			'arbitration_number'      => is_admin() ? wpj_get_arbitration_in_review_number() : '',
			'order_expected_delivery' => isset( $wp_query->query_vars['oid'] ) ? wpj_get_order_expected_time( $wp_query->query_vars['oid'] ) : false,
		);

		$search_vars = array(
			'allow_job'     => wpj_get_option( 'wpjobster_enable_jobs_for_advanced_search' ),
			'allow_request' => wpj_get_option( 'wpjobster_enable_requests_for_advanced_search' ),
			'allow_users'   => wpj_get_option( 'wpjobster_enable_users_for_advanced_search' ),
		);

		$subscription_vars = array(
			'subscription_enabled'      => wpj_get_option( 'wpjobster_subscription_enabled' ),
			'subscription_fees_enabled' => wpj_get_option( 'wpjobster_fees_for_subscriber_enabled' ),
			'subscription_fee'          => wpj_get_subscription_info( get_current_user_id(), 'wpjobster_subscription_fees' )
		);

		$character_limits = array(
			'characters_request_title_min'           => wpj_get_characters_limit( 'request_title', 'min', 0 ),
			'characters_request_title_max'           => wpj_get_characters_limit( 'request_title', 'max', 80 ),
			'characters_request_desc_min'            => wpj_get_characters_limit( 'request_description', 'min', 0 ),
			'characters_request_desc_max'            => wpj_get_characters_limit( 'request_description', 'max', 1000 ),
			'characters_feedback_min'                => wpj_get_characters_limit( 'feedback_message', 'min', 0 ),
			'characters_feedback_max'                => wpj_get_characters_limit( 'feedback_message', 'max', 1000 ),
			'characters_pm_min'                      => wpj_get_characters_limit( 'private_message', 'min', 0 ),
			'characters_pm_max'                      => wpj_get_characters_limit( 'private_message', 'max', 1200 ),
			'characters_job_title_min'               => wpj_get_characters_limit( 'job_title', 'min', 15 ),
			'characters_job_title_max'               => wpj_get_characters_limit( 'job_title', 'max', 80 ),
			'characters_job_desc_min'                => wpj_get_characters_limit( 'job_description', 'min', 0 ),
			'characters_job_desc_max'                => wpj_get_characters_limit( 'job_description', 'max', 1000 ),
			'characters_job_instr_min'               => wpj_get_characters_limit( 'characters_jobinstr_min', 'min', 0 ),
			'characters_job_instr_max'               => wpj_get_characters_limit( 'characters_jobinstr_min', 'max', 350 ),
			'characters_extradesc_min'               => wpj_get_characters_limit( 'job_extra_description', 'min', 0 ),
			'characters_extradesc_max'               => wpj_get_characters_limit( 'job_extra_description', 'max', 50 ),
			'characters_job_package_title_min'       => wpj_get_characters_limit( 'job_package_title', 'min', 0 ),
			'characters_job_package_title_max'       => wpj_get_characters_limit( 'job_package_title', 'max', 120 ),
			'characters_job_package_description_min' => wpj_get_characters_limit( 'job_package_description', 'min', 0 ),
			'characters_job_package_description_max' => wpj_get_characters_limit( 'job_package_description', 'max', 1000 ),
		);

		if ( is_page( wpj_get_option( 'wpjobster_post_new_page_id' ) ) ) {
			$user_features_vars = array(
				'enable_extra'    => wpj_get_user_feature_status( 'wpjobster_enable_extra', 'wpjobster_subscription_noof_extras_enabled' ),
				'extra_multiples' => wpj_get_user_feature_value( 'extras', 'noof_extras', 10 ),
				'video_multiples' => wpj_get_user_feature_value( 'vds', 'video_multiples', 1 ),
			);

			$amount_limits = array(
				'amount_jobprice_min'           => wpj_get_user_feature_value( 'min_amount', 'min_job_price' ),
				'amount_jobprice_max'           => wpj_get_user_feature_value( 'max_amount', 'max_job_price' ),
				'amount_job_pacakger_price_min' => wpj_get_option( 'wpj_pacakge_amount_price_limits' )[1],
				'amount_job_pacakger_price_max' => wpj_get_option( 'wpj_pacakge_amount_price_limits' )[2],
				'amount_jobextra_price_min'     => wpj_get_user_feature_value( 'min_extra_amount', 'min_extra_price' ),
				'amount_jobextra_price_max'     => wpj_get_user_feature_value( 'max_extra_amount', 'max_extra_price' ),
			);

		} else $user_features_vars = $amount_limits = array();

/* STRINGS */

		$text_with_array_strings = array(
			'days' => array(
				'sun' => _x( 'S', 'Abbreviation of: Sunday', 'wpjobster' ),
				'mon' => _x( 'M', 'Abbreviation of: Monday', 'wpjobster' ),
				'tue' => _x( 'T', 'Abbreviation of: Tuesday', 'wpjobster' ),
				'wed' => _x( 'W', 'Abbreviation of: Wednesday', 'wpjobster' ),
				'thu' => _x( 'T', 'Abbreviation of: Thursday', 'wpjobster' ),
				'fri' => _x( 'F', 'Abbreviation of: Friday', 'wpjobster' ),
				'sat' => _x( 'S', 'Abbreviation of: Saturday', 'wpjobster' ),
			),
			'days2' => array(
				'su' => _x( 'Su', 'Abbreviation of: Sunday', 'wpjobster' ),
				'mo' => _x( 'Mo', 'Abbreviation of: Monday', 'wpjobster' ),
				'tu' => _x( 'Tu', 'Abbreviation of: Tuesday', 'wpjobster' ),
				'we' => _x( 'We', 'Abbreviation of: Wednesday', 'wpjobster' ),
				'th' => _x( 'Th', 'Abbreviation of: Thursday', 'wpjobster' ),
				'fr' => _x( 'Fr', 'Abbreviation of: Friday', 'wpjobster' ),
				'sa' => _x( 'Sa', 'Abbreviation of: Saturday', 'wpjobster' ),
			),
			'monthsShort' => array(
				'jan' => _x( 'Jan', 'Abbreviation of: January', 'wpjobster' ),
				'feb' => _x( 'Feb', 'Abbreviation of: February', 'wpjobster' ),
				'mar' => _x( 'Mar', 'Abbreviation of: March', 'wpjobster' ),
				'apr' => _x( 'Apr', 'Abbreviation of: April', 'wpjobster' ),
				'may' => _x( 'May', 'Abbreviation of: May', 'wpjobster' ),
				'jun' => _x( 'Jun', 'Abbreviation of: June', 'wpjobster' ),
				'jul' => _x( 'Jul', 'Abbreviation of: July', 'wpjobster' ),
				'aug' => _x( 'Aug', 'Abbreviation of: August', 'wpjobster' ),
				'sep' => _x( 'Sep', 'Abbreviation of: September', 'wpjobster' ),
				'oct' => _x( 'Oct', 'Abbreviation of: October', 'wpjobster' ),
				'nov' => _x( 'Nov', 'Abbreviation of: November', 'wpjobster' ),
				'dec' => _x( 'Dec', 'Abbreviation of: December', 'wpjobster' ),
			),
			'months' => array(
				'jan' => _x( 'January', 'Full name of: January', 'wpjobster' ),
				'feb' => _x( 'February', 'Full name of: February', 'wpjobster' ),
				'mar' => _x( 'March', 'Full name of: March', 'wpjobster' ),
				'apr' => _x( 'April', 'Full name of: April', 'wpjobster' ),
				'may' => _x( 'May', 'Full name of: May', 'wpjobster' ),
				'jun' => _x( 'June', 'Full name of: June', 'wpjobster' ),
				'jul' => _x( 'July', 'Full name of: July', 'wpjobster' ),
				'aug' => _x( 'August', 'Full name of: August', 'wpjobster' ),
				'sep' => _x( 'September', 'Full name of: September', 'wpjobster' ),
				'oct' => _x( 'October', 'Full name of: October', 'wpjobster' ),
				'nov' => _x( 'November', 'Full name of: November', 'wpjobster' ),
				'dec' => _x( 'December', 'Full name of: December', 'wpjobster' ),
			),
		);

		$text_with_vars_strings = array(
			'account_balance'             => sprintf( __( 'Account Balance - %s', 'wpjobster' ), wpj_show_price( wpj_get_user_credit( get_current_user_id() ) ) ),
			'attachments_max_size_err'    => sprintf( __( 'Maximum file size is %s MB!', 'wpjobster' ), wpj_get_media_max_upload_size( 'attachment' ) ),
			'deliv_max_err'               => sprintf( __( 'Delivery days must be less than or equal to %s', 'wpjobster' ), wpj_get_option( 'wpjobster_request_max_delivery_days' ) ),
			'feedback_min_desc'           => sprintf( __( 'The description field needs to have at least %d characters', 'wpjobster' ), wpj_get_characters_limit( 'feedback_message', 'min', 0 ) ),
			'feedback_max_desc'           => sprintf( __( 'The description field needs to have at most %d characters', 'wpjobster' ), wpj_get_characters_limit( 'feedback_message', 'max', 1000 ) ),
			'lbl_request_title_min'       => sprintf( __( 'The title field needs to have at least %d characters', 'wpjobster' ), wpj_get_characters_limit( 'request_title', 'min', 0 ) ),
			'lbl_request_title_max'       => sprintf( __( 'The title field needs to have at most %d characters', 'wpjobster' ), wpj_get_characters_limit( 'request_title', 'max', 80 ) ),
			'lbl_request_description_min' => sprintf( __( 'The description field needs to have at least %d characters', 'wpjobster' ), wpj_get_characters_limit( 'request_description', 'min', 0 ) ),
			'lbl_request_description_max' => sprintf( __( 'The description field needs to have at most %d characters', 'wpjobster' ), wpj_get_characters_limit( 'request_description', 'max', 1000 ) ),
			'pm_min_content'              => sprintf( __( 'The message needs to have at least %d characters', 'wpjobster' ), wpj_get_characters_limit( 'private_message', 'min', 0 ) ),
			'pm_max_content'              => sprintf( __( 'The message needs to have at most %d characters', 'wpjobster' ), wpj_get_characters_limit( 'private_message', 'max', 1200 ) ),
			'price_min_err'               => sprintf( __( 'Money amount must be bigger than %s', 'wpjobster' ), wpj_show_price_classic( wpj_get_option( 'wpjobster_offer_price_min' ) ) ),
			'price_max_err'               => sprintf( __( 'Maximum money amount is %s', 'wpjobster' ), wpj_show_price_classic( wpj_get_option( 'wpjobster_offer_price_max' ) ) ),
		);

		$text_strings = array(
			'accepted'                         => __( 'Accepted', 'wpjobster' ),
			'activate'                         => __( 'Activate', 'wpjobster' ),
			'add_lbl'                          => __( 'Add', 'wpjobster' ),
			'add_new_lbl'                      => __( 'Add New', 'wpjobster' ),
			'add_quick_response'               => __( 'Create a new quick response', 'wpjobster' ),
			'am'                               => __( 'AM', 'wpjobster' ),
			'amount'                           => __( 'Amount', 'wpjobster' ),
			'amount_err'                       => __( 'Please type an amount of money.', 'wpjobster' ),

			'badge_empty'                      => __( 'Please select at least one badge.', 'wpjobster' ),

			'cancel_lbl'                       => __( 'Cancel', 'wpjobster' ),
			'cancelled'                        => __( 'Cancelled', 'wpjobster' ),
			'check_all_email'                  => __( 'Check all', 'wpjobster' ),
			'check_all_sms'                    => __( 'Check all', 'wpjobster' ),
			'clear'                            => __( 'Clear', 'wpjobster' ),
			'close'                            => __( 'Close', 'wpjobster' ),
			'completed_jobs'                   => __( 'Completed Jobs:', 'wpjobster' ),
			'contact'                          => __( 'Contact', 'wpjobster' ),
			'custom'                           => __( 'Custom', 'wpjobster' ),

			'date'                             => __( 'Date', 'wpjobster' ),
			'deactivate'                       => __( 'Deactivate', 'wpjobster' ),
			'declined'                         => __( 'Declined', 'wpjobster' ),
			'delete_lbl'                       => __( 'Delete', 'wpjobster' ),
			'deliv_err'                        => __( 'Please type delivery days.', 'wpjobster' ),
			'deliv_min_err'                    => __( 'Delivery days must be greater than or equal to 1', 'wpjobster' ),

			'edit_lbl'                         => __( 'Edit', 'wpjobster' ),
			'edit_desc_lbl'                    => __( 'Edit Description', 'wpjobster' ),
			'edit_quick_response'              => __( 'Edit quick response', 'wpjobster' ),
			'email_send_lbl'                   => __( 'Email sent', 'wpjobster' ),
			'empty_quick_response'             => __( 'You must enter a name and a quick response', 'wpjobster' ),
			'err'                              => __( 'Error', 'wpjobster' ),
			'err_already_in_vacation'          => __( 'You already have vacation mode active.', 'wpjobster' ),
			'err_empty_start_date'             => __( 'Please select the start date.', 'wpjobster' ),
			'err_small_start_date'             => __( 'You can\'t select a date from the past.', 'wpjobster' ),
			'err_empty_end_date'               => __( 'Please select the end date.', 'wpjobster' ),
			'err_small_end_date'               => __( 'Please select a date in the future.', 'wpjobster' ),
			'err_something_wrong'              => __( 'Something went wrong.', 'wpjobster' ),
			'err_try_again'                    => __( 'Try again', 'wpjobster' ),
			'err_try_again_later'              => __( 'Please try again later.', 'wpjobster' ),
			'err_unknown'                      => __( 'Unknown error', 'wpjobster' ),
			'error_403'                        => __( '403 Forbidden', 'wpjobster' ),
			'error_404'                        => __( '404 Error', 'wpjobster' ),

			'featured_empty'                   => __( 'Please select at least one page.', 'wpjobster' ),
			'featured_interval'                => __( 'The interval was changed in the meantime.', 'wpjobster' ),
			'feedback_min'                     => __( 'Please insert a longer description for your rating', 'wpjobster' ),
			'feedback_max'                     => __( 'Please insert a shorter description for your rating', 'wpjobster' ),
			'feedback_stars'                   => __( 'Please select the amount of stars', 'wpjobster' ),
			'finished'                         => __( 'Finished', 'wpjobster' ),
			'forbidden_file_type'              => __( 'Forbidden file type', 'wpjobster' ),
			'from'                             => __( 'From', 'wpjobster' ),

			'get_for_free'                     => __( 'Get for free', 'wpjobster' ),

			'insert_faq'                       => __( 'Insert your question and answer', 'wpjobster' ),
			'invalid_file_type'                => __( 'Invalid file type.', 'wpjobster' ),

			'jobs_label'                       => __( 'Jobs', 'wpjobster' ),

			'language_lbl'                     => __( 'Language', 'wpjobster' ),
			'last_7_days'                      => __( 'Last 7 Days', 'wpjobster' ),
			'last_30_days'                     => __( 'Last 30 Days', 'wpjobster' ),
			'last_month'                       => __( 'Last Month', 'wpjobster' ),
			'lbl_cost'                         => __( 'Cost', 'wpjobster' ),
			'lbl_loading'                      => __( 'Loading...', 'wpjobster' ),
			'lbl_options'                      => __( 'Options', 'wpjobster' ),
			'lbl_please_select'                => __( 'Please Select', 'wpjobster' ),
			'lbl_request_budget'               => __( 'Budget from is equal or higher than budget to!', 'wpjobster' ),
			'lbl_request_category'             => __( 'Please select a category!', 'wpjobster' ),
			'lbl_request_date'                 => __( 'Start date is equal or higher than end date!', 'wpjobster' ),
			'lbl_request_description_empty'    => __( 'You cannot leave the description request empty!', 'wpjobster' ),
			'lbl_request_title_empty'          => __( 'You cannot leave the title request empty!', 'wpjobster' ),
			'lbl_request_cf_empty'             => __( 'You cannot leave empty the following field:', 'wpjobster' ),
			'lvl_update_lbl'                   => __( 'Update', 'wpjobster' ),
			'lvl_saved_lbl'                    => __( 'Saved', 'wpjobster' ),

			'maximum_file_size_exceeded'       => __( 'Maximum file size exceeded', 'wpjobster' ),
			'maximum_number_of_files_exceeded' => __( 'Maximum number of files exceeded.', 'wpjobster' ),
			'media_blank'                      => __( "You need to upload at least one media for your verification.", "wpjobster" ),
			'msg_err'                          => __( 'Please write something in the text field.', 'wpjobster' ),

			'no_active_jobs'                   => __( 'No active jobs.', 'wpjobster' ),
			'no_certifications'                => __( 'Click on "Add New" to add a new Certification!', 'wpjobster' ),
			'no_credits'                       => __( 'The selected job can\'t be activated until you add credits to your account.', 'wpjobster' ),
			'no_description'                   => __( 'Click on "Edit Description" to add a Description!', 'wpjobster' ),
			'no_educations'                    => __( 'Click on "Add New" to add a new Education!', 'wpjobster' ),
			'no_gateway_enabled'               => __( 'Payment methods are not available at this time. Please contact the administrator of this site for help.', 'wpjobster' ),
			'no_inactive_jobs'                 => __( 'No inactive jobs.', 'wpjobster' ),
			'no_languages'                     => __( 'Click on "Add New" to add a new Language!', 'wpjobster' ),
			'no_messages'                      => __( 'No messages here', 'wpjobster' ),
			'no_quick_responses'               => __( 'No quick responses', 'wpjobster' ),
			'no_rejected_jobs'                 => __( 'No rejected jobs.', 'wpjobster' ),
			'no_requests'                      => __( 'There are no requests yet.', 'wpjobster' ),
			'no_skills'                        => __( 'Click on "Add New" to add a new Skill!', 'wpjobster' ),
			'no_tagline'                       => __( 'Click here to add a tagline!', 'wpjobster' ),
			'no_under-review_jobs'             => __( 'No under review jobs.', 'wpjobster' ),
			'not_enough_credits'               => __( 'You don\'t have enough money in your balance!', 'wpjobster' ),
			'not_your_post'                    => __( 'This is not your post.', 'wpjobster' ),
			'not_logged_in'                    => __( 'You need to login.', 'wpjobster' ),
			'nothing_found'                    => __( 'No results found.', 'wpjobster' ),
			'now'                              => __( 'Now', 'wpjobster' ),

			'offer_declined'                   => __( 'You have declined the offer.', 'wpjobster' ),
			'offer_withdrawn'                  => __( 'You have withdrawn your offer.', 'wpjobster' ),
			'open_in_messages'                 => __( 'Open in Messages', 'wpjobster' ),

			'paused'                           => __( 'paused', 'wpjobster' ),
			'payment_type'                     => __( 'Payment type', 'wpjobster' ),
			'please_wait_lbl'                  => __( 'Please wait', 'wpjobster' ),
			'pm'                               => __( 'PM', 'wpjobster' ),
			'proficiency_lbl'                  => __( 'Proficiency', 'wpjobster' ),
			'published'                        => __( 'published', 'wpjobster' ),

			'rating'                           => __( 'Rating:', 'wpjobster' ),
			'read_less'                        => __( 'Read Less', 'wpjobster' ),
			'read_more'                        => __( 'Read More', 'wpjobster' ),
			'registered'                       => __( 'Registered:', 'wpjobster' ),
			'requests_label'                   => __( 'Requests', 'wpjobster' ),
			'report_user'                      => __( 'Report user', 'wpjobster' ),

			'save_lbl'                         => __( 'Save', 'wpjobster' ),
			'search_users_label'               => __( 'Search users containing', 'wpjobster' ),
			'select_category'                  => __( 'Select Category', 'wpjobster' ),
			'select_file'                      => __( 'Select file', 'wpjobster' ),
			'select_subcategory'               => __( 'Select Subcategory', 'wpjobster' ),
			'send_email_lbl'                   => __( 'Send email', 'wpjobster' ),
			'sent_lbl'                         => __( 'Sent', 'wpjobster' ),
			'show_less'                        => __( 'Show Less', 'wpjobster' ),
			'skill_lbl'                        => __( 'Skill', 'wpjobster' ),
			'submit'                           => __( 'Submit', 'wpjobster' ),
			'subscription_empty'               => __( 'Please select a plan.', 'wpjobster' ),
			'success'                          => __( 'Success', 'wpjobster' ),
			'success_saved'                    => __( 'Your settings have been saved.', 'wpjobster' ),

			'this_month'                       => __( 'This Month', 'wpjobster' ),
			'to'                               => __( 'To', 'wpjobster' ),
			'today'                            => __( 'Today', 'wpjobster' ),
			'topup_package_empty'              => __( 'Please select the package first', 'wpjobster' ),

			'unavailable_lbl'                  => __( 'Unavailable', 'wpjobster' ),
			'uncheck_all_email'                => __( 'Uncheck all', 'wpjobster' ),
			'uncheck_all_sms'                  => __( 'Uncheck all', 'wpjobster' ),
			'unknown_error'                    => __( 'Unknown Error', 'wpjobster' ),
			'url_error_lbl'                    => __( 'The url you provided doesn\'t contain a valid image.', 'wpjobster' ),
			'users_label'                      => __( 'Users', 'wpjobster' ),

			'view_more'                        => __( 'View More', 'wpjobster' ),

			'yesterday'                        => __( 'Yesterday', 'wpjobster' ),

			'withdrawn'                        => __( 'Withdrawn', 'wpjobster' ),
			'write_message'                    => __( 'Write a message...', 'wpjobster' ),
			'withdrawal_request'               => __( 'The withdrawal request was sent successfully.', 'wpjobster' )
		);

		$authentication_strings = array(
			'login'            => addslashes( __( 'Login', 'wpjobster' ) ),
			'register'         => addslashes( __( 'Register', 'wpjobster' ) ),
			'forgot'           => addslashes( __( 'Forgot Password', 'wpjobster' ) ),
			'reset'            => addslashes( __( 'Reset Password', 'wpjobster' ) ),
			'user_name'        => addslashes( __( 'Username', 'wpjobster' ) ),
			'user_email'       => addslashes( __( 'Username / Email Address', 'wpjobster' ) ),
			'email'            => addslashes( __( 'Email', 'wpjobster' ) ),
			'password'         => addslashes( __( 'Password', 'wpjobster' ) ),
			'confirm_password' => addslashes( __( 'Confirm Password', 'wpjobster' ) ),
			'phone_number'     => addslashes( __( 'Phone Number', 'wpjobster' ) ),
			'company'          => addslashes( __( 'Company', 'wpjobster' ) ),
		);

		$dropzone_strings = array(
			'dictFallbackMessage'          => addslashes( __( "Your browser does not support drag'n'drop file uploads.", "wpjobster" ) ),
			'dictFallbackText'             => addslashes( __( "Please use the fallback form below to upload your files like in the olden days.", "wpjobster" ) ),
			'dictFileTooBig'               => addslashes( __( "File is too big ({{filesize}}MiB). Max filesize: {{maxFilesize}}MiB.", "wpjobster" ) ),
			'dictInvalidFileType'          => addslashes( __( "You can't upload files of this type.", "wpjobster" ) ),
			'dictResponseError'            => addslashes( __( "Server responded with {{statusCode}} code.", "wpjobster" ) ),
			'dictCancelUpload'             => addslashes( __( "Cancel upload", "wpjobster" ) ),
			'dictCancelUploadConfirmation' => addslashes( __( "Are you sure you want to cancel this upload?", "wpjobster" ) ),
			'dictRemoveFile'               => addslashes( __( "Remove file", "wpjobster" ) ),
			'dictMaxFilesExceeded'         => addslashes( __( "You cannot upload any more files.", "wpjobster" ) ),
			'dictdragDropBrowse'           => addslashes( __( 'Drag & Drop a Photo or <span>Browse</span>', 'wpjobster' ) )
		);

/* LOCALIZE */

		$localize_arr_strings = array_merge(
			$theme_vars,
			$page_transition_vars,
			$wp_url_vars,
			$theme_url_vars,
			$page_id_vars,
			$key_vars,
			$header_vars,
			$currency_vars,
			$fees_vars,
			$post_data_vars,
			$attachment_vars,
			$media_vars,
			$location_vars,
			$emoji_vars,
			$notify_vars,
			$job_vars,
			$job_featured_vars,
			$job_package_vars,
			$request_vars,
			$user_vars,
			$order_vars,
			$search_vars,
			$subscription_vars,
			$character_limits,
			$user_features_vars,
			$amount_limits,
			$text_with_array_strings,
			$text_with_vars_strings,
			$text_strings,
			$authentication_strings,
			$dropzone_strings,
			! empty( $JobsNewEditClass ) ? $JobsNewEditClass->getJobValidationStrings() : array()
		);

		$localize_arr_strings = apply_filters( 'wpj_localize_strings_filter', $localize_arr_strings );

		wp_localize_script( 'wpj-admin-scripts', 'wpj_vars', $localize_arr_strings );
		wp_localize_script( 'wpj-front-scripts', 'wpj_vars', $localize_arr_strings );

	}
}

add_action( 'wp_head', 'wpj_php_vars_for_js', 1 );
if ( ! function_exists( 'wpj_php_vars_for_js' ) ) {
	function wpj_php_vars_for_js() {
		$scheme = is_ssl() ? 'https' : 'http'; ?>

		<script>
			var ajaxurl           = '<?php echo admin_url( 'admin-ajax.php', $scheme ); ?>';
			var is_user_logged_in = '<?php echo is_user_logged_in(); ?>';
		</script>

	<?php }
}