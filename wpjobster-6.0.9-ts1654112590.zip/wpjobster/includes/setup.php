<?php

// LOCALIZE
include_once get_template_directory() . '/includes/theme-setup/localize.php';

// HEAD META
include_once get_template_directory() . '/includes/theme-setup/head-metas.php';

// SCRIPTS AND STYLES
include_once get_template_directory() . '/includes/theme-setup/scripts-and-styles.php';

// POST TYPES & TAXONOMY //
include_once get_template_directory() . '/includes/theme-setup/post-types-and-taxonomies.php';

// WIDGETS
include_once get_template_directory() . '/includes/theme-setup/widgets.php';

// MENUS
include_once get_template_directory() . '/includes/theme-setup/menus.php';

// REDIRECTS
include_once get_template_directory() . '/includes/theme-setup/redirects.php';

// REWRITE RULES
include_once get_template_directory() . '/includes/theme-setup/rules.php';

// PERMALINKS
include_once get_template_directory() . '/includes/theme-setup/permalink.php';

// TEXT DOMAIN
include_once get_template_directory() . '/includes/theme-setup/textdomain.php';

// UPDATER
include_once get_template_directory() . '/includes/theme-setup/updater.php';

// THEME ACTIVATE/DEACTIVATE
include_once get_template_directory() . '/includes/theme-setup/activate-deactivate.php';

// MEDIA
include_once get_template_directory() . '/includes/theme-setup/media.php';

// COOKIES
include_once get_template_directory() . '/includes/theme-setup/cookies.php';

// LICENSE
include_once get_template_directory() . '/includes/theme-setup/license.php';

// TITLE
include_once get_template_directory() . '/includes/theme-setup/title.php';

// PLUGINS
include_once get_template_directory() . '/includes/theme-setup/plugins.php';

// PAGES
include_once get_template_directory() . '/includes/theme-setup/pages.php';

// CRONS
include_once get_template_directory() . '/includes/theme-setup/crons.php';

// ACF PATH
add_filter( 'acf/settings/load_json', function( $paths ) {
	$paths[] = get_template_directory() . '/lib/acf-json';
	return $paths;
});

// OUTPUT BUFFERING
add_action( 'init', function() { ob_start(); } );
add_action( 'wp_footer', function() { ob_end_flush(); } );