jQuery( document ).ready( function( $ ) {

	// post new job/request
	$( document ).on( 'click', 'body.wpj-is-iframe.wpj-is-handheld .post-new-job-wrapper .tab-controls a.right', function( e ) {
		e.preventDefault();
		var scrollOffset = $( ".post-new-job-wrapper" ).offset().top - $( "#content-full-ov" ).offset().top;
		$( '.pusher' ).animate( { scrollTop: scrollOffset }, 1000 );
	});

	$( document ).on( 'click', 'body.wpj-is-iframe.wpj-is-handheld .post-new-job-wrapper .tab-controls a.left', function( e ) {
		e.preventDefault();
		var scrollOffset = $( ".post-new-job-wrapper" ).offset().top - $( "#content-full-ov" ).offset().top;
		$( '.pusher' ).animate( { scrollTop: scrollOffset }, 1000 );
	});

	// private messages
	$( ".pusher" ).animate({ scrollTop: $( '.pm-list' ).prop( "scrollHeight" )}, 1000 );

	// chatbox
	$( ".pusher" ).animate({ scrollTop: $( '#order-notification-messages-wrapper' ).prop( "scrollHeight" )}, 1000 );

	// lazy load fixes
	if ( $( 'body' ).hasClass( 'wpj-is-iframe' ) && $( 'body' ).hasClass( 'wpj-is-handheld' ) ) {
		jQuery( '.pusher' ).scroll( function() {
			if ( typeof jQuery.fn.echoLazyLoadRender == 'function' ) {
				jQuery.fn.echoLazyLoadRender();
			}
		});
	}

});
