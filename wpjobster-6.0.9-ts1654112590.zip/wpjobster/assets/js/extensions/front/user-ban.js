jQuery( document ).ready(function( $ ) {

	/**
	 * Validate user IP ban - zm-ajax
	 */
	window.ajax_login_register_validate_user_ban = function( myObj ) {
		$this = myObj;

		$form = $this.parents( 'form' );

		$.ajax({
			data    : "action=validate_user_ban",
			dataType: 'json',
			type    : "POST",
			url     : _ajax_login_settings.ajaxurl,
			success : function( msg ) {
				ajax_login_register_show_message( $form, msg );
			}
		});

		if ( typeof msg !== 'undefined' ) {
			if ( msg.code == 'error' ) {
				return false;
			}
		}
	}

	$( document ).on( 'click', '.register_button', function() {
		ajax_login_register_validate_user_ban( $( "#login" ) );
	});

});