jQuery( document ).ready( function( $ ) {

	$( document ).on( 'click', '.js-generate-referral-url-btn', function( e ) {
		e.preventDefault();

		if ( $( '.js-referral-input-url' ).val() ) {
			var content = $( '.js-referral-input-url' ).val() + '?ref=' + $( this ).attr( 'aria-label' );

		} else {
			var content = wpj_vars.home_url + '?ref=' + $( this ).attr( 'aria-label' );

		}

		$( '.js-referral-generated-url-link' ).show().html( '<span class="ui big basic label">' + content + '</span' );

	});

});