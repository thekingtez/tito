Hooks.add_action( 'wpj_after_page_load_without_refresh', wpj_invoices_init_scripts );
function wpj_invoices_init_scripts() {
	if ( jQuery( '.js-topup-order-invoice-button' )[0] ) {
		var orderid = window.location.href.replace( /\/+$/,'' ).split( '/' ).pop();
		jQuery( '.js-topup-order-invoice-button' ).attr( 'href', wpj_vars.blog_url + '/invoice/topup/' + orderid );
	}
}