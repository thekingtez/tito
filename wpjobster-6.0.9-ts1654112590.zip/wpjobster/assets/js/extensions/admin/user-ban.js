jQuery( document ).ready( function( $ ) {

	/* Ban section */
	$( '#ub_status' ).on( 'change rightnow', function() {
		if ( $( this ).val() == 'banned_account' || $( this ).val() == 'banned_ip' ) {
			$( '.banned_section' ).show();
		} else {
			$( '.banned_section' ).hide();
		}
	}).triggerHandler( 'rightnow' );

	/* Period selector */
	$( '#ub_period' ).on( 'change rightnow', function() {
		if ( $( this ).val() == 'temporarily' ) {
			$( '.ub_period_date' ).show();
		} else {
			$( '.ub_period_date' ).hide();
		}
	}).triggerHandler( 'rightnow' );

	/* New violation record */
	$( '.violations-record-content' ).on( 'click', function() {
		$( this ).hide();

		$( '.violations-record-new' ).show();
		$( '.violations-record-textarea' ).focus();
	});

	/* Cancel new violation record */
	$( '.violations-record-btn' ).on( 'click', function( e ) {
		e.preventDefault();

		$( '.violations-record-textarea' ).val( '' );

		$( '.violations-record-new' ).hide();
		$( '.violations-record-content' ).show();
	});

});
