jQuery( document ).ready( function( $ ) {

	/* WISE */
	$( document ).on( 'click', '.js-generate-profile-id', function() {
		$( this ).text( 'Loading...' );

		$.ajax({
			type   : "POST",
			url    : wpj_vars.ajaxurl,
			data   : { action: 'generate_profile_id_action' },
			success: function( response ) {
				$( '.js-generate-profile-id' ).text( 'Generate Profile ID' );
				$( '.js-profile-id-content' ).html( response );
			}
		});
	});

	$( document ).on( 'click', '.mark-order-completed', function( e ) {

		/* WISE */
		if ( $( this ).hasClass( 'wise' ) ) {
			e.preventDefault();

			$( this ).parents( 'tr' ).find( 'input[type="checkbox"]' ).prop( 'checked', true );

			$( '#processWisePayRequest' ).trigger( 'click' );
		}

		/* PAYONEER */
		if ( $( this ).hasClass( 'payoneer' ) ) {
			e.preventDefault();

			$( this ).parents( 'tr' ).find( 'input[type="checkbox"]' ).prop( "checked", true );

			$( '#processPayoneerPayRequest' ).trigger( 'click' );
		}

	});

});