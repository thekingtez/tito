jQuery( document ).ready( function( $ ) {

	$( window ).scroll( function() {

		wpj_init_on_scroll();

	});

});

function wpj_init_on_scroll() {
	// fixed header
	wpj_add_fixed_menu_on_scroll();

	// scroll to top button
	wpj_toggle_scroll_to_top_button();
}