jQuery( document ).ready( function( $ ) {

	// user settings save
	$( document ).on( "click", ".js-save-user-settings", function( e ) {

		e.preventDefault();

		var this_form = $( this ).parents( '.ui.form' );

		jQuery.ajax({
			type : "POST",
			url  : wpj_vars.ajaxurl,
			data : "action=save_user_settings_action&" + this_form.serialize(),
			beforeSend: function() {
				this_form.addClass( 'loading' );
			},
			success: function( response ) {
				obj = JSON.parse( response );

				const messagePosition = window.innerWidth > 768 ? 'right' : 'top'

				if ( obj.status == 'error' )
					$( '.js-save-user-settings' ).notify( obj.error, { position: messagePosition, className: 'error' } );

				else
					$( '.js-save-user-settings' ).notify( wpj_vars.success_saved, { position: messagePosition, className: 'success' } );

				Hooks.do_action( 'wpj_after_user_settings_saved' );
			},
			complete: function() {
				this_form.removeClass( 'loading' );
			}
		});
	});

});

// user profile details popup
function wpj_init_user_profile_tooltips() {
	if ( jQuery( '.content-wrapper' )[0] )
		jQuery( '.content-wrapper' ).popup({ on: 'hover' });
}