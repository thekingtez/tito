jQuery( document ).ready( function( $ ) {

	// Brizy: stop login/register popup when editing
	if ( wpj_vars.is_user_logged_in == true && ( getUrlParameter( 'brizy-edit' ) || getUrlParameter( 'brizy-edit-iframe' ) ) ) {
		$( document ).off( 'click', '.login-link' );
		$( document ).off( 'click', '.register-link' );
	}

	// Clear localstorage on logout
	$( document ).on( 'click', '.log-out', function() {
		localStorage.clear();
	});

});

function wpj_change_authentication_page_data() {
	if ( jQuery( 'body' ).hasClass( "rtl" ) ) jQuery( ".cell_number" ).parent().addClass( "iti-rtl" );

	// Login / Register Fields
	jQuery( "#registerform" ).addClass( 'ui form' );

	jQuery( '#divider_login_outer' ).appendTo( '#login form' );

	jQuery( "#login form p label" ).contents().filter( function() {
		if ( this.type == 'checkbox' ) {
			jQuery( this ).parent().addClass( 'ui checkbox' );
		}
		return ( this.nodeType === 3 );
	}).wrap( '<span class="box"></span>' );

	// Login / Register - Titles
	jQuery( "#loginform" ).prepend( "<h2 style='text-align:center;'>" + wpj_vars.login + "</h2>" );
	jQuery( "#registerform" ).prepend( "<h2 style='text-align:center;'>" + wpj_vars.register + "</h2>" );

	jQuery( "#lostpasswordform" ).prepend( "<h2 style='text-align:center;'>" + wpj_vars.forgot + "</h2>" );
	jQuery( "#resetpassform" ).prepend( "<h2 style='text-align:center;'>" + wpj_vars.reset + "</h2>" );

	// Login / Register - PlaceHolders
	jQuery( "#user_login" ).attr( "placeholder", wpj_vars.user_name );
	jQuery( "#loginform #user_login" ).attr( "placeholder", wpj_vars.user_email );
	jQuery( "#lostpasswordform #user_login" ).attr( "placeholder", wpj_vars.user_email );
	jQuery( "#lostpasswordform #wp-submit" ).attr( "value", wpj_vars.reset );
	jQuery( "#loginform #wp-submit" ).attr( "value", wpj_vars.login );

	jQuery( "#user_email" ).attr( "placeholder", wpj_vars.email );
	jQuery( "#user_pass" ).attr( "placeholder", wpj_vars.password );
	jQuery( "#cell_number" ).attr( "placeholder", wpj_vars.phone_number );
	jQuery( "#user_company" ).attr( "placeholder", wpj_vars.company );
	jQuery( "#user_password" ).attr( "placeholder", wpj_vars.password );
	jQuery( "#user_confirm_password" ).attr( "placeholder", wpj_vars.confirm_password );
}