jQuery( document ).ready( function( $ ) {

	/* FILTER BUTTONS */
	$( document ).on( 'click', '.kt-tab-title-active, .kt-tab-title-inactive', function() {
		if ( ! $( this ).parents( '.wp-block-kadence-tabs' ).hasClass( 'without-responsive-dropdown' ) ) {
			var active_tab = window.location.pathname.split( '/' ).filter( Boolean ).pop(); // get active tab
			if ( active_tab != $( this ).attr( 'id' ) ) {
				history.pushState( null, null, wpj_vars.parent_url + '/' + $( this ).attr( 'id' ) ); // for pc
				$( this ).parents( ".kt-tabs-wrap" ).find( '.ui.dropdown' ).dropdown( 'set selected', $( '.kt-tab-title-active' ).attr( 'id' ) ); // for mobile
			}
		}
	});

	/* BROWSER NAVIGATION */
	$( window ).on( 'popstate', function( e ) {
		var active_tab = window.location.pathname.match( /([^\/]*)\/*$/ )[1]; // get active tab
		$( '.kt-tabs-wrap' ).find( '.ui.dropdown' ).dropdown( 'set selected', active_tab ); // for mobile
	});

	/* SHOW/HIDE FIELDS ON LET'S MEET */
	$( document ).on( 'change', '.js-lets-meet-trigger', function( e ) {
		if ( $( '.wp-block-kadence-rowlayout' )[0] ) {

			if ( this.checked ) {
				$( '.js-lets-meet-item' ).each( function() {
					$( this ).parents( '.kt-inside-inner-col:first' ).show();
					$( this ).parents( '.wp-block-kadence-rowlayout' ).eq( 1 ).show();
				});

			} else {
				$( '.js-lets-meet-item' ).each( function() {
					$( this ).parents( '.kt-inside-inner-col:first' ).hide();

					if ( $( this ).parents( '.wp-block-kadence-rowlayout:first' ).find( '.wp-block-kadence-column' ).find( '.kt-inside-inner-col:visible' ).length == 0 ) {
						$( this ).parents( '.wp-block-kadence-rowlayout' ).eq( 1 ).hide();
					}
				});

			}

		}
	});

	/* JOB BULK ACTION BUTTON */
	$( document ).on( 'click', '.js-job-bulk-action-btn', function( e ) {
		e.preventDefault();
		$( '.js-job-bulk-action-button' ).trigger( 'click' );
	});

});

/* TABS TO DROPDOWN RESPONSIVE */
( function ( $ ) {
	$.fn.wpjPBTabsToDropdownInit = function() {
		if ( $( '.wp-block-kadence-tabs' )[0] ) {
			$( '.wp-block-kadence-tabs' ).not( '.without-responsive-dropdown' ).each( function() {
				var $cnt         = $( this ).find( '.kt-tabs-wrap' );
				var selected_val = false;

				$( '<select />' ).insertAfter( $cnt.find( '.kt-tabs-title-list' ).first() );

				$cnt.find( '.kt-tabs-title-list' ).first().find( '.kt-title-item' ).each( function() {
					var $el = $( this );

					if ( $el.hasClass( 'kt-tab-title-active' ) )
						selected_val = $el.attr( 'id' );

					$( '<option />', {
						'value'   : $el.attr( 'id' ),
						'text'    : $el.text(),
					}).appendTo( $cnt.find( 'select' ).first() );
				});

				// set mobile active tab
				if ( selected_val ) $cnt.find( 'select' ).val( selected_val );

				$cnt.find( 'select' ).change( function() {
					// set pc active tab
					if ( $cnt.find( '.kt-tabs-title-list' ).first().find( 'li[id="' + $( this ).val() + '"]' ).find( 'a' )[0] )
						$cnt.find( '.kt-tabs-title-list' ).first().find( 'li[id="' + $( this ).val() + '"]' ).find( 'a' ).trigger( 'click' );
				});

				$cnt.find( 'select' ).addClass( 'fluid' );
				$cnt.find( 'select' ).dropdown( { message: { noResults: wpj_vars.nothing_found } } );
			});
		}
	}
} ( jQuery ) );

/* ADD FORM ELEMENT TO PAGE */
function wpj_add_form_element() {
	// user settings
	if ( jQuery( '.page-id-' + wpj_vars.user_settings_page_id )[0] && jQuery( '.kt-tab-inner-content' )[0] ) {
		jQuery( '.kt-tab-inner-content' ).each( function() {
			jQuery( this ).find( '.kt-tab-inner-content-inner:first > *' ).wrapAll( '<form class="ui form" method="post" enctype="multipart/form-data"></form>' );
		});
	}

	// post new request
	if ( jQuery( '.page-id-' + wpj_vars.new_request_page_id )[0] && jQuery( '.kt-inside-inner-col' )[0] ) {
		jQuery( '.post-new-wrapper' ).wrapAll( '<form id="add-edit-request-form" class="ui form" method="post" enctype="multipart/form-data"></form>' );
		jQuery( '.post-new-wrapper' ).find( '.wp-block-kadence-column.ui.form' ).removeClass( 'ui form' );

		// init popup and calendar fields
		jQuery.fn.wpjTooltipInit();
		jQuery.fn.wpjCalendarInit();
	}

	// post new job
	if ( jQuery( '.page-id-' + wpj_vars.new_job_page_id )[0] && jQuery( '.wp-block-kadence-tabs' )[0] ) {
		jQuery( '.post-new-wrapper' ).wrapAll( '<form id="add-edit-job-form" class="ui form" method="post" enctype="multipart/form-data"></form>' );
		jQuery( '.post-new-wrapper' ).find( '.wp-block-kadence-column.ui.form' ).removeClass( 'ui form' );

		// init popup fields
		jQuery.fn.wpjTooltipInit();
	}

	Hooks.do_action( 'wpj_after_form_added_to_page_builder' );
}

/* REINIT PB TABS TO FIX THE URL HASH */
function wpj_reinit_kadence_tabs() {
	var tabs_script = jQuery( '.wp-footer-scripts script[src*="kadence-blocks/dist/kt-tabs-min.js"]' )[0].outerHTML;
	jQuery( '.wp-footer-scripts script[src*="kadence-blocks/dist/kt-tabs-min.js"]' ).remove();
	jQuery( tabs_script ).appendTo( '.wp-footer-scripts' );
}

/* CHANGE TAB */
function wpj_change_kadence_active_tab( active_tab ) {
	if ( jQuery( '.kt-tabs-title-list' )[0] ) {
		if ( typeof active_tab === 'undefined' )
			var active_tab = window.location.pathname.split( '/' ).filter( Boolean ).pop(); // get active tab

		if ( jQuery( '.kt-tabs-title-list' ).find( 'li[id="' + active_tab + '"]' ).find( 'a' )[0] ) {
			jQuery( '.kt-tabs-title-list' ).find( 'li[id="' + active_tab + '"]' ).find( 'a' ).trigger( 'click' ); // for pc
			jQuery( '.kt-tabs-title-list' ).siblings( '.ui.dropdown' ).dropdown( 'set selected', active_tab ); // for mobile
		}
	}
}

/* REFRESH TAB CONTENT */
function wpj_refresh_kadence_tab_content() {
	// tab button
	if ( jQuery( '.kt-tabs-title-list' )[0] ) {
		jQuery( '.kt-tabs-title-list li' ).each( function() {
			refreshContent( '.' + jQuery.trim( jQuery( this ).find( 'a' ).attr( 'class' ) ).split( /\s+/ ).join( '.' ) );
		});
	}

	// tab content
	if ( jQuery( '.kt-tabs-content-wrap' )[0] ) refreshContent( '.kt-tabs-content-wrap' );
}

/* HIDE POST NEW DISABLED FIELDS */
function wpj_hide_disabled_page_builder_post_new_fields() {
	if ( jQuery( '.post-new-optional-fields-row-wrapper' )[0] )
		jQuery( '.post-new-optional-fields-row-wrapper' ).show();

	if (
		jQuery( '.subcategory-field-wrapper' )[0]
		&& ( jQuery.trim( jQuery( '.subcategory-field-wrapper' ).find( '#request_subcategories' ).text() ) != ''
			|| jQuery.trim( jQuery( '.subcategory-field-wrapper' ).find( '#job_subcategories' ).text() ) != '' )
	) {
		jQuery( '.subcategory-field-wrapper' ).find( '.kt-inside-inner-col' ).show();
	}

	if ( jQuery( '.js-disabled-field' )[0] ) {
		jQuery( '.js-disabled-field' ).each( function() {
			jQuery( this ).parents( '.kt-inside-inner-col' ).eq( 0 ).hide();

			if ( jQuery( this ).parents( '.wp-block-kadence-column:first' ).siblings( '.wp-block-kadence-column' ).find( '.kt-inside-inner-col' ).text().length <= 0 )
				jQuery( this ).parents( '.wp-block-kadence-rowlayout' ).eq( 1 ).hide(); // half solo

			if ( jQuery( this ).parents( '.wp-block-kadence-column:first' ).siblings( '.wp-block-kadence-column' ).find( '.js-disabled-field' ).length > 0 )
				jQuery( this ).parents( '.wp-block-kadence-rowlayout' ).eq( 1 ).hide(); // empty row

			if ( jQuery( this ).parents( '.wp-block-kadence-column:first' ).siblings( '.wp-block-kadence-column' ).find( '.kt-inside-inner-col' ).find( '.js-tooltip-handler' ).length <= 0 )
				jQuery( this ).parents( '.wp-block-kadence-rowlayout' ).eq( 0 ).hide();

			if (
				jQuery( this ).parents( '.wp-block-kadence-rowlayout:first' ).siblings( '.wp-block-kadence-rowlayout:visible' ).length == 0
				&& jQuery( this ).parents( '.wp-block-kadence-rowlayout:first' ).siblings( '.wp-block-kadence-spacer' )[0]
			)
				jQuery( this ).parents( '.wp-block-kadence-rowlayout' ).eq( 1 ).hide(); // extra

		});
	}

}

/* ADD USER COVER CLASS */
function wpj_add_user_cover_class() {
	if ( jQuery( '.user-profile-cover-row-wrapper' )[0] ) {
		if ( jQuery( '.ub-cover-photo' )[0] )
			jQuery( '.user-profile-cover-row-wrapper' ).addClass( 'user-has-cover js-user-has-cover' );
		else
			jQuery( '.user-profile-cover-row-wrapper' ).removeClass( 'user-has-cover js-user-has-cover' );
	}
}

/* SHOW SELLERS PROJECTS CAROUSEL */
function wpj_show_sellers_projects_carousel() {
	if ( jQuery( '.seller-projects-carousel-wrapper' )[0] ) {
		setTimeout( function() {
			if ( jQuery( '.seller-projects-carousel-wrapper' ).find( '.slick-track' ).find( '.slick-slide:first' ).hasClass( 'kt-post-slider-item' ) ) {
				jQuery( '.seller-projects-carousel-wrapper' ).show();
				jQuery( '.jobs-images-carousel' ).hide();
			}
		}, 100 );
	}
}