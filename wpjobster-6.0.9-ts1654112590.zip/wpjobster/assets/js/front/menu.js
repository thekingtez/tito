jQuery( document ).ready( function( $ ) {
	// slider main menu
	$( document ).on( 'click', '.menu-direction-right', function( e ) {
		e.preventDefault();
		$( '.middle-menu-slider' ).find( '.categories-menu-list' ).animate( {scrollLeft: '+=200'}, 500 );
	});

	$( document ).on( 'click', '.menu-direction-left', function( e ) {
		e.preventDefault();
		$( '.middle-menu-slider' ).find( '.categories-menu-list' ).animate( {scrollLeft: '-=200'}, 500 );
	});

	// show user dropdown menu
	$( document ).on( 'click', '.nh-accordion-handler', function( e ) {
		e.preventDefault();

		$( ".nh-accordion" ).slideUp( 150 );
		$( ".nh-accordion-handler" ).removeClass( "nh-accordion-selected" );

		if ( $( this ).parent().children( " .nh-accordion" ).css( "display" ) == "block" ) {
			$( this ).parent().children( ".nh-accordion" ).slideUp( 150 );
			$( this ).removeClass( "nh-accordion-selected" );

			e.stopPropagation();
		} else {
			$( this ).parent().children( ".nh-accordion" ).slideDown( 150 );
			$( this ).addClass( "nh-accordion-selected" );

			e.stopPropagation();
		}
	});

	// responsive menus
	$( document ).on( 'click', '.js-mobile-menu-toggle', function( e ) {
		if ( $( this ).attr( 'class' ).indexOf( 'menu-left' ) != -1 ) {
			if ( ! $( '.left.menu' ).hasClass( 'visible' ) ) {
				$( '.ui.sidebar.left' ).sidebar({
					onChange: function() { $( 'html[dir=rtl]' ).css( 'overflow-x', 'hidden' ); },
					onHidden: function() { $( 'html[dir=rtl]' ).css( 'overflow-x', '' ); },
				})
				.sidebar( 'toggle' );

			}
		}

		if ( $( this ).attr( 'class' ).indexOf( 'menu-right' ) != -1 ) {
			if ( ! $( '.right.menu' ).hasClass( 'visible' ) ) {
				$( '.ui.sidebar.right' ).sidebar({
					onChange: function() { $( 'html[dir=rtl]' ).css( 'overflow-x', 'hidden' ); },
					onHidden: function() { $( 'html[dir=rtl]' ).css( 'overflow-x', '' ); },
				})
				.sidebar( 'toggle' );
			}
		}
	});

	// dropdown menu
	const $menu = $( '.js-dropdown-menu' );

	$( '.js-dropdown-menu-trigger' ).click( function() {
		$( this ).parent().toggleClass( 'dropdown-menu-open' );
	});

	$( document ).click( function( e ) {
		var target = e.target;
		$menu.each( function() {
			if ( $( this ).has( target ).length === 0 ) {
				$( this ).removeClass( 'dropdown-menu-open' );
			}
		});
	});
});

// fixed menu
function wpj_add_fixed_menu_on_scroll() {
	// fixed header menu
	if ( wpj_vars.header_style == 'fixed' ) {
		if ( jQuery( window ).scrollTop() > 0 ) {
			jQuery( ".header-wrapper" ).addClass( "fixed" );
			jQuery( 'html' ).addClass( "fixed-header" );
		} else {
			jQuery( ".header-wrapper" ).removeClass( "fixed" );
			jQuery( 'html' ).removeClass( "fixed-header" );
		}
	}

	// fixed header top menu
	if ( wpj_vars.header_style == 'fixed_top' ) {
		if ( jQuery( window ).scrollTop() > 0 ) {
			jQuery( ".header-wrapper-top" ).addClass( "fixed" );
			jQuery( 'html' ).addClass( "fixed-top-header" );
		} else {
			jQuery( ".header-wrapper-top" ).removeClass( "fixed" );
			jQuery( 'html' ).removeClass( "fixed-top-header" );
		}
	}

	// fixed header bottom menu
	if ( wpj_vars.header_style == 'fixed_bottom' ) {
		if ( jQuery( window ).scrollTop() > 0 ) {
			jQuery( ".header-wrapper-menu" ).addClass( "fixed" );
			jQuery( 'html' ).addClass( "fixed-bottom-header" );
		} else {
			jQuery( ".header-wrapper-menu" ).removeClass( "fixed" );
			jQuery( 'html' ).removeClass( "fixed-bottom-header" );
		}
	}
}

// submenu left for first element of a new row
function wpj_change_first_menu_item_alignment() {
	var last_element = false;
	jQuery( 'ul.categories-menu-list' ).children( 'li' ).each( function() {
		if ( last_element && last_element.offset().top != jQuery( this ).offset().top ) {
			if ( jQuery( this ).find( 'ul' ).hasClass( 'right0' ) ) {
				jQuery( this ).find( 'ul' ).removeClass( 'right0' ).removeClass( 'mr10' ).addClass( 'left0' );
			}
		}
		last_element = jQuery( this );
	});
}

// main menu
function wpj_change_long_main_menu_alignment() {
	if ( wpj_vars.long_menu_arrows == '1' ) {
		if ( jQuery( 'ul.categories-menu-list' ).prop( 'scrollWidth' ) > jQuery( 'ul.categories-menu-list' ).prop( 'clientWidth' ) ) {
			jQuery( '.main-menu-wrapper' ).find( '.arrows-wrapper' ).addClass( 'visible' );
			jQuery( 'ul.categories-menu-list' ).css( 'overflow', 'hidden' );
			jQuery( '.middle-menu-slider' ).find( 'ul' ).css( 'white-space', 'nowrap' );

		} else {
			jQuery( '.main-menu-wrapper' ).find( '.arrows-wrapper' ).removeClass( 'visible' );
			jQuery( '.middle-menu-slider' ).find( 'ul' ).css( 'overflow', 'visible' );
			jQuery( '.middle-menu-slider' ).find( 'ul' ).css( 'white-space', 'initial' );

		}
	}
}
