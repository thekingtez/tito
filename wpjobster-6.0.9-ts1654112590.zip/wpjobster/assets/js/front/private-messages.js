jQuery( document ).ready( function( $ ) {

	// init load more messages
	wpj_init_load_more_messages();

	// show image upload form
	$( document ).on( 'click', '.js-pm-img-attach-btn', function( e ) {
		$( '.messages-image-uploader-wrapper' ).show();
		$( this ).parents( '.thread-input-padding' ).find( '.dz-default.dz-message' ).trigger( 'click' );
	});

	// show search user form
	$( document ).on( 'click', '.js-search-users-btn', function( e ) {
		if ( $( '.thread-list-user-search' ).is( ':hidden' ) ) {
			$( this ).find( 'i' ).removeClass( 'search' ).addClass( 'times' );
			$( '.thread-list-user-search' ).slideDown( 'fast' );

			// for page builder
			$( '.js-search-users-btn-open' ).hide();
			$( '.js-search-users-btn-close' ).css({ display: "flex" });

		} else {
			$( this ).find( 'i' ).removeClass( 'times' ).addClass( 'search' );
			$( '.thread-list-user-search' ).slideUp( 'fast' );

			// for page builder
			$( '.js-search-users-btn-open' ).css({ display: "flex" });
			$( '.js-search-users-btn-close' ).hide();

		}
	});

	// conversation actions
	$( document ).on( 'click', '.js-pm-action-archive, .js-pm-action-unarchive, .js-pm-action-delete, .js-pm-delete', function ( e ) {
		e.preventDefault();

		var action = '';
		if ( $( this ).attr( 'class' ).includes( 'js-pm-action-archive' ) )
			action = 'archive_conversation_action';
		else if ( $( this ).attr( 'class' ).includes( 'js-pm-action-unarchive' ) )
			action = 'unarchive_conversation_action';
		else if ( $( this ).attr( 'class' ).includes( 'js-pm-action-delete' ) )
			action = 'delete_conversation_action';
		else if ( $( this ).attr( 'class' ).includes( 'js-pm-delete' ) )
			action = 'delete_message_action';

		$.ajax({
			type: 'post',
			url : wpj_vars.ajaxurl,
			data: {
				action      : action,
				interlocutor: $( this ).attr( 'data-uid' ),
				message_id  : $( this ).attr( 'data-pm-id' )
			},
			success: function( data ) {
				if ( action == 'delete_message_action' ) {
					// refresh message body div
					refreshContent( '.pm-list' );

					// refresh conversations body div
					refreshContent( '.thread-list-wrapper' );

				} else {
					// go to pm page
					changeURL( wpj_vars.pm_url );

				}
			}
		});
	});

	// send message
	$( document ).on( 'click', '.submit-private-message', function( e ) {
		e.preventDefault();

		var otheruid = $( '#pm_interlocutor_id' ).val();

		if ( wpj_vars.pm_emoji_enabled != 'no' )
			var message = validateInputContent( $( '.cmi-listen.message-field' ).data( 'emojioneArea' ).getText() );

		else
			var message = validateInputContent( $( '.cmi-listen.message-field' ).val() );

		var upload     = $( 'input[name="hidden_files_pm_attachments"]' ).val();
		var img_upload = '';
		if ( $( '.dz-success.dz-complete' )[0] ) {
			var img_upload_arr = [];
			$( '.dz-success.dz-complete' ).each( function () {
				img_upload_arr.push( $( this ).attr( 'data-id' ) );
			});
			img_upload = img_upload_arr.join( ',' );
		}

		var request_id = $( '#pm_request_id' ).val();
		var job_id     = $( '#pm_job_id' ).val();

		if ( wpj_vars.pm_emoji_enabled != 'no' )
			var message_length = get_input_length_emoji( $( '.cmi-listen.message-field' ).data( 'emojioneArea' ).getText() );

		else
			var message_length = get_input_length( $( '.cmi-listen.message-field' ) );

		if ( message == "" && ! upload && ! img_upload )
			wpj_focus_pm_input();

		else if ( message_length < parseInt( wpj_vars.characters_pm_min ) && ! upload && ! img_upload )
			$( '.wrapper-pm-to-user' ).notify( wpj_vars.pm_min_content, { position: 'top', className: 'error' } );

		else if ( message_length > parseInt( wpj_vars.characters_pm_max ) && ! upload && ! img_upload )
			$( '.wrapper-pm-to-user' ).notify( wpj_vars.pm_max_content, { position: 'top', className: 'error' } );

		else {
			jQuery.ajax({
				type: 'post',
				url : wpj_vars.ajaxurl,
				data: {
					action    : 'send_message_action',
					otheruid  : otheruid,
					message   : message,
					upload    : upload,
					img_upload: img_upload,
					request_id: request_id,
					job_id    : job_id,
				},
				beforeSend: function() {
					// add loader
					addLoader( '.thread-input' );
				},
				success: function( data ) {
					// refresh message body div
					refreshContent( '.pm-list' );

					// refresh conversations body div
					refreshContent( '.thread-list-wrapper' );

					// remove no message string
					$( '.error-no-messages' ).remove();

					// clear the input
					$( '#message-pm-user' ).val( '' );
					$( '#message-pm-user' ).css( 'height', 'auto' );

					if ( wpj_vars.pm_emoji_enabled != 'no' ) $( '.emojionearea-editor' ).text( '' );

					// clear the attachments queue
					$( '#uploadifive-file_upload_pm_attachments-queue' ).empty();
					$( 'input[name="hidden_files_pm_attachments"]' ).val( '' );

					// close image attachments queue
					$( '.messages-image-uploader-wrapper' ).hide();

					// clear the image attachments queue
					$( '.dz-image-wrapper' ).remove();
				},
				error: function( response ) {
					console.log( response );
				},
				complete: function() {
					// remove loader
					setTimeout( function () { $( '.ui.active.inverted.dimmer' ).remove(); }, 2000 );

					// focus the input
					wpj_focus_pm_input();
				}
			});

		}

	});

	// send message with enter
	$( document ).on( 'keypress', '.cmi-listen.message-field', function( e ) {
		if ( $( '#pm-enter-key' ).is( ':checked' ) && e.keyCode == 13 && ! e.shiftKey ) {
			e.preventDefault();
			if ( $( this ).parents( '.wrapper-pm-to-user' )[0] ) $( '.submit-private-message' ).trigger( 'click' );
			if ( $( this ).parents( '#order-message-form' )[0] ) $( '.send-message' ).trigger( 'click' );
		}
	});

	// auto-resize textarea based on input
	if ( jQuery( '.is-page-pm-single' )[0] ) {

		// TODO: doesn't work on window resize
		$( '.cmi-listen.message-field' ).each( function () {
			// note: this breaks the emojionearea input on Firefox

		}).on( 'input propertychange change blur', function () {
			this.style.height = 'auto';
			this.style.height = ( this.scrollHeight ) + 'px';

			// move icons position on scroll
			if ( wpj_vars.pm_emoji_enabled != 'yes' ) {
				if ( this.scrollHeight >= 207 ) {
					$( '.thread-input' ).find( '.input-pm-quick-response' ).animate({ 'right' : '47px' }, 100 );
					$( '.thread-input' ).find( '.input-pm-settings' ).animate({ 'right' : '20px' }, 100 );
					this.style.paddingRight = '60px';

				} else {
					$( '.thread-input' ).find( '.input-pm-quick-response' ).animate({ 'right' : '37px' }, 100 );
					$( '.thread-input' ).find( '.input-pm-settings' ).animate({ 'right' : '10px' }, 100 );
					this.style.paddingRight = '70px';

				}
			}
		});

		MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
		var observer = new MutationObserver( function( mutations, observer ) {
			// fired when a mutation occurs
			// note: this triggers 70 times on first input focus for some reason

			// auto-resize content container based on input
			jQuery( '.thread-wrapper' ).css( 'margin-bottom', jQuery( '.thread-input' ).height() );
		});

		// define what element should be observed by the observer
		// and what types of mutations trigger the callback
		observer.observe(document, {
			subtree: true,
			attributes: true,
			childList: true
			//...
		});
	}

	// fire lazy load on messages scroll
	if ( $( '.is-page-pm' )[0] ) {
		$( '.js-messages-list' ).on( 'scroll', _.debounce( function(){
			if ( typeof $.fn.wpjLazyLoadRender == 'function' ) {
				$.fn.wpjLazyLoadRender();
			}
		}, 200 ) );

		$( '.thread-list-viewport' ).on( 'scroll', _.debounce( function(){
			if ( typeof $.fn.wpjLazyLoadRender == 'function' ) {
				$.fn.wpjLazyLoadRender();
			}
		}, 200 ) );
	}

});

function wpj_focus_pm_input() {
	if ( jQuery( '.is-page-pm-single' )[0] ) {
		if ( wpj_vars.pm_emoji_enabled != 'no' ) {
			setTimeout(function(){
				jQuery( '.emojionearea-editor' ).focus();
			}, 300 ) // wait for emojionearea to be ready, there is no ready e
		} else {
			jQuery( '#message-pm-user' ).focus();
		}
	}
}

function wpj_send_message_with_enter() {
	if ( jQuery( '.ui.checkbox.send-message-enter-key' )[0] ) {

		jQuery( '.ui.checkbox.send-message-enter-key' ).checkbox({
			onChange: function() {
				jQuery.ajax({
					type: 'post',
					url : wpj_vars.ajaxurl,
					data: {
						action: 'save_pm_enter_key_action',
						value : jQuery( '#pm-enter-key' ).is( ':checked' ) ? true : false,
					},
					success: function( data ) {}
				});
			}
		});

	}
}

function wpj_hide_admin_bar_on_pm_page() {
	if ( jQuery( '.is-page-pm' )[0] ) jQuery( 'html' ).attr( 'style', 'margin-top: 0 !important' );
	else jQuery( 'html' ).removeAttr( 'style' );
}

function wpj_search_conversation_user( element ) {
	// user to search
	var value = validateInputContent( jQuery( element ).val().toLowerCase() );

	// if the wanted user existed, display it
	jQuery( '#user_messages > .js-tpm-holder' ).each( function() {
		if ( jQuery( this ).find( '.pm-user' ).text().toLowerCase().search( value ) > -1 ) jQuery( this ).show();
		else jQuery( this ).hide();
	});

	// render the images
	if ( typeof jQuery.fn.wpjLazyLoadRender == 'function' ) jQuery.fn.wpjLazyLoadRender();

	// show/hide "No user found" message
	if ( jQuery( '#user_messages > .js-tpm-holder' ).children( ':visible' ).length == 0 ) jQuery( '#no_messages' ).show();
	else jQuery( '#no_messages' ).hide();
}

function wpj_filter_message( msg ) {
	ret = '';

	jQuery.ajax({
		url  : wpj_vars.ajaxurl,
		type : 'post',
		async: false,
		data : {
			action : 'filter_message_action',
			message: msg
		},
		success: function( result ) {
			ret = result;
		}
	});

	// return filtered message
	return ret;
}