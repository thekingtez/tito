jQuery( document ).ready( function( $ ) {

	// change currency and keep the POST
	$( document ).on( 'change', '#purchase_job_currency', function( e ) {
		$( 'form[name="myFormPurchase"]' ).attr( 'action', wpj_vars.page_url + '?site_currency=' + $( 'select[id="purchase_job_currency"]' ).val() );
		$( 'form[name="myFormPurchase"]' ).submit();
	});

	// change currency on mobile
	$( document ).on( 'click', '.js-dropdown-menu.currency .item, .currency-list-mobile li', function( e ) {
		window.location = wpj_vars.page_url + '?site_currency=' + $( this ).data( "currencyval" );
	});

});