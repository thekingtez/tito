//----------------------------------------
// Draw dynamic content after the pageload
//----------------------------------------
function wpj_display_header_user_info() {
	if ( wpj_vars.is_user_logged_in == true ) {
		jQuery.ajax({
			url: wpj_vars.ajaxurl,
			data : {
				action: 'load_user_info_account_menu_action'
			},
			success: function( data ) {
				jQuery( '.js-user-info-menu' ).each( function() {
					jQuery( this ).replaceWith( data );
				});
			}
		});
	}
}

function wpj_display_chat_sidebar() {
	if ( wpj_vars.chat_enabled == 'yes' && wpj_vars.is_user_logged_in == true ) {
		jQuery.ajax({
			url: wpj_vars.ajaxurl,
			data : {
				action: 'load_chat_system_action'
			},
			success: function( data ) {
				jQuery( '.js-chat-sidebar' ).each( function() {
					jQuery( this ).replaceWith( data );

					wpj_chat_set_sidebar_height();
					wpj_chat_open_boxes_on_load();
					wpj_chat_hide_sidebar_elements_minimalist();
					wpj_init_chat_tooltips();
				});
			}
		});
	}
}
