jQuery( document ).ready( function( $ ) {

	// Work Samples Select
	$( document ).on( 'click', '.js-select-work-sample', function() {

		var $allSamples = $( this ).closest( '.js-review-form' ).find( '.js-select-work-sample' );
		var $submitButton = $( this ).closest( '.js-review-form' ).find( '.submit-user-rating' );

		if ( $( this ).hasClass( 'selected' ) ) {

			$allSamples.removeClass( 'selected' );
			$submitButton.attr( 'data-sample', '' );

		} else {

			$allSamples.removeClass( 'selected' );
			$( this ).addClass( 'selected' );
			$submitButton.attr( 'data-sample', $( this ).attr( 'data-id' ) );
		}
	});

});

// Work Samples Init
function wpj_init_work_sample() {
	jQuery( '.js-review-form' ).each(function() {

		var $firstSample = jQuery( this ).find( '.js-select-work-sample' ).first();
		var $submitButton = jQuery( this ).find( '.submit-user-rating' );

		$firstSample.addClass( 'selected' );
		$submitButton.attr( 'data-sample', $firstSample.attr( 'data-id' ) );
	});
}