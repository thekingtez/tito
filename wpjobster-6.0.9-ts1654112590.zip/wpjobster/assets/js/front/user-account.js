jQuery( document ).ready( function( $ ) {

	// open legend modal
	$( document ).on( 'click', '#status-messages-legend-link', function( e ) {
		$( '.ui.modal.legend.' + $( this ).attr( 'data-page' ) + '.' + $( this ).attr( 'data-tab' ) ).modal( 'setting', 'transition', 'fly down' ).modal( 'show' );
	});

	// change filter page url
	$( document ).on( 'change', '.filter-results-by', function() {
		var switch_filter = $( this ).dropdown( 'get value' );
		if ( switch_filter ) changeURL( wpj_vars.page_url + '?switch_filter=' + switch_filter );
	});

});

// hide post new row when field is disabled from admin
function wpj_hide_disabled_post_new_fields() {
	if ( jQuery( '.js-displayed-field' )[0] ) {
		jQuery( '.js-displayed-field' ).each( function() {
			jQuery( this ).parents( '.field' ).removeClass( 'hidden' );
			jQuery( this ).parents( '.fields' ).removeClass( 'hidden' );
		});
	}
}