// Chat / PM - Gallery
function wpj_init_attachments_gallery() {
	if ( jQuery( '.js-pm-image-attachments-gallery' )[0] ) {
		jQuery( '.js-pm-image-attachments-gallery' ).featherlightGallery({
			nextIcon      : '&#9656;',
			previousIcon  : '&#9666;',
			variant       : 'wpj-pm-image-attachments',
			openSpeed     : 100,
			closeSpeed    : 100,
			galleryFadeIn : 100,
			galleryFadeOut: 100
		});
	}
}


// Video Url Validation (YouTube Or Vimeo)
function wpj_validate_video_url(url) {
	var p  = /^(?:https?:\/\/)?(?:www\.)?youtube\.com\/watch\?(?=.*v=((\w|-){11}))(?:\S+)?$/;
	var p2 = /^(?:https?:\/\/)?(?:www\.)?youtu\.be\/(((\w|-){11}))(?:\S+)?$/;
	var p3 = /^(?:https?:\/\/)?(?:www\.)?vimeo\.com\//;

	return ( url.match(p) || url.match(p2) || url.match(p3) ) ? RegExp.$1 : false;
}
