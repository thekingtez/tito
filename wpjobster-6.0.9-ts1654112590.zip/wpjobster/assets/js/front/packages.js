jQuery( document ).ready( function( $ ) {

	// Delete a Row
	$( document ).on( 'click', '.pck-icon-rem', function( e ) {
		if ( $( '.pck-icon-rem' ).length > 1 ) {
			$( this ).parents( '.pck-repeater' ).remove();

		} else {
			$( '.pck-repeater .ui.checkbox' ).each( function(){
				$( this ).checkbox( 'uncheck' );
			});

			$( '.pck-inp-custom-name' ).val( '' );

		}
	});

	// Add a Row
	$( document ).on( 'click', '#add_custom_field_to_package', function( e ) {
		var clone = $( '.pck-repeater:first' ).clone();
		clone.find( 'input:text' ).val( '' );
		clone.find( 'input:checkbox' ).removeAttr( 'checked' );
		clone.find( '.pck-icon-rem' ).show();
		clone.appendTo( '.packages tbody' );

		$( '.ui.checkbox' ).checkbox();
	});

	// Select package
	$( document ).on( 'click', '.pck-sidebar-select-package, .pck-mobile-select-package', function( e ) {
		var $this = $( this );
		var regex = /[+-]?\d+(\.\d+)?/g;
		var indx  = parseFloat( $( this ).attr( 'class' ).match( regex ) );

		$( '.pck-order' ).eq( indx ).trigger( 'click' );

		if ( $this.attr( 'class' ).match( 'pck-mobile-select-package' ) ) {
			wpj_change_package_selection( $( '.pck-sidebar-select-package.' + indx ), '.packages-sidebar', '.pck-sidebar-select-package', 'sidebar' );
			wpj_change_package_selection( $this, '.packages-mobile', '.pck-mobile-select-package', 'mobile' );

		} else {
			wpj_change_package_selection( $this, '.packages-sidebar', '.pck-sidebar-select-package', 'sidebar' );
			wpj_change_package_selection( $( '.pck-mobile-select-package.' + indx ), '.packages-mobile', '.pck-mobile-select-package', 'mobile' );

		}
	});

	// Send package values
	$( document ).on( 'click', '.pck-order', function( e ) {
		var $this         = $( this );
		var current_nth   = $this.index();
		var nth           = current_nth + 1;
		var pck_to_select = current_nth - 1;

		wpj_change_package_selection( $( '.' + pck_to_select ), '.packages-sidebar', '.pck-sidebar-select-package', 'sidebar' );

		// Check the column
		$this.children( 'div' ).children( 'input' ).prop( 'checked', true );

		// Change column color
		wpj_change_package_color( $this );

		// Update package id
		$( '.package_no' ).val( pck_to_select );

		// Update package type
		var package_type_unformatted = $this.parents( 'tbody' ).siblings( 'thead' ).find( 'th:nth-child( ' + ( nth ) + ' )' ).html();
		$( '.sidebar-top-info .type' ).html( package_type_unformatted );

		// Update delivery time
		var deliv_time_formatted = $this.parent().prev( 'tr' ).prev( 'tr' ).prev( 'tr' ).children( 'td:nth-child( ' + nth + ' )' ).html();
		$( '.sidebar-delivery-days span' ).html( deliv_time_formatted );

		var deliv_time_unformatted = parseFloat( deliv_time_formatted.match( /[+-]?\d+(\.\d+)?/g ) );
		$( '.package_delivery_days' ).val( deliv_time_unformatted );

		// Update the price
		var price_formatted = $this.parent().prev( 'tr' ).children( 'td:nth-child( ' + nth + ' )' ).html();
		$( '.js-job-quantity-wrapper .extra-price-inside' ).html( price_formatted );
		$( '.sidebar-top-info .price' ).html( price_formatted );

		var price_unformatted = $this.parent().prev( 'tr' ).children( 'td:nth-child( ' + nth + ' )' ).attr( 'data-price' );
		$( '.total' ).data( 'price', price_unformatted ).attr( 'data-price', price_unformatted );
		$( '.package_price' ).val( price_unformatted );

		// Update the total price
		wpj_update_purchase_price( 'job_purchase' );
	});

	// Add New Custom Field
	var indx   = 1;
	var indx_b = 1;
	var indx_s = 1;
	var indx_p = 1;
	$( document ).on( 'click', '#add_pck_custom_field', function( e ) {
		var new_field = $( '.pck-repeater:first' ).clone();

		if ( indx > ( JSON.parse( wpj_vars.pck_cf_name ).length - 1 ) ) indx = 1;
		if ( indx_b > ( JSON.parse( wpj_vars.pck_cf_name ).length - 1 ) ) indx_b = 1;
		if ( indx_s > ( JSON.parse( wpj_vars.pck_cf_name ).length - 1 ) ) indx_s = 1;
		if ( indx_p > ( JSON.parse( wpj_vars.pck_cf_name ).length - 1 ) ) indx_p = 1;

		new_field.find( ':input' ).each( function() {

			if ( ! $( this ).is( ":checked" ) ) $( this ).val( 'off' );

			if ( e.originalEvent !== undefined ) { // IF button is clicked
				new_field.find( 'input:text' ).val( '' );
				new_field.find( 'input:checkbox' ).removeAttr( 'checked' );
				new_field.find( '.pck-icon-rem' ).show();

				var new_handler_id = $( this ).parent().data( 'handler-id' ) + Math.floor( Math.random() * 1000001 );
				$( this ).parent().attr( 'data-handler-id', new_handler_id );
				$( this ).parent().siblings( '.ui.popup' ).attr( 'data-tooltip-id', new_handler_id );

			} else { // IF button is triggered( for edit job )
				var obj_cf_name = JSON.parse( wpj_vars.pck_cf_name );
				if ( this.name == 'pck-inp-custom-name[]' ) {
					$( this ).val( obj_cf_name[indx] ); indx++;
				}

				var obj_cf_basic = JSON.parse( wpj_vars.pck_cf_basic );
				if ( this.name == 'pck-chk-value[basic][]' ) {
					if ( obj_cf_basic[indx_b] == 'on' ) {
						$( this ).parent().checkbox( 'check' );
						$( this ).val( 'on' );

					} else {
						$( this ).parent().checkbox( 'uncheck' );
						$( this ).val( 'off' );

					} indx_b++;
				}

				var obj_cf_standard = JSON.parse( wpj_vars.pck_cf_standard );
				if ( this.name == 'pck-chk-value[standard][]' ) {
					if ( obj_cf_standard[indx_s] == 'on' ) {
						$( this ).parent().checkbox( 'check' );
						$( this ).val( 'on' );

					} else {
						$( this ).parent().checkbox( 'uncheck' );
						$( this ).val( 'off' );

					} indx_s++;
				}

				var obj_cf_premium = JSON.parse( wpj_vars.pck_cf_premium );
				if ( this.name == 'pck-chk-value[premium][]' ) {
					if ( obj_cf_premium[indx_p] == 'on' ) {
						$( this ).parent().checkbox( 'check' );
						$( this ).val( 'on' );

					} else {
						$( this ).parent().checkbox( 'uncheck' );
						$( this ).val( 'off' );

					} indx_p++;
				}
			}

		});

		new_field.appendTo( '.packages tbody' );

		$( '.ui.checkbox' ).checkbox();

		jQuery.fn.wpjTooltipInit();
	});

	// PCK CF Checkbox Change
	$( document ).on( "change", "input.pck_cf_chk", function() {
		var value = $( this ).is( ":checked" ) ? 'on' : 'off';
		$( this ).siblings( "input[type='hidden']" ).val( value );
	});

	// PCK Max Days Change
	$( document ).on( 'change', 'select[name="package_max_days[]"]', function() {
		wpj_pck_disable_efd_delivery_days();
	});

});

function wpj_pck_disable_efd_delivery_days() {
	var price_type = jQuery( 'select[name="price_type"]' ).val();

	if ( price_type == 'package' ) {
		var total_days = 0;
		jQuery( 'select[name="package_max_days[]"]' ).each( function() {
			if ( jQuery( this ).val() > total_days ) total_days = parseInt( jQuery( this ).val() );
		});

		jQuery( '.max_days_fast.ui.dropdown .menu .item' ).each( function( ind, el ) {
			if ( parseInt( total_days ) && parseInt( jQuery( el ).data( 'value' ) ) >= parseInt( total_days ) )
				jQuery( el ).addClass( 'disabled' );

			else
				jQuery( el ).removeClass( 'disabled' );

		});
	}
}

function wpj_change_package_color( $this ) {
	jQuery( '.pc-packages .active' ).removeClass( 'active' );

	var col = $this.parents( 'tbody' ).siblings( 'thead' ).children( 'tr' ).children( 'th:nth(' + $this.index() + ')' ).index();

	jQuery( 'td' ).filter( ':nth-child(' + ( col + 1 ) + ')' ).addClass( 'active' );
}

function wpj_change_package_selection( $this, $packages_selector, $package_selector, $type ) {
	jQuery( $packages_selector ).each( function() {
		jQuery( this ).removeClass( 'selected' );
		jQuery( this ).find( $package_selector ).removeClass( 'right' ).removeClass( 'labeled' );
		jQuery( this ).find( $package_selector ).children( 'i.checkmark.icon' ).hide();

		if ( $type == 'sidebar' ) {
			jQuery( this ).find( '.title.active' ).removeClass( 'active' );
			jQuery( this ).find( '.content.active' ).removeClass( 'active' );

		} else if ( $type == 'mobile' ) {
			jQuery( this ).siblings( '.packages-tabs' ).children( '.item.active' ).removeClass( 'active' );
			jQuery( this ).removeClass( 'active' );

		}
	});

	$this.parents( $packages_selector ).addClass( 'selected' );
	$this.addClass( 'right' ).addClass( 'labeled' );
	$this.children( 'i.checkmark.icon' ).show();

	if ( $type == 'sidebar' ) {
		$this.parents( '.content' ).addClass( 'active' );
		$this.parents( '.content' ).siblings( '.title' ).addClass( 'active' );

	} else if ( $type == 'mobile' ) {
		$this.parents( '.packages-mobile' ).addClass( 'active' );
		curr_tab = $this.parents( '.packages-mobile' ).attr( 'data-tab' );
		$this.parents( '.packages-mobile' ).siblings( '.packages-tabs' ).find( "[data-tab='" + curr_tab + "']" ).addClass( 'active' );

	}
}

// Trigger standard package click
function wpj_select_package_on_page_load() {
	jQuery( '.pck-order' ).eq( Hooks.apply_filters( 'wpj_package_onload_filter', 1 ) ).trigger( 'click' );
}

// Set package price to total value
function wpj_set_package_to_total_order_price() {
	if ( jQuery( '.package_price' )[0] && jQuery( '.package_price' ).val() )
		jQuery( '.total' ).data( 'price', jQuery( '.package_price' ).val() ).attr( 'data-price', jQuery( '.package_price' ).val() );
}

// Trigger add new custom field
function wpj_load_package_custom_fields() {
	if ( jQuery( '.page-id-' + wpj_vars.new_job_page_id )[0] && wpj_vars.pck_cf_name ) {
		jQuery.each( JSON.parse( wpj_vars.pck_cf_name ), function( key, value ) {
			if ( key != 0 && value != '' )
				jQuery( '#add_pck_custom_field' ).trigger( 'click' );
		});
	}
}