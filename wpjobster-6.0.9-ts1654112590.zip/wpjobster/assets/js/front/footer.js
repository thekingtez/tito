jQuery( document ).ready( function( $ ) {
	// scroll to top
	$( document ).on( 'click', '.scrollToTop', function( e ) {
		$( 'html, body' ).animate({ scrollTop : 0 }, 800 ) ;
		return false;
	});

	// click on menu arrow
	$( document ).on( 'click', '.js-toggle-arrow', function() {
		if ( $( this ).find( '.dynamically-icon' ).is( ':visible' ) ) {
			var $cnt = $( this ).find( '.js-toggle-angle-icon' );

			if ( $cnt.hasClass( 'toggle-angle-icon-up' ) ) {
				$cnt.removeClass( 'toggle-angle-icon-up' ).addClass( 'toggle-angle-icon-down' );
				$cnt.parents( '.js-toggle-wrapper' ).siblings( 'div' ).slideUp( 'slow' );
				$cnt.parents( '.js-toggle-wrapper' ).addClass( 'collapsed' );

			} else {
				$cnt.removeClass( 'toggle-angle-icon-down' ).addClass( 'toggle-angle-icon-up' );
				$cnt.parents( '.js-toggle-wrapper' ).siblings( 'div' ).slideDown( 'slow' );
				$cnt.parents( '.js-toggle-wrapper' ).removeClass( 'collapsed' );

			}
		}
	});
});

function wpj_collapse_footer_menus() {
	jQuery( '.js-toggle-arrow' ).each( function() {
		var $cnt = jQuery( this ).find( '.js-toggle-angle-icon' );

		if ( isMobile() && $cnt.hasClass( 'toggle-angle-icon-up' ) ) {
			$cnt.removeClass( 'toggle-angle-icon-up' ).addClass( 'toggle-angle-icon-down' );
			$cnt.parents( '.js-toggle-wrapper' ).siblings( 'div' ).slideUp( 'slow' );
			$cnt.parents( '.js-toggle-wrapper' ).addClass( 'collapsed' );

		} else if ( ! isMobile() && $cnt.hasClass( 'toggle-angle-icon-down' ) ) {
			$cnt.removeClass( 'toggle-angle-icon-down' ).addClass( 'toggle-angle-icon-up' );
			$cnt.parents( '.js-toggle-wrapper' ).siblings( 'div' ).slideDown( 'slow' );
			$cnt.parents( '.js-toggle-wrapper' ).removeClass( 'collapsed' );

		}
	});
}

function wpj_toggle_scroll_to_top_button() {
	if ( jQuery( this ).scrollTop() > 100 ) jQuery( '.scrollToTop' ).fadeIn();
	else jQuery( '.scrollToTop' ).fadeOut();
}

function wpj_add_responsive_classes_to_footer_elements() {
	if ( jQuery( this ).width() <= 767 ) {
		// Footer bottom elements order
		if ( ! jQuery( '.footer-row-social-media' ).hasClass( 'doubling' ) )  jQuery( '.footer-row-social-media' ).addClass( 'doubling' );
		if ( ! jQuery( '.footer-row-social-media' ).hasClass( 'stackable' ) ) jQuery( '.footer-row-social-media' ).addClass( 'stackable' );

	} else {
		// Footer bottom elements order
		jQuery( '.footer-row-social-media' ).removeClass( 'doubling' ).removeClass( 'stackable' );

	}
}