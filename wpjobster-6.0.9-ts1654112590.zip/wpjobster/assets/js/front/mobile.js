jQuery( document ).ready( function( $ ) {

	// iOS devices
	var ver = getIOSversion();
	if ( ver[0] >= 11 ) $( "body" ).addClass( "ios11" );

	// mobile iframe
	if ( inIframe() ) {
		$( 'body' ).addClass( 'wpj-is-iframe' );
		$( 'body' ).removeClass( 'wpj-maybe-iframe' );
		$.cookie( 'wpj_is_iframe', 'true', { expires: 7, path: '/' });

	} else {
		$( 'body' ).removeClass( 'wpj-is-iframe' );
		$( 'body' ).removeClass( 'wpj-maybe-iframe' );
		$.cookie( 'wpj_is_iframe', 'false', { expires: 7, path: '/' });

	}

});