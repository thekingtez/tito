jQuery( document ).ready( function( $ ) {

	// Update user balance
	$( document ).on( 'click', '.js-update-user-credit', function( e ) {
		e.preventDefault();

		$( '.js-update-user-credit' ).val( 'Saving... Please wait...' );

		$.ajax({
			type: "POST",
			url: wpj_vars.ajaxurl,
			data: {
				action       : 'update_user_balance_action',
				user_id      : getUrlParameter( 'user_id' ),
				update_action: $( '.js-user-credit-action' ).val(),
				amount       : $( 'input[name="amount"]' ).val()
			},
			success: function( msg ) {
				// Refresh div content
				refreshContent( '.js-user-balance' );

				// Change button name
				$( '.js-update-user-credit' ).val( 'Update' );
			}
		});
	});

});