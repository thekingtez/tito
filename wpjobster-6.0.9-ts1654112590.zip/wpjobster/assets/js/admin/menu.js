jQuery( document ).ready( function( $ ) {

	// ORDER MENU FIRST TAB
	if ( getUrlParameter( 'active_tab' ) )
		var selected_tab = getUrlParameter( 'active_tab' );
	else
		var selected_tab = jQuery( '#usual2 .wpj-admin-header:first' ).next( 'div' ).attr( 'id' );

	if ( ! selected_tab ) selected_tab = 'tabs1';

	if ( selected_tab ) {
		jQuery( "#usual2 ul" ).idTabs( selected_tab );
		jQuery( ".tltp_cls" ).tipTip({ maxWidth: "330" });
	}

});