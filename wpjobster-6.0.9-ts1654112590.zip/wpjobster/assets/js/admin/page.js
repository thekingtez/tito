jQuery( document ).ready( function( $ ) {

	$( document ).on( 'click', '.js-reset-page', function() {
		$.ajax({
			type: "POST",
			url: wpj_vars.ajaxurl,
			data: {
				action: 'reset_page_action',
				post  : getUrlParameter( 'post' )
			},
			success: function( msg ) {
				location.reload();
			}
		});
	});

});