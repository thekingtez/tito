jQuery( document ).ready( function( $ ) {

	if ( $( '.update-google-fonts' )[0] )
		$( '.update-google-fonts' ).trigger( 'click' );

});