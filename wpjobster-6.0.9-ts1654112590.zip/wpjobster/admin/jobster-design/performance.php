<?php /* Performance */

Redux::setSection( $opt_name, array(
	'title'  => __( 'Performance', 'wpjobster' ),
	'id'     => 'performance-settings',
	'icon'   => 'el el-cog',
	'fields' => array(
		array(
			'id'       => 'enable_lazy_loading',
			'type'     => 'switch',
			'title'    => __( 'Enable lazy loading', 'wpjobster' ),
			'on'       => __( 'Enabled', 'wpjobster' ),
			'off'      => __( 'Disabled', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'enable_js_defer',
			'type'     => 'switch',
			'title'    => __( 'Defer parsing of JavaScript', 'wpjobster' ),
			'on'       => __( 'Enabled', 'wpjobster' ),
			'off'      => __( 'Disabled', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'enable_css_preload',
			'type'     => 'switch',
			'title'    => __( 'Preload CSS', 'wpjobster' ),
			'on'       => __( 'Enabled', 'wpjobster' ),
			'off'      => __( 'Disabled', 'wpjobster' ),
			'default'  => true,
		),
	)
) );