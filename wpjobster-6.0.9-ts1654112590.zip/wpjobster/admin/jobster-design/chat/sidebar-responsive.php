<?php /* Anchor Responsive */

Redux::setSection( $opt_name, array(
	'title'    => esc_html__( 'Anchor Responsive', 'wpjobster' ),
	'id'         => 'chat-sidebar-resposnive-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'          => 'chat_responsive_sidebar_head_bg_color',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '.chat-sidebar-container .chat-sidebar-anchor-text',
			),
			'title'       => esc_html__( 'Responsive head background colour', 'wpjobster' ),
			'default'     => '#ffffff',
			'color_alpha' => true,
		),
		array(
			'id'          => 'chat_responsive_sidebar_head_bg_hover_color',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '.chat-sidebar-container .chat-sidebar-anchor-text:hover',
			),
			'title'       => esc_html__( 'Responsive head background colour (hover)', 'wpjobster' ),
			'default'     => '#ffffff',
			'color_alpha' => true,
		),
		array(
			'id'          => 'chat_responsive_sidebar_head_text_color',
			'type'        => 'link_color',
			'title'       => __( 'Responsive head text colour', 'wpjobster' ),
			'active'      => false,
			'visited'     => false,
			'color_alpha' => true,
			'default'     => array(
				'regular' => '#333333',
				'hover'   => '#333333',
			),
			'output'      => array(
				'color'   => '.chat-sidebar-container .chat-sidebar-anchor-text'
			),
		),
	)
) );