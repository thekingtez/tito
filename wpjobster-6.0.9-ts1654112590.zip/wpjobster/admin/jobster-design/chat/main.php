<?php /* Chat */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Chat', 'wpjobster' ),
	'id'         => 'chat-settings',
	'icon'   => 'el el-comment-alt',
	'fields' => array(

	)
) );