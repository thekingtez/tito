<?php /* Box Body */

Redux::setSection( $opt_name, array(
	'title'    => esc_html__( 'MessageBox Body', 'wpjobster' ),
	'id'         => 'chat-message-box-body-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'          => 'chat_box_body_bg_color',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '.message-box-container .message-box-body',
			),
			'title'       => esc_html__( 'Background colour', 'wpjobster' ),
			'default'     => '#ffffff',
			'color_alpha' => true,
		),
		array(
			'id'          => 'chat_box_body_send_bg_color',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '
					.message-box-container .message-box-body .message-box-content .message-wrapper.sent .message-text-content,
					.message-box-container .message-box-body .message-box-content .message-wrapper.sent .message-text-content a
				',
				'color'        => '.message-box-container .message-box-body .message-box-content .message-wrapper.received .message-text-content .message-custom-offer i.icon',
				'border-color' => '.message-box-container .message-box-body .message-box-content .message-wrapper.received .message-text-content.custom-offer'
			),
			'title'       => esc_html__( 'Message sent background colour', 'wpjobster' ),
			'default'     => '#c4ffef',
			'color_alpha' => true,
		),
		array(
			'id'          => 'chat_box_body_send_text_color',
			'type'        => 'color',
			'output'      => array(
				'color'            => '
					.message-box-container .message-box-body .message-box-content .message-wrapper.sent .message-text-content *,
					.message-box-container .message-box-body .message-box-content .message-wrapper.sent .message-text-content a,
					.message-box-container .message-box-body .message-box-content .message-wrapper.sent .attachments-wrapper .attachment-item-filesize,
					.message-box-container .message-box-body .message-box-content .message-wrapper.sent .attachment-item-content a:before,
					.message-box-container .message-box-body .message-box-content .message-wrapper.sent .attachments-wrapper .attachment-item-wrapper a:before
				',
			),
			'title'       => esc_html__( 'Message sent text colour', 'wpjobster' ),
			'default'     => '#1a604d',
			'color_alpha' => true,
		),
		array(
			'id'          => 'chat_box_body_received_bg_color',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '
					.message-box-container .message-box-body .message-box-content .message-wrapper.received .message-text-content,
					.message-box-container .message-box-body .message-box-content .message-wrapper.received .message-text-content a
				',
				'color'        => '.message-box-container .message-box-body .message-box-content .message-wrapper.sent .message-text-content .message-custom-offer i.icon',
				'border-color' => '.message-box-container .message-box-body .message-box-content .message-wrapper.sent .message-text-content.custom-offer'
			),
			'title'       => esc_html__( 'Message received background colour', 'wpjobster' ),
			'default'     => '#eff5ff',
			'color_alpha' => true,
		),
		array(
			'id'          => 'chat_box_body_received_text_color',
			'type'        => 'color',
			'output'      => array(
				'color'   => '
					.message-box-container .message-box-body .message-box-content .message-wrapper.received .message-text-content *,
					.message-box-container .message-box-body .message-box-content .message-wrapper.received .message-text-content a,
					.message-box-container .message-box-body .message-box-content .message-wrapper.received .attachments-wrapper .attachment-item-filesize,
					.message-box-container .message-box-body .message-box-content .message-wrapper.received .attachment-item-content a:before,
					.message-box-container .message-box-body .message-box-content .message-wrapper.received .attachments-wrapper .attachment-item-wrapper a:before
				',
			),
			'title'       => esc_html__( 'Message received text colour', 'wpjobster' ),
			'default'     => '#454a60',
			'color_alpha' => true,
		),
	)
) );