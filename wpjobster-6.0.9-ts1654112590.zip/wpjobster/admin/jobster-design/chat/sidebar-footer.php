<?php /* Sidebar Search */

Redux::setSection( $opt_name, array(
	'title'    => esc_html__( 'Sidebar Search', 'wpjobster' ),
	'id'         => 'chat-sidebar-footer-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'chat_header_search_icon_name',
			'type'     => 'text',
			'title'    => __( 'Search icon name', 'wpjobster' ),
			'default'  => 'search',
			'subtitle' => sprintf( __( 'Example: info, list alternate outline, address card outline, file outline, image outline, video, plus square outline, truck.<br />All icons: %s', 'wpjobster' ), '<a href="https://semantic-ui.com/elements/icon.html" target="_blank">https://semantic-ui.com/elements/icon.html</a>' )
		),
		array(
			'id'          => 'chat_search_input_bgcolor',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '.chat-sidebar-user-search .ui.input > input, .chat-sidebar-minimal-container .chat-sidebar-user-search'
			),
			'title'       => __( 'Background colour', 'wpjobster' ),
			'default'     => '#FFFFFF',
			'color_alpha' => true,
		),
		array(
			'id'          => 'chat_search_input_bgcolor_hover',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '.chat-sidebar-user-search .ui.input:hover > input, .chat-sidebar-minimal-container .chat-sidebar-user-search:hover'
			),
			'title'       => __( 'Background colour (hover)', 'wpjobster' ),
			'default'     => '#FFFFFF',
			'color_alpha' => true,
		),
		array(
			'id'          => 'chat_search_input_color',
			'type'        => 'color',
			'output'      => array(
				'color'   => '
					.chat-sidebar-user-search,
					.chat-sidebar-user-search .ui.input,
					.chat-sidebar-user-search .ui.input .chat-sidebar-inp-user-search,
					.chat-sidebar-user-search .ui.input .chat-sidebar-inp-user-search::placeholder,
					.chat-sidebar-minimal-container .chat-sidebar-user-search .chat-sidebar-user-search-icon
				'
			),
			'title'       => __( 'Colour', 'wpjobster' ),
			'default'     => '#333435',
			'color_alpha' => true,
		),
	)
) );