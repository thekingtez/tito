<?php /* Header */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Header', 'wpjobster' ),
	'id'         => 'header-font-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'      => 'header_links_color',
			'type'    => 'link_color',
			'title'   => __( 'Header links colour', 'wpjobster' ),
			'focus'   => true,
			'visited' => true,
			'default' => array(
				'regular' => '#333435',
				'hover'   => '#20c497',
				'active'  => '#20c497',
				'visited' => '#333435',
				'focus'   => '#20c497',
			),
			'color_alpha' => true,
			'output'      => array(
				'color' => '
					.header-wrapper #menu-header-user-account-menu,
					.header-wrapper .menu-secondary-private-menu-container ul > li > a,
					.header-wrapper .menu-secondary-private-menu-container ul > li > a > span,
					.header-wrapper .ui.segments.middle-menu .main-menu-wrapper ul > li > a,
					.header-wrapper .ui.segments.middle-menu .main-menu-wrapper ul > li > a > span,
					.header-wrapper .ui.segments.middle-menu .main-menu-wrapper ul > li > ul > li > a,
					.header-wrapper .ui.segments.middle-menu .main-menu-wrapper ul > li > ul > li > a > span,
					.header-wrapper .nh-submenu.nh-accordions ul > li > a,
					.header-wrapper .nh-submenu.nh-accordions ul > li > div > ul > li > a,
					.header-wrapper .user-notification-icons a,
					.header-wrapper .wpj-view-all-cnt > a
				'
			),
		),
		array(
			'id'             => 'header-font-settings',
			'type'           => 'typography',
			'title'          => esc_html__( 'Header font', 'wpjobster' ),
			'google'         => true,
			'all-styles'     => true,
			'all-subsets'    => true,
			'units'          => 'px',
			'word-spacing'   => true,
			'letter-spacing' => true,
			'text-align'     => true,
			'text-transform' => true,
			'default'        => array(
				'color'       => '#333435',
				'font-size'   => '14px',
				'line-height' => '14px',
				'font-family' => 'Poppins',
				'font-weight' => '400',
			),
			'color_alpha' => true,
			'output'      => array( '
				.header-wrapper div,
				.header-wrapper p,
				.header-wrapper span,
				.header-wrapper input::-webkit-input-placeholder,
				.header-wrapper .ui.list .list > .item .header.user-info-name,
				.header-wrapper .ui.list > .item .header.user-info-name,
				.header-wrapper .user-info-menu .user-info-name:before,
				.header-wrapper .wpj-view-all-cnt *,
				.header-wrapper .ui.button
			' ),
		),
		array(
			'id'             => 'header-menus-settings',
			'type'           => 'typography',
			'title'          => esc_html__( 'Header menus', 'wpjobster' ),
			'google'         => true,
			'all-styles'     => true,
			'all-subsets'    => true,
			'units'          => 'px',
			'word-spacing'   => true,
			'letter-spacing' => true,
			'text-align'     => true,
			'text-transform' => true,
			'color'          => false,
			'default'        => array(
				'font-size'   => '14px',
				'line-height' => '20px',
				'font-family' => 'Poppins',
				'font-weight' => '400',
			),
			'output' => array( '
				.main-menu-wrapper a,
				.ui.segments.middle-menu ul li a,
				.user-info-menu a
			' ),
		)
	)
) );
