<?php /* Typography */

Redux::setSection( $opt_name, array(
	'title'  => __( 'Typography', 'wpjobster' ),
	'id'     => 'typography-settings',
	'icon'   => 'el el-font',
	'fields' => array()
) );