<?php /* Site Typography */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Elements', 'wpjobster' ),
	'id'         => 'elements-font-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'          => 'site-font-family-settings',
			'type'        => 'typography',
			'title'       => esc_html__( 'Site font family', 'wpjobster' ),
			'google'      => true,
			'font-style'  => false,
			'font-weight' => false,
			'font-size'   => false,
			'subsets'     => false,
			'line-height' => false,
			'text-align'  => false,
			'color'       => false,
			'default'     => array(
				'font-family' => 'Poppins',
			),
			'output' => array( '
				p:not(.header-wrapper *):not(.footer-wrapper *):not(.icon),
				div:not(.header-wrapper *):not(.footer-wrapper *):not(.icon):not(.emojionearea-button-close):not(.emojionearea-button-open),
				span:not(.header-wrapper *):not(.footer-wrapper *):not(.icon):not(.dashicons),
				a:not(.header-wrapper *):not(.footer-wrapper *):not(.icon),
				button:not(.header-wrapper *):not(.footer-wrapper *):not(.icon),
				.ui.button:not(.header-wrapper *):not(.footer-wrapper *):not(.icon),
				input:not(.header-wrapper *):not(.footer-wrapper *):not(.icon),
				.ui.input > input:not(.header-wrapper *):not(.footer-wrapper *):not(.icon),
				textarea:not(.header-wrapper *):not(.footer-wrapper *):not(.icon),
				input::-webkit-input-placeholder,
				textarea::-webkit-input-placeholder,
				text,
				.ui.accordion .title:not(.ui),
				.ui.list .list > .item .header,
				.ui.list > .item .header,
				.ui.form input:not([type]),
				.ui.form input[type="date"],
				.ui.form input[type="datetime-local"],
				.ui.form input[type="email"],
				.ui.form input[type="number"],
				.ui.form input[type="password"],
				.ui.form input[type="search"],
				.ui.form input[type="tel"],
				.ui.form input[type="time"],
				.ui.form input[type="text"],
				.ui.form input[type="file"],
				.ui.form input[type="url"],
				.landing-image-wrapper .ui.button.landing-image-button,
				.categories-icon-carousel-wrapper .carousel-content .carousel-item-wrapper .item-content .item-title
			' ),
		),
		array(
			'id'      => 'links-colour',
			'type'    => 'link_color',
			'title'   => __( 'Link colour', 'wpjobster' ),
			'focus'   => true,
			'visited' => true,
			'default' => array(
				'regular' => '#313546',
				'hover'   => '#20c497',
				'active'  => '#20c497',
				'visited' => '#333435',
				'focus'   => '#20c497',
			),
			'color_alpha' => true,
			'output'      => array(
				'color' => '
					a,
					.most-popular-terms a,
					.ui.cards > .card > .content a:not(.ui),
					.ui.card > .content a:not(.ui),
					.ui.cards > .card > .content a:not(.ui) > div,
					.ui.card > .content a:not(.ui) > div,
					.ui.card a.list-header
				'
			),
		)
	)
) );