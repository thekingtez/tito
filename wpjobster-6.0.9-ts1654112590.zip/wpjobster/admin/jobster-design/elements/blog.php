<?php /* Blog */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Blog', 'wpjobster' ),
	'id'         => 'blog-design-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'           => 'no_image_icon_options_blog',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Blog - no image', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
		),
		array(
			'id'           => 'no_image_icon_options_news',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'News - no image', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
		),
	)
) );