<?php /* Request */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Request', 'wpjobster' ),
	'id'         => 'request-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'           => 'lets_meet_rich_icon_options_request',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Let\'s meet image', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
		)
	)
) );