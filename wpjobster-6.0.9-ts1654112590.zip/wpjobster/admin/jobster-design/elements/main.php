<?php /* Elements */

Redux::setSection( $opt_name, array(
	'title'  => __( 'Elements', 'wpjobster' ),
	'id'     => 'elements-settings',
	'icon'   => 'el el-picture',
	'fields' => array(

	)
) );