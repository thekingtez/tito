<?php /* Job */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Job', 'wpjobster' ),
	'id'         => 'job-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'           => 'no_image_icon_options_job',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Job - no image', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
		),
		array(
			'id'       => 'job-cards-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Job cards', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'enable_video_icon_cards',
			'type'     => 'switch',
			'title'    => __( 'Video icon on cards', 'wpjobster' ),
			'on'       => __( 'Enabled', 'wpjobster' ),
			'off'      => __( 'Disabled', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'enable_rating_count_cards',
			'type'     => 'switch',
			'title'    => __( 'Enable rating count on homepage cards', 'wpjobster' ),
			'on'       => __( 'Enabled', 'wpjobster' ),
			'off'      => __( 'Disabled', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'cards_style',
			'type'     => 'select',
			'title'    => esc_html__( 'Job cards style', 'wpjobster' ),
			'options'  => array(
				'1' => esc_attr__( '1 - Simple (sliding on hover)', 'wpjobster' ),
				'2' => esc_attr__( '2 - Rich (no hover)', 'wpjobster' ),
				'3' => esc_attr__( '3 - Slider', 'wpjobster' ),
			),
			'default'  => '3',
		),
		array(
			'id'       => 'border_over_box_shadow',
			'type'     => 'switch',
			'title'    => __( 'Enable border instead of box shadow on job cards', 'wpjobster' ),
			'on'       => __( 'Enabled', 'wpjobster' ),
			'off'      => __( 'Disabled', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'           => 'featured_simple_icon_options_job',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Featured icon image', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
			'required' => array( 'cards_style', '=', '1' )
		),
		array(
			'id'           => 'lets_meet_simple_icon_options_job',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Let\'s meet icon image', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
			'required' => array( 'cards_style', '=', '1' )
		),
		array(
			'id'           => 'instant_delivery_simple_icon_options_job',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Instant delivery icon image', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
			'required' => array( 'cards_style', '=', '1' )
		),
		array(
			'id'       => 'lets_meet_rich_icon_options_job',
			'type'     => 'text',
			'title'    => __( 'Let\'s meet icon', 'wpjobster' ),
			'default'  => 'blue map marker',
			'subtitle' => sprintf( __( 'Example: info, list alternate outline, address card outline, file outline, image outline, video, plus square outline, truck.<br />All icons: %s', 'wpjobster' ), '<a href="https://semantic-ui.com/elements/icon.html" target="_blank">https://semantic-ui.com/elements/icon.html</a>' ),
			'required' => array( 'cards_style', '=', '2' )
		),
		array(
			'id'       => 'instant_delivery_rich_icon_options_job',
			'type'     => 'text',
			'title'    => __( 'Instant delivery icon', 'wpjobster' ),
			'default'  => 'green arrow circle down',
			'subtitle' => sprintf( __( 'Example: info, list alternate outline, address card outline, file outline, image outline, video, plus square outline, truck.<br />All icons: %s', 'wpjobster' ), '<a href="https://semantic-ui.com/elements/icon.html" target="_blank">https://semantic-ui.com/elements/icon.html</a>' ),
			'required' => array( 'cards_style', '=', '2' )
		),
		array(
			'id'       => 'wpjobster_user_level_for_thumbnails',
			'type'     => 'switch',
			'title'    => __( 'Enable user level icons for thumbnails', 'wpjobster' ),
			'default'  => true,
			'required' => array(
				array( 'cards_style', '=', array( '1', '2' ) )
			)
		),
		array(
			'id'           => 'level1_card_icon_options_user',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Level 1', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
			'required'     => array( 'wpjobster_user_level_for_thumbnails', '=', true )
		),
		array(
			'id'           => 'level2_card_icon_options_user',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Level 2', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
			'required'     => array( 'wpjobster_user_level_for_thumbnails', '=', true )
		),
		array(
			'id'           => 'level3_card_icon_options_user',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Level 3', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
			'required'     => array( 'wpjobster_user_level_for_thumbnails', '=', true )
		),
		array(
			'id'       => 'lets_meet_slider_icon_options_job',
			'type'     => 'text',
			'title'    => __( 'Let\'s meet icon', 'wpjobster' ),
			'desc'     => __( 'Leave the field blank if you want the default icon to appear.', 'wpjobster' ),
			'subtitle' => sprintf( __( 'Example: info, list alternate outline, address card outline, file outline, image outline, video, plus square outline, truck.<br />All icons: %s', 'wpjobster' ), '<a href="https://semantic-ui.com/elements/icon.html" target="_blank">https://semantic-ui.com/elements/icon.html</a>' ),
			'required' => array( 'cards_style', '=', '3' )
		),
		array(
			'id'       => 'instant_delivery_slider_icon_options_job',
			'type'     => 'text',
			'title'    => __( 'Instant delivery icon', 'wpjobster' ),
			'desc'     => __( 'Leave the field blank if you want the default icon to appear.', 'wpjobster' ),
			'subtitle' => sprintf( __( 'Example: info, list alternate outline, address card outline, file outline, image outline, video, plus square outline, truck.<br />All icons: %s', 'wpjobster' ), '<a href="https://semantic-ui.com/elements/icon.html" target="_blank">https://semantic-ui.com/elements/icon.html</a>' ),
			'required' => array( 'cards_style', '=', '3' )
		),
		array(
			'id'       => 'featured_slider_icon_options_job',
			'type'     => 'text',
			'title'    => __( 'Featured icon', 'wpjobster' ),
			'desc'     => __( 'Leave the field blank if you want the default icon to appear.', 'wpjobster' ),
			'subtitle' => sprintf( __( 'Example: info, list alternate outline, address card outline, file outline, image outline, video, plus square outline, truck.<br />All icons: %s', 'wpjobster' ), '<a href="https://semantic-ui.com/elements/icon.html" target="_blank">https://semantic-ui.com/elements/icon.html</a>' ),
			'required' => array( 'cards_style', '=', '3' )
		),
		array(
			'id'       => 'favorites_slider_icon_options_job',
			'type'     => 'text',
			'title'    => __( 'Favorites icon', 'wpjobster' ),
			'default'  => 'heart',
			'subtitle' => sprintf( __( 'Example: info, list alternate outline, address card outline, file outline, image outline, video, plus square outline, truck.<br />All icons: %s', 'wpjobster' ), '<a href="https://semantic-ui.com/elements/icon.html" target="_blank">https://semantic-ui.com/elements/icon.html</a>' ),
			'required' => array( 'cards_style', '=', '3' )
		)
	)
) );