<?php /* Logo */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Logo', 'wpjobster' ),
	'id'         => 'footer-logo-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'           => 'footer_logo_image',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Footer logo', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
		),
		array(
			'id'            => 'footer_logo_height',
			'type'          => 'dimensions',
			'title'         => esc_html__( 'Logo height', 'wpjobster' ),
			'units'         => 'px',
			'width'         => 'false',
			'default'       => array(
				'height'  => 44,
			),
			'output'         => array( '.footer-wrapper .logo-holder img' )
		),
		array(
			'id'             => 'footer_logo_spacing',
			'type'           => 'spacing',
			'mode'           => 'padding',
			'all'            => false,
			'units'          => 'px',
			'display_units'  => false,
			'title'          => __( 'Logo spacing', 'wpjobster' ),
			'subtitle'       => __( 'For spacing you can use only px', 'wpjobster' ),
			'default'        => array(
				'padding-top'    => '10',
				'padding-right'  => '0',
				'padding-bottom' => '10',
				'padding-left'   => '0',
				'units'          => 'px',
			),
			'output'         => array( '.footer-wrapper .logo-holder' ),
		),
		array(
			'id'       => 'logo_grayscale_enable',
			'type'     => 'switch',
			'title'    => __( 'Enable grayscale for footer logo', 'wpjobster' ),
			'on'       => __( 'Enabled', 'wpjobster' ),
			'off'      => __( 'Disabled', 'wpjobster' ),
			'default'  => true,
		),
	)
) );