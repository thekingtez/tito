<?php /* Cards */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Cards', 'wpjobster' ),
	'id'         => 'footer-cards-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'           => 'image_demo',
			'type'         => 'repeater',
			'title'        => __( 'Footer cards', 'wpjobster' ),
			'item_name'    => __( 'card', 'wpjobster' ),
			'group_values' => true,
			'bind_title'   => esc_html__( 'Card', 'wpjobster' ),
			'fields'       => array(
				array(
					'id'           => 'card_item',
					'type'         => 'media',
					'url'          => true,
					'title'        => esc_html__( 'Card', 'wpjobster' ),
					'subtitle'     => __( 'Upload card images', 'wpjobster' ),
					'compiler'     => 'true',
					'preview_size' => 'full',
				),
			)
		)
	)
) );