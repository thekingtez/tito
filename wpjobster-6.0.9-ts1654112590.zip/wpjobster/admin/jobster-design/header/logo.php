<?php /* Logo */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Logo', 'wpjobster' ),
	'id'         => 'header-logo-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'           => 'site_logo',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Header logo', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
		),
		array(
			'id'           => 'site_logo_white',
			'type'         => 'media',
			'url'          => true,
			'title'        => esc_html__( 'Header white logo', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
		),
		array(
			'id'            => 'logo_height',
			'type'          => 'dimensions',
			'title'         => esc_html__( 'Logo height', 'wpjobster' ),
			'units'         => 'px',
			'width'         => 'false',
			'default'       => array(
				'height'  => 44,
			),
			'output'         => array( '.header-wrapper .logo-holder img' )
		),
		array(
			'id'             => 'logo_spacing',
			'type'           => 'spacing',
			'mode'           => 'padding',
			'all'            => false,
			'units'          => 'px',
			'display_units'  => false,
			'title'          => __( 'Logo spacing', 'wpjobster' ),
			'subtitle'       => __( 'For spacing you can use only px', 'wpjobster' ),
			'default'        => array(
				'padding-top'    => '10',
				'padding-right'  => '0',
				'padding-bottom' => '10',
				'padding-left'   => '0',
				'units'          => 'px',
			),
			'output'         => array( '.header-wrapper .logo-holder' ),
		)
	)
) );
