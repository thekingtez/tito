<?php /* Balance */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Balance', 'wpjobster' ),
	'id'         => 'header-balance-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'          => 'balance_colour_options_header',
			'type'        => 'color',
			'output'      => array(
				'color' => '
					.user-info-menu .header-user-credit
				'
			),
			'title'       => __( 'Colour', 'wpjobster' ),
			'default'     => '#ffffff',
			'color_alpha' => true,
		),
		array(
			'id'          => 'balance_hover_colour_options_header',
			'type'        => 'color',
			'output'      => array(
				'color' => '
					.user-info-menu .header-user-credit:hover
				'
			),
			'title'       => __( 'Hover colour', 'wpjobster' ),
			'default'     => '#ffffff',
			'color_alpha' => true,
		),
		array(
			'id'          => 'balance_bg_colour_options_header',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '
					.user-info-menu .header-user-credit
				'
			),
			'title'       => __( 'Background colour', 'wpjobster' ),
			'default'     => '#20c497',
			'color_alpha' => true,
		),
		array(
			'id'          => 'balance_bg_hover_colour_options_header',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '
					.user-info-menu .header-user-credit:hover
				'
			),
			'title'       => __( 'Background hover colour', 'wpjobster' ),
			'default'     => '#20c497',
			'color_alpha' => true,
		),
		array(
			'id'      => 'balance_border_header',
			'type'    => 'border',
			'all'     => true,
			'output'  => array( '.user-info-menu .header-user-credit' ),
			'title'   => esc_html__( 'Border', 'wpjobster' ),
			'default' => array(
				'border-color'  => '#fff',
				'border-style'  => 'solid',
				'border-width'  => '2px'
			),
		),
	)
) );