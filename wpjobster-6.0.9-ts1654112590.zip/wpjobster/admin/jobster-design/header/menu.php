<?php /* Menu */

Redux::setSection( $opt_name, array(
	'title'      => __( 'Menu', 'wpjobster' ),
	'id'         => 'header-menu-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'main-menu-section-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Main menu', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'enable_long_menu_arrows',
			'type'     => 'switch',
			'title'    => __( 'Long menu arrows', 'wpjobster' ),
			'subtitle' => __( 'Displays a long menu, which instead of moving on to the next row, displays some arrows with which you can navigate left and right.<br>Warning: this type of menu does not support submenus', 'wpjobster' ),
			'on'       => __( 'Enabled', 'wpjobster' ),
			'off'      => __( 'Disabled', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'menu_style',
			'type'     => 'select',
			'title'    => esc_html__( 'Submenu style', 'wpjobster' ),
			'options'  => array(
				'1' => esc_attr__( 'One column', 'wpjobster' ),
				'2' => esc_attr__( 'Two columns', 'wpjobster' ),
			),
			'default'  => '2',
		),
		array(
			'id'          => 'mainmenu_submenu_bg_colour',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '.categories-menu-list ul.sub-menu',
			),
			'title'       => esc_html__( 'Submenu background colour', 'wpjobster' ),
			'default'     => '#FFFFFF',
			'color_alpha' => true,
		),
		array(
			'id'       => 'dropdown-menu-section-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Dropdown menu', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'dropdown_menu_style',
			'type'     => 'select',
			'title'    => esc_html__( 'Menu style', 'wpjobster' ),
			'options'  => array(
				'1' => esc_attr__( 'One column', 'wpjobster' ),
				'2' => esc_attr__( 'Two columns', 'wpjobster' ),
			),
			'default'  => '2',
		),
		array(
			'id'          => 'dropdown_bg_colour',
			'type'        => 'color',
			'output'      => array(
				'background-color'    => '.user-info-menu .dropdown-menu-wrapper .nh-submenu',
				'border-bottom-color' => '.user-info-menu .dropdown-menu-wrapper .nh-submenu:after',
			),
			'title'       => esc_html__( 'Background colour', 'wpjobster' ),
			'default'     => '#FFFFFF',
			'color_alpha' => true,
		),
		array(
			'id'          => 'dropdown_border_colour',
			'type'        => 'color',
			'output'      => array(
				'border-color'        => '.user-info-menu .dropdown-menu-wrapper .nh-submenu',
				'border-bottom-color' => '.user-info-menu .dropdown-menu-wrapper .nh-submenu:before',
			),
			'title'       => esc_html__( 'Border colour', 'wpjobster' ),
			'default'     => '#ffffff',
			'color_alpha' => true,
		),
		array(
			'id'          => 'dropdown_separator_colour',
			'type'        => 'color',
			'output'      => array(
				'border-bottom-color' => '.user-info-menu .nh-submenu.nh-accordions .nh-accordion.styled ul li:last-child'
			),
			'title'       => esc_html__( 'Separator colour', 'wpjobster' ),
			'default'     => '#eeeeef',
			'color_alpha' => true,
		),
		array(
			'id'          => 'dropdown_submenu_bg_colour',
			'type'        => 'color',
			'output'      => array(
				'background-color' => '.user-info-menu .nh-submenu.nh-accordions .nh-accordion',
			),
			'title'       => esc_html__( 'Submenu background colour', 'wpjobster' ),
			'default'     => '#FFFFFF',
			'color_alpha' => true,
		),
		array(
			'id'       => 'mobile-menu-section-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Mobile menu', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'           => 'left_mobile_menu_image_options_header',
			'type'         => 'media',
			'url'          => true,
			'title'        => __( 'Left menu image', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
		),
		array(
			'id'       => 'left_mobile_menu_icon_options_header',
			'type'     => 'text',
			'title'    => __( 'Left menu icon name', 'wpjobster' ),
			'default'  => 'thick bars',
			'subtitle' => sprintf( __( 'Example: info, list alternate outline, address card outline, file outline, image outline, video, plus square outline, truck.<br />All icons: %s', 'wpjobster' ), '<a href="https://semantic-ui.com/elements/icon.html" target="_blank">https://semantic-ui.com/elements/icon.html</a>' )
		),
		array(
			'id'          => 'left_mobile_menu_colour_icon_options_header',
			'type'        => 'color',
			'output'      => array(
				'color'       => '.header-wrapper.header-mobile .menu-left .icon'
			),
			'title'       => esc_html__( 'Left menu icon colour', 'wpjobster' ),
			'default'     => '#20c497',
			'color_alpha' => true,
		),
		array(
			'id'           => 'right_mobile_menu_image_options_header',
			'type'         => 'media',
			'url'          => true,
			'title'        => __( 'Right menu image', 'wpjobster' ),
			'compiler'     => 'true',
			'preview_size' => 'full',
		),
		array(
			'id'       => 'right_mobile_menu_icon_options_header',
			'type'     => 'text',
			'title'    => __( 'Right menu icon name', 'wpjobster' ),
			'default'  => 'th',
			'subtitle' => sprintf( __( 'Example: info, list alternate outline, address card outline, file outline, image outline, video, plus square outline, truck.<br />All icons: %s', 'wpjobster' ), '<a href="https://semantic-ui.com/elements/icon.html" target="_blank">https://semantic-ui.com/elements/icon.html</a>' )
		),
		array(
			'id'          => 'right_mobile_menu_colour_icon_options_header',
			'type'        => 'color',
			'output'      => array(
				'color' => '.header-wrapper.header-mobile .menu-right .icon'
			),
			'title'       => esc_html__( 'Right menu icon colour', 'wpjobster' ),
			'default'     => '#20c497',
			'color_alpha' => true,
		),
	)
) );