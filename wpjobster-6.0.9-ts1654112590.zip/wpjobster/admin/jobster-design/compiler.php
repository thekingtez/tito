<?php
add_action( 'wp_ajax_nopriv_wpjobster_save_less_css_file', 'wpjobster_save_less_css_file' );
add_action( 'wp_ajax_wpjobster_save_less_css_file', 'wpjobster_save_less_css_file' );
function wpjobster_save_less_css_file() {
	$upload_dir = wp_upload_dir();

	$dirname = $upload_dir['basedir'] . '/wpjobster';

	if ( ! file_exists( $dirname ) ) wp_mkdir_p( $dirname );

	$path = $upload_dir['basedir'] . '/wpjobster/semantic.css';
	file_put_contents( $path, stripslashes( $_POST['content'] ) );

	update_option( 'wpj_last_css_compiled', time() );

	wp_die();
}

add_action( 'redux/options/jobster_design/saved', 'wpj_set_cookie_colors' );
function wpj_set_cookie_colors( $options ) {
	setcookie( 'primaryColor', $options['site_primary_color'], time() + 86400, '/' );
	setcookie( 'secondaryColor', $options['site_secondary_color'], time() + 86400, '/' );
}