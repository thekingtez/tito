<?php // Vendor //
include_once get_template_directory() . '/vendor/tgm-plugin-activation.php'; /* TGMPA */
require_once get_parent_theme_file_path( '/vendor/merlin/vendor/autoload.php' ); /* merlin autoload */
require_once get_parent_theme_file_path( '/vendor/merlin/class-merlin.php' ); /* merlin class */

// Less Compiler //
include_once get_template_directory() . '/admin/jobster-design/compiler.php';

// Setup //
$options = wpj_get_folder_files( get_template_directory() . '/admin/setup' );
foreach ( $options as $option ) { include_once $option; }

// Pages //
$pages = wpj_get_folder_files( get_template_directory() . '/admin/pages' );
foreach ( $pages as $page ) { include_once $page; }