<?php
add_action( 'wp_ajax_reset_page_action', 'wpj_reset_page_action' );
function wpj_reset_page_action( $post_id = '', $post_title = '', $with_update = true ) {
	if ( ! $post_id && isset( $_REQUEST['post'] ) ) $post_id = $_REQUEST['post'];
	if ( ! $post_title && $post_id ) $post_title = get_the_title( $post_id );

	if ( $post_id || $post_title ) {
		$page_content = apply_filters( 'wpj_reset_page_action_content_filter', '', $post_id, $post_title );

		if ( ! $page_content ) {

			$curl = curl_init();

			curl_setopt_array( $curl, Array(
				CURLOPT_URL            => 'https://democontent.wpjobster.com/v6/jobster_content_gutenberg.xml',
				CURLOPT_USERAGENT      => 'spider',
				CURLOPT_TIMEOUT        => 120,
				CURLOPT_CONNECTTIMEOUT => 30,
				CURLOPT_RETURNTRANSFER => TRUE,
				CURLOPT_ENCODING       => 'UTF-8'
			) );

			$data = curl_exec( $curl );

			curl_close( $curl );

			$data = str_replace( "<content:encoded>", "<contentEncoded>", $data );
			$data = str_replace( "</content:encoded>", "</contentEncoded>", $data );

			$data = str_replace( "<wp:post_id>", "<postId>", $data );
			$data = str_replace( "</wp:post_id>", "</postId>", $data );

			$xml  = simplexml_load_string( $data, 'SimpleXMLElement', LIBXML_NOCDATA );

			foreach ( $xml->channel->item as $item ) {
				if ( $item->postId == $post_id || $post_title == $item->title ) {
					$page_content = ( string ) $item->contentEncoded;

					if ( $with_update && $page_content ) {
						$post_arr = array(
							'ID'           => $post_id,
							'post_content' => $page_content,
						);

						wp_update_post( $post_arr );
					}
				}
			}

		}

	}

	if ( wpj_is_ajax_call() ) wp_die();

	return ! empty( $page_content ) ? $page_content : false;
}