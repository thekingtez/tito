<?php
add_filter( 'manage_edit-job_columns', 'wpj_admin_job_info_label' );
function wpj_admin_job_info_label( $columns ) {
	$columns = array(
		"cb"            => "<input type=\"checkbox\" />",
		"title"         => __( "Job Title", 'wpjobster' ),
		"price"         => __( "Price", 'wpjobster' ),
		"author"        => __( "Author", 'wpjobster' ),
		"posted"        => __( "Posted On", 'wpjobster' ),
		"active"        => __( "Status", 'wpjobster' ),
		"active_reason" => __( "Status Reason", 'wpjobster' ),
		"thumbnail"     => __( "Thumbnail", 'wpjobster' ),
		"options"       => __( "Options", 'wpjobster' )
	);

	return $columns;
}

add_action( 'manage_posts_custom_column', 'wpj_admin_job_info_action' );
function wpj_admin_job_info_action( $column ) {
	global $post;

	if ( "ID" == $column ) echo $post->ID;

	elseif ( "description" == $column ) echo $post->ID;

	elseif ( "price" == $column ) {
		$wpjobster_packages = wpj_get_option( 'wpjobster_packages_enabled' );
		$packages           = get_post_meta( $post->ID, 'job_packages', true );
		$package_price      = get_post_meta( $post->ID, 'package_price', true );

		if ( $wpjobster_packages == 'yes' && $packages == 'yes' && $package_price ) {
			sort( $package_price );
			$package_price = array_diff( $package_price, array( null ) );
			echo wpj_show_price( min( $package_price ) );
			echo ' - ';
			echo wpj_show_price( max( $package_price ) );
		} elseif ( get_post_meta( $post->ID, 'price_type', true ) && get_post_meta( $post->ID, 'price_type', true ) != 'fixed' ) {
			echo wpj_show_price( get_post_meta( $post->ID, 'price', true ), 1 ) . ' ' . __( 'per', 'wpjobster' ) . ' ' . wpj_change_rate_word ( get_post_meta( $post->ID, 'price_type', true ) );
		} else {
			echo wpj_show_price( get_post_meta( $post->ID, 'price', true ) );
		}
	}

	elseif ( "author" == $column ) echo $post->post_author;

	elseif ( "posted" == $column ) echo wpj_date( 'jS \of F, Y \<\b\r\/\>H:i:s', strtotime( $post->post_date ) );

	elseif ( "active" == $column ) echo get_post_meta( $post->ID, 'active', true ) == 1 ? __( "Active", "wpjobster" ) : __( "Inactive", "wpjobster" );

	elseif ( "active_reason" == $column ) echo get_post_meta( $post->ID, 'active', true ) == 1 ? get_post_meta( $post->ID, 'activate_reason', true ) : get_post_meta( $post->ID, 'deactivation_reason', true );

	elseif ( "thumbnail" == $column ) echo '<a href="' . get_bloginfo( 'url' ) . '/wp-admin/post.php?post=' . $post->ID . '&action=edit"><img class="no-border round-avatar" src="' . wpj_get_job_image( $post->ID, 60, 60 ) . '" width="60" height="60" /></a>';

	elseif ( "options" == $column ) {
		echo '<div style="padding-top:20px">';

			echo '<a class="awesome" href="' . get_bloginfo( 'url' ) . '/wp-admin/post.php?post=' . $post->ID . '&action=edit">Edit</a> | ';
			echo '<a class="awesome" href="' . get_permalink( $post->ID ) . '" target="_blank">View</a> | ';
			echo '<a class="trash" href="' . get_delete_post_link( $post->ID ) . '">Trash</a> | ';

			if ( get_post_meta( $post->ID, 'active', true ) == 1 ) {
				echo '<a class="awesome" href="' . get_bloginfo( 'url' ) . '/wp-admin/edit.php?post_type=job&post=' . $post->ID . '&activate=0">' . __( 'Deactivate', 'wpjobster' ) . '</a> ';
			} else {
				echo '<a class="awesome" href="' . get_bloginfo( 'url' ) . '/wp-admin/edit.php?post_type=job&post=' . $post->ID . '&activate=1">' . __( 'Activate', 'wpjobster' ) . '</a> ';
			}

		echo '</div>';
	}
}

add_action( 'load-edit.php', 'wpj_admin_change_job_status' );
function wpj_admin_change_job_status() {
	if ( ! empty ( $_GET['post'] ) ) {
		if ( isset( $_GET['activate'] ) && $_GET['activate'] == '0' ) {
			wpj_deactivate_job( $_GET['post'], 'by_admin' );

		} elseif ( isset( $_GET['activate'] ) && $_GET['activate'] == '1' ) {
			wpj_activate_job( $_GET['post'], 'by_admin' );

		}
	}
}

add_filter( 'bulk_actions-edit-job', 'wpj_admin_activate_all_label_bulk_actions' );
function wpj_admin_activate_all_label_bulk_actions( $bulk_actions ) {
	$bulk_actions['activate_all'] = __( 'Activate all', 'wpjobster');
	$bulk_actions['deactivate_all'] = __( 'Deactivate all', 'wpjobster');

	return $bulk_actions;
}

add_filter( 'handle_bulk_actions-edit-job', 'wpj_admin_activate_all_action_bulk_actions', 10, 3 );
function wpj_admin_activate_all_action_bulk_actions( $redirect_to, $doaction, $post_ids ) {
	if ( $doaction == 'activate_all' || $doaction == 'deactivate_all' ) {

		foreach ( $post_ids as $post_id ) {
			if ( $doaction == 'deactivate_all' ) {
				wpj_deactivate_job( $post_id, 'by_admin' );
			} elseif ( $doaction == 'activate_all' ) {
				wpj_activate_job( $post_id, 'by_admin' );
			}
		}

	}

	return $redirect_to;
}

add_filter( 'views_edit-job', 'wpj_filter_job_status' );
function wpj_filter_job_status( $views ) {
	global $wp, $wpdb;

	$query_active = $wpdb->get_var( "
		SELECT count(DISTINCT pm.post_id)
		FROM {$wpdb->postmeta} pm
		JOIN {$wpdb->posts} p ON (p.ID = pm.post_id)
		WHERE pm.meta_key = 'active'
		AND pm.meta_value = '1'
		AND p.post_type = 'job'
		AND p.post_status IN ( 'publish', 'pending', 'draft' );
	" );

	$query_inactive = $wpdb->get_var( "
		SELECT count(DISTINCT pm.post_id)
		FROM {$wpdb->postmeta} pm
		JOIN {$wpdb->posts} p ON (p.ID = pm.post_id)
		WHERE pm.meta_key = 'active'
		AND pm.meta_value = '0'
		AND p.post_type = 'job'
		AND p.post_status IN ( 'publish', 'pending', 'draft' );
	" );

	$class_active = isset( $_GET[ 'active' ] ) && $_GET[ 'active' ] == 1 ? ' current' : '';
	$class_inactive = isset( $_GET[ 'active' ] ) && $_GET[ 'active' ] == 0 ? ' current' : '';

	$current_url = home_url( add_query_arg( array( $_GET ), $wp->request ) );

	$views['active'] = sprintf(
		'<a class="' . $class_active . '" href="%s">%s <span class="count">(%d)</span></a>',
		esc_url( $current_url . '&active=1' ),
		esc_html__( 'Active', 'wpjobster' ),
		$query_active
	);

	$views['inactive'] = sprintf(
		'<a class="' . $class_inactive . '" href="%s">%s <span class="count">(%d)</span></a>',
		esc_url( $current_url . '&active=0' ),
		esc_html__( 'Inactive', 'wpjobster' ),
		$query_inactive
	);

	return $views;
}

add_action( 'load-edit.php', 'wpj_load_custom_filters' );
function wpj_load_custom_filters() {
	global $typenow;

	if ( 'job' != $typenow ) return false;

	add_filter( 'posts_where' , 'wpj_posts_status_where' );
}

function wpj_posts_status_where( $where ) {
	global $wpdb;

	if ( ! empty( $_GET[ 'active' ] ) || ( isset( $_GET[ 'active' ] ) && $_GET[ 'active' ] == 0 ) ) {
		$where .= " AND ID IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key='active' AND meta_value='" . $_GET[ 'active' ] . "')";
	}

	return $where;
}