<?php
class WPJ_Transactions {
	public function getRowQuery( $rows_per_page = 10, $pageno = 1, $limited = false ) {
		global $wpdb;

		$user = WPJ_Form::get( 'search_user', '' );
		$uid = ctype_digit( $user ) || is_int( $user ) ? $_GET['search_user'] : '';
		if ( ! $uid ) {
			$query  = "SELECT ID FROM {$wpdb->users} WHERE user_login = '{$user}'";
			$result = $wpdb->get_results( $query );
			$uid = count( $result ) > 0 ? $result[0]->ID : '';
		}

		$query = "SELECT * FROM {$wpdb->prefix}job_payment_transactions";

		if ( $user ) { $query .= " WHERE uid = {$uid}"; }

		$query .= " ORDER BY id DESC";

		if ( $limited ) {
			$query .= " LIMIT " . ( $pageno - 1 ) * $rows_per_page . ',' . $rows_per_page;
		}

		return $query;
	}

	public function getOrderRow() {
		$r = array( 'all' => '', 'limited' => '', 'lastpage' => '', 'pageno' => '' );

		global $wpdb;

		$rows_per_page = 20;

		if ( isset( $_GET['pj'] ) ) $pageno = $_GET['pj'];
		else $pageno = 1;

		$s1 = $this->getRowQuery( $rows_per_page, $pageno, false );
		$s  = $this->getRowQuery( $rows_per_page, $pageno, true );

		$nr       = count( $wpdb->get_results( $s1 ) );
		$lastpage = ceil( $nr / $rows_per_page );

		$r = array(
			'all'      => $wpdb->get_results( $s ),
			'limited'  => $wpdb->get_results( $s1 ),
			'lastpage' => $lastpage,
			'pageno'   => $pageno,
			'count'    => $nr
		);

		return $r;
	}
}