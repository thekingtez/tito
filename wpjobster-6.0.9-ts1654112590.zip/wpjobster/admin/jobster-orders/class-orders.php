<?php
class WPJ_Orders {
	public function __construct() {
		add_action( 'wp_ajax_delete_review', array( $this, 'deleteReview' ) );
		add_action( 'wp_ajax_delete_review_response', array( $this, 'deleteReviewResponse' ) );
		add_action( 'wp_ajax_delete_transaction_message', array( $this, 'deleteTransactionMessage' ) );

		add_action( 'wpjobster_taketo_banktransfer_gateway', array( $this, 'initializeBankTransfer' ), 10, 2 );
		add_action( 'wpjobster_processafter_banktransfer_gateway', array( $this, 'processBankTransfer' ), 10, 1 );
	}

	public static function init() {
		$class = __CLASS__; new $class;
	}

	public function changeOrderStatusMessage() {
		$message = array();

		if ( isset( $_GET['payment_status'] ) ) {
			if ( $_GET['payment_status'] == 'success' )
				$message = array( 'type' => 'success', 'message' => __( "Order status changed to Completed", "wpjobster" ) );

			if ( $_GET['payment_status'] == 'fail' )
				$message = array( 'type' => 'success', 'message' => __( "Order status changed to Cancelled", "wpjobster" ) );

			if ( $_GET['payment_status'] == 'error' )
				$message = array( 'type' => 'error',   'message' => __( "Something went wrong. Please try again", "wpjobster" ) );

		}

		return $message;
	}

	public function changeOrderStatusAction() {
		if ( ! is_demo_admin() ) {

			if ( isset( $_GET['order_action'] ) ) {
				$order_id     = WPJ_Form::get( 'order_id', '' );
				$order_action = WPJ_Form::get( 'order_action', '' );
				$payment_type = WPJ_Form::get( 'payment_type', '' );

				if ( $order_id && $payment_type && ( $order_action == 'mark_as_paid' || $order_action == 'mark_as_cancelled' ) ) {
					$class_name = 'WPJ_' . str_replace( '_', '_', ucwords( $this->getClassNameByPaymentType( $payment_type ), '_' ) );
					if ( ! class_exists( $class_name ) ) {
						include_once get_template_directory() . '/lib/gateways/class-' . str_replace( '_', '-', $this->getClassNameByPaymentType( $payment_type ) ) . '.php';
						$payment_type_class = new $class_name( 'free' );
					}

					if ( $order_action == 'mark_as_paid' ) {
						if ( $payment_type == 'subscription' ) {
							do_action( "wpjobster_" . $this->getClassNameByPaymentType( $payment_type ) . "_payment_success", $order_id, 'free', 'Paid by Admin', '', 'no' );

						} elseif ( $payment_type == 'withdrawal' ) {
							$this->acceptWithdrawalRequest( $order_id );

						} else {
							do_action( "wpjobster_" . $this->getClassNameByPaymentType( $payment_type ) . "_payment_success", $order_id, 'free', 'Paid by Admin', '', 'no' );
							if ( $payment_type == $this->getClassNameByPaymentType( 'job_purchase' ) )
								do_action( 'wpj_after_job_payment_is_completed', $order_id, 'admin' );

						}

						wp_redirect( get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&payment_status=success&status=active&active_tab=' . $payment_type );
					}

					if ( $order_action == 'mark_as_cancelled' ) {
						if ( $payment_type == 'withdrawal' ) {
							$this->denyWithdrawalRequest( $order_id );

						} else {
							do_action( "wpjobster_" . $this->getClassNameByPaymentType( $payment_type ) . "_payment_failed", $order_id, 'free', 'Cancelled by Admin', '', 'no' );

						}

						wp_redirect( get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&payment_status=fail&status=cancelled&active_tab=' . $payment_type );
					}

				} elseif ( ! $order_id || ! $order_action || ! $payment_type ) {
					wp_redirect( get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&payment_status=error&active_tab=' . $payment_type );

				}
			}
		}
	}

	public function closeJob( $order_id = '' ) {
		if ( ! $order_id && isset( $_GET['idclose'] ) ) $order_id = $_GET['idclose'];

		if ( ! is_demo_admin() ) {
			if ( $order_id ) {

				if ( WPJ_Form::get( 'payment_type' ) == 'subscription' ) { // remove subscription
					wpj_remove_subscription( $order_id );

				} else { // close job order

					global $wpdb;

					$tm = current_time( 'timestamp', 1 );
					if ( ! is_numeric( $order_id ) ) { echo "ERROR!"; die; }

					$s      = "SELECT * FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts WHERE orders.pid = posts.ID AND orders.id = {$order_id}";
					$r      = $wpdb->get_results( $s );
					$row    = $r[0];
					$oid    = $row->id;
					$pid    = $row->pid;
					$buyer  = $row->uid;
					$seller = $row->post_author;

					if ( ( $row->closed != 1 && $row->completed != 1 ) || ( $row->closed != 1 && $row->clearing_period == 3 ) ) {

						$s1 = "UPDATE {$wpdb->prefix}job_orders SET closed = '1', force_cancellation = '1', payment_status = 'cancelled', date_closed = '{$tm}' WHERE id = {$order_id}";
						$wpdb->query( $s1 );

						// Insert to chatbox
						$row_exist = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}job_chatbox WHERE datemade = %d AND uid = -14 AND oid = %d", current_time( 'timestamp', 1 ), $order_id ) );

						if ( ! $row_exist ) {
							$wpdb->insert(
								$wpdb->prefix . 'job_chatbox',
								array(
									'datemade' => current_time( 'timestamp', 1 ),
									'uid'      => -14,
									'oid'      => $order_id,
									'content'  => __( 'Closed by Admin', 'wpjobster' )
								),
								array( '%d', '%d', '%d', '%s' )
							);

							$this_notification = $wpdb->insert_id;

							wpj_update_user_notifications( array(
								'user1'       => $seller,
								'user2'       => $buyer,
								'type'        => 'notifications',
								'number'      => +1,
								'notify_id'   => $this_notification,
								'notify_type' => 'cancel_admin',
								'order_id'    => $oid
							) );

							wpj_refund_payment( $row, $order_id );

							if ( wpj_is_custom_offer( $pid ) ) {
								wpj_cancel_custom_offer( 'cancel_offer_admin', $pid, $oid, $seller, $buyer );
								wpj_deactivate_custom_offer( 'closed', $pid, $seller );

							} else {
								wpj_notify_user_translated( 'cancel_admin', $buyer, array( '##transaction_number##' => wpj_camouflage_oid( $oid, $row->date_made ), '##transaction_page_link##' => wpj_get_order_link( $oid ), '##job_name##' => $row->post_title, '##job_link##' => urldecode( get_permalink( $pid ) ) ), '', 'email' );

								wpj_notify_user_translated( 'cancel_admin', $seller, array( '##transaction_number##' => wpj_camouflage_oid( $oid, $row->date_made ), '##transaction_page_link##' => wpj_get_order_link( $oid ), '##job_name##' => $row->post_title, '##job_link##' => urldecode( get_permalink( $pid ) ) ), '', 'email' );

							}

							do_action( 'wpj_after_order_is_cancelled', $oid, 'job_purchase' );
						}

					} else { ?>

						<div class="notice notice-error is-dismissible">
							<p><?php _e( 'You can\'t close a completed order.', 'wpjobster' ); ?></p>
						</div>

					<?php }
				}
			}
		}
	}

	public function clearJob() {
		// Clear now
		if ( isset( $_GET['idclear'] ) ) {
			global $wpdb;

			$order = wpj_get_order( $_GET['idclear'] );

			if ( $order->clearing_period != 1 ) {

				wpj_mark_order_as_cleared( $_GET['idclear'] );

				$wpdb->update(
					$wpdb->prefix . 'job_orders',
					array(
						'clearing_period' => 1,
					),
					array( 'id' => $_GET['idclear'] ),
					array(
						'%d',
					),
					array( '%d' )
				);
			}
		}

		// Block clear
		if ( isset( $_GET['idblockclear'] ) ) {
			global $wpdb;

			$order_info = wpj_get_order( $_GET['idblockclear'] );

			if ( $order_info->clearing_period == 2 ) {
				$wpdb->update(
					$wpdb->prefix . 'job_orders',
					array(
						'clearing_period' => 3,
					),
					array( 'id' => $_GET['idblockclear'] ),
					array(
						'%d',
					),
					array( '%d' )
				);
			}
		}
	}

	public function deleteReview() {
		global $wpdb;

		$row_review = $wpdb->get_results("
			SELECT *
			FROM {$wpdb->prefix}job_ratings
			WHERE id = {$_POST['id']}
		");

		$orderid = $row_review[0]->orderid;

		$wpdb->query( "DELETE FROM {$wpdb->prefix}job_ratings_by_seller WHERE orderid = {$orderid} LIMIT 1" );
		$wpdb->query( "DELETE FROM {$wpdb->prefix}job_ratings WHERE id = {$_POST['id']}" );

		wp_die();
	}

	public function deleteReviewResponse() {
		global $wpdb;

		$wpdb->query( "DELETE FROM {$wpdb->prefix}job_ratings_by_seller WHERE id = {$_POST['id']}" );

		wp_die();
	}

	public function deleteTransactionMessage() {
		global $wpdb;

		$message_id = $_POST['id'];

		$chatbox_message = wpj_get_chatbox_message( $message_id );

		if ( $chatbox_message ) {
			$order = wpj_get_order( $chatbox_message->oid );

			$wpdb->query( "DELETE FROM {$wpdb->prefix}job_chatbox WHERE id = {$message_id}" );

			wpj_refresh_user_notifications( wpj_get_seller_id( $order ), 'notifications' );
			wpj_refresh_user_notifications( $order->uid, 'notifications' );
		}

		wp_die();
	}

	public function initializeBankTransfer( $payment_type, $order_details ) {

		$orderid = $order_details['id'];

		if ( $payment_type == 'job_purchase' ) $uid = $order_details['uid'];
		else $uid = $order_details['user_id'];

		$payment_row = wpj_get_payment( array( 'payment_type_id' => $order_details['id'], 'payment_type' => $payment_type ) );

		if ( $payment_type == 'topup' ) {
			$reason = 'send_bankdetails_to_topup_buyer';

		} elseif ( $payment_type == 'feature' ) {
			$reason = 'send_bankdetails_to_feature_buyer';

		} elseif ( $payment_type == 'custom_extra' ) {
			$reason = 'send_bankdetails_to_custom_extra_buyer';

		} elseif ( $payment_type == 'tips' ) {
			$reason = 'send_bankdetails_to_tips_buyer';

		} else {
			$reason = 'send_bankdetails_to_buyer';

		}

		wpj_notify_user_translated( $reason, $uid, array(
			'##bank_details##'          => nl2br( wpj_get_option( 'wpjobster_bank_details' ) ),
			'##job_name##'              => ! empty( $order_details['job_title'] ) ? $order_details['job_title'] : '',
			'##transaction_page_link##' => wpj_get_order_link( $orderid )
		) );

		wpj_notify_user_translated( 'new_bank_transfer_pending', 'admin', array(
			'##sender_username##'  => wpj_get_user_display_type( $uid ),
			'##payment_type##'     => $payment_type,
			'##payment_amount##'   => wpj_show_price_classic( $payment_row->final_amount_exchanged ),
			'##admin_orders_url##' => wpj_get_admin_order_link( $payment_type )
		) );

		if ( $orderid ) {
			if ( $payment_type == 'topup' ) {
				wp_redirect( wpj_get_order_link_by_payment_type( $payment_type, $orderid ) );

			} elseif ( $payment_type == 'feature' ) {
				wp_redirect( wpj_get_order_link_by_payment_type( 'feature', $orderid ) );

			} elseif ( $payment_type == 'custom_extra' || $payment_type == 'tips' ) {
				$order_details = wpj_get_tips_order_by( 'id', $orderid );
				wp_redirect( wpj_get_order_link( $order_details->order_id, '', $payment_type ) );

			} else {
				wp_redirect( wpj_get_order_link( $orderid ) );

			}

		} else {
			wp_redirect( get_bloginfo( 'url' ) );

		}

		exit;
	}

	public function processBankTransfer( $payment_type ) {
		if ( isset( $_GET ) ) $response_array["get"] = $_GET;
		if ( isset( $_POST ) ) $response_array["post"] = $_POST;

		parse_str( file_get_contents( "php://input" ), $response_array["php_input"] );

		$order_id = WPJ_Form::get( 'order_id', 0 );

		if ( $order_id ) {
			if ( current_user_can( 'administrator' ) ) {
				$cancel_message   = "Cancelled by admin";
				$complete_message = "Completed by admin";

			} else {
				$cancel_message = "Cancelled by buyer";

			}

			if ( isset( $_GET['action'] ) && $_GET['action'] == 'complete' ) {
				if ( current_user_can( 'administrator' ) ) {
					do_action( "wpjobster_" . $payment_type . "_payment_success", $order_id, 'banktransfer', $complete_message, json_encode( $response_array ) );

				} else {
					wp_die(
						__( 'Only admins can complete bank transfers.', 'wpjobster' ),
						__( 'Unauthorized', 'wpjobster' ),
						array( 'response' => 401 )
					);

				}

			} else {
				do_action( "wpjobster_" . $payment_type . "_payment_failed", $order_id, 'banktransfer', $cancel_message, json_encode( $response_array ) );

			}

			die();

		} else {
			wp_die(
				__( 'Missing order id.', 'wpjobster' ),
				__( 'Bad request', 'wpjobster' ),
				array( 'response' => 400 )
			);

		}
	}

	public function processPayRequest() {
		if ( ! empty( $_POST['processPayRequest'] ) ) {

			global $wpdb;
			$ids      = isset( $_POST['requests'] ) ? $_POST['requests'] : '';
			$currency = wpj_get_site_default_curreny();

			$paypal_appid     = wpj_get_option( 'wpjobster_theme_appid' );
			$paypal_appsecret = wpj_get_option( 'wpjobster_theme_appsecret' );

			if ( $paypal_appid && $paypal_appsecret ) {
				$emails = array();
				$mounts = array();
				$paypal_payout_requests_info = array();

				if ( $ids ) {
					foreach ( $ids as $id ) {
						$s   = "SELECT * FROM {$wpdb->prefix}job_withdraw WHERE id = '{$id}'";
						$row = $wpdb->get_results( $s );
						$row = $row[0];

						if ( $row->done == 0 ) {
							$paypal_email = wpj_user( $row->uid, 'paypal_email' );
							$emails[] = $paypal_email;
							$mounts[] = $row->amount;
							$paypal_payout_requests_info[$id]['email']    = $paypal_email;
							$paypal_payout_requests_info[$id]['amount']   = $row->amount;
							$paypal_payout_requests_info[$id]['userid']   = $row->uid;
							$paypal_payout_requests_info[$id]['uniqueid'] = $id;

						}
					}
				}

				if ( ! empty( $emails ) ) {
					include_once get_template_directory() . '/lib/plugins/wpjobster-paypal/lib/paypal-withdrawal/vendor/paypal/rest-api-sdk-php/wpj/payment.php';

				} else {
					echo '
						<div class="notice notice-error is-dismissible">
							<p>' . __( 'No Paypal order selected!', 'wpjobster' ) . '</p>
						</div>
					';

				}
			} else {
				echo '
					<div class="notice notice-error is-dismissible">
						<p>' . __( 'PayPal Client ID and PayPal Secret are blank!', 'wpjobster' ) . '</p>
					</div>
				';

			}
		}
	}

	public function acceptWithdrawalRequest( $order_id = '' ) {
		if ( is_numeric( $order_id ) ) {
			global $wpdb;

			$tm = current_time( 'timestamp', 1 );

			$s   = "SELECT * FROM {$wpdb->prefix}job_withdraw WHERE id = '{$order_id}'";
			$row = $wpdb->get_results( $s );
			$row = $row[0];

			if ( $row->done == 0 || $row->done == -2 ) {

				$wpdb->query( "UPDATE {$wpdb->prefix}job_withdraw SET done = '1', datedone = '{$tm}' WHERE id = '{$order_id}'" );

				wpj_notify_user_translated( 'withdraw_compl', $row->uid, array( '##amount_withdrawn##' => wpj_show_price_classic( $row->amount ), '##withdraw_method##' => wpj_translate_string( $row->methods ) ), '', 'email' );

				$details = wpj_translate_string( $row->methods ) . ': ' . $row->payeremail;
				$reason  = __( 'Withdrawal to', 'wpjobster' ) . ' ' . $details;

				wpj_add_history_log( array( 'tp' => '0', 'reason' => $reason, 'amount' => $row->amount, 'uid' => $row->uid, 'rid' => 9, 'payed_amt' => $details ) );
			}
		}
	}

	public function denyWithdrawalRequest( $order_id = '' ) {
		if ( is_numeric( $order_id ) ) {
			global $wpdb;

			$tm = current_time( 'timestamp', 1 );

			$s   = "SELECT * FROM {$wpdb->prefix}job_withdraw where id='{$order_id}'";
			$row = $wpdb->get_results( $s );
			$row = $row[0];

			if ( $row->done == 0 ) {
				$wpdb->query( "UPDATE {$wpdb->prefix}job_withdraw SET done = '-1', rejected_on = '{$tm}', rejected = '1', datedone = '{$tm}' WHERE id='{$order_id}'" );

				wpj_notify_user_translated( 'withdraw_decl', $row->uid, array( '##amount_withdrawn##' => wpj_show_price_classic( $row->amount ), '##withdraw_method##' => wpj_translate_string( $row->methods ) ), '', 'email' );

				$ucr = wpj_get_user_credit( $row->uid );
				wpj_update_user_credit( $row->uid, $ucr + $row->amount );
			}
		}
	}

	public function getOrderFilters( $payment_type = '' ) {
		$filters = array(
			'all'       => __( 'all', 'wpjobster' ),
			'active'    => __( 'active', 'wpjobster' ),
			'delivered' => __( 'delivered', 'wpjobster' ),
			'completed' => __( 'completed', 'wpjobster' ),
			'closed'    => __( 'closed', 'wpjobster' ),
			'pending'   => __( 'pending', 'wpjobster' ),
			'cancelled' => __( 'cancelled', 'wpjobster' ),
			'expired'   => __( 'expired', 'wpjobster' )
		);

		if ( $payment_type != 'job-purchase' && $payment_type != 'subscription' ) {
			unset( $filters['active'], $filters['delivered'], $filters['closed'], $filters['expired'] );

		} elseif ( $payment_type == 'subscription' ) {
			unset( $filters['delivered'], $filters['completed'], $filters['closed'], $filters['expired'] );

		}

		return $filters;
	}

	public function getClassNameByPaymentType( $payment_type = '' ) {
		if ( $payment_type == 'job-purchase' ) {
			return 'job_purchase';

		} elseif ( $payment_type == 'withdrawal' ) {
			return 'job_purchase';

		} elseif ( $payment_type == 'custom-extra' ) {
			return 'custom_extra';

		} else {
			return $payment_type;

		}
	}

	public function getActiveTabInfo( $payment_type = '' ) {
		$tab_name = '';
		$inp_name = '';
		$pgn_name = '';
		$btn_name = '';

		if ( $payment_type == 'job-purchase' ) {
			$tab_name = 'job-purchase';
			$pgn_name = 'pj_job_purchase';
			$inp_name = 'search_user_job_purchase';
			$btn_name = 'wpjobster_save_job_purchase';

		} elseif ( $payment_type == 'topup' ) {
			$tab_name = 'topup';
			$pgn_name = 'pj_topup';
			$inp_name = 'search_user_topup';
			$btn_name = 'wpjobster_save_topup';

		} elseif ( $payment_type == 'feature' ) {
			$tab_name = 'feature';
			$pgn_name = 'pj_feature';
			$inp_name = 'search_user_feature';
			$btn_name = 'wpjobster_save_feature';

		} elseif ( $payment_type == 'withdrawal' ) {
			$tab_name = 'withdrawal';
			$pgn_name = 'pj_withdrawal';
			$inp_name = 'search_user_withdrawal';
			$btn_name = 'wpjobster_save_withdrawal';

		} elseif ( $payment_type == 'custom-extra' ) {
			$tab_name = 'custom-extra';
			$pgn_name = 'pj_custom_extra';
			$inp_name = 'search_user_custom_extra';
			$btn_name = 'wpjobster_save_custom_extra';

		} elseif ( $payment_type == 'tips' ) {
			$tab_name = 'tips';
			$pgn_name = 'pj_tips';
			$inp_name = 'search_user_tips';
			$btn_name = 'wpjobster_save_tips';

		} elseif ( $payment_type == 'subscription' ) {
			$tab_name = 'subscription';
			$pgn_name = 'pj_subscription';
			$inp_name = 'search_user_subscription';
			$btn_name = 'wpjobster_save_subscription';

		}

		return array(
			'at'  => $tab_name,
			'inp' => $inp_name,
			'pg'  => $pgn_name,
			'sb'  => $btn_name
		);
	}

	public function getRowValues( $payment_type = '', $row = array() ) {
		$values = array();

		if ( $payment_type == 'job-purchase' || $payment_type == 'custom-extra' || $payment_type == 'tips' ) {
			if ( $payment_type == 'job-purchase' ) {
				$pid       = $row->pid;
				$date_made = $row->date_made;

				$deciphered_amount = explode( '|', $row->payedamount );
				$currency          = $deciphered_amount[0];
				$total_amount      = $deciphered_amount[1] + wpj_get_custom_extras_amount( $row, 'amount' );
				$amount            = $currency . '|' . apply_filters( 'wpj_admin_order_list_amount_filter', $total_amount, $row, 'job_purchase' );

				$buyer     = get_userdata( $row->uid );
				$gateway   = $row->payment_gateway;

				$order = wpj_get_order( $row->id );

				if ( $row->done_seller == 1 && $row->done_buyer == 0 ) {
					$payment_status = __( 'Delivered', 'wpjobster' );

				} elseif ( $row->done_buyer == 1 && $row->done_seller == 1 ) {
					$payment_status = __( 'Completed', 'wpjobster' );

				} elseif ( $row->done_seller == 0 && $row->done_buyer == 0 && $row->payment_status == 'completed' ) {
					$payment_status = __( 'Waiting for the seller to confirm', 'wpjobster' );

				} elseif ( $row->payment_status == 'pending' ) {
					$payment_status = __( 'Pending', 'wpjobster' );

				} elseif ( $row->payment_status == 'cancelled' ) {
					$payment_status = __( 'Cancelled', 'wpjobster' );

				} else {
					$payment_status = $row->payment_status;

				}

			} else {

				$order = wpj_get_order( $row->order_id );

				if ( $payment_type == 'custom-extra' ) {
					$custom_extras = json_decode( $order->custom_extras );
					$custom_extra  = $custom_extras[$row->custom_extra_id];

					$ce_payedamount = $custom_extra->price;
					if ( isset( $custom_extra->processing_fees ) ) $ce_payedamount += $custom_extra->processing_fees;
					if ( isset( $custom_extra->tax ) ) $ce_payedamount += $custom_extra->tax;
				}

				$pid       = $order->pid;
				$date_made = $row->added_on;
				$amount    = $row->currency . '|' . ( $payment_type == 'custom-extra' ? $ce_payedamount : $row->payable_amount );
				$buyer     = get_userdata( $row->user_id );
				$gateway   = $row->payment_gateway_name;

			}

			$post   = get_post( $pid );
			$seller = isset( $post->post_author ) ? get_userdata( $post->post_author ) : '';

			$additional_price_info = apply_filters( 'wpj_admin_order_list_price_info_filter', false, $order, $amount );

			$values = array(
				'#' . wpj_camouflage_oid( $row->id, $date_made ),
				'<a href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&order_id=' . $row->id . '&order_view=order_single_page&payment_type=' . $payment_type . '&active_tab=' . $payment_type . '">' . __( 'View Order Details', 'wpjobster' ) . '</a>',
				'<a href="' . get_permalink( $pid ) . '">' . ( isset( $post->post_title ) ? $post->post_title : '' ) . '</a>',
				wpj_deciphere_amount_classic( $amount ) . $additional_price_info,
				wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $date_made ),
				isset( $buyer->ID ) ? wpj_get_user_display_type( $buyer->ID ) : sprintf( __( 'Deleted User (ID: %d)', 'wpjobster' ), $row->uid ),
				isset( $seller->ID ) ? wpj_get_user_display_type( $seller->ID ) : sprintf( __( 'Deleted User (ID: %d)', 'wpjobster' ), ( isset( $post->post_author ) ? $post->post_author : '' ) ),
				$gateway,
				$row->payment_status,
			);

			if ( $payment_type == 'job-purchase' ) { $values[] = $payment_status; }

		} elseif ( $payment_type == 'topup' || $payment_type == 'feature' ) {
			$user   = get_userdata( $row->user_id );
			$amount = $payment_type == 'topup' ? wpj_get_exchanged_value( $row->package_cost_without_tax, $row->currency, wpj_get_site_default_curreny() ) : $row->featured_amount;

			$values = array(
				'#' . wpj_camouflage_oid( $row->id, $row->added_on ),
				'<a href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&order_id=' . $row->id . '&order_view=order_single_page&payment_type=' . $payment_type . '&active_tab=' . $payment_type . '">' . __( 'View Order Details', 'wpjobster' ) . '</a>',
				wpj_show_price_classic( $amount ),
				wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->added_on ),
				wpj_get_user_display_type( $user->ID ),
				$row->payment_gateway_name,
				$row->payment_status
			);

		} elseif ( $payment_type == 'withdrawal' ) {
			$user = get_userdata( $row->uid );
			if ( $row->done == 1 ) {
				$status = __( 'Completed', 'wpjobster' );
			} elseif ( $row->done == -1 && $row->rejected == 1 ) {
				$status = __( 'Rejected', 'wpjobster' );
			} elseif ( $row->done == -2 ) {
				$status = __( 'Processing', 'wpjobster' );
			} else {
				$status = __( 'Pending', 'wpjobster' );
			}

			$values = array(
				'#' . wpj_camouflage_oid( $row->id, $row->datemade ),
				'<a href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&order_id=' . $row->id . '&order_view=order_single_page&payment_type=' . $payment_type . '&active_tab=' . $payment_type . '">' . __( 'View Order Details', 'wpjobster' ) . '</a>',
				wpj_deciphere_amount_classic( $row->payedamount ),
				wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->datemade ),
				wpj_get_user_display_type( $user->ID ),
				$row->payeremail,
				$row->methods,
				$status
			);

		} elseif ( $payment_type == 'subscription' ) {
			$user = get_userdata( $row->user_id );
			$level_name = wpj_get_option( 'wpjobster_subscription_name_level' . preg_replace( "/[^0-9\.]/", '', $row->level ) );
			$level_name = $level_name ? ' (' . $level_name . ')' : '';

			$values = array(
				'#' . wpj_camouflage_oid( $row->id, $row->addon_date ),
				'<a href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&order_id=' . $row->id . '&order_view=order_single_page&payment_type=' . $payment_type . '&active_tab=' . $payment_type . '">' . __( 'View Order Details', 'wpjobster' ) . '</a>',
				wpj_deciphere_amount_classic( $row->mc_currency . '|' . $row->payable_amount ),
				wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->addon_date ),
				wpj_get_user_display_type( $user->ID ),
				$row->level . $level_name,
				$row->plan,
				$row->payment_gateway_name,
				strtolower( $row->payment_status )
			);

		}

		return $values;
	}

	public function getRowQuery( $payment_type = '', $filter = '', $rows_per_page = 10, $pageno = 1, $limited = false ) {
		global $wpdb;

		$page_info = $this->getActiveTabInfo( $payment_type );

		$user = WPJ_Form::get( $page_info['inp'], '' );
		$uid = ctype_digit( $user ) || is_int( $user ) ? $user : '';
		if ( ! $uid ) {
			$query  = "SELECT ID FROM {$wpdb->users} WHERE user_login = '{$user}'";
			$result = $wpdb->get_results( $query );
			$uid = count( $result ) > 0 ? $result[0]->ID : '';
		}

		$query = '';
		if ( $payment_type == 'job-purchase' ) {
			$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts WHERE posts.ID = orders.pid";

			if ( $filter == 'active' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.ID = orders.pid
						AND orders.done_seller = '0'
						AND orders.done_buyer = '0'
						AND orders.date_finished = '0'
						AND orders.closed = '0'
						AND orders.payment_status != 'cancelled'
						AND orders.payment_status != 'pending'
				";

			} elseif( $filter == 'delivered' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.ID = orders.pid
					AND orders.done_seller = '1'
					AND orders.done_buyer = '0'
					AND orders.closed = '0'
				";

			} elseif( $filter == 'completed' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.ID = orders.pid
						AND orders.done_seller = '1'
						AND orders.done_buyer = '1'
						AND orders.closed = '0'
				";

			} elseif( $filter == 'closed' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.ID = orders.pid
						AND orders.closed = '1'
				";

			} elseif( $filter == 'pending' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.ID = orders.pid
						AND orders.payment_status = 'pending'
				";

			} elseif( $filter == 'cancelled' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.ID = orders.pid
						AND orders.payment_status = 'cancelled'
				";

			} elseif( $filter == 'expired' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_orders orders, {$wpdb->prefix}posts posts
					WHERE posts.ID = orders.pid
						AND orders.payment_status = 'expired'
				";

			}

			if ( $uid ) { $query .= " AND ( orders.uid = {$uid} OR posts.post_author = {$uid} )"; }

		} elseif ( $payment_type == 'topup' ) {
			$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_topup_orders orders WHERE 1=1";

			if ( $filter == 'completed' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_topup_orders orders
					WHERE orders.payment_status = 'completed'
				";

			} elseif( $filter == 'pending' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_topup_orders orders
					WHERE orders.payment_status = 'pending'
				";

			} elseif( $filter == 'cancelled' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_topup_orders orders
					WHERE orders.payment_status = 'cancelled'
				";

			}

			if ( $uid ) { $query .= " AND orders.user_id = {$uid}"; }

		} elseif ( $payment_type == 'feature' ) {
			$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_featured_orders orders WHERE 1=1";

			if ( $filter == 'completed' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_featured_orders orders
					WHERE orders.payment_status = 'completed'
				";

			} elseif( $filter == 'pending' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_featured_orders orders
					WHERE orders.payment_status = 'pending'
				";

			} elseif( $filter == 'cancelled' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_featured_orders orders
					WHERE orders.payment_status = 'cancelled'
				";

			}

			if ( $uid ) { $query .= " AND orders.user_id = {$uid}"; }

		} elseif ( $payment_type == 'withdrawal' ) {
			$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_withdraw orders WHERE ( activation_key is NULL or activation_key = '' )";

			if ( $filter == 'completed' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_withdraw orders
					WHERE orders.done = '1'
				";

			} elseif( $filter == 'pending' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_withdraw orders
					WHERE ( orders.done = '0' OR orders.done = '-2' )
					AND ( activation_key is NULL or activation_key = '' )
				";

			} elseif( $filter == 'cancelled' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_withdraw orders
					WHERE orders.rejected = '1'
				";

			}

			if ( $uid ) { $query .= " AND orders.uid = {$uid}"; }

		} elseif ( $payment_type == 'custom-extra' ) {
			$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_custom_extra_orders orders WHERE 1=1";

			if ( $filter == 'completed' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_custom_extra_orders orders
					WHERE orders.payment_status = 'completed'
				";

			} elseif( $filter == 'pending' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_custom_extra_orders orders
					WHERE orders.payment_status = 'pending'
				";

			} elseif( $filter == 'cancelled' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_custom_extra_orders orders
					WHERE orders.payment_status = 'cancelled'
				";

			}

			if ( $uid ) { $query .= " AND orders.user_id = {$uid}"; }

		} elseif ( $payment_type == 'tips' ) {
			$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_tips_orders orders WHERE 1=1";

			if ( $filter == 'completed' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_tips_orders orders
					WHERE orders.payment_status = 'completed'
				";

			} elseif( $filter == 'pending' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_tips_orders orders
					WHERE orders.payment_status = 'pending'
				";

			} elseif( $filter == 'cancelled' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_tips_orders orders
					WHERE orders.payment_status = 'cancelled'
				";

			}

			if ( $uid ) { $query .= " AND orders.user_id = {$uid}"; }

		} elseif ( $payment_type == 'subscription' ) {
			$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_subscription_orders orders WHERE 1=1";

			if ( $filter == 'active' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_subscription_orders orders
					WHERE orders.subscription_status = 'active'
				";

			} elseif( $filter == 'pending' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_subscription_orders orders
					WHERE orders.payment_status = 'pending'
				";

			} elseif( $filter == 'cancelled' ) {
				$query = "
					SELECT DISTINCT *
					FROM {$wpdb->prefix}job_subscription_orders orders
					WHERE orders.payment_status = 'cancelled'
				";

			}

			if ( $uid ) { $query .= " AND orders.user_id = {$uid}"; }

		}

		$query .= " ORDER BY orders.id DESC";

		if ( $limited ) {
			$query .= " LIMIT " . ( $pageno - 1 ) * $rows_per_page . ',' . $rows_per_page;
		}

		return $query;
	}

	public function getCountOfOrders( $payment_type = '', $filter = '' ) {
		global $wpdb;

		$query   = $this->getRowQuery( $payment_type, $filter );
		$results = $wpdb->get_results( $query );
		$count   = $results ? count( $results ) : 0;

		return $count;
	}

	public function getOrderRow( $payment_type = '', $filter = '' ) {
		$r = array( 'all' => '', 'limited' => '', 'lastpage' => '', 'pageno' => '' );

		global $wpdb;

		$rows_per_page = 10;

		$page_info = $this->getActiveTabInfo( $payment_type );
		$pg = $page_info['pg'];
		if ( isset( $_GET[$pg] ) ) $pageno = $_GET[$pg];
		else $pageno = 1;

		$s1 = $this->getRowQuery( $payment_type, $filter, $rows_per_page, $pageno, false );
		$s  = $this->getRowQuery( $payment_type, $filter, $rows_per_page, $pageno, true );

		$nr       = count( $wpdb->get_results( $s1 ) );
		$lastpage = ceil( $nr / $rows_per_page );

		$r = array(
			'all'      => $wpdb->get_results( $s ),
			'limited'  => $wpdb->get_results( $s1 ),
			'lastpage' => $lastpage,
			'pageno'   => $pageno
		);

		return $r;
	}

	public function getActionText( $row = array(), $payment_type = '', $filter = '' ) {
		$filter = $filter ? '&status=' . $filter : '';

		$mark_paid = '
			<a title="' . __( 'Mark payment completed', 'wpjobster' ) . '" href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&order_id=' . $row->id . '&order_action=mark_as_paid&payment_type=' . $payment_type . '&active_tab=' . $payment_type . $filter . '" class="awesome tltp_cls mark-order-completed' . ( isset( $row->methods ) ? ' ' . sanitize_title( $row->methods ) : '' ) . '">
				<span class=""><i class="check icon"></i></span>
			</a>
		';

		$mark_paid_manual = '
			<a title="' . __( 'Mark payment manual as completed', 'wpjobster' ) . '" href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&order_id=' . $row->id . '&order_action=mark_as_paid&payment_type=' . $payment_type . '&active_tab=' . $payment_type . $filter . '" class="awesome tltp_cls' . ( isset( $row->methods ) ? ' ' . sanitize_title( $row->methods ) : '' ) . '">
				<span class=""><i class="check icon"></i></span>
			</a>
		';

		$mark_paid_automatical = '
			<a title="' . __( 'Mark payment automatically as completed', 'wpjobster' ) . '" href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&order_id=' . $row->id . '&order_action=mark_as_paid&payment_type=' . $payment_type . '&active_tab=' . $payment_type . $filter . '" class="awesome tltp_cls mark-order-completed' . ( isset( $row->methods ) ? ' ' . sanitize_title( $row->methods ) : '' ) . '">
				<span class=""><i class="double check icon"></i></span>
			</a>
		';

		$already_paid = '
			<span title="' . __( 'Payment already completed', 'wpjobster' ) . '" class="tltp_cls" style="color: #ddd;"><i class="check icon"></i></span>
		';

		$order_cancelled = '
			<span title="' . __( 'Payment already cancelled', 'wpjobster' ) . '" class="tltp_cls" style="color: #ddd;"><i class="check icon"></i></span>
		';

		$mark_cancel = '
			<a title="' . __( 'Mark payment cancelled', 'wpjobster' ) . '" href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&order_id=' . $row->id . '&order_action=mark_as_cancelled&payment_type=' . $payment_type . '&active_tab=' . $payment_type . $filter . '" class="awesome tltp_cls">
				<span class=""><i class="minus icon"></i></span>
			</a>';

		$mark_cancel_disabled = '
			<span title="' . __( 'You can\'t cancel this payment', 'wpjobster' ) . '" class="tltp_cls" style="color: #ddd;"><i class="minus icon"></i></span>
		';

		$close_job = '
			<a href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&idclose=' . $row->id . '&payment_type=' . $payment_type . '&active_tab=' . $payment_type . $filter . '" class="tltp_cls awesome" title="' . __( 'Force close order', 'wpjobster' ) . '">
				<span class=""><i class="remove icon"></i></span>
			</a>
		';

		$close_job_disabled = '
			<span title="' . __( 'You can\'t close this order', 'wpjobster' ) . '" class="tltp_cls" style="color: #ddd;"><i class="remove icon"></i></span>
		';

		$mark_cleared = '
			<a href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&idclear=' . $row->id . '&payment_type=' . $payment_type . '&active_tab=' . $payment_type . $filter . '" class="tltp_cls awesome" title="' . __( 'Clear now', 'wpjobster' ) . '">
				<span class=""><i class="clock icon"></i></span>
			</a>
		';

		$already_cleared = '
			<span title="' . __( 'Already cleared', 'wpjobster' ) . '" class="tltp_cls" style="color: #ddd;"><i class="clock icon"></i></span>
		';

		$block_clearing = '
			<a href="' . get_bloginfo( 'url' ) . '/wp-admin/admin.php?page=jobster-orders&idblockclear=' . $row->id . '&payment_type=' . $payment_type . '&active_tab=' . $payment_type . $filter . '" class="tltp_cls awesome" title="' . __( 'Block the clearing', 'wpjobster' ) . '">
				<span class=""><i class="ban icon"></i></span>
			</a>
		';

		$already_blocked = '
			<span title="' . __( 'Clearing already blocked. You can clear the order anytime or you can close the order to refund the payment.', 'wpjobster' ) . '" class="tltp_cls" style="color: #f1990d;"><i class="ban icon"></i></span>
		';

		$block_disabled = '
			<span title="' . __( 'You can\'t block the clearing because the order is already cleared', 'wpjobster' ) . '" class="tltp_cls" style="color: #ff0000;"><i class="ban icon"></i></span>
		';

		$block_order_complete = '
			<span title="' . __( 'The order needs to be completed to be cleared', 'wpjobster' ) . '" class="tltp_cls" style="color: #ddd;"><i class="clock icon"></i></span>
		';

		$clear_order_complete = '
			<span title="' . __( 'The order needs to be completed to block the clearing or the order is already cleared', 'wpjobster' ) . '" class="tltp_cls" style="color: #ddd;"><i class="ban icon"></i></span>
		';

		return array(
			'paid'               => $mark_paid,
			'paid_manual'        => $mark_paid_manual, // manual withdrawal
			'paid_automatical'   => $mark_paid_automatical, // automatic withdrawal
			'already_paid'       => $already_paid,
			'order_cancelled'    => $order_cancelled,
			'cancel'             => $mark_cancel,
			'cancel_disabled'    => $mark_cancel_disabled,
			'close_job'          => $close_job,
			'close_job_disabled' => $close_job_disabled,
			'cleared'            => $mark_cleared,
			'already_cleared'    => $already_cleared,
			'block_clearing'     => $block_clearing,
			'already_blocked'    => $already_blocked,
			'block_disabled'     => $block_disabled,
			'block_ord_cmp'      => $block_order_complete,
			'clear_ord_cmp'      => $clear_order_complete
		);
	}

	public function showOrderActions( $payment_type = '', $filter = '', $row = array() ) {
		$action_text = $this->getActionText( $row, $payment_type, $filter );

		if ( $payment_type == 'job-purchase' ) { /* JOB ORDERS */
			if ( $row->payment_status == 'pending' ) {
				echo $action_text['paid']; // mark paid
				echo $action_text['cancel']; // cancel
				echo $action_text['block_ord_cmp']; // block disabled
				echo $action_text['clear_ord_cmp']; // clear disabled
				echo $action_text['close_job']; // close job

			} elseif ( $row->payment_status == 'failed' || $row->payment_status == 'cancelled' || $row->payment_status == 'expired' ) {
				echo $action_text['already_paid']; // already paid
				echo $action_text['cancel_disabled']; // cancel disabled
				echo $action_text['block_ord_cmp']; // block disabled
				echo $action_text['clear_ord_cmp']; // clear disabled
				echo $action_text['close_job_disabled']; // cancel disabled

			} elseif ( $row->clearing_period == 3 ) {
				echo $action_text['already_paid']; // already paid
				echo $action_text['cancel_disabled']; // cancel disabled
				echo $action_text['cleared']; // mark cleared
				echo $action_text['already_blocked']; // already blocked
				echo $action_text['close_job']; // close job

			} else {
				echo $action_text['already_paid']; // already paid
				echo $action_text['cancel_disabled']; // cancel disabled

				if ( $row->done_seller == 1 && $row->done_buyer == 1 && $row->closed != 1 ) {
					if ( $row->clearing_period != 1 ) {
						echo $action_text['cleared']; // mark cleared
					} else {
						echo $action_text['already_cleared']; // already cleared
					}

					if ( $row->clearing_period == 2 ) {
						echo $action_text['block_clearing']; // block the clearing
					} elseif ( $row->clearing_period == 3 ) {
						echo $action_text['already_blocked']; // already blocked
					} else {
						echo $action_text['block_disabled']; // blocked disabled
					}
				} else {
					echo $action_text['block_ord_cmp']; // block disabled
					echo $action_text['clear_ord_cmp']; // clear disabled
				}

				if ( $row->closed != 1 && $row->completed != 1 )
					echo $action_text['close_job']; // close job
				else
					echo $action_text['close_job_disabled']; // cancel disabled

			}

		} elseif ( $payment_type == 'withdrawal' ) { /* WITHDRAWAL ORDERS */
			if ( $filter != 'completed' ) { // if order is not completed or closed
				if ( $row->done == '0' ) {
					$show_manual_btn = apply_filters( 'wpj_show_hide_manual_withdrawal_button_filter', true, $row );
					if ( $show_manual_btn ) {
						echo $action_text['paid_manual']; // mark paid manual
					}

					$configuration_id     = apply_filters( 'wpj_withdrawal_id_filter', wpj_get_option( 'wpjobster_theme_appid' ) );
					$configuration_secret = apply_filters( 'wpj_withdrawal_password_filter', wpj_get_option( 'wpjobster_theme_appsecret' ) );

					$show_automatic_btn = apply_filters( 'wpj_show_hide_automatic_withdrawal_button_filter', ( $configuration_id && $configuration_secret && strtolower( $row->methods ) == 'paypal' ? true : false ), $row );

					if ( $show_automatic_btn && $filter == 'pending' ) {
						echo $action_text['paid_automatical']; // mark paid automatical
					}
					echo $action_text['cancel']; // cancel

				} elseif ( $row->rejected == '1' ) {
					echo $action_text['order_cancelled']; // order cancelled
					echo $action_text['cancel_disabled']; // cancel disabled

				} else {
					echo $action_text['already_paid']; // already paid
					echo $action_text['cancel_disabled']; // cancel disabled

				}

			} else {
				echo $action_text['already_paid']; // already paid
				echo $action_text['cancel_disabled']; // cancel disabled

			}

		} elseif ( $payment_type == 'subscription' ) { /* SUBSCRIPTION ORDERS */
			if ( $row->payment_status != 'failed' && $row->payment_status != 'cancelled' ) {
				if ( $row->payment_status == 'pending' ) {
					echo $action_text['paid']; // mark paid
					echo $action_text['cancel']; // cancel
					echo $action_text['close_job']; // remove subscription
				} else {
					echo $action_text['already_paid']; // already paid
					echo $action_text['cancel_disabled']; // cancel
					echo $action_text['close_job']; // remove subscription
				}

			} else {
				echo $action_text['already_paid']; // already paid
				echo $action_text['cancel_disabled']; // cancel
				echo $action_text['close_job_disabled']; // cancel disabled
			}

		} else {
			if ( $filter != 'completed' ) { // if order is not completed or closed
				if ( $row->payment_status == 'pending' ) {
					echo $action_text['paid']; // mark paid
					echo $action_text['cancel']; // cancel

				} elseif ( $row->payment_status == 'failed' || $row->payment_status == 'cancelled' ) {
					echo $action_text['order_cancelled']; // order cancelled
					echo $action_text['cancel_disabled']; // cancel disabled

				} else {
					echo $action_text['already_paid']; // already paid
					echo $action_text['cancel_disabled']; // cancel

				}

			} else {
				echo $action_text['already_paid']; // already paid
				echo $action_text['cancel_disabled']; // cancel disabled

			}
		}

		do_action( 'wpj_after_admin_order_actions', $row, $payment_type );
	}

	public function listSingleJobValues( $order_id = '', $payment_type = '', $section = '' ) {
		if ( $payment_type == 'job-purchase' ) {
			$values = $this->getJobPurchaseOrderDetails( $order_id );
		} elseif ( $payment_type == 'topup' ) {
			$values = $this->getTopupOrderDetails( $order_id );
		} elseif ( $payment_type == 'feature' ) {
			$values = $this->getFeaturedOrderDetails( $order_id );
		} elseif ( $payment_type == 'withdrawal' ) {
			$values = $this->getWithdrawalOrderDetails( $order_id );
		} elseif ( $payment_type == 'custom-extra' ) {
			$values = $this->getCustomExtraOrderDetails( $order_id );
		} elseif ( $payment_type == 'tips' ) {
			$values = $this->getTipsOrderDetails( $order_id );
		} elseif ( $payment_type == 'subscription' ) {
			$values = $this->getSubscriptionOrderDetails( $order_id );
		}

		if ( $values[$section] ) {

			echo '<table>';
				foreach ( $values[$section] as $key => $value ) {
					if ( $section == 'custom_extra' ) {
						echo '<tr><td colspan="2"><p>' . apply_filters( 'wpj_admin_custom_extra_id_string_filter', sprintf( __( 'Custom extra #%d', 'wpjobster' ), $key ), $key, $order_id ) . '</p></td></tr>';
					} elseif ( $section == 'tips' ) {
						echo '<tr><td colspan="2"><p>' . sprintf( __( 'Tips #%d', 'wpjobster' ), $key ) . '</p></td></tr>';
					} elseif ( $section == 'cancellation' ) {
						echo '<tr><td colspan="2"><p>' . __( 'Request cancellation', 'wpjobster' ) . '</p></td></tr>';
					} elseif ( $section == 'modification' ) {
						echo '<tr><td colspan="2"><p>' . __( 'Request modification', 'wpjobster' ) . '</p></td></tr>';
					} elseif ( $section == 'buyer_review' ) {
						echo '<tr><td colspan="2"><p>' . __( 'Buyer', 'wpjobster' ) . '</p></td></tr>';
					} elseif ( $section == 'seller_review' ) {
						echo '<tr><td colspan="2"><p>' . __( 'Seller', 'wpjobster' ) . '</p></td></tr>';
					} elseif ( $section == 'gateway_responses' ) {
						echo '<tr><td colspan="2"><p>' . sprintf( __( 'Response #%d', 'wpjobster' ), $key + 1 ) . '</p></td></tr>';
					}

					foreach ( $value as $key2 => $value2 ) {
						echo '<tr>';
							echo '<td><b>' . $value2['label'] . ':  </b></td>';
							echo '<td>' . $value2['value'] . '</td>';
						echo '</tr>';
					}
				}
			echo '</table>';

		} else {
			if ( $section == 'payment' || $section == 'order' ) {
				$message = __( 'No informations about this order.', 'wpjobster' );
			} elseif ( $section == 'price' ) {
				$message = __( 'No informations about prices.', 'wpjobster' );
			} elseif ( $section == 'custom_extra' ) {
				$message = __( 'No custom extras for this order.', 'wpjobster' );
			} elseif ( $section == 'tips' ) {
				$message = __( 'No tips for this order.', 'wpjobster' );
			} elseif ( $section == 'buyer_review' ) {
				$message = __( 'No review from buyer.', 'wpjobster' );
			} elseif ( $section == 'seller_review' ) {
				$message = __( 'No review from seller.', 'wpjobster' );
			} elseif ( $section == 'chatbox_messages' ) {
				$message = __( 'No messages for this order.', 'wpjobster' );
			} elseif ( $section == 'gateway_responses' ) {
				$message = __( 'No responses for this order.', 'wpjobster' );
			}

			if ( $section != 'cancellation' && $section != 'modification' ) {
				echo '<p>' . $message . '</p>';
			}

		}
	}

	public function getJobPurchaseOrderDetails( $order_id = '' ) {
		global $wpdb;

		$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_orders WHERE id = {$order_id}";
		$rows = $wpdb->get_results( $query );

		$payment_arr      = array();
		$order_arr        = array();
		$price_arr        = array();
		$custom_extra_arr = array();
		$tips_arr         = array();
		$extra_arr        = array();
		$cancellation_arr = array();
		$modification_arr = array();

		if ( $rows ) {
			foreach ( $rows as $key => $row ) {
				// Payment
				$payment_arr[$key]['status'] = array(
					'label' => __( 'Payment status', 'wpjobster' ),
					'value' => $row->payment_status
				);

				if ( $row->force_cancellation ) {
					$force_cancellation = wpj_get_order_cancellation_message( $row );
					$payment_arr[$key]['reason'] = array(
						'label' => __( 'Cancellation details', 'wpjobster' ),
						'value' => $force_cancellation['message'] . ' - ' . $force_cancellation['reason']
					);
				}

				$payment_arr[$key]['gateway'] = array(
					'label' => __( 'Payment gateway', 'wpjobster' ),
					'value' => $row->payment_gateway
				);

				if ( $row->payment_details ) {
					$payment_arr[$key]['details'] = array(
						'label' => __( 'Payment details', 'wpjobster' ),
						'value' => $row->payment_details
					);
				}

				// Order
				$buyer  = get_userdata( $row->uid );
				$post   = get_post( $row->pid );
				$seller = get_userdata( $post->post_author );

				if ( $row->clearing_period == 1 ) {
					$cleared = __( 'Yes', 'wpjobster' );
				} elseif ( $row->clearing_period == 3 ) {
					$cleared = __( 'No, blocked by admin', 'wpjobster' );
				} else {
					$cleared = __( 'No', 'wpjobster' );
				}

				$order_arr[] = array(
					'post_id'           => array(
						'label' => __( 'Post ID', 'wpjobster' ),
						'value' => $row->pid,
					),
					'order_id'          => array(
						'label' => __( 'Order ID', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_order_link( $row->id ) . '">' . $row->id . '</a>',
					),
					'job_title'         => array(
						'label' => __( 'Job Title', 'wpjobster' ),
						'value' =>  '<a href="' . get_permalink( $row->pid ) . '">' . $row->job_title . '</a>',
					),
					'buyer'             => array(
						'label' => __( 'Buyer', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $buyer->user_login ) . '">' . wpj_get_user_display_type( $buyer->ID ) . '</a>',
					),
					'seller'            => array(
						'label' => __( 'Seller', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $seller->user_login ) . '">' . wpj_get_user_display_type( $seller->ID ) . '</a>',
					),
					'date_made'         => array(
						'label' => __( 'Date made', 'wpjobster' ),
						'value' => $row->date_made ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->date_made ) : '-',
					),
					'expected_delivery' => array(
						'label' => __( 'Expected delivery', 'wpjobster' ),
						'value' => $row->expected_delivery ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->expected_delivery ) : '-',
					),
					'delivered'         => array(
						'label' => __( 'Delivered', 'wpjobster' ),
						'value' => $row->done_seller == 1 ? __( 'Yes', 'wpjobster' ) : __( 'No', 'wpjobster' ),
					),
					'completed'         => array(
						'label' => __( 'Completed', 'wpjobster' ),
						'value' => $row->done_buyer == 1 ? __( 'Yes', 'wpjobster' ) : __( 'No', 'wpjobster' ),
					),
					'date_completed'    => array(
						'label' => __( 'Completed date', 'wpjobster' ),
						'value' => $row->date_completed ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->date_completed ) : '-',
					),
					'closed'            => array(
						'label' => __( 'Closed', 'wpjobster' ),
						'value' => $row->closed == 1 ? __( 'Yes', 'wpjobster' ) : __( 'No', 'wpjobster' ),
					),
					'date_closed'       => array(
						'label' => __( 'Closed date', 'wpjobster' ),
						'value' => $row->date_closed ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->date_closed ) : '-',
					),
					'cleared'           => array(
						'label' => __( 'Cleared', 'wpjobster' ),
						'value' => $cleared,
					),
					'date_to_clear'     => array(
						'label' => __( 'Clearing date', 'wpjobster' ),
						'value' => $row->date_to_clear ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->date_to_clear ) : '-',
					),
				);

				// Order Price
				$final_paid_amount = $row->final_paidamount ? explode( '|', $row->final_paidamount ) : 0;
				if ( isset( $final_paid_amount[0] ) && $final_paid_amount[0] != wpj_get_site_default_curreny() ) {
					$paid_amount = wpj_get_exchanged_value( $final_paid_amount[1], $final_paid_amount[0], wpj_get_site_default_curreny() );
				} else {
					$paid_amount = $final_paid_amount[1];
				}

				$price_arr[] = array(
					'job_price'       => array(
						'label' => __( 'Job price', 'wpjobster' ),
						'value' => wpj_show_price_classic( $row->job_price ),
					),
					'processing_fees' => array(
						'label' => __( 'Processing fees', 'wpjobster' ),
						'value' => wpj_show_price_classic( $row->processing_fees ),
					),
					'site_fees'       => array(
						'label' => __( 'Site fees', 'wpjobster' ),
						'value' => wpj_show_price_classic( $row->site_fees ),
					),
					'tax_amount'      => array(
						'label' => __( 'Tax', 'wpjobster' ),
						'value' => wpj_show_price_classic( $row->tax_amount ),
					),
					'admin_fee'       => array(
						'label' => __( 'Admin fees', 'wpjobster' ),
						'value' => wpj_show_price_classic( $row->admin_fee ),
					),
					'shipping'        => array(
						'label' => __( 'Shipping', 'wpjobster' ),
						'value' => wpj_show_price_classic( $row->shipping ),
					),
					'total_paid'      => array(
						'label' => __( 'Total paid', 'wpjobster' ),
						'value' => wpj_show_price_classic( $paid_amount ),
					),
				);

				$price_arr = apply_filters( 'wpj_admin_order_details_price_info_filter', $price_arr, $order_id );

				// Extra
				for ( $i = 1; $i <= 10; $i++ ) {
					$extra_arr[] = $this->getExtraSectionValues( $row, $i );
				}
				$extra_arr[] = $this->getExtraSectionValues( $row, '_fast' );
				$extra_arr[] = $this->getExtraSectionValues( $row, '_revision' );

				// Custom extra
				$custom_extras = json_decode( $row->custom_extras );
				if ( $custom_extras ) {
					foreach ( $custom_extras as $ce_key => $ce ) {
						$custom_extra_arr[] = $this->getTipsAndCeSectionValues( $ce, 'custom_extra' );
					}
				}

				// Tips
				$tips = json_decode( $row->tips );
				if ( $tips ) {
					foreach ( $tips as $tip_key => $tip ) {
						$tips_arr[] = $this->getTipsAndCeSectionValues( $tip, 'tips' );
					}
				}

				// Cancellation and Modification
				if ( $row->request_cancellation_from_seller == 1 || $row->request_cancellation_from_buyer == 1 ) {
					$cancellation_accepted = $row->accept_cancellation_request == 1 ? __( 'Yes', 'wpjobster' ) : __( 'No', 'wpjobster' );
				}

				$cancellation_arr[] = array(
					'cancelled_by_buyer'         => array(
						'label' => __( 'Buyer request cancellation', 'wpjobster' ),
						'value' => $row->request_cancellation_from_buyer == 1 ? __( 'Yes', 'wpjobster' ) : __( 'No', 'wpjobster' ),
					),
					'cancelled_by_seller'        => array(
						'label' => __( 'Seller request cancellation', 'wpjobster' ),
						'value' => $row->request_cancellation_from_seller == 1 ? __( 'Yes', 'wpjobster' ) : __( 'No', 'wpjobster' ),
					),
					'cancelled_by_admin'         => array(
						'label' => __( 'Admin cancelled the order', 'wpjobster' ),
						'value' => $row->force_cancellation == 1 ? __( 'Yes', 'wpjobster' ) : __( 'No', 'wpjobster' ),
					),
					'cancellation_date'          => array(
						'label' => __( 'Request cancellation date', 'wpjobster' ),
						'value' => $row->date_request_cancellation ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->date_request_cancellation ) : '-',
					),
					'cancellation_accepted'      => array(
						'label' => __( 'Cancellation accepted', 'wpjobster' ),
						'value' => isset( $cancellation_accepted ) ? $cancellation_accepted : '-',
					),
					'cancellation_accepted_date' => array(
						'label' => __( 'Cancellation accepted date', 'wpjobster' ),
						'value' => $row->date_accept_cancellation ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->date_accept_cancellation ) : '-',
					),
				);

				$modification_arr[] = array(
					'request_modification'         => array(
						'label' => __( 'Request modification', 'wpjobster' ),
						'value' => $row->request_modification == 1 ? __( 'Yes', 'wpjobster' ) : __( 'No', 'wpjobster' ),
					),
					'request_modification_date'    => array(
						'label' => __( 'Request modification date', 'wpjobster' ),
						'value' => $row->date_request_modification ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->date_request_modification ) : '-',
					),
					'request_modification_message' => array(
						'label' => __( 'Request modification message', 'wpjobster' ),
						'value' => $row->message_request_modification ? $row->message_request_modification : '-',
					),
				);

				// Gateway responses
				$responses_arr     = array();
				$responses_query   = "SELECT DISTINCT * FROM {$wpdb->prefix}job_webhooks WHERE order_id = {$row->id} AND payment_type = 'job_purchase' ORDER BY id ASC";
				$responses_results = $wpdb->get_results( $responses_query );

				foreach ( $responses_results as $row ) {
					$responses_arr[] = array(
						'status' => array(
							'label' => __( 'Status', 'wpjobster' ),
							'value' => $row->status,
						),
						'payment_id' => array(
							'label' => __( 'Payment ID', 'wpjobster' ),
							'value' => $row->payment_id,
						),
						'event_type' => array(
							'label' => __( 'Event Type', 'wpjobster' ),
							'value' => $row->type,
						),
						'description' => array(
							'label' => __( 'Description', 'wpjobster' ),
							'value' => $row->description,
						),
						'amount' => array(
							'label' => __( 'Amount', 'wpjobster' ),
							'value' => $row->amount . ' ' . $row->amount_currency,
						),
						'fees' => array(
							'label' => __( 'Fees', 'wpjobster' ),
							'value' => $row->fees . ' ' . $row->fees_currency,
						),
						'date' => array(
							'label' => __( 'Date', 'wpjobster' ),
							'value' => wpj_date( '', $row->create_time ),
						)
					);
				}
			}

			// Review
			$buyer_ratings_arr    = array();
			$seller_ratings_arr   = array();
			$chatbox_messages_arr = array();

			$chatbox_query   = "SELECT DISTINCT * FROM {$wpdb->prefix}job_chatbox WHERE oid = {$order_id} ORDER BY id ASC";
			$chatbox_results = $wpdb->get_results( $chatbox_query );

			foreach ( $chatbox_results as $row ) {
				// Buyer rating
				if ( $row->uid == -18 ) {
					$buyer_rating_query = "SELECT * FROM {$wpdb->prefix}job_ratings WHERE orderid = {$order_id}";
					$buyer_rating_result = $wpdb->get_results( $buyer_rating_query );
					if ( isset( $buyer_rating_result[0] ) ) {

						ob_start();
						wpj_display_rating_stars( $buyer_rating_result[0]->grade );
						$stars = ob_get_contents();
						ob_end_clean();

						$buyer_ratings_arr[] = array(
							'buyer_stars' => array(
								'label' => __( 'Buyer stars', 'wpjobster' ),
								'value' => $stars,
							),
							'buyer_message' => array(
								'label' => __( 'Buyer review', 'wpjobster' ),
								'value' => $buyer_rating_result[0]->reason,
							),
							'buyer_awarded' => array(
								'label' => __( 'Awarded On', 'wpjobster' ),
								'value' => wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $buyer_rating_result[0]->datemade ),
							),
							'buyer_action' => array(
								'label' => __( 'Delete buyer review', 'wpjobster' ),
								'value' => '<a id="delete_review" data-id="' . $buyer_rating_result[0]->id . '" class="button-secondary">' . __( 'Delete', 'wpjobster' ) . '</a>'
							)
						);
					}
				}

				// Seller rating
				if ( $row->uid == -19 ) {
					$seller_rating_query = "SELECT * FROM {$wpdb->prefix}job_ratings_by_seller WHERE orderid = {$order_id}";
					$seller_rating_result = $wpdb->get_results( $seller_rating_query );
					if ( isset( $seller_rating_result[0] ) ) {

						ob_start();
						wpj_display_rating_stars( $seller_rating_result[0]->grade );
						$stars = ob_get_contents();
						ob_end_clean();

						$seller_ratings_arr[] = array(
							'seller_stars' => array(
								'label' => __( 'Seller stars', 'wpjobster' ),
								'value' => $stars,
							),
							'seller_message' => array(
								'label' => __( 'Seller review', 'wpjobster' ),
								'value' => $seller_rating_result[0]->reason,
							),
							'seller_awarded' => array(
								'label' => __( 'Awarded On', 'wpjobster' ),
								'value' => wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $seller_rating_result[0]->datemade ),
							),
							'seller_action' => array(
								'label' => __( 'Delete seller review', 'wpjobster' ),
								'value' => '<a id="delete_review_response" data-id="' . $seller_rating_result[0]->id . '" class="button-secondary">' . __( 'Delete response', 'wpjobster' ) . '</a>'
							)
						);
					}
				}

				// Chatbox messages
				if ( $row->uid > 0 ) {
					$usr_dt = get_userdata( $row->uid );
					$chatbox_messages_arr[] = array(
						'messages' => array(
							'label' => '<a href="' . wpj_get_user_profile_link( $usr_dt->user_login ) . '">' . wpj_get_user_display_type( $usr_dt->ID ) . '</a>',
							'value' => $row->content . '&nbsp;<a class="cursor-pointer" id="delete_order_message" data-id="' . $row->id . '">' . __( 'Delete', 'wpjobster' ) . '</a>'
						)
					);
				}

			}

		}

		if ( count( array_filter( $extra_arr ) ) == 0 ) {
			$extra_arr = array();
		}

		return array(
			'payment'           => $payment_arr,
			'order'             => $order_arr,
			'price'             => $price_arr,
			'custom_extra'      => $custom_extra_arr,
			'tips'              => $tips_arr,
			'extra'             => $extra_arr,
			'cancellation'      => $cancellation_arr,
			'modification'      => $modification_arr,
			'buyer_review'      => $buyer_ratings_arr,
			'seller_review'     => $seller_ratings_arr,
			'chatbox_messages'  => $chatbox_messages_arr,
			'gateway_responses' => $responses_arr
		);

	}

	public function getTopupOrderDetails( $order_id = '' ) {
		global $wpdb;

		$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_topup_orders WHERE id = {$order_id}";
		$rows = $wpdb->get_results( $query );

		$payment_arr      = array();
		$order_arr        = array();
		$price_arr        = array();

		if ( $rows ) {
			foreach ( $rows as $key => $row ) {

				// Payment
				$payment_arr[] = array(
					'status'       => array(
						'label' => __( 'Payment status', 'wpjobster' ),
						'value' => $row->payment_status,
					),
					'gateway'      => array(
						'label' => __( 'Payment gateway', 'wpjobster' ),
						'value' => $row->payment_gateway_name,
					),
					'payment_date' => array(
						'label' => __( 'Payment date', 'wpjobster' ),
						'value' => $row->paid_on ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->paid_on ) : '-',
					),
				);

				// Order
				$user = get_userdata( $row->user_id );
				$order_arr[] = array(
					'order_id'   => array(
						'label' => __( 'Order ID', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_order_link_by_payment_type( 'topup', $row->id ) . '">' . $row->id . '</a>',
					),
					'added_date' => array(
						'label' => __( 'Date made', 'wpjobster' ),
						'value' => $row->added_on ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->added_on ) : '-',
					),
					'user_id'    => array(
						'label' => __( 'User', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $user->user_login ) . '">' . wpj_get_user_display_type( $user->ID ) . '</a>',
					),
				);

				// Price
				$price_arr[] = array(
					'pacakge_cost'    => array(
						'label' => __( 'Pacakge cost', 'wpjobster' ),
						'value' => wpj_show_price_classic ( wpj_get_exchanged_value( $row->package_cost_without_tax, $row->currency, wpj_get_site_default_curreny() ) ),
					),
					'package_credits' => array(
						'label' => __( 'Package credits', 'wpjobster' ),
						'value' => wpj_show_price_classic( wpj_get_exchanged_value( $row->package_credit_without_tax, $row->currency, wpj_get_site_default_curreny() ) ),
					),
					'tax'             => array(
						'label' => __( 'Tax', 'wpjobster' ),
						'value' => wpj_show_price_classic( wpj_get_exchanged_value( $row->tax, $row->currency, wpj_get_site_default_curreny() ) ),
					),
				);

				// Gateway responses
				$responses_arr     = array();
				$responses_query   = "SELECT DISTINCT * FROM {$wpdb->prefix}job_webhooks WHERE order_id = {$row->id} AND payment_type = 'topup' ORDER BY id ASC";
				$responses_results = $wpdb->get_results( $responses_query );

				foreach ( $responses_results as $row ) {
					$responses_arr[] = array(
						'status' => array(
							'label' => __( 'Status', 'wpjobster' ),
							'value' => $row->status,
						),
						'payment_id' => array(
							'label' => __( 'Payment ID', 'wpjobster' ),
							'value' => $row->payment_id,
						),
						'event_type' => array(
							'label' => __( 'Event Type', 'wpjobster' ),
							'value' => $row->type,
						),
						'description' => array(
							'label' => __( 'Description', 'wpjobster' ),
							'value' => $row->description,
						),
						'amount' => array(
							'label' => __( 'Amount', 'wpjobster' ),
							'value' => $row->amount . ' ' . $row->amount_currency,
						),
						'fees' => array(
							'label' => __( 'Fees', 'wpjobster' ),
							'value' => $row->fees . ' ' . $row->fees_currency,
						),
						'date' => array(
							'label' => __( 'Date', 'wpjobster' ),
							'value' => wpj_date( '', $row->create_time ),
						)
					);
				}
			}
		}

		return array(
			'payment'           => $payment_arr,
			'order'             => $order_arr,
			'price'             => $price_arr,
			'gateway_responses' => $responses_arr
		);
	}

	public function getFeaturedOrderDetails( $order_id = '' ) {
		global $wpdb;

		$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_featured_orders WHERE id = {$order_id}";
		$rows = $wpdb->get_results( $query );

		$payment_arr      = array();
		$order_arr        = array();
		$price_arr        = array();

		if ( $rows ) {
			foreach ( $rows as $key => $row ) {

				// Payment
				$payment_arr[] = array(
					'status'       => array(
						'label' => __( 'Payment status', 'wpjobster' ),
						'value' => $row->payment_status,
					),
					'gateway'      => array(
						'label' => __( 'Payment gateway', 'wpjobster' ),
						'value' => $row->payment_gateway_name,
					),
					'payment_date' => array(
						'label' => __( 'Payment date', 'wpjobster' ),
						'value' => $row->paid_on ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->paid_on ) : '-',
					),
				);

				// Order
				$user   = get_userdata( $row->user_id );
				$f_page = $this->getOrderFeaturedPages( $row );
				$order_arr[] = array(
					'order_id'       => array(
						'label' => __( 'Order ID', 'wpjobster' ),
						'value' => $row->id,
					),
					'job_id'         => array(
						'label' => __( 'Job ID', 'wpjobster' ),
						'value' => $row->job_id,
					),
					'job_title'      => array(
						'label' => __( 'Job Title', 'wpjobster' ),
						'value' =>  '<a href="' . get_permalink( $row->job_id ) . '">' . get_the_title( $row->job_id ) . '</a>',
					),
					'added_date'     => array(
						'label' => __( 'Date made', 'wpjobster' ),
						'value' => $row->added_on ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->added_on ) : '-',
					),
					'user_id'        => array(
						'label' => __( 'User', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $user->user_login ) . '">' . wpj_get_user_display_type( $user->ID ) . '</a>',
					),
					'featured_pages' => array(
						'label' => __( 'Featured job', 'wpjobster' ),
						'value' => $f_page,
					),
				);

				// Price
				$featured_amount = $row->featured_amount;
				$tax             = wpj_get_exchanged_value( $row->tax, $row->currency, wpj_get_site_default_curreny() );
				$paid_amount     = wpj_get_exchanged_value( $row->payable_amount, $row->currency, wpj_get_site_default_curreny() );
				$processing_fees = $paid_amount - $tax - $featured_amount;

				$price_arr[] = array(
					'featured_amount' => array(
						'label' => __( 'Feature price', 'wpjobster' ),
						'value' => wpj_show_price_classic( $featured_amount ),
					),
					'processing_fees' => array(
						'label' => __( 'Processing fees', 'wpjobster' ),
						'value' => wpj_show_price_classic( $processing_fees ),
					),
					'tax'             => array(
						'label' => __( 'Tax', 'wpjobster' ),
						'value' => wpj_show_price_classic( $tax ),
					),
					'paid_amount'     => array(
						'label' => __( 'Total paid amount', 'wpjobster' ),
						'value' => wpj_show_price_classic( $paid_amount ),
					),
				);

				// Gateway responses
				$responses_arr     = array();
				$responses_query   = "SELECT DISTINCT * FROM {$wpdb->prefix}job_webhooks WHERE order_id = {$row->id} AND payment_type = 'feature' ORDER BY id ASC";
				$responses_results = $wpdb->get_results( $responses_query );

				foreach ( $responses_results as $row ) {
					$responses_arr[] = array(
						'status' => array(
							'label' => __( 'Status', 'wpjobster' ),
							'value' => $row->status,
						),
						'payment_id' => array(
							'label' => __( 'Payment ID', 'wpjobster' ),
							'value' => $row->payment_id,
						),
						'event_type' => array(
							'label' => __( 'Event Type', 'wpjobster' ),
							'value' => $row->type,
						),
						'description' => array(
							'label' => __( 'Description', 'wpjobster' ),
							'value' => $row->description,
						),
						'amount' => array(
							'label' => __( 'Amount', 'wpjobster' ),
							'value' => $row->amount . ' ' . $row->amount_currency,
						),
						'fees' => array(
							'label' => __( 'Fees', 'wpjobster' ),
							'value' => $row->fees . ' ' . $row->fees_currency,
						),
						'date' => array(
							'label' => __( 'Date', 'wpjobster' ),
							'value' => wpj_date( '', $row->create_time ),
						)
					);
				}
			}
		}

		return array(
			'payment'           => $payment_arr,
			'order'             => $order_arr,
			'price'             => $price_arr,
			'gateway_responses' => $responses_arr
		);
	}

	public function getWithdrawalOrderDetails( $order_id = '' ) {
		global $wpdb;

		$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_withdraw WHERE id = {$order_id}";
		$rows = $wpdb->get_results( $query );

		$payment_arr      = array();
		$order_arr        = array();
		$price_arr        = array();

		if ( $rows ) {
			foreach ( $rows as $key => $row ) {

				// Payment
				if ( $row->done == 1 ) {
					$status = __( 'Completed by Admin', 'wpjobster' );
				} elseif ( $row->done == -1 && $row->rejected == 1 ) {
					$status = __( 'Rejected By Admin', 'wpjobster' );
				} elseif ( $row->done == -2 ) {
					$status = __( 'Processing', 'wpjobster' );
				} else {
					$status = __( 'Pending', 'wpjobster' );
				}
				$payment_arr[] = array(
					'status'        => array(
						'label' => __( 'Payment status', 'wpjobster' ),
						'value' => $status,
					),
					'gateway'       => array(
						'label' => __( 'Payment gateway', 'wpjobster' ),
						'value' => $row->methods,
					),
					'date_accepted' => array(
						'label' => __( 'Date accepted', 'wpjobster' ),
						'value' => $row->datedone ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->datedone ) : '-',
					),
					'date_rejected' => array(
						'label' => __( 'Date rejected', 'wpjobster' ),
						'value' => $row->rejected_on ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->rejected_on ) : '-',
					),
				);

				// Order
				$user = get_userdata( $row->uid );
				$order_arr[] = array(
					'order_id'   => array(
						'label' => __( 'Order ID', 'wpjobster' ),
						'value' => $row->id,
					),
					'added_date' => array(
						'label' => __( 'Date made', 'wpjobster' ),
						'value' => $row->datemade ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->datemade ) : '-',
					),
					'user_id'    => array(
						'label' => __( 'User', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $user->user_login ) . '">' . wpj_get_user_display_type( $user->ID ) . '</a>',
					),
					'email'      => array(
						'label' => __( 'User info', 'wpjobster' ),
						'value' => $row->payeremail,
					),
				);

				// Price
				$final_paid_amount = $row->payedamount ? explode( '|', $row->payedamount ) : 0;
				if ( isset( $final_paid_amount[0] ) && $final_paid_amount[0] != wpj_get_site_default_curreny() ) {
					$paid_amount = wpj_get_exchanged_value( $final_paid_amount[1], $final_paid_amount[0], wpj_get_site_default_curreny() );
				} else {
					$paid_amount = $final_paid_amount[1];
				}
				$price_arr[] = array(
					'amount' => array(
						'label' => __( 'Amount', 'wpjobster' ),
						'value' => wpj_show_price_classic( $paid_amount ),
					),
				);

				// Gateway responses
				$responses_arr     = array();
				$responses_query   = "SELECT DISTINCT * FROM {$wpdb->prefix}job_webhooks WHERE order_id = {$row->id} AND payment_type = 'withdrawal' ORDER BY id ASC";
				$responses_results = $wpdb->get_results( $responses_query );

				foreach ( $responses_results as $row ) {
					$responses_arr[] = array(
						'status' => array(
							'label' => __( 'Status', 'wpjobster' ),
							'value' => $row->status,
						),
						'payment_id' => array(
							'label' => __( 'Payment ID', 'wpjobster' ),
							'value' => $row->payment_id,
						),
						'event_type' => array(
							'label' => __( 'Event Type', 'wpjobster' ),
							'value' => $row->type,
						),
						'description' => array(
							'label' => __( 'Description', 'wpjobster' ),
							'value' => $row->description,
						),
						'amount' => array(
							'label' => __( 'Amount', 'wpjobster' ),
							'value' => $row->amount . ' ' . $row->amount_currency,
						),
						'fees' => array(
							'label' => __( 'Fees', 'wpjobster' ),
							'value' => $row->fees . ' ' . $row->fees_currency,
						),
						'date' => array(
							'label' => __( 'Date', 'wpjobster' ),
							'value' => wpj_date( '', $row->create_time ),
						)
					);
				}
			}
		}

		return array(
			'payment'           => $payment_arr,
			'order'             => $order_arr,
			'price'             => $price_arr,
			'gateway_responses' => $responses_arr
		);
	}

	public function getCustomExtraOrderDetails( $order_id = '' ) {
		global $wpdb;

		$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_custom_extra_orders WHERE id = {$order_id}";
		$rows = $wpdb->get_results( $query );

		$payment_arr      = array();
		$order_arr        = array();
		$price_arr        = array();

		if ( $rows ) {
			foreach ( $rows as $key => $row ) {

				// Payment
				$payment_arr[] = array(
					'status'       => array(
						'label' => __( 'Payment status', 'wpjobster' ),
						'value' => $row->payment_status,
					),
					'gateway'      => array(
						'label' => __( 'Payment gateway', 'wpjobster' ),
						'value' => $row->payment_gateway_name,
					),
					'payment_date' => array(
						'label' => __( 'Payment date', 'wpjobster' ),
						'value' => $row->paid_on ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->paid_on ) : '-',
					),
				);

				// Order
				$order_info = wpj_get_order( $row->order_id );
				$buyer      = get_userdata( $row->user_id );
				$post       = get_post( $order_info->pid );
				$seller     = get_userdata( $post->post_author );

				$order_arr[] = array(
					'order_id'        => array(
						'label' => __( 'Order ID', 'wpjobster' ),
						'value' => $row->id,
					),
					'ce_id'           => array(
						'label' => __( 'Custom Extra ID', 'wpjobster' ),
						'value' => $row->custom_extra_id,
					),
					'parent_order_id' => array(
						'label' => __( 'Parent Order ID', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_order_link( $row->order_id ) . '">' . $row->order_id . '</a>',
					),
					'job_title'       => array(
						'label' => __( 'Job Title', 'wpjobster' ),
						'value' =>  '<a href="' . get_permalink( $order_info->pid ) . '">' . $order_info->job_title . '</a>',
					),
					'buyer'           => array(
						'label' => __( 'Buyer', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $buyer->user_login ) . '">' . wpj_get_user_display_type( $buyer->ID ) . '</a>',
					),
					'seller'          => array(
						'label' => __( 'Seller', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $seller->user_login ) . '">' . wpj_get_user_display_type( $seller->ID ) . '</a>',
					),
					'added_date'      => array(
						'label' => __( 'Date made', 'wpjobster' ),
						'value' => $row->added_on ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->added_on ) : '-',
					),
				);

				// Price
				$custom_extras = json_decode( $order_info->custom_extras );
				$custom_extra  = $custom_extras[$row->custom_extra_id];

				$ce_payedamount = $custom_extra->price;
				if ( isset( $custom_extra->processing_fees ) ) $ce_payedamount += $custom_extra->processing_fees;
				if ( isset( $custom_extra->tax ) ) $ce_payedamount += $custom_extra->tax;

				$ce_tax = isset( $custom_extra->tax ) ? $custom_extra->tax : 0;

				$price_arr[] = array(
					'ce_amount'   => array(
						'label' => __( 'Custom Extra Amount', 'wpjobster' ),
						'value' => wpj_show_price_classic( wpj_get_exchanged_value( $custom_extra->price, $row->currency, wpj_get_site_default_curreny() ) ),
					),
					'paid_amount' => array(
						'label' => __( 'Paid amount', 'wpjobster' ),
						'value' => wpj_show_price_classic( wpj_get_exchanged_value( $ce_payedamount, $row->currency, wpj_get_site_default_curreny() ) ),
					),
					'tax'         => array(
						'label' => __( 'Tax', 'wpjobster' ),
						'value' => wpj_show_price_classic( wpj_get_exchanged_value( $ce_tax, $row->currency, wpj_get_site_default_curreny() ) ),
					),
				);

				// Gateway responses
				$responses_arr     = array();
				$responses_query   = "SELECT DISTINCT * FROM {$wpdb->prefix}job_webhooks WHERE order_id = {$row->id} AND payment_type = 'custom_extra' ORDER BY id ASC";
				$responses_results = $wpdb->get_results( $responses_query );

				foreach ( $responses_results as $row ) {
					$responses_arr[] = array(
						'status' => array(
							'label' => __( 'Status', 'wpjobster' ),
							'value' => $row->status,
						),
						'payment_id' => array(
							'label' => __( 'Payment ID', 'wpjobster' ),
							'value' => $row->payment_id,
						),
						'event_type' => array(
							'label' => __( 'Event Type', 'wpjobster' ),
							'value' => $row->type,
						),
						'description' => array(
							'label' => __( 'Description', 'wpjobster' ),
							'value' => $row->description,
						),
						'amount' => array(
							'label' => __( 'Amount', 'wpjobster' ),
							'value' => $row->amount . ' ' . $row->amount_currency,
						),
						'fees' => array(
							'label' => __( 'Fees', 'wpjobster' ),
							'value' => $row->fees . ' ' . $row->fees_currency,
						),
						'date' => array(
							'label' => __( 'Date', 'wpjobster' ),
							'value' => wpj_date( '', $row->create_time ),
						)
					);
				}
			}
		}

		return array(
			'payment'           => $payment_arr,
			'order'             => $order_arr,
			'price'             => $price_arr,
			'gateway_responses' => $responses_arr
		);
	}

	public function getTipsOrderDetails( $order_id = '' ) {
		global $wpdb;

		$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_tips_orders WHERE id = {$order_id}";
		$rows = $wpdb->get_results( $query );

		$payment_arr      = array();
		$order_arr        = array();
		$price_arr        = array();

		if ( $rows ) {
			foreach ( $rows as $key => $row ) {

				// Payment
				$payment_arr[] = array(
					'status'       => array(
						'label' => __( 'Payment status', 'wpjobster' ),
						'value' => $row->payment_status,
					),
					'gateway'      => array(
						'label' => __( 'Payment gateway', 'wpjobster' ),
						'value' => $row->payment_gateway_name,
					),
					'payment_date' => array(
						'label' => __( 'Payment date', 'wpjobster' ),
						'value' => $row->paid_on ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->paid_on ) : '-',
					),
				);

				// Order
				$order_info = wpj_get_order( $row->order_id );
				$buyer      = get_userdata( $row->user_id );
				$post       = get_post( $order_info->pid );
				$seller     = get_userdata( $post->post_author );

				$order_arr[] = array(
					'order_id'        => array(
						'label' => __( 'Order ID', 'wpjobster' ),
						'value' => $row->id,
					),
					'ce_id'           => array(
						'label' => __( 'Tips ID', 'wpjobster' ),
						'value' => $row->tips_id,
					),
					'parent_order_id' => array(
						'label' => __( 'Parent order ID', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_order_link( $row->order_id ) . '">' . $row->order_id . '</a>',
					),
					'job_title'       => array(
						'label' => __( 'Job title', 'wpjobster' ),
						'value' =>  '<a href="' . get_permalink( $order_info->pid ) . '">' . $order_info->job_title . '</a>',
					),
					'buyer'           => array(
						'label' => __( 'Buyer', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $buyer->user_login ) . '">' . wpj_get_user_display_type( $buyer->ID ) . '</a>',
					),
					'seller'          => array(
						'label' => __( 'Seller', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $seller->user_login ) . '">' . wpj_get_user_display_type( $seller->ID ) . '</a>',
					),
					'added_date'      => array(
						'label' => __( 'Date made', 'wpjobster' ),
						'value' => $row->added_on ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->added_on ) : '-',
					),
				);

				// Price
				$price_arr[] = array(
					'ce_amount'   => array(
						'label' => __( 'Tips amount', 'wpjobster' ),
						'value' => wpj_show_price_classic ( wpj_get_exchanged_value( $row->tips_amount, $row->currency, wpj_get_site_default_curreny() ) ),
					),
					'paid_amount' => array(
						'label' => __( 'Paid amount', 'wpjobster' ),
						'value' => wpj_show_price_classic( wpj_get_exchanged_value( $row->payable_amount, $row->currency, wpj_get_site_default_curreny() ) ),
					),
					'tax'         => array(
						'label' => __( 'Tax', 'wpjobster' ),
						'value' => wpj_show_price_classic( wpj_get_exchanged_value( $row->tax, $row->currency, wpj_get_site_default_curreny() ) ),
					),
				);

				// Gateway responses
				$responses_arr     = array();
				$responses_query   = "SELECT DISTINCT * FROM {$wpdb->prefix}job_webhooks WHERE order_id = {$row->id} AND payment_type = 'tips' ORDER BY id ASC";
				$responses_results = $wpdb->get_results( $responses_query );

				foreach ( $responses_results as $row ) {
					$responses_arr[] = array(
						'status' => array(
							'label' => __( 'Status', 'wpjobster' ),
							'value' => $row->status,
						),
						'payment_id' => array(
							'label' => __( 'Payment ID', 'wpjobster' ),
							'value' => $row->payment_id,
						),
						'event_type' => array(
							'label' => __( 'Event Type', 'wpjobster' ),
							'value' => $row->type,
						),
						'description' => array(
							'label' => __( 'Description', 'wpjobster' ),
							'value' => $row->description,
						),
						'amount' => array(
							'label' => __( 'Amount', 'wpjobster' ),
							'value' => $row->amount . ' ' . $row->amount_currency,
						),
						'fees' => array(
							'label' => __( 'Fees', 'wpjobster' ),
							'value' => $row->fees . ' ' . $row->fees_currency,
						),
						'date' => array(
							'label' => __( 'Date', 'wpjobster' ),
							'value' => wpj_date( '', $row->create_time ),
						)
					);
				}
			}
		}

		return array(
			'payment'           => $payment_arr,
			'order'             => $order_arr,
			'price'             => $price_arr,
			'gateway_responses' => $responses_arr
		);
	}

	public function getSubscriptionOrderDetails( $order_id = '' ) {
		global $wpdb;

		$query = "SELECT DISTINCT * FROM {$wpdb->prefix}job_subscription_orders WHERE id = {$order_id}";
		$rows = $wpdb->get_results( $query );

		$payment_arr      = array();
		$order_arr        = array();
		$price_arr        = array();

		if ( $rows ) {
			foreach ( $rows as $key => $row ) {

				// Payment
				$payment_arr[] = array(
					'status'       => array(
						'label' => __( 'Payment status', 'wpjobster' ),
						'value' => $row->payment_status,
					),
					'gateway'      => array(
						'label' => __( 'Payment gateway', 'wpjobster' ),
						'value' => $row->payment_gateway_name,
					),
					'payment_date' => array(
						'label' => __( 'Payment date', 'wpjobster' ),
						'value' => $row->payment_date ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->payment_date ) : '-',
					),
				);

				// Order
				$user = get_userdata( $row->user_id );
				$order_arr[] = array(
					'order_id'            => array(
						'label' => __( 'Order ID', 'wpjobster' ),
						'value' => $row->id,
					),
					'subscription_status' => array(
						'label' => __( 'Subscription status', 'wpjobster' ),
						'value' => $row->subscription_status,
					),
					'subscription_plan'   => array(
						'label' => __( 'Subscription plan', 'wpjobster' ),
						'value' => $row->plan,
					),
					'subscription_level'  => array(
						'label' => __( 'Subscription level', 'wpjobster' ),
						'value' => str_replace( array( '-', '–' ), '', $row->level ),
					),
					'user'                => array(
						'label' => __( 'User', 'wpjobster' ),
						'value' => '<a href="' . wpj_get_user_profile_link( $user->user_login ) . '">' . wpj_get_user_display_type( $user->ID ) . '</a>',
					),
					'added_date'          => array(
						'label' => __( 'Date made', 'wpjobster' ),
						'value' => $row->addon_date ? wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->addon_date ) : '-',
					),
				);

				// Price
				$price_arr[] = array(
					'amount'   => array(
						'label' => __( 'Amount', 'wpjobster' ),
						'value' => wpj_show_price_classic ( wpj_get_exchanged_value( $row->amount, $row->mc_currency, wpj_get_site_default_curreny() ) ),
					),
					'paid_amount' => array(
						'label' => __( 'Paid amount', 'wpjobster' ),
						'value' => wpj_show_price_classic( wpj_get_exchanged_value( $row->payable_amount, $row->mc_currency, wpj_get_site_default_curreny() ) ),
					),
					'tax'         => array(
						'label' => __( 'Tax', 'wpjobster' ),
						'value' => wpj_show_price_classic( wpj_get_exchanged_value( $row->tax, $row->mc_currency, wpj_get_site_default_curreny() ) ),
					),
				);

				// Gateway responses
				$responses_arr     = array();
				$responses_query   = "SELECT DISTINCT * FROM {$wpdb->prefix}job_webhooks WHERE order_id = {$row->id} AND payment_type = 'subscription' ORDER BY id ASC";
				$responses_results = $wpdb->get_results( $responses_query );

				foreach ( $responses_results as $row ) {
					$responses_arr[] = array(
						'status' => array(
							'label' => __( 'Status', 'wpjobster' ),
							'value' => $row->status,
						),
						'payment_id' => array(
							'label' => __( 'Payment ID', 'wpjobster' ),
							'value' => $row->payment_id,
						),
						'event_type' => array(
							'label' => __( 'Event Type', 'wpjobster' ),
							'value' => $row->type,
						),
						'description' => array(
							'label' => __( 'Description', 'wpjobster' ),
							'value' => $row->description,
						),
						'amount' => array(
							'label' => __( 'Amount', 'wpjobster' ),
							'value' => $row->amount . ' ' . $row->amount_currency,
						),
						'fees' => array(
							'label' => __( 'Fees', 'wpjobster' ),
							'value' => $row->fees . ' ' . $row->fees_currency,
						),
						'date' => array(
							'label' => __( 'Date', 'wpjobster' ),
							'value' => wpj_date( '', $row->create_time ),
						)
					);
				}
			}
		}

		return array(
			'payment'           => $payment_arr,
			'order'             => $order_arr,
			'price'             => $price_arr,
			'gateway_responses' => $responses_arr
		);
	}

	public function getTipsAndCeSectionValues( $row = '', $type = '' ) {
		if ( isset( $row->completed ) && $row->completed == 1 )     $status = __( 'completed', 'wpjobster' );
		elseif ( isset( $row->delivered ) && $row->delivered == 1 ) $status = __( 'delivered', 'wpjobster' );
		elseif ( isset( $row->paid ) && $row->paid == 1 )           $status = __( 'paid', 'wpjobster' );
		elseif ( isset( $row->declined ) && $row->declined == 1 )   $status = __( 'declined', 'wpjobster' );
		elseif ( isset( $row->cancelled ) && $row->cancelled == 1 ) $status = __( 'cancelled', 'wpjobster' );
		else $status = __( 'pending', 'wpjobster' );

		$amount = $type == 'tips' ? $row->amount : $row->price;

		$processing_fees = isset( $row->processing_fees ) ? $row->processing_fees : 0;
		$tax = isset( $row->tax ) ? $row->tax : 0;

		return array(
			'description' => array(
				'label' => $type == 'tips' ? __( 'Reason', 'wpjobster' ) : __( 'Description', 'wpjobster' ),
				'value' => $type == 'tips' ? $row->reason : $row->description,
			),
			'price' => array(
				'label' => __( 'Price', 'wpjobster' ),
				'value' => $amount,
			),
			'processing_fees' => array(
				'label' => __( 'Processing fees', 'wpjobster' ),
				'value' => wpj_show_price_classic( $processing_fees ),
			),
			'tax' => array(
				'label' => __( 'Tax', 'wpjobster' ),
				'value' => wpj_show_price_classic( $tax ),
			),
			'paid_amount' => array(
				'label' => __( 'Paid amount', 'wpjobster' ),
				'value' => wpj_show_price_classic( $amount + $processing_fees + $tax ),
			),
			'date' => array(
				'label' => __( 'Date', 'wpjobster' ),
				'value' => wpj_date( wpj_get_option( 'date_format' ) . ' ' . wpj_get_option( 'time_format' ), $row->time ),
			),
			'status' => array(
				'label' => __( 'Status', 'wpjobster' ),
				'value' => $status,
			),
		);
	}

	public function getExtraSectionValues( $row = '', $nr = '' ) {
		if ( $row->{'extra' . $nr } == 1 ) {
			$extra['extra' . $nr]['enable'] = $row->{'extra' . $nr };

			if ( $nr != '_fast' && $nr != '_revision' ) {
				$extra['extra' . $nr]['title'] = array(
					'label' => __( 'Title', 'wpjobster' ),
					'value' => $row->{'extra' . $nr . '_title' },
				);
			}

			$extra['extra' . $nr]['price'] = array(
				'label' => __( 'Price', 'wpjobster' ),
				'value' => wpj_show_price_classic( $row->{'extra' . $nr . '_price' } ),
			);

			$extra['extra' . $nr]['days'] = array(
				'label' => __( 'Max days to deliver', 'wpjobster' ),
				'value' => sprintf( _n( '%d day', '%d days', $row->{'extra' . $nr . '_days' }, 'wpjobster' ), $row->{'extra' . $nr . '_days' } ),
			);

			return $extra;
		} else {
			return false;
		}
	}

	public function getOrderFeaturedPages( $row = array() ) {
		$f_page = array();

		$pages = str_split( $row->feature_pages );

		if ( isset( $pages[0] ) ) {
			if ( $pages[0] == 'h' ) $f_page[] = array( __( 'homepage', 'wpjobster' ), $row->h_date_start );
			elseif ( $pages[0] == 'c' ) $f_page[] = array( __( 'category', 'wpjobster' ), $row->c_date_start );
			elseif ( $pages[0] == 's' ) $f_page[] = array( __( 'subcategory', 'wpjobster' ), $row->s_date_start );
		}

		if ( isset( $pages[1] ) ) {
			if ( $pages[1] == 'h' ) $f_page[] = array( __( 'homepage', 'wpjobster' ), $row->h_date_start );
			elseif ( $pages[1] == 'c' ) $f_page[] = array( __( 'category', 'wpjobster' ), $row->c_date_start );
			elseif ( $pages[1] == 's' ) $f_page[] = array( __( 'subcategory', 'wpjobster' ), $row->s_date_start );
		}

		if ( isset( $pages[2] ) ) {
			if ( $pages[2] == 'h' ) $f_page[] = array( __( 'homepage', 'wpjobster' ), $row->h_date_start );
			elseif ( $pages[2] == 'c' ) $f_page[] = array( __( 'category', 'wpjobster' ), $row->c_date_start );
			elseif ( $pages[2] == 's' ) $f_page[] = array( __( 'subcategory', 'wpjobster' ), $row->s_date_start );
		}

		$elements = array();
		foreach ( $f_page as $f_key => $f_value ) {
			$elements[] = $f_value[0] . ' (' . wpj_date( wpj_get_option( 'date_format' ), $f_value[1] ) . ')';
		}

		return implode( ', ', $elements );
	}
}

add_action( 'after_setup_theme', array( 'WPJ_Orders', 'init' ) );