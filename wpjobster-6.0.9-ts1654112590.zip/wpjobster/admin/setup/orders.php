<?php // Jobster Orders

$orders = wpj_get_folder_files( get_template_directory() . '/admin/jobster-orders' );
foreach ( $orders as $order ) { include_once $order; }

add_action( 'admin_menu', function() { /* admin orders menu */
	add_menu_page(
		esc_html__( 'Orders', 'wpjobster' ), esc_html__( 'Orders', 'wpjobster' ), 'manage_options', 'jobster-orders', 'wpj_display_order_page_content', 'dashicons-cart', 35
	);
	add_submenu_page(
		'jobster-orders', esc_html__( 'Resolution Center', 'wpjobster' ), esc_html__( 'Resolution Center', 'wpjobster' ) . '<span class="count_arbitration"></span>', 'manage_options', 'jobster-resolution-center', 'wpj_display_resolution_center_page_content'
	);
	add_submenu_page(
		'jobster-orders', esc_html__( 'Transactions', 'wpjobster' ), esc_html__( 'Transactions', 'wpjobster' ), 'manage_options', 'jobster-transactions', 'wpj_display_transactions_page_content'
	);
	add_submenu_page(
		'jobster-orders', esc_html__( 'Summary', 'wpjobster' ), esc_html__( 'Summary', 'wpjobster' ), 'manage_options', 'jobster-summary', 'wpj_display_summary_page_content'
	);

	add_menu_page(
		esc_html__( 'Messages', 'wpjobster' ), esc_html__( 'Messages', 'wpjobster' ), 'manage_options', 'jobster-messages', 'wpj_display_private_messages_page_content', 'dashicons-email-alt', 36
	);
});

add_action( 'admin_bar_menu', function( $admin_bar ) { /* admin bar orders menu */
	$admin_bar->add_menu( array(
		'id'    => 'jobster-orders',
		'title' => '<span class="ab-icon dashicons-cart"></span>' . __( 'Jobster Orders', 'wpjobster' ),
		'href'  => get_admin_url() . 'admin.php?page=jobster-orders',
		'meta'  => array( 'title' => __( 'Orders', 'wpjobster' ) )
	));
}, 33, 1 );