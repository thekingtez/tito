<?php // Tracking

Redux::setSection( $opt_name, array(
	'title'      => __( 'Tracking', 'wpjobster' ),
	'icon'       => 'el el-graph',
	'id'         => 'tracking',
	'fields'     => array(

/* GOOGLE ANALYTICS */
		array(
			'id'       => 'google-analytics-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Google Analytics', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'wpjobster_enable_google_analytics',
			'type'     => 'switch',
			'title'    => __( 'Enable Google Analytics', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_analytics_code',
			'type'     => 'textarea',
			'title'    => __( 'Analytics Code', 'wpjobster' ),
		),

/* OTHER TRACKING */
		array(
			'id'       => 'other-tracking-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Other Tracking', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'wpjobster_enable_other_tracking',
			'type'     => 'switch',
			'title'    => __( 'Enable Other Tracking', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_other_tracking_code',
			'type'     => 'textarea',
			'title'    => __( 'Other Tracking Code', 'wpjobster' ),
		),
	)
) );