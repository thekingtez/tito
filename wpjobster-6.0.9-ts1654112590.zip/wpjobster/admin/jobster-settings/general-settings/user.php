<?php // User Settings

Redux::setSection( $opt_name, array(
	'title'      => __( 'User', 'wpjobster' ),
	'desc'       => __( 'User Settings', 'wpjobster' ),
	'id'         => 'user-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'wpjobster_display_name_publicly',
			'type'     => 'select',
			'title'    => __( 'Display name publicly as', 'wpjobster' ),
			'options'  => array(
				'username'        => __( 'Username', 'wpjobster' ),
				'first_name'      => __( 'First name', 'wpjobster' ),
				'last_name'       => __( 'Last name', 'wpjobster' ),
				'display_name'    => __( 'Display name', 'wpjobster' ),
				'first_last_name' => __( 'First Last name', 'wpjobster' ),
				'last_first_name' => __( 'Last First name', 'wpjobster' )
			),
			'default'  => 'username',
		),

/* FEATURES */
		array(
			'id'       => 'user-features-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Features', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'wpjobster_wysiwyg_for_profile',
			'type'     => 'switch',
			'title'    => __( 'Allow WYSIWYG editor for description', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'wpjobster_enable_last_seen',
			'type'     => 'switch',
			'title'    => __( 'Enable last seen on user page', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_enable_user_social_media',
			'type'     => 'switch',
			'title'    => __( 'Enable social media links on user page', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_enable_jobs_section_on_user_profile',
			'type'     => 'switch',
			'title'    => __( 'Enable jobs section on user page', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'wpjobster_enable_user_vat_id',
			'type'     => 'switch',
			'title'    => __( 'Enable user Tax/VAT ID', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_en_user_online_status',
			'type'     => 'select',
			'title'    => __( 'Enable user online status', 'wpjobster' ),
			'options'  => array(
				'yes_with_text' => __( 'Yes, with text', 'wpjobster' ),
				'yes_with_icon' => __( 'Yes, with icon', 'wpjobster'),
				'no'            => __( 'No', 'wpjobster' )
			),
			'default'  => 'yes_with_text',
		),

/* Images */
		array(
			'id'       => 'user-images-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Images', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'wpjobster_max_user_cover_upload_size',
			'type'     => 'text',
			'title'    => __( 'Max cover upload size (MB)', 'wpjobster' ),
			'subtitle' => sprintf( __( 'Max allowed value is %sMB', 'wpjobster' ), $post_max_size ),
			'default'  => 10,
		),
		array(
			'id'       => 'wpjobster_max_user_avatar_upload_size',
			'type'     => 'text',
			'title'    => __( 'Max avatar upload size (MB)', 'wpjobster' ),
			'subtitle' => sprintf( __( 'Max allowed value is %sMB', 'wpjobster' ), $post_max_size ),
			'default'  => 10,
		),
		array(
			'id'       => 'wpjobster_max_user_skill_upload_size',
			'type'     => 'text',
			'title'    => __( 'Max skill upload size (MB)', 'wpjobster' ),
			'subtitle' => sprintf( __( 'Max allowed value is %sMB', 'wpjobster' ), $post_max_size ),
			'default'  => 10,
		),

/* PORTFOLIO */
		array(
			'id'       => 'user-portfolio-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Portfolio', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'wpjobster_enable_user_profile_portfolio',
			'type'     => 'switch',
			'title'    => __( 'Enable user portfolio', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'wpjobster_profile_default_nr_of_pics',
			'type'     => 'text',
			'title'    => __( 'Max amount of pictures', 'wpjobster' ),
			'subtitle' => __( 'Maximum number of uploaded images per user', 'wpjobster' ),
			'default'  => 10,
			'required' => array( 'wpjobster_enable_user_profile_portfolio', '=', true )
		),
		array(
			'id'       => 'wpjobster_profile_max_img_upload_size',
			'type'     => 'text',
			'title'    => __( 'Max image upload size (MB)', 'wpjobster' ),
			'subtitle' => sprintf( __( 'Max allowed value is %sMB', 'wpjobster' ), $post_max_size ),
			'default'  => 10,
			'required' => array( 'wpjobster_enable_user_profile_portfolio', '=', true )
		),
		array(
			'id'       => 'wpjobster_profile_min_img_upload_width',
			'type'     => 'text',
			'title'    => __( 'Min image upload width', 'wpjobster' ),
			'subtitle' => __( 'in PX', 'wpjobster' ),
			'default'  => 720,
			'required' => array( 'wpjobster_enable_user_profile_portfolio', '=', true )
		),
		array(
			'id'       => 'wpjobster_profile_min_img_upload_height',
			'type'     => 'text',
			'title'    => __( 'Min image upload height', 'wpjobster' ),
			'subtitle' => __( 'in PX', 'wpjobster' ),
			'default'  => 405,
			'required' => array( 'wpjobster_enable_user_profile_portfolio', '=', true )
		),

/* COUNTRY & TIMEZONE */
		array(
			'id'       => 'user-country-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Country & Timezone', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'wpjobster_en_country_flags',
			'type'     => 'switch',
			'title'    => __( 'Enable country flags', 'wpjobster' ),
			'subtitle' => __( 'Display country flag on profile page and job pages, based on the country selected by the user.', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_phone_country_select',
			'type'     => 'select',
			'title'    => __( 'Default country flag for phone number', 'wpjobster' ),
			'options'  => array_merge( array( 'autodetect' => __( 'Autodetect', 'wpjobster' ) ), wpj_get_country_name_by_code() ),
			'default'  => 'US',
		),
		array(
			'id'       => 'wpjobster_enable_country_select',
			'type'     => 'switch',
			'title'    => __( 'Enable user country select', 'wpjobster' ),
			'subtitle' => __( 'Let the users choose their country, even after filling it automatically by IP.', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'wpjobster_user_time_zone',
			'type'     => 'select',
			'title'    => __( 'Default user time zone', 'wpjobster' ),
			'options'  => array_merge( array( 'autodetect' => __( 'Autodetect', 'wpjobster' ) ), wpj_get_timezone_by_name() ),
			'default'  => 'autodetect'
		),

/* STATS */
		array(
			'id'       => 'user-stats-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Stats', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'wpjobster_enable_user_stats',
			'type'     => 'switch',
			'title'    => __( 'Enable user stats bar', 'wpjobster' ),
			'subtitle' => __( 'Enable or disable the basic user stats bar on my account, sales and shopping pages.', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'wpjobster_enable_user_charts',
			'type'     => 'switch',
			'title'    => __( 'Enable user stats charts', 'wpjobster' ),
			'subtitle' => __( 'Enable the advanced user stats charts. User stats bar needs to be active.', 'wpjobster' ),
			'default'  => true,
		),

/* LOGIN & REGISTER */
		array(
			'id'       => 'user-authentication-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Login & Register', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'wpjobster_enable_phone_number',
			'type'     => 'switch',
			'title'    => __( 'Enable user phone number on registration page', 'wpjobster' ),
			'subtitle' => __( 'Enable or disable the field for phone number on registration page.', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_phone_number_mandatory',
			'type'     => 'switch',
			'title'    => __( 'Phone number mandatory on registration', 'wpjobster' ),
			'subtitle' => __( 'Phone number mandatory on registration page.', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_enable_user_company',
			'type'     => 'switch',
			'title'    => __( 'Enable user company on registration page', 'wpjobster' ),
			'subtitle' => __( 'Enable or disable the field for company on registration page.', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_enable_user_reCaptcha',
			'type'     => 'switch',
			'title'    => __( 'Enable reCAPTCHA v2 on registration/login page', 'wpjobster' ),
			'subtitle' => __( 'Enable or disable the field for reCaptcha on registration page.', 'wpjobster' ),
			'desc'     => __( 'Go to General Settings and fill in the <b>reCAPTCHA v2 API key</b> and the <b>reCAPTCHA v2 API secret</b> fields.', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_enable_user_2fa',
			'type'     => 'switch',
			'title'    => __( 'Enable 2FA on login page', 'wpjobster' ),
			'subtitle' => __( 'Enable or disable the field for 2FA on registration page.', 'wpjobster' ),
			'default'  => false,
		),
		array(
			'id'       => 'wpjobster_enable_login_hints',
			'type'     => 'switch',
			'title'    => __( 'Enable login hints', 'wpjobster' ),
			'subtitle' => __( 'Enable or disable the hints on registration page.', 'wpjobster' ),
			'default'  => true,
		),
		array(
			'id'       => 'wpjobster_register_tos_and_privacy',
			'type'     => 'select',
			'title'    => __( 'TOS and Privacy Policy on registration page', 'wpjobster' ),
			'subtitle' => __( 'Don\'t forget to check and update the Terms of Service and Privacy Policy pages with your own terms! You can find them in the Page Assignments section.', 'wpjobster' ),
			'options'  => array(
				'disabled' => __( 'Disabled', 'wpjobster' ),
				'text'     => __( 'Text Notice', 'wpjobster' ),
				'checkbox' => __( 'Required Checkbox', 'wpjobster' )
			),
			'default'  => 'disabled'
		),

/* REVIEWS */
		array(
			'id'       => 'user-review-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Reviews', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'       => 'wpjobster_user_min_rating',
			'type'     => 'text',
			'title'    => __( 'Min rating number', 'wpjobster' ),
			'subtitle' => __( 'The minimum number of reviews to display the user rating.', 'wpjobster' ),
			'default'  => 3,
		),
	)
) );