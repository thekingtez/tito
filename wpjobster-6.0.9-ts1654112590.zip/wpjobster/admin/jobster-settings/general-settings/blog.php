<?php // Blog Settings

Redux::setSection( $opt_name, array(
	'title'      => __( 'Blog', 'wpjobster' ),
	'desc'       => __( 'Blog & News Settings', 'wpjobster' ),
	'id'         => 'blog-settings',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'wpjobster_allow_comments_on_blog_news_pages',
			'type'     => 'switch',
			'title'    => __( 'Allow comments on blog and news pages', 'wpjobster' ),
			'subtitle' => __( 'Enabling this option, site users will be able to write comments on the posted articles.', 'wpjobster' ),
			'default'  => false,
		),
	)
) );