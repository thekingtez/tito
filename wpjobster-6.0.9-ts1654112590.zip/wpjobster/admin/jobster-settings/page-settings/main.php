<?php // Page Settings

Redux::setSection( $opt_name, array(
	'title'      => __( 'Page Settings', 'wpjobster' ),
	'desc'       => __( 'Pages & Permalinks', 'wpjobster' ),
	'id'         => 'page-settings',
	'icon'       => 'el el-file-edit',
	'fields'     => array(

	)
) );