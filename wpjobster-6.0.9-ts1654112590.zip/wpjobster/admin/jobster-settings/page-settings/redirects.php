<?php // Redirects Settings

Redux::setSection( $opt_name, array(
	'title'      => __( 'Redirects', 'wpjobster' ),
	'desc'       => __( 'Redirects Settings', 'wpjobster' ),
	'id'         => 'redirects-settings',
	'subsection' => true,
	'fields'     => array(

/* AUTHENTICATION */

		array(
			'id'       => 'authentication-redirects-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Authentication', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'      => 'wpjobster_login_redirection_page',
			'type'    => 'select',
			'data'    => 'pages',
			'title'   => __( 'Login redirection', 'wpjobster' ),
			'default' => ! empty( get_page_by_title( 'Homepage - Loggedin' ) ) ? get_page_by_title( 'Homepage - Loggedin' )->ID : get_option( 'main_page_url_user' )
		),
		array(
			'id'      => 'wpjobster_register_redirection_page',
			'type'    => 'select',
			'data'    => 'pages',
			'title'   => __( 'Register redirection', 'wpjobster' ),
			'default' => ! empty( get_page_by_title( 'Homepage - Loggedin' ) ) ? get_page_by_title( 'Homepage - Loggedin' )->ID : get_option( 'main_page_url_user' )
		),

/* POST NEW */

		array(
			'id'       => 'post-new-redirects-settings',
			'type'     => 'section',
			'title'    => esc_html__( 'Post New', 'wpjobster' ),
			'indent'   => true,
		),
		array(
			'id'      => 'wpjobster_post_new_job_redirection_page',
			'type'    => 'select',
			'data'    => 'pages',
			'title'   => __( 'Post new job redirection', 'wpjobster' ),
			'default' => ! empty( get_page_by_title( 'My Account' ) ) ? get_page_by_title( 'My Account' )->ID : get_option( 'wpjobster_my_account_page_id' )
		),
		array(
			'id'      => 'wpjobster_post_new_request_redirection_page',
			'type'    => 'select',
			'data'    => 'pages',
			'title'   => __( 'Post new request redirection', 'wpjobster' ),
			'default' => ! empty( get_page_by_title( 'My Requests' ) ) ? get_page_by_title( 'My Requests' )->ID : get_option( 'wpjobster_my_requests_page_id' )
		),

	)
) );