<?php // Extensions

Redux::setSection( $opt_name, array(
	'title'      => __( 'Extensions', 'wpjobster' ),
	'desc'       => __( 'Extensions Settings', 'wpjobster' ),
	'id'         => 'extensions-settings',
	'icon'       => 'el el-puzzle',
	'fields'     => array(

	)
) );