<?php // Payment Gateways Settings

Redux::setSection( $opt_name, array(
	'title'      => __( 'Payment Gateways', 'wpjobster' ),
	'desc'       => __( 'Payment Methods', 'wpjobster' ),
	'id'         => 'payment-gateways-settings',
	'icon'       => 'el el-credit-card',
	'fields'     => array(

	)
) );