<?php // Features Settings

Redux::setSection( $opt_name, array(
	'title'      => __( 'Feature Settings', 'wpjobster' ),
	'desc'       => __( 'Feature Settings by Level or Subscription', 'wpjobster' ),
	'id'         => 'feature-settings',
	'icon'       => 'el el-glasses',
	'fields'     => array(

	)
) );