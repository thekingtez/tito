<?php // Job Payment Type Settings

Redux::setSection( $opt_name, array(
	'title'      => __( 'Payment Type', 'wpjobster' ),
	'desc'       => __( 'Payment Type Settings', 'wpjobster' ),
	'id'         => 'payment-type-settings',
	'icon'       => 'el el-eur',
	'fields'     => array(

	)
) );