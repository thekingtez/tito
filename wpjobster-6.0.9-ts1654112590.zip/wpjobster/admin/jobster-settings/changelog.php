<?php // Changelog

Redux::setSection( $opt_name, array(
	'title'      => __( 'Changelog', 'wpjobster' ),
	'icon'       => 'el el-list-alt',
	'id'         => 'changelog',
	'fields'     => array(
		array(
			'id'           => 'readme',
			'type'         => 'raw',
			'markdown'     => true,
			'content_path' => get_template_directory() . '/README.md',
		),
	)
) );