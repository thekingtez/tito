<?php // Character Settings

Redux::setSection( $opt_name, array(
	'title'      => __( 'Character Settings', 'wpjobster' ),
	'desc'       => __( 'Filters & Limits', 'wpjobster' ),
	'id'         => 'character-settings',
	'icon'       => 'el el-text-width',
	'fields'     => array(

	)
) );