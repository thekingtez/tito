<?php // Email & SMS Notifications

$email_categories = wpj_get_notifications_array();
$languages        = wpj_get_preferred_languages();

$user_arr = array(
	'receiver_username'       => __( "the person that will receive the emails.", "wpjobster" ),
	'receiver_email'          => __( "the email address of the user", "wpjobster" ),
	'sender_username'         => __( "the other person involved in the transaction.", "wpjobster" ),
	'username'                => __( "this is used mostly for emails sent to admin, because receiver_username woudn't make sense", "wpjobster" ),
	'user_email'              => __( "this is used mostly for emails sent to admin, because receiver_email woudn't make sense", "wpjobster" ),
	'password'                => __( "the auto generated password for old nonajax registration", "wpjobster" ),
	'password_reset_link'     => __( "the password reset link", "wpjobster" ),
	'email_verification'      => __( "the email verification link", "wpjobster" ),
	'private_message_excerpt' => __( "the private message excerpt", "wpjobster" ),
	'private_message_content' => __( "the private message content", "wpjobster" )
);

$service_arr = array(
	'all_featured_info' => __( "the periods and pages of the job that will be featured", "wpjobster" ),
	'job_name'          => __( "new job's title", "wpjobster" ),
	'job_link'          => __( "link for the new job", "wpjobster" ),
	'request_name'      => __( "new request's title", "wpjobster" ),
	'request_link'      => __( "link for the new request", "wpjobster" )
);

$order_arr = array(
	'current_level'         => __( "current level of the receiver", "wpjobster" ),
	'payment_type'          => __( "payment type used for transaction", "wpjobster" ),
	'payment_amount'        => __( "payment amount for current transaction", "wpjobster" ),
	'mc_gross'              => __( "gross amount for current transaction", "wpjobster" ),
	'processing_fees'       => __( "processing fee amount for current transaction", "wpjobster" ),
	'tax_amount'            => __( "tax amount for current transaction", "wpjobster" ),
	'transaction_number'    => __( "transaction number", "wpjobster" ),
	'transaction_page_link' => __( "transaction page link", "wpjobster" )
);

$withdrawal_arr = array(
	'amount_withdrawn'              => __( "amount withdrawn, including", "wpjobster" ),
	'withdraw_method'               => __( "withdraw method", "wpjobster" ),
	'withdrawal_email_verification' => __( "withdrawal verification link", "wpjobster" ),
	'withdrawal_username'           => __( "withdraw username for admin email", "wpjobster" ),
	'withdrawal_amount'             => __( "withdraw amount for admin email", "wpjobster" ),
	'withdrawal_method'             => __( "withdraw method for admin email", "wpjobster" ),
	'withdrawal_link'               => __( "user withdrawal link", "wpjobster" )
);

$topup_arr = array(
	'amount_updated'             => __( "balance amount after topup", "wpjobster" ),
	'amount_updated_in_currency' => __( "balance amount after topup for current currency", "wpjobster" ),
	'payment_gateway'            => __( "payment gateway used for topup", "wpjobster" )
);

$subscription_arr = array(
	'current_subscription_level'  => __( "current subscription level", "wpjobster" ),
	'current_subscription_amount' => __( "current subscription amount", "wpjobster" ),
	'current_subscription_period' => __( "current subscription period", "wpjobster" ),
	'next_subscription_level'     => __( "next subscriptionlevel", "wpjobster" ),
	'next_subscription_amount'    => __( "next subscription amount", "wpjobster" ),
	'next_billing_date'           => __( "next subscription date", "wpjobster" )
);

$exchange_arr = array(
	'main_currency'      => __( "exchange - site currency", "wpjobster" ),
	'old_price'          => __( "exchange - old currency value", "wpjobster" ),
	'new_price'          => __( "exchange - new currency value", "wpjobster" ),
	'percent_difference' => __( "exchange - percent difference between old and new currency value", "wpjobster" )
);

$link_arr = array(
	'my_account_url'       => __( "your website's my account link", "wpjobster" ),
	'private_message_link' => __( "the link for the conversation with a particular user", "wpjobster" ),
	'admin_orders_url'     => __( "your website's admin orders link", "wpjobster" )
);

$site_arr = array(
	'your_site_name' => __( "your website's name", "wpjobster" ),
	'your_site_url'  => __( "your website's homepage url", "wpjobster" ),
);

foreach ( $user_arr as $user_k => $user_f ) {
	$user_fields[] = array( 'id' => $user_k, 'type' => 'info', 'style' => 'custom', 'color' => '#00a0d2', 'title' => '##' . $user_k . '##', 'desc' => $user_f );
}

foreach ( $service_arr as $service_k => $service_f ) {
	$service_fields[] = array( 'id' => $service_k, 'type' => 'info', 'style' => 'custom', 'color' => '#00a0d2', 'title' => '##' . $service_k . '##', 'desc' => $service_f );
}

foreach ( $order_arr as $order_k => $order_f ) {
	$order_fields[] = array( 'id' => $order_k, 'type' => 'info', 'style' => 'custom', 'color' => '#00a0d2', 'title' => '##' . $order_k . '##', 'desc' => $order_f );
}
foreach ( $withdrawal_arr as $withdrawal_k => $withdrawal_f ) {
	$withdrawal_fields[] = array( 'id' => $withdrawal_k, 'type' => 'info', 'style' => 'custom', 'color' => '#00a0d2', 'title' => '##' . $withdrawal_k . '##', 'desc' => $withdrawal_f );
}
foreach ( $topup_arr as $topup_k => $topup_f ) {
	$topup_fields[] = array( 'id' => $topup_k, 'type' => 'info', 'style' => 'custom', 'color' => '#00a0d2', 'title' => '##' . $topup_k . '##', 'desc' => $topup_f );
}
foreach ( $subscription_arr as $subscription_k => $subscription_f ) {
	$subscription_fields[] = array( 'id' => $subscription_k, 'type' => 'info', 'style' => 'custom', 'color' => '#00a0d2', 'title' => '##' . $subscription_k . '##', 'desc' => $subscription_f );
}
foreach ( $exchange_arr as $exchange_k => $exchange_f ) {
	$exchange_fields[] = array( 'id' => $exchange_k, 'type' => 'info', 'style' => 'custom', 'color' => '#00a0d2', 'title' => '##' . $exchange_k . '##', 'desc' => $exchange_f );
}
foreach ( $link_arr as $link_k => $link_f ) {
	$link_fields[] = array( 'id' => $link_k, 'type' => 'info', 'style' => 'custom', 'color' => '#00a0d2', 'title' => '##' . $link_k . '##', 'desc' => $link_f );
}
foreach ( $site_arr as $site_k => $site_f ) {
	$site_fields[] = array( 'id' => $site_k, 'type' => 'info', 'style' => 'custom', 'color' => '#00a0d2', 'title' => '##' . $site_k . '##', 'desc' => $site_f );
}

Redux::setSection( $opt_name, array(
	'title'  => __( 'Notifications', 'wpjobster' ),
	'desc'   => esc_html__( 'All tags legend (You can NOT use all of them in each email, please see the available shortcodes list from top)', 'wpjobster' ),
	'id'     => 'notifications-content-list',
	'icon'   => 'el el-envelope',
	'fields' => apply_filters( 'wpj_notifications_legend_filter', array_merge(
		array(
			array(
				'id'       => 'users-notification-legend',
				'type'     => 'section',
				'title'    => esc_html__( 'User', 'wpjobster' ),
				'indent'   => true,
			)
		), $user_fields,
		array(
			array(
				'id'       => 'services-notification-legend',
				'type'     => 'section',
				'title'    => esc_html__( 'Service', 'wpjobster' ),
				'indent'   => true,
			)
		), $service_fields,
		array(
			array(
				'id'       => 'orders-notification-legend',
				'type'     => 'section',
				'title'    => esc_html__( 'Order', 'wpjobster' ),
				'indent'   => true,
			)
		), $order_fields,
		array(
			array(
				'id'       => 'withdrawals-notification-legend',
				'type'     => 'section',
				'title'    => esc_html__( 'Withdrawal', 'wpjobster' ),
				'indent'   => true,
			)
		), $withdrawal_fields,
		array(
			array(
				'id'       => 'topup-notification-legend',
				'type'     => 'section',
				'title'    => esc_html__( 'Topup', 'wpjobster' ),
				'indent'   => true,
			)
		), $topup_fields,
		array(
			array(
				'id'       => 'subscription-notification-legend',
				'type'     => 'section',
				'title'    => esc_html__( 'Subscription', 'wpjobster' ),
				'indent'   => true,
			)
		), $subscription_fields,
		array(
			array(
				'id'       => 'exchange-notification-legend',
				'type'     => 'section',
				'title'    => esc_html__( 'Exchange', 'wpjobster' ),
				'indent'   => true,
			)
		), $exchange_fields,
		array(
			array(
				'id'       => 'link-notification-legend',
				'type'     => 'section',
				'title'    => esc_html__( 'Link', 'wpjobster' ),
				'indent'   => true,
			)
		), $link_fields,
		array(
			array(
				'id'       => 'site-notification-legend',
				'type'     => 'section',
				'title'    => esc_html__( 'Site', 'wpjobster' ),
				'indent'   => true,
			)
		), $site_fields
	) )
) );

foreach ( $email_categories as $key => $email_category ) {

	$notification_fields = array();

	foreach ( $email_category["items"] as $reason  => $item ) {
		$description = explode( '<br />', $item['description'] );

		$email_desc = $description[0];

		unset( $description[0] );
		unset( $description[1] );
		unset( $description[2] );
		unset( $description[3] );

		$notification_fields[] = array(
			'id'       => $reason  . '-start',
			'type'     => 'accordion',
			'title'    => $item['title'],
			'subtitle' => $email_desc . '<br />' . sprintf( __( 'Available shortcodes: <b>%s</b>', 'wpjobster' ), implode( ', ', array_filter( array_map( 'trim', $description ) ) ) ),
			'position' => 'start'
		);

		$notification_fields[] = array(
			'id'      => 'uz_email_' . $reason . '_enable',
			'type'    => 'switch',
			'title'   => esc_html__( 'Enable this EMAIL', 'wpjobster' ),
			'default' => get_option( 'uz_email_' . $reason . '_enable' ) == 'yes' ? true : false
		);

		foreach ( $languages as $lang => $lang_name ) {
			$notification_fields[] = array(
				'id'      => 'uz_email_' . $reason . '_' . $lang . '_subject',
				'title'   => __( 'Email Subject:', 'wpjobster' ) . ' (' . $lang_name . ')',
				'type'    => 'text',
				'default' => get_option( 'uz_email_' . $reason . '_' . $lang . '_subject' )
			);

			$notification_fields[] = array(
				'id'    => 'uz_email_' . $reason . '_' . $lang . '_message',
				'title' => __( 'Email Content:', 'wpjobster' ) . ' (' . $lang_name . ')',
				'type'  => 'textarea',
				// 'type'  => 'editor',
				'args'  => array(
					'media_buttons' => false,
					'textarea_rows' => 10,
					'tinymce'       => array(
						'toolbar1'  => 'undo redo | copy cut paste | formatselect fontselect fontsizeselect | removeformat | numlist bullist | outdent indent',
						'toolbar2'  => 'bold italic underline strikethrough superscript subscript wp_code | forecolor backcolor | alignleft aligncenter alignright alignjustify | rtl | wp_add_media image media | link unlink | charmap fullscreen',
						'plugins'   => 'paste directionality fullscreen image link media charmap hr lists charmap wordpress textcolor',
					)
				),
				'default' => get_option( 'uz_email_' . $reason . '_' . $lang . '_message' )
			);
		}

		$notification_fields[] = array(
			'id'       => 'uz_sms_' . $reason . '_enable',
			'type'     => 'switch',
			'title'    => esc_html__( 'Enable this SMS', 'wpjobster' ),
			'disabled' => ! wpj_is_allowed( 'sms_notifications' ) ? true : false,
			'default'  => get_option( 'uz_sms_' . $reason . '_enable' ) == 'yes' ? true : false
		);

		foreach ( $languages as $lang => $lang_name ) {
			$notification_fields[] = array(
				'id'       => 'uz_sms_' . $reason . '_' . $lang . '_message',
				'type'     => 'textarea',
				'title'    => __( 'SMS Content:', 'wpjobster' ) . ' (' . $lang_name . ')',
				'disabled' => ! wpj_is_allowed( 'sms_notifications' ) ? true : false,
				'default'  => get_option( 'uz_sms_' . $reason . '_' . $lang . '_message' )
			);
		}

		$notification_fields[] = array(
			'id'       => $reason  . '-end',
			'type'     => 'accordion',
			'position' => 'end'
		);
	}

	Redux::setSection( $opt_name, array(
		'title'      => $email_category["title"],
		'desc'       => __( 'Email & SMS Notification Content', 'wpjobster' ),
		'id'         => $key,
		'subsection' => true,
		'fields'     => $languages ? $notification_fields : array(
			array(
				'id'    => 'no-preferred-language-selected-' . $key,
				'type'  => 'info',
				'style' => 'warning',
				'title' => __( 'No preferred language selected!', 'wpjobster' ),
				'desc'  => __( 'You must select at least one language in the Languages section of the Notify Settings menu in order to edit the content of the emails.', 'wpjobster' )
			)
		)
	) );
}