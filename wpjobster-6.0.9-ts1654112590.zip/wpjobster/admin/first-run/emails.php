<?php

update_option( 'uz_email_user_new_en_subject', 'Welcome to ##your_site_name##' );
update_option( 'uz_email_user_new_en_message',
				'Hello ##username##,'.PHP_EOL.PHP_EOL.

				'Welcome to our website.'.PHP_EOL.
				'Your username: ##receiver_username##'.PHP_EOL.PHP_EOL.

				'Please follow this link to verify your email address: ##email_verification##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_user_admin_new_en_subject', 'New user registration on ##your_site_name##' );
update_option( 'uz_email_user_admin_new_en_message',
				'Hello admin,'.PHP_EOL.PHP_EOL.

				'A new user just registered on your site.'.PHP_EOL.PHP_EOL.

				'Details:'.PHP_EOL.
				'Username: ##username##'.PHP_EOL.
				'Email: ##user_email##' );

update_option( 'uz_email_user_verification_en_subject', 'Please verify your email address' );
update_option( 'uz_email_user_verification_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Please click the following link in order to verify your email address: ##email_verification##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_job_new_en_subject', 'New job: ##job_name##' );
update_option( 'uz_email_job_new_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your job <b>##job_name##</b> has been posted on the website. However it is not live yet.'.PHP_EOL.
				'The job needs to be approved by the admin before it goes live. '.PHP_EOL.
				'You will be notified by email when the job is active and published.'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_job_acc_en_subject', 'Your new job was published' );
update_option( 'uz_email_job_acc_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your job <b>##job_name##</b> was approved by the administrator.'.PHP_EOL.
				'You can see it here: ##job_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_job_decl_en_subject', 'Your new job was not published yet' );
update_option( 'uz_email_job_decl_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Our team has checked your job <b>##job_name##</b>, and found that you need to make some changes.'.PHP_EOL.PHP_EOL.

				'For more information on what changes need to be done, please login to your account and check your account page: ##my_account_url##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_job_admin_new_en_subject', 'New job: ##job_name##' );
update_option( 'uz_email_job_admin_new_en_message',
				'The user ##username## has posted a new job on your website.'.PHP_EOL.
				'Job name: <b>##job_name##</b> '.PHP_EOL.
				'The job is not automatically approved so you have to manually approve the job before it appears on your website.'.PHP_EOL.PHP_EOL.

				'Go here: ##your_site_url##/wp-admin/edit.php?post_type=job' );

update_option( 'uz_email_job_admin_acc_en_subject', 'New job: ##job_name##' );
update_option( 'uz_email_job_admin_acc_en_message',
				'The user ##username## has posted a new job on your website.'.PHP_EOL.
				'Job name: <b>##job_name##</b> '.PHP_EOL.

				'The job was automatically approved on your website.'.PHP_EOL.PHP_EOL.

				'View the job here: ##job_link##' );

update_option( 'uz_email_withdraw_req_en_subject', 'You have requested a withdrawal' );
update_option( 'uz_email_withdraw_req_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'We have received your request. It will be processed within 2 to 3 working days.'.PHP_EOL.PHP_EOL.

				'Withdraw details:'.PHP_EOL.
				'Amount: ##amount_withdrawn##'.PHP_EOL.
				'Method: ##withdraw_method##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_withdraw_compl_en_subject', 'Your withdrawal request was processed' );
update_option( 'uz_email_withdraw_compl_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your withdraw request was processed.'.PHP_EOL.PHP_EOL.

				'Withdraw details:'.PHP_EOL.
				'Amount: ##amount_withdrawn##'.PHP_EOL.
				'Method: ##withdraw_method##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_withdraw_decl_en_subject', 'Your withdrawal request has been rejected' );
update_option( 'uz_email_withdraw_decl_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Unfortunately, your withdrawal request has been denied.'.PHP_EOL.PHP_EOL.

				'Withdraw details:'.PHP_EOL.
				'Amount: ##amount_withdrawn##'.PHP_EOL.
				'Method: ##withdraw_method##'.PHP_EOL.PHP_EOL.

				'A common reason for rejecting the request is incomplete or insufficient information at our disposal on your account.'.PHP_EOL.
				'Please contact support for more information abou that.'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_level_down_en_subject', 'Your level was downgraded' );
update_option( 'uz_email_level_down_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your level was downgraded to ##current_level##.'.PHP_EOL.
				'Your level will be upgraded again based on your sales and ratings.'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_level_up_en_subject', 'Your level was upgraded' );
update_option( 'uz_email_level_up_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Congratulations! Your level was upgraded to ##current_level##.'.PHP_EOL.
				'Keep up the good work!'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_new_message_en_subject', 'You have a new private message' );
update_option( 'uz_email_new_message_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have received a new message from ##sender_username##.'.PHP_EOL.PHP_EOL.
				'The message: ##private_message_content##'.PHP_EOL.PHP_EOL.
				'If you want to read the message on the site, please follow this link: ##private_message_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_new_request_en_subject', 'You have a new request' );
update_option( 'uz_email_new_request_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have received a new request from ##sender_username##.'.PHP_EOL.
				'Please follow this link in order to answer: ##private_message_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_new_offer_en_subject', 'You have a new offer' );
update_option( 'uz_email_new_offer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have received a new offer from ##sender_username##.'.PHP_EOL.
				'Please follow this link in order to answer: ##private_message_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_offer_acc_buyer_en_subject', 'Your have accepted an offer' );
update_option( 'uz_email_offer_acc_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have accepted the offer from ##sender_username##.'.PHP_EOL.
				'In order to get in touch with the seller, please visit the following link and provide all the info he needs for the work: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_offer_acc_seller_en_subject', 'Your offer was accepted' );
update_option( 'uz_email_offer_acc_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your offer was accepted by ##sender_username##.'.PHP_EOL.
				'In order to get in touch with the buyer, please visit the following link and ask for all the info that you need for the work: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_offer_decl_en_subject', 'Your offer was declined' );
update_option( 'uz_email_offer_decl_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Unfortunately, ##sender_username## declined your offer.'.PHP_EOL.
				'Please contact him for more details using this link: ##private_message_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_offer_withdr_en_subject', 'The offer was withdrawn' );
update_option( 'uz_email_offer_withdr_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has withdrawn the offer.'.PHP_EOL.
				'Please contact him for more details using this link: ##private_message_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_offer_exp_en_subject', 'The offer has expired' );
update_option( 'uz_email_offer_exp_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'The offer from ##sender_username## has expired.'.PHP_EOL.
				'Please contact him for more details using this link: ##private_message_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_purchased_buyer_en_subject', 'New job purchased: ##job_name##' );
update_option( 'uz_email_purchased_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have just bought this job: ##job_name##'.PHP_EOL.
				'In order to get in touch with the seller, please visit the following link and provide all the info he needs for the work: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_purchased_seller_en_subject', 'New job sold: ##job_name##' );
update_option( 'uz_email_purchased_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have just sold this job: ##job_name##'.PHP_EOL.
				'In order to get in touch with the buyer, please visit the following link and ask for all the info that you need for the work: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_order_message_en_subject', 'New message for transaction ##transaction_number##' );
update_option( 'uz_email_order_message_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have a new message from ##sender_username## related to transaction ##transaction_number##.'.PHP_EOL.
				'Please click here in order to read and respond to it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_buyer_en_subject', 'Mutual cancellation request for ##transaction_number##' );
update_option( 'uz_email_cancel_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has requested a mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link and accept or deny this request: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_seller_en_subject', 'Mutual cancellation request for ##transaction_number##' );
update_option( 'uz_email_cancel_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has requested a mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link and accept or deny this request: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_acc_buyer_en_subject', 'The transaction ##transaction_number## was cancelled' );
update_option( 'uz_email_cancel_acc_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has accepted the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_acc_seller_en_subject', 'The transaction ##transaction_number## was cancelled' );
update_option( 'uz_email_cancel_acc_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has accepted the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_decl_buyer_en_subject', 'The buyer refused to cancel the transaction' );
update_option( 'uz_email_cancel_decl_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has denied the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_decl_seller_en_subject', 'The seller refused to cancel the transaction' );
update_option( 'uz_email_cancel_decl_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has denied the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_abort_buyer_en_subject', 'The buyer aborted the cancellation for ##transaction_number##' );
update_option( 'uz_email_cancel_abort_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has aborted the mutual cancellation request for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_abort_seller_en_subject', 'The seller aborted the cancellation for ##transaction_number##' );
update_option( 'uz_email_cancel_abort_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has aborted the mutual cancellation request for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_admin_en_subject', 'The transaction ##transaction_number## was cancelled by admin' );
update_option( 'uz_email_cancel_admin_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Transaction ##transaction_number## was cancelled by admin. The money are refunded to the buyer.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_mod_buyer_en_subject', 'The buyer requested a modification for ##transaction_number##' );
update_option( 'uz_email_mod_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has requested a modification for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_order_delivered_en_subject', 'Congratulations! Transaction ##transaction_number## was delivered' );
update_option( 'uz_email_order_delivered_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'The seller has delivered the order. You can check and download the files here: ##transaction_page_link##'.PHP_EOL.
				'If everything is ok, please mark the job as completed and the funds will be released to the seller.'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_order_complete_en_subject', 'Congratulations! Transaction ##transaction_number## was completed' );
update_option( 'uz_email_order_complete_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'The buyer has marked the order as completed.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_new_feedback_en_subject', 'You have a new feedback for: ##job_name##' );
update_option( 'uz_email_new_feedback_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## just sent you the feedback for transaction ##transaction_number##'.PHP_EOL.
				'You can find the review here: ##transaction_page_link## or on the job page: ##job_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_offer_buyer_en_subject', 'Mutual cancellation request for ##transaction_number##' );
update_option( 'uz_email_cancel_offer_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has requested a mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link and accept or deny this request: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_offer_seller_en_subject', 'Mutual cancellation request for ##transaction_number##' );
update_option( 'uz_email_cancel_offer_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has requested a mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link and accept or deny this request: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_offer_acc_buyer_en_subject', 'The transaction ##transaction_number## was cancelled' );
update_option( 'uz_email_cancel_offer_acc_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has accepted the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_offer_acc_seller_en_subject', 'The transaction ##transaction_number## was cancelled' );
update_option( 'uz_email_cancel_offer_acc_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has accepted the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_offer_decl_buyer_en_subject', 'The buyer refused to cancel the transaction' );
update_option( 'uz_email_cancel_offer_decl_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has denied the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_offer_decl_seller_en_subject', 'The seller refused to cancel the transaction' );
update_option( 'uz_email_cancel_offer_decl_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has denied the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_offer_abort_buyer_en_subject', 'The buyer aborted the cancellation for ##transaction_number##' );
update_option( 'uz_email_cancel_offer_abort_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has aborted the mutual cancellation request for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_offer_abort_seller_en_subject', 'The seller aborted the cancellation for ##transaction_number##' );
update_option( 'uz_email_cancel_offer_abort_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has aborted the mutual cancellation request for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_offer_admin_en_subject', 'The transaction ##transaction_number## was cancelled by admin' );
update_option( 'uz_email_cancel_offer_admin_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Transaction ##transaction_number## was cancelled by admin. The money are refunded to the buyer.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_mod_offer_buyer_en_subject', 'The buyer requested a modification for ##transaction_number##' );
update_option( 'uz_email_mod_offer_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## has requested a modification for transaction ##transaction_number##.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_order_offer_delivered_en_subject', 'Congratulations! Transaction ##transaction_number## was delivered' );
update_option( 'uz_email_order_offer_delivered_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'The seller has delivered the order. You can check and download the files here: ##transaction_page_link##'.PHP_EOL.
				'If everything is ok, please mark the job as completed and the funds will be released to the seller.'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_order_offer_complete_en_subject', 'Congratulations! Transaction ##transaction_number## was completed' );
update_option( 'uz_email_order_offer_complete_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'The buyer has marked the order as completed.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_new_offer_feedback_en_subject', 'You have a new feedback for: ##transaction_number##' );
update_option( 'uz_email_new_offer_feedback_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'##sender_username## just sent you the feedback for transaction ##transaction_number##'.PHP_EOL.
				'You can find the review here: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_balance_down_en_subject', 'Your in-site balance was decreased' );
update_option( 'uz_email_balance_down_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your in-site balance was decreased by admin with ##amount_updated##.'.PHP_EOL.
				'You need to top up your account'.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_balance_up_en_subject', 'Your in-site balance was increased' );
update_option( 'uz_email_balance_up_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your in-site balance was increased by admin with ##amount_updated##.'.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_balance_up_paypal_en_subject', 'Your in-site balance was increased' );
update_option( 'uz_email_balance_up_paypal_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your in-site balance was increased by payment via paypal with ##amount_updated##.'.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_balance_up_topup_en_subject', 'Your in-site balance was increased' );
update_option( 'uz_email_balance_up_topup_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your in-site balance was increased by payment via topup with ##amount_updated##.'.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_balance_admin_down_en_subject', 'Balance decreased for user ##username##' );
update_option( 'uz_email_balance_admin_down_en_message',
				'Hello admin,'.PHP_EOL.PHP_EOL.

				'You or another admin just decreased the in-site balance for the user: ##username## with ##amount_updated##.'.PHP_EOL.

				'Details:'.PHP_EOL.
				'Username: ##username##'.PHP_EOL.
				'Amount Decreased: ##amount_updated##' );

update_option( 'uz_email_balance_admin_up_en_subject', 'Balance increased for user ##username##' );
update_option( 'uz_email_balance_admin_up_en_message',
				'Hello admin,'.PHP_EOL.PHP_EOL.

				'You or another admin just increased the in-site balance for the user: ##username## with ##amount_updated##.'.PHP_EOL.

				'Details:'.PHP_EOL.
				'Username: ##username##'.PHP_EOL.
				'Amount Increased: ##amount_updated##' );

update_option( 'uz_email_balance_admin_up_paypal_en_subject', 'Balance increased for user ##username## via paypal' );
update_option( 'uz_email_balance_admin_up_paypal_en_message',
				'Hello admin,'.PHP_EOL.PHP_EOL.

				'User just increased the in-site balance via paypal. User: ##username## with ##amount_updated##.'.PHP_EOL.

				'Details:'.PHP_EOL.
				'Username: ##username##'.PHP_EOL.
				'Amount Increased: ##amount_updated##' );

update_option( 'uz_email_balance_admin_up_topup_en_subject', 'Balance increased for user ##username## via topup' );
update_option( 'uz_email_balance_admin_up_topup_en_message',
				'Hello admin,'.PHP_EOL.PHP_EOL.

				'User just increased the in-site balance by topup. User: ##username## with ##amount_updated##.'.PHP_EOL.

				'Details:'.PHP_EOL.
				'Username: ##username##'.PHP_EOL.
				'Amount Increased: ##amount_updated##' );

update_option( 'uz_email_balance_negative_en_subject', 'Your in-site balance was negative' );
update_option( 'uz_email_balance_negative_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your in-site balance was negative with ##amount_updated##.'.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_featured_new_en_subject', 'New featured job: ##job_name##' );
update_option( 'uz_email_featured_new_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your job <a href="##job_link##"><b>##job_name##</b></a> has been featured on the website.'.PHP_EOL.
				'Featured info: '.PHP_EOL.
									'##all_featured_info##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_featured_admin_new_en_subject', 'New featured job: ##job_name##' );
update_option( 'uz_email_featured_admin_new_en_message',
				'The user ##username## has featured a new job on your website.'.PHP_EOL.

				'Job name: <a href="##job_link##"><b>##job_name##</b></a>'.PHP_EOL.
				'Featured info: '.PHP_EOL.
									'##all_featured_info##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_request_new_en_subject', 'New request: ##request_name##' );
update_option( 'uz_email_request_new_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your request <b>##request_name##</b> has been posted on the website. However it is not live yet.'.PHP_EOL.
				'The request needs to be approved by the admin before it goes live. '.PHP_EOL.
				'You will be notified by email when the request is active and published.'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_request_acc_en_subject', 'Your new request was published' );
update_option( 'uz_email_request_acc_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your request <b>##request_name##</b> was approved by the administrator.'.PHP_EOL.
				'You can see it here: ##request_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_request_decl_en_subject', 'Your new request was not published yet' );
update_option( 'uz_email_request_decl_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Our team has checked your request <b>##request_name##</b>, and found that you need to make some changes.'.PHP_EOL.PHP_EOL.

				'For more information on what changes need to be done, please login to your account and check your account page: ##my_account_url##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_request_admin_new_en_subject', 'New request: ##request_name##' );
update_option( 'uz_email_request_admin_new_en_message',
				'The user ##username## has posted a new request on your website.'.PHP_EOL.
				'Request name: <b>##request_name##</b> '.PHP_EOL.
				'The request is not automatically approved so you have to manually approve the request before it appears on your website.'.PHP_EOL.PHP_EOL.

				'Go here: ##your_site_url##/wp-admin/edit.php?post_type=request' );

update_option( 'uz_email_request_admin_acc_en_subject', 'New request: ##request_name##' );
update_option( 'uz_email_request_admin_acc_en_message',
				'The user ##username## has posted a new request on your website.'.PHP_EOL.
				'Request name: <b>##request_name##</b> '.PHP_EOL.

				'The request was automatically approved on your website.'.PHP_EOL.PHP_EOL.

				'View the request here: ##request_link##' );

update_option( 'uz_email_send_bankdetails_to_buyer_en_subject', 'Your payment for the following job is pending: ##job_name##' );
update_option( 'uz_email_send_bankdetails_to_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'We have received the order for the following job: ##job_name##. '.PHP_EOL.
				'You can check your order status here: ##transaction_page_link##. '.PHP_EOL.PHP_EOL.

				'In order to further process your order, please make the wire transfer using the following bank details:'.PHP_EOL.PHP_EOL.
				'##bank_details##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_send_bankdetails_to_topup_buyer_en_subject', 'Your top up payment is pending' );
update_option( 'uz_email_send_bankdetails_to_topup_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'In order to further process your topup order, please make the wire transfer using the following bank details:'.PHP_EOL.PHP_EOL.
				'##bank_details##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_send_bankdetails_to_feature_buyer_en_subject', 'Your job feature payment is pending' );
update_option( 'uz_email_send_bankdetails_to_feature_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'We have received the order for featuring the following job: ##job_name##. '.PHP_EOL.PHP_EOL.

				'In order to further process your order, please make the wire transfer using the following bank details:'.PHP_EOL.PHP_EOL.
				'##bank_details##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_payment_completed_by_admin_en_subject', 'Your payment was confirmed' );
update_option( 'uz_email_payment_completed_by_admin_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'The admin just confirmed your payment.'.PHP_EOL.
				'In order to get in touch with the seller, please visit the following link and provide all the info he needs for the work: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_admin_payment_completed_by_admin_en_subject', 'You have just confirmed a payment' );
update_option( 'uz_email_admin_payment_completed_by_admin_en_message',

				'Hello admin,'.PHP_EOL.PHP_EOL.

				'You have just confirmed a payment for the following order: ##transaction_page_link##' );

update_option( 'uz_email_new_custom_extra_en_subject', 'You have a new custom extra' );
update_option( 'uz_email_new_custom_extra_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have received a new custom extra from ##sender_username##.'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_custom_extra_en_subject', 'You have a custom extra cancelled' );
update_option( 'uz_email_cancel_custom_extra_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'A custom extra from ##sender_username## was cancelled.'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_decline_custom_extra_en_subject', 'You have a custom extra declined' );
update_option( 'uz_email_decline_custom_extra_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'A custom extra was declined by ##sender_username##.'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_custom_extra_paid_new_en_subject', 'You paid a new custom extra' );
update_option( 'uz_email_custom_extra_paid_new_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You just paid a custom extra.'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_custom_extra_paid_new_seller_en_subject', 'New custom extra payment' );
update_option( 'uz_email_custom_extra_paid_new_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'A custom extra was paid by ##sender_username##.'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_custom_extra_paid_admin_new_en_subject', 'New custom extra payment on ##your_site_name##' );
update_option( 'uz_email_custom_extra_paid_admin_new_en_message',
				'Hello admin,'.PHP_EOL.PHP_EOL.

				'A custom extra was paid on your site.'.PHP_EOL.PHP_EOL.

				'Order: ##transaction_page_link##' );

update_option( 'uz_email_custom_extra_cancelled_by_admin_en_subject', 'Custom extra payment cancelled by admin' );
update_option('uz_email_custom_extra_cancelled_by_admin_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'A custom extra payment ( with Bank Transfer ) was cancelled by admin.'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team');

update_option( 'uz_email_custom_extra_cancelled_by_admin_seller_en_subject', 'Custom extra payment cancelled by admin' );
update_option('uz_email_custom_extra_cancelled_by_admin_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'A custom extra payment ( with Bank Transfer ) was cancelled by admin.'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team');

update_option( 'uz_email_send_bankdetails_to_custom_extra_buyer_en_subject', 'Your custom extra payment is pending' );
update_option( 'uz_email_send_bankdetails_to_custom_extra_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'We have received the order for custom extra. '.PHP_EOL.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'In order to further process your order, please make the wire transfer using the following bank details:'.PHP_EOL.PHP_EOL.
				'##bank_details##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_job_edit_en_subject', 'Edit job: ##job_name##' );
update_option( 'uz_email_job_edit_en_message',
				'The user ##username## has edited a job on your website.'.PHP_EOL.
				'Job name: <b>##job_name##</b> '.PHP_EOL.
				'The job is not automatically approved so you have to manually approve the job before it appears on your website.'.PHP_EOL.PHP_EOL.

				'Go here: ##your_site_url##/wp-admin/edit.php?post_type=job' );

update_option( 'uz_email_request_edit_en_subject', 'Edit request: ##request_name##' );
update_option( 'uz_email_request_edit_en_message',
				'The user ##username## has edited a request on your website.'.PHP_EOL.
				'Request name: <b>##request_name##</b> '.PHP_EOL.
				'The request is not automatically approved so you have to manually approve the request before it appears on your website.'.PHP_EOL.PHP_EOL.

				'Go here: ##your_site_url##/wp-admin/edit.php?post_type=request' );

update_option( 'uz_email_new_bank_transfer_pending_en_subject', 'New Bank Transfer Pending' );
update_option( 'uz_email_new_bank_transfer_pending_en_message',
				'Hello admin, '.PHP_EOL.PHP_EOL.

				'##sender_username## will make a bank transfer payment which you have to manually approve in the next few days, as soon as it gets cleared. '.PHP_EOL.PHP_EOL.

				'Payment type: ##payment_type## '.PHP_EOL.
				'Payment amount: ##payment_amount## '.PHP_EOL.PHP_EOL.

				'You can find more details and approve it on the following link: '.PHP_EOL.
				'##admin_orders_url## '.PHP_EOL.PHP_EOL.

				'Thank you, '.PHP_EOL.
				'##your_site_name## team.' );

update_option( 'uz_email_price_update_subscription_en_subject', 'Subscription price updated on ##your_site_name##' );
update_option( 'uz_email_price_update_subscription_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'We have updated the subscription price, please check your account for more details: '.PHP_EOL.
				'##subscription_url##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_balance_down_subscription_en_subject', 'New subscription purchase on ##your_site_name##' );
update_option( 'uz_email_balance_down_subscription_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have successfully purchased a subscription on ##your_site_name##.'.PHP_EOL.PHP_EOL.

				'Subscription: ##current_subscription_level##,'.PHP_EOL.
				'Period: ##current_subscription_period##,'.PHP_EOL.
				'Price: $ ##current_subscription_amount##'.PHP_EOL.PHP_EOL.

				'Next subscription amount: $ ##next_subscription_amount##,'.PHP_EOL.
				'Next billing date: ##next_billing_date##,'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_balance_down_subscription_change_en_subject', 'Subscription changed on ##your_site_name##' );
update_option( 'uz_email_balance_down_subscription_change_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have successfully changed your subscription on ##your_site_name##.'.PHP_EOL.PHP_EOL.

				'Subscription: ##current_subscription_level##,'.PHP_EOL.
				'Period: ##current_subscription_period##,'.PHP_EOL.
				'Price: $ ##current_subscription_amount##'.PHP_EOL.PHP_EOL.

				'Next subscription amount: $ ##next_subscription_amount##,'.PHP_EOL.
				'Next billing date: ##next_billing_date##,'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_wpjobster_subscription_prior_notification_en_subject', 'Subscription renewal on ##your_site_name##' );
update_option('uz_email_wpjobster_subscription_prior_notification_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'This is a reminder that your subscription with level ##current_subscription_level## expires in ##no_of_days_subscription_left## day( s ) and you are now within your subscription grace period.'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team');

update_option( 'uz_email_subscription_cancel_en_subject', 'Subscription cancellation on ##your_site_name##' );
update_option( 'uz_email_subscription_cancel_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have successfully cancelled your subscription on ##your_site_name##.'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_subscription_cancel_lowbalance_en_subject', 'Subscription cancellation on ##your_site_name##' );
update_option( 'uz_email_subscription_cancel_lowbalance_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Your subscription on ##your_site_name## has been cancelled because you don\'t have enough funds in your wallet.'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_subscription_schedule_en_subject', 'Subscription scheduled on ##your_site_name##' );
update_option( 'uz_email_subscription_schedule_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have successfully scheduled your subscription on ##your_site_name##.'.PHP_EOL.PHP_EOL.

				'Subscription: ##next_subscription_level##,'.PHP_EOL.
				'Next subscription amount: $ ##next_subscription_amount##,'.PHP_EOL.
				'Next billing date: ##next_billing_date##,'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_user_forgot_password_en_subject', 'Reset Password' );
update_option( 'uz_email_user_forgot_password_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You or Someone has asked to reset the password for the following site and username.'.PHP_EOL.PHP_EOL.

				'##your_site_url##  Username: ##receiver_username##'.PHP_EOL.PHP_EOL.

				'To reset your password visit the following address, otherwise just ignore this email and nothing will happen.'.PHP_EOL.
				'##password_reset_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_balance_up_topup_en_subject', 'Balance increased for user ##username## via topup' );
update_option( 'uz_email_balance_up_topup_en_message',
				'Hello admin,'.PHP_EOL.PHP_EOL.

				'User just increased the in-site balance by topup. User: ##username## with ##amount_updated##.'.PHP_EOL.

				'Details:'.PHP_EOL.
				'Username: ##username##'.PHP_EOL.
				'Amount Increased: ##amount_updated##' );

update_option( 'uz_email_new_tips_en_subject', 'You create a new tips' );
update_option( 'uz_email_new_tips_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You just create a new tips order'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_tips_en_subject', 'You cancelled a tips order' );
update_option( 'uz_email_cancel_tips_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'A tips order was cancelled.'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_tips_paid_new_en_subject', 'You have a new tips' );
update_option( 'uz_email_tips_paid_new_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'You have received a new tips from ##sender_username##.'.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_send_bankdetails_to_tips_buyer_en_subject', 'Your tips payment is pending' );
update_option( 'uz_email_send_bankdetails_to_tips_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'We have received the order for tips. '.PHP_EOL.PHP_EOL.
				'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'In order to further process your order, please make the wire transfer using the following bank details:'.PHP_EOL.PHP_EOL.
				'##bank_details##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_ord_expired_seller_en_subject', 'The transaction ##transaction_number## was cancelled' );
update_option( 'uz_email_cancel_ord_expired_seller_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Unfortunately, ##sender_username## has cancelled the transaction ##transaction_number## because you failed to deliver the order on time.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_cancel_ord_expired_buyer_en_subject', 'The transaction ##transaction_number## was cancelled' );
update_option( 'uz_email_cancel_ord_expired_buyer_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'This is a confirmation that the transaction ##transaction_number## has been successfully cancelled. Money has been refunded to you in a form of credit balance.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_admin_arbitration_en_subject', 'The user ##username## has requested arbitration' );
update_option( 'uz_email_admin_arbitration_en_message',
				'The user ##username## has requested arbitration for:'.PHP_EOL.PHP_EOL.

				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Job name: ##job_name##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##' );

update_option( 'uz_email_arb_new_request_en_subject', 'Arbitration request confirmation' );
update_option( 'uz_email_arb_new_request_en_message',
				'Hello ##username##,'.PHP_EOL.PHP_EOL.

				'This is a confirmation that we have received an arbitration request for a transaction you are involved in:'.PHP_EOL.PHP_EOL.

				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Job name: ##job_name##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Should we require additional information we will leave you a message on the transaction page directly.'.PHP_EOL.PHP_EOL.

				'Regards,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_arb_request_closed_buyer_en_subject', 'Arbitration in favor of ##buyer_username##' );
update_option( 'uz_email_arb_request_closed_buyer_en_message',
				'Hello ##username##,'.PHP_EOL.PHP_EOL.

				'This is a confirmation that arbitration request for the transaction referenced below has been decided in favor of ##buyer_username##.'.PHP_EOL.PHP_EOL.

				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Job name: ##job_name##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'This order has been cancelled and ##buyer_username## has been refunded.'.PHP_EOL.PHP_EOL.

				'Message from support: "##message_from_support##"'.PHP_EOL.PHP_EOL.

				'Regards,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_arb_request_closed_seller_en_subject', 'Arbitration in favor of ##seller_username##' );
update_option( 'uz_email_arb_request_closed_seller_en_message',
				'Hello ##username##,'.PHP_EOL.PHP_EOL.

				'This is a confirmation that arbitration request for the transaction referenced below has been decided in favor of ##seller_username##.'.PHP_EOL.PHP_EOL.

				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Job name: ##job_name##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'##seller_username## should proceed with delivering the order.'.PHP_EOL.PHP_EOL.

				'Message from support: "##message_from_support##"'.PHP_EOL.PHP_EOL.

				'Regards,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_arb_request_aborted_en_subject', 'Arbitration aborted' );
update_option( 'uz_email_arb_request_aborted_en_message',
				'Hello ##username##,'.PHP_EOL.PHP_EOL.

				'This is a confirmation that arbitration request for the transaction referenced below has been aborted by ##username_aborting##.'.PHP_EOL.PHP_EOL.

				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Job name: ##job_name##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Regards,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_admin_new_subscription_en_subject', 'New subscription for user ##username##' );
update_option( 'uz_email_admin_new_subscription_en_message',
				'The user ##username## has purchased a subscription on ##your_site_name##'.PHP_EOL.PHP_EOL.

				'Subscription: ##current_subscription_level##,'.PHP_EOL.
				'Period: ##current_subscription_period##,'.PHP_EOL.
				'Price: $ ##current_subscription_amount##'
);

update_option( 'uz_email_admin_upgrade_subscription_en_subject', 'Subscription changed for user ##username##' );
update_option( 'uz_email_admin_upgrade_subscription_en_message',
				'The user ##username## changed his subscription on ##your_site_name##'.PHP_EOL.PHP_EOL.

				'Subscription: ##current_subscription_level##,'.PHP_EOL.
				'Period: ##current_subscription_period##,'.PHP_EOL.
				'Price: $ ##current_subscription_amount##'
);

update_option( 'uz_email_admin_cancel_subscription_en_subject', 'Subscription cancelled for user ##username##' );
update_option( 'uz_email_admin_cancel_subscription_en_message',
				'The user ##username## cancelled his subscription on ##your_site_name##'
);

update_option( 'uz_email_admin_new_withdrawal_request_en_subject', 'New withdrawal request from user ##withdrawal_username##' );
update_option( 'uz_email_admin_new_withdrawal_request_en_message',
				'Hello admin'.PHP_EOL.PHP_EOL.

				'You have a new withdrawal request'.PHP_EOL.PHP_EOL.

				'User: ##withdrawal_username##'.PHP_EOL.
				'Amount: ##withdrawal_amount##'.PHP_EOL.
				'Payment Method: ##withdrawal_method##'
);

update_option( 'uz_email_admin_openexchangerates_not_responding_en_subject', '[WPJobster Warning] OpenExchangeRates.org is not responding!' );
update_option( 'uz_email_admin_openexchangerates_not_responding_en_message',
				'Hello admin'.PHP_EOL.PHP_EOL.

				'The exchange rates were not updated because the JSON from OpenExchangeRates.org was empty. That means either their site was down when we tried to fetch them or your App ID is wrong. If this is the first time when you receive this message, please check if you have filled your Open Exchange Rate App ID in your site\'s settings ( WPJobster > Pricing Settings > Rates ). If you want, you can update the rates manually or wait for the daily automatic update.'
);

update_option( 'uz_email_admin_openexchangerates_higher_en_subject', '[WPJobster Warning] Currency Drop higher than 5%!' );
update_option( 'uz_email_admin_openexchangerates_higher_en_message',
				'Hello admin'.PHP_EOL.PHP_EOL.

				'The exchange rates were not updated because the difference between the following currencies compared to USD was bigger than 5%:'.PHP_EOL.PHP_EOL.

				'[start_list]'.PHP_EOL.
				'##main_currency## from ##old_price## to ##new_price## ( ##percent_difference##% )'.PHP_EOL.
				'[end_list]'.PHP_EOL.

				"Please go to your site's settings ( WPJobster > Pricing Settings > Rates ) and update the rates manually. Next time, if the difference will be smaller than 5% they will be updated automatically."
);

update_option( 'uz_email_job_admin_purchased_en_subject', 'New Job Purchased on your site - ##job_name##' );
update_option( 'uz_email_job_admin_purchased_en_message',
				'Hello admin'.PHP_EOL.PHP_EOL.

				'A new job has been purchased on your site:'.PHP_EOL.PHP_EOL.

				'Job name: <a href="##job_link##"><b>##job_name##</b></a>'
);

update_option( 'uz_email_extend_delivery_request_en_subject', 'The user ##sender_username## has requested an extension of the delivery time' );
update_option( 'uz_email_extend_delivery_request_en_message',
				'The user ##sender_username## has requested an extension of the delivery time for:'.PHP_EOL.PHP_EOL.

				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Job name: ##job_name##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Message: ##extend_delivery_message##'.PHP_EOL.
				'Required number of days: ##extend_delivery_days##' );

update_option( 'uz_email_extend_delivery_accept_en_subject', 'The user ##sender_username## has accepted the extension of the delivery time' );
update_option( 'uz_email_extend_delivery_accept_en_message',
				'The user ##sender_username## has accepted the extension of the delivery time for:'.PHP_EOL.PHP_EOL.

				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Job name: ##job_name##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Message: ##extend_delivery_message##'.PHP_EOL.
				'Required number of days: ##extend_delivery_days##' );

update_option( 'uz_email_extend_delivery_decline_en_subject', 'The user ##sender_username## has declined the extension of the delivery time' );
update_option( 'uz_email_extend_delivery_decline_en_message',
				'The user ##sender_username## has declined the extension of the delivery time for:'.PHP_EOL.PHP_EOL.

				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Job name: ##job_name##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Message: ##extend_delivery_message##'.PHP_EOL.
				'Required number of days: ##extend_delivery_days##' );

update_option( 'uz_email_extend_delivery_abort_en_subject', 'The user ##sender_username## has aborted the extension of the delivery time' );
update_option( 'uz_email_extend_delivery_abort_en_message',
				'The user ##sender_username## has aborted the extension of the delivery time for:'.PHP_EOL.PHP_EOL.

				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Job name: ##job_name##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Message: ##extend_delivery_message##'.PHP_EOL.
				'Required number of days: ##extend_delivery_days##' );

update_option( 'uz_email_ord_expires_soon_en_subject', 'Transaction ##transaction_number## will expire soon' );
update_option( 'uz_email_ord_expires_soon_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'We would like to remind you that the transaction with number ##transaction_number## will expire soon.'.PHP_EOL.
				'Please complete the transaction.'.PHP_EOL.PHP_EOL.

				'Job name: <a href="##job_link##"><b>##job_name##</b></a>'.PHP_EOL.PHP_EOL.
				'Transaction number: ##transaction_number##'.PHP_EOL.
				'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Regards,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_order_accepted_en_subject', 'The seller accepted the order ##transaction_number##' );
update_option( 'uz_email_order_accepted_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Transaction ##transaction_number## was accepted by seller.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );

update_option( 'uz_email_order_rejected_en_subject', 'The seller rejected the order ##transaction_number##' );
update_option( 'uz_email_order_rejected_en_message',
				'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

				'Transaction ##transaction_number## was rejected by seller. The money are refunded to your account.'.PHP_EOL.
				'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

				'Thank you,'.PHP_EOL.
				'##your_site_name## Team' );