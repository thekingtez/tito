<?php
wpj_frun_htaccess_set_server_limits();

function wpj_frun_htaccess_set_server_limits() {
	$limits = array();
	$limits[] = 'php_value memory_limit 512M';
	$limits[] = 'php_value post_max_size 256M';
	$limits[] = 'php_value upload_max_filesize 256M';
	$limits[] = 'php_value max_input_vars 3000';

	$result = wpj_add_content_to_htaccess( '.htaccess', 'SERVER LIMITS', $limits );
	if ( $result != 1 ) { echo '<p>' . $result . '</p>'; }
}