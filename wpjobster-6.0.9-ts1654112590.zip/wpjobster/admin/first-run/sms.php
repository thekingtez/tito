<?php

update_option( 'uz_sms_user_new_en_message',
	'Hello ##username##,'.PHP_EOL.PHP_EOL.

	'Your username: ##receiver_username##'.PHP_EOL.PHP_EOL.

	'Link to verify your email address: ##email_verification##' );

update_option( 'uz_sms_user_admin_new_en_message',
	'Hello admin,'.PHP_EOL.PHP_EOL.

	'A new user just registered on your site.'.PHP_EOL.PHP_EOL.

	'Details:'.PHP_EOL.
	'Username: ##username##'.PHP_EOL.
	'Email: ##user_email##' );

update_option( 'uz_sms_user_verification_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Click on following link in order to verify your email address: ##email_verification##' );

update_option( 'uz_sms_job_new_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your job ##job_name## has been posted on website.'.PHP_EOL.
	'The job needs to be approved by the admin before it goes live.' );

update_option( 'uz_sms_job_acc_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your job ##job_name## was approved by the administrator.'.PHP_EOL.
	'You can see it here: ##job_link##' );

update_option( 'uz_sms_job_decl_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Our team has checked your job ##job_name##, and found that you need to make some changes.'.PHP_EOL.PHP_EOL.

	'For more info please login to your account' );

update_option( 'uz_sms_job_admin_new_en_message',
	'Job name: ##job_name##'.PHP_EOL.
	'The job is not automatically approved so you have to manually approve the job before it appears on your website.' );

update_option( 'uz_sms_job_admin_acc_en_message',
	'The user ##username## has posted a new job on your website.'.PHP_EOL.
	'Job name: <b>##job_name##</b> '.PHP_EOL.

	'The job was automatically approved on your website.' );

update_option( 'uz_sms_withdraw_req_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'We have received your request. It will be processed within 2 to 3 working days.'.PHP_EOL.PHP_EOL.

	'Amt: ##amount_withdrawn##'.PHP_EOL.
	'Method: ##withdraw_method##' );

update_option( 'uz_sms_withdraw_compl_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your withdraw request was processed.'.PHP_EOL.PHP_EOL.

	'Withdraw details:'.PHP_EOL.
	'Amount: ##amount_withdrawn##'.PHP_EOL.
	'Method: ##withdraw_method##' );

update_option( 'uz_sms_withdraw_decl_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Unfortunately, your withdrawal request has been denied.'.PHP_EOL.PHP_EOL.

	'Withdraw details:'.PHP_EOL.
	'Amount: ##amount_withdrawn##'.PHP_EOL.
	'Method: ##withdraw_method##' );

update_option( 'uz_sms_level_down_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your level was downgraded to ##current_level##.'.PHP_EOL.
	'Your level will be upgraded again based on your sales and ratings.' );

update_option( 'uz_sms_level_up_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Congratulations! Your level was upgraded to ##current_level##.'.PHP_EOL.
	'Keep up the good work!' );

update_option( 'uz_sms_balance_down_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your in-site balance was decreased by admin with ##amount_updated##.'.PHP_EOL.
	'You need to top up your account'.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_balance_up_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your in-site balance was increased by admin with ##amount_updated##.'.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_balance_up_paypal_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your in-site balance was increased by payment via paypal with ##amount_updated##.'.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_balance_admin_down_en_message',
	'Hello admin,'.PHP_EOL.PHP_EOL.

	'You or another admin just decreased the in-site balance for the user: ##username## with ##amount_updated##.'.PHP_EOL.

	'Amount Decreased: ##amount_updated##' );

update_option( 'uz_sms_balance_admin_up_en_message',
	'Hello admin,'.PHP_EOL.PHP_EOL.

	'You or another admin just increased the in-site balance for the user: ##username## with ##amount_updated##.'.PHP_EOL.

	'Amount Increased: ##amount_updated##' );

update_option( 'uz_sms_balance_admin_up_paypal_en_message',
	'Hello admin,'.PHP_EOL.PHP_EOL.

	'User just increased the in-site balance via paypal. User: ##username## with ##amount_updated##.'.PHP_EOL.

	'Amount Increased: ##amount_updated##' );

update_option( 'uz_sms_new_message_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You have received a new message from ##sender_username##.'.PHP_EOL.
	'The message: ##private_message_content##'.PHP_EOL.PHP_EOL.
	'If you want to read the message on the site, please follow this link: ##private_message_link##' );

update_option( 'uz_sms_new_request_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You have received a new request from ##sender_username##.'.PHP_EOL.
	'Follow this link in order to answer: ##private_message_link##' );

update_option( 'uz_sms_new_offer_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You have received a new offer from ##sender_username##.'.PHP_EOL.
	'Follow this link in order to answer: ##private_message_link##' );

update_option( 'uz_sms_offer_acc_buyer_en_message',
	'You have accepted the offer from ##sender_username##.'.PHP_EOL.
	'In order to get in touch with the seller, please visit the following link: ##transaction_page_link##' );

update_option( 'uz_sms_offer_acc_seller_en_message',
	'Your offer was accepted by ##sender_username##.'.PHP_EOL.
	'In order to get in touch with the buyer, please visit the following link: ##transaction_page_link##' );

update_option( 'uz_sms_offer_decl_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Unfortunately, ##sender_username## declined your offer.'.PHP_EOL.
	'Contact him for more details using link: ##private_message_link##' );

update_option( 'uz_sms_offer_withdr_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'##sender_username## has withdrawn the offer.'.PHP_EOL.
	'Contact him for more details using link: ##private_message_link##' );

update_option( 'uz_sms_offer_exp_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'The offer from ##sender_username## has expired.'.PHP_EOL.
	'Contact him for more details using link: ##private_message_link##' );

update_option( 'uz_sms_purchased_buyer_en_message',
	'You have just bought this job: ##job_name##'.PHP_EOL.
	'In order to get in touch with the seller, please visit the following link: ##transaction_page_link##' );

update_option( 'uz_sms_purchased_seller_en_message',
	'You have just sold this job: ##job_name##'.PHP_EOL.
	'In order to get in touch with the buyer, please visit the following link: ##transaction_page_link##' );

update_option( 'uz_sms_order_message_en_message',
	'You have a new msg from ##sender_username## related to transaction ##transaction_number##.'.PHP_EOL.
	'Click here to read and respond: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_buyer_en_message',
	'##sender_username## has requested a mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link to accept or deny request: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_seller_en_message',
	'##sender_username## has requested a mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link to accept or deny request: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_acc_buyer_en_message',
	'##sender_username## has accepted the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_acc_seller_en_message',
	'##sender_username## has accepted the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_decl_buyer_en_message',
	'##sender_username## has denied the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_decl_seller_en_message',
	'##sender_username## has denied the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_abort_buyer_en_message',
	'##sender_username## has aborted the mutual cancellation request for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_abort_seller_en_message',
	'##sender_username## has aborted the mutual cancellation request for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_admin_en_message',
	'Transaction ##transaction_number## was cancelled by admin. The money are refunded to the buyer.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_mod_buyer_en_message',
	'##sender_username## has requested a modification for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_order_delivered_en_message',
	'The seller has delivered the order. You can check and download the files here: ##transaction_page_link##'.PHP_EOL.
	'Mark the job as completed if ok' );

update_option( 'uz_sms_order_complete_en_message',
	'The buyer has marked the order as completed.'.PHP_EOL.
	'Please click this link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_new_feedback_en_message',
	'##sender_username## just sent you the feedback for transaction ##transaction_number##'.PHP_EOL.
	'You can find the review here: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_offer_buyer_en_message',
	'##sender_username## has requested a mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link to accept or deny request: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_offer_seller_en_message',
	'##sender_username## has requested a mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link to accept or deny request: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_offer_acc_buyer_en_message',
	'##sender_username## has accepted the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_offer_acc_seller_en_message',
	'##sender_username## has accepted the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_offer_decl_buyer_en_message',
	'##sender_username## has denied the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_offer_decl_seller_en_message',
	'##sender_username## has denied the mutual cancellation for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_offer_abort_buyer_en_message',
	'##sender_username## has aborted the mutual cancellation request for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_offer_abort_seller_en_message',
	'##sender_username## has aborted the mutual cancellation request for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_offer_admin_en_message',
	'Transaction ##transaction_number## was cancelled by admin. The money are refunded to the buyer.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_mod_offer_buyer_en_message',

	'##sender_username## has requested a modification for transaction ##transaction_number##.'.PHP_EOL.
	'Link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_order_offer_delivered_en_message',
	'The seller has delivered the order. You can check and download the files here: ##transaction_page_link##'.PHP_EOL.
	'Mark the job as completed, If ok' );

update_option( 'uz_sms_order_offer_complete_en_message',
	'The buyer has marked the order as completed.'.PHP_EOL.
	'Please click this link for more info: ##transaction_page_link##' );

update_option( 'uz_sms_new_offer_feedback_en_message',
	'##sender_username## just sent you the feedback for transaction ##transaction_number##'.PHP_EOL.
	'You can find the review here: ##transaction_page_link##' );

update_option( 'uz_sms_featured_new_en_message',
	'Your job ##job_link## ##job_name## has been featured on the website.'.PHP_EOL.
	'Featured info: '.PHP_EOL.
						'##all_featured_info##' );

update_option( 'uz_sms_balance_negative_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your in-site balance was negative with ##amount_updated##.' );

update_option( 'uz_sms_new_custom_extra_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You have received a new custom extra from ##sender_username##.'.PHP_EOL.
	'Follow this link in order to see it: ##transaction_page_link##' );

update_option( 'uz_sms_cancel_custom_extra_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'A custom extra from ##sender_username## was cancelled.'.PHP_EOL.
	'Follow this link in order to see it: ##transaction_page_link##' );

update_option( 'uz_sms_decline_custom_extra_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'A custom extra was declined by ##sender_username##.'.PHP_EOL.
	'Follow this link in order to see it: ##transaction_page_link##' );

update_option( 'uz_sms_custom_extra_paid_new_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You just paid a custom extra.'.PHP_EOL.
	'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_custom_extra_paid_new_seller_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'A custom extra was paid by ##sender_username##.'.PHP_EOL.
	'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_custom_extra_paid_admin_new_en_message',
	'Hello admin,'.PHP_EOL.PHP_EOL.

	'A custom extra was paid on your site.'.PHP_EOL.PHP_EOL.

	'Order: ##transaction_page_link##' );

update_option('uz_sms_custom_extra_cancelled_by_admin_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'A custom extra payment ( with Bank Transfer ) was cancelled by admin.'.PHP_EOL.
	'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team');

update_option('uz_sms_custom_extra_cancelled_by_admin_seller_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'A custom extra payment ( with Bank Transfer ) was cancelled by admin.'.PHP_EOL.
	'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team');

update_option( 'uz_sms_send_bankdetails_to_custom_extra_buyer_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'We have received the order for custom extra. '.PHP_EOL.PHP_EOL.
	'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'In order to further process your order, please make the wire transfer using the following bank details:'.PHP_EOL.PHP_EOL.
	'##bank_details##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_price_update_subscription_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'We have updated the subscription price, please check your account for more details: '.PHP_EOL.
	'##subscription_url##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_balance_down_subscription_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You have successfully purchased a subscription on ##your_site_name##.'.PHP_EOL.PHP_EOL.

	'Subscription: ##current_subscription_level##,'.PHP_EOL.
	'Period: ##current_subscription_period##,'.PHP_EOL.
	'Price: $ ##current_subscription_amount##'.PHP_EOL.PHP_EOL.

	'Next subscription amount: $ ##next_subscription_amount##,'.PHP_EOL.
	'Next billing date: ##next_billing_date##,'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_balance_down_subscription_change_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You have successfully changed your subscription on ##your_site_name##.'.PHP_EOL.PHP_EOL.

	'Subscription: ##current_subscription_level##,'.PHP_EOL.
	'Period: ##current_subscription_period##,'.PHP_EOL.
	'Price: $ ##current_subscription_amount##'.PHP_EOL.PHP_EOL.

	'Next subscription amount: $ ##next_subscription_amount##,'.PHP_EOL.
	'Next billing date: ##next_billing_date##,'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option('uz_sms_wpjobster_subscription_prior_notification_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'This is a reminder that your subscription with level ##current_subscription_level## expires in ##no_of_days_subscription_left## day( s ) and you are now within your subscription grace period.'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team');

update_option( 'uz_sms_subscription_cancel_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You have successfully cancelled your subscription on ##your_site_name##.'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_subscription_cancel_lowbalance_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your subscription on ##your_site_name## has been cancelled because you don\'t have enough funds in your wallet.'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_subscription_schedule_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You have successfully scheduled your subscription on ##your_site_name##.'.PHP_EOL.PHP_EOL.

	'Subscription: ##next_subscription_level##,'.PHP_EOL.
	'Next subscription amount: $ ##next_subscription_amount##,'.PHP_EOL.
	'Next billing date: ##next_billing_date##,'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_user_forgot_password_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'To reset your password visit the following address, otherwise just ignore this sms and nothing will happen.'.PHP_EOL.
	'##password_reset_link##' );

update_option( 'uz_sms_balance_admin_up_topup_en_message',
	'Hello admin,'.PHP_EOL.PHP_EOL.

	'User just increased the in-site balance by topup. User: ##username## with ##amount_updated##.'.PHP_EOL.

	'Amount Increased: ##amount_updated##' );

update_option( 'uz_sms_balance_up_topup_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Your in-site balance was increased by payment via topup with ##amount_updated##.'.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_new_tips_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You just create a new tips order'.PHP_EOL.
	'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_cancel_tips_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'A tips order was cancelled.'.PHP_EOL.
	'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_tips_paid_new_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'You have received a new tips from ##sender_username##.'.PHP_EOL.
	'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_send_bankdetails_to_tips_buyer_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'We have received the order for tips. '.PHP_EOL.PHP_EOL.
	'Please follow this link in order to see it: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'In order to further process your order, please make the wire transfer using the following bank details:'.PHP_EOL.PHP_EOL.
	'##bank_details##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_cancel_ord_expired_seller_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Unfortunately, ##sender_username##  has cancelled the transaction ##transaction_number## because you failed to deliver the order on time.'.PHP_EOL.
	'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_cancel_ord_expired_buyer_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'This is a confirmation that the transaction ##transaction_number## has been successfully cancelled. Money has been refunded to you in a form of credit balance.'.PHP_EOL.
	'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );


update_option( 'uz_sms_admin_arbitration_en_message',
	'The user ##username## has requested arbitration for:'.PHP_EOL.PHP_EOL.

	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Job name: ##job_name##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##' );

update_option( 'uz_sms_arb_new_request_en_message',
	'Hello ##username##,'.PHP_EOL.PHP_EOL.

	'This is a confirmation that we have received an arbitration request for a transaction you are involved in:'.PHP_EOL.PHP_EOL.

	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Job name: ##job_name##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Should we require additional information we will leave you a message on the transaction page directly.'.PHP_EOL.PHP_EOL.

	'Regards,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_arb_request_closed_buyer_en_message',
	'Hello ##username##,'.PHP_EOL.PHP_EOL.

	'This is a confirmation that arbitration request for the transaction referenced below has been decided in favor of ##buyer_username##.'.PHP_EOL.PHP_EOL.

	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Job name: ##job_name##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'This order has been cancelled and ##buyer_username## has been refunded.'.PHP_EOL.PHP_EOL.

	'Message from support: "##message_from_support##"'.PHP_EOL.PHP_EOL.

	'Regards,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_arb_request_closed_seller_en_message',
	'Hello ##username##,'.PHP_EOL.PHP_EOL.

	'This is a confirmation that arbitration request for the transaction referenced below has been decided in favor of ##seller_username##.'.PHP_EOL.PHP_EOL.

	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Job name: ##job_name##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'##seller_username## should proceed with delivering the order.'.PHP_EOL.PHP_EOL.

	'Message from support: "##message_from_support##"'.PHP_EOL.PHP_EOL.

	'Regards,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_arb_request_aborted_en_message',
	'Hello ##username##,'.PHP_EOL.PHP_EOL.

	'This is a confirmation that arbitration request for the transaction referenced below has been aborted by ##username_aborting##.'.PHP_EOL.PHP_EOL.

	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Job name: ##job_name##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Regards,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_admin_new_subscription_en_message',
	'The user ##username## has purchased a subscription on ##your_site_name##'.PHP_EOL.PHP_EOL.

	'Subscription: ##current_subscription_level##,'.PHP_EOL.
	'Period: ##current_subscription_period##,'.PHP_EOL.
	'Price: $ ##current_subscription_amount##'
);

update_option( 'uz_sms_admin_upgrade_subscription_en_message',
	'The user ##username## changed his subscription on ##your_site_name##'.PHP_EOL.PHP_EOL.

	'Subscription: ##current_subscription_level##,'.PHP_EOL.
	'Period: ##current_subscription_period##,'.PHP_EOL.
	'Price: $ ##current_subscription_amount##'
);

update_option( 'uz_sms_admin_cancel_subscription_en_message',
	'The user ##username## cancelled his subscription on ##your_site_name##'
);

update_option( 'uz_sms_admin_new_withdrawal_request_en_message',
	'Hello admin'.PHP_EOL.PHP_EOL.

	'You have a new withdrawal request'.PHP_EOL.PHP_EOL.

	'User: ##withdrawal_username##'.PHP_EOL.
	'Amount: ##withdrawal_amount##'.PHP_EOL.
	'Payment Method: ##withdrawal_method##'
);

update_option( 'uz_sms_admin_openexchangerates_not_responding_en_message',
	'Hello admin'.PHP_EOL.PHP_EOL.

	'The exchange rates were not updated because the JSON from OpenExchangeRates.org was empty. That means either their site was down when we tried to fetch them or your App ID is wrong. If this is the first time when you receive this message, please check if you have filled your Open Exchange Rate App ID in your site\'s settings ( WPJobster > Pricing Settings > Rates ). If you want, you can update the rates manually or wait for the daily automatic update.'
);

update_option( 'uz_sms_admin_openexchangerates_higher_en_message',
	'Hello admin'.PHP_EOL.PHP_EOL.

	'The exchange rates were not updated because the difference between the following currencies compared to USD was bigger than 5%:'.PHP_EOL.PHP_EOL.

	'[start_list]'.PHP_EOL.
	'##main_currency## from ##old_price## to ##new_price## ( ##percent_difference##% )'.PHP_EOL.
	'[end_list]'.PHP_EOL.

	"Please go to your site's settings ( WPJobster > Pricing Settings > Rates ) and update the rates manually. Next time, if the difference will be smaller than 5% they will be updated automatically."
);

update_option( 'uz_sms_job_admin_purchased_en_message',
	'Hello admin'.PHP_EOL.PHP_EOL.

	'A new job has been purchased on your site:'.PHP_EOL.PHP_EOL.

	'Job name: <a href="##job_link##"><b>##job_name##</b></a>'
);

update_option( 'uz_sms_extend_delivery_request_en_message',
	'The user ##sender_username## has requested an extension of the delivery time for:'.PHP_EOL.PHP_EOL.

	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Job name: ##job_name##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Message: ##extend_delivery_message##'.PHP_EOL.
	'Required number of days: ##extend_delivery_days##' );

update_option( 'uz_sms_extend_delivery_accept_en_message',
	'The user ##sender_username## has accepted the extension of the delivery time for:'.PHP_EOL.PHP_EOL.

	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Job name: ##job_name##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Message: ##extend_delivery_message##'.PHP_EOL.
	'Required number of days: ##extend_delivery_days##' );

update_option( 'uz_sms_extend_delivery_decline_en_message',
	'The user ##sender_username## has declined the extension of the delivery time for:'.PHP_EOL.PHP_EOL.

	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Job name: ##job_name##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Message: ##extend_delivery_message##'.PHP_EOL.
	'Required number of days: ##extend_delivery_days##' );

update_option( 'uz_sms_extend_delivery_abort_en_message',
	'The user ##sender_username## has aborted the extension of the delivery time for:'.PHP_EOL.PHP_EOL.

	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Job name: ##job_name##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Message: ##extend_delivery_message##'.PHP_EOL.
	'Required number of days: ##extend_delivery_days##' );

update_option( 'uz_sms_ord_expires_soon_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'We would like to remind you that the transaction with number ##transaction_number## will expire soon.'.PHP_EOL.
	'Please complete the transaction.'.PHP_EOL.PHP_EOL.

	'Job name: <a href="##job_link##"><b>##job_name##</b></a>'.PHP_EOL.PHP_EOL.
	'Transaction number: ##transaction_number##'.PHP_EOL.
	'Transaction page: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Regards,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_order_accepted_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Transaction ##transaction_number## was accepted by seller.'.PHP_EOL.
	'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );

update_option( 'uz_sms_order_rejected_en_message',
	'Hello ##receiver_username##,'.PHP_EOL.PHP_EOL.

	'Transaction ##transaction_number## was rejected by seller. The money are refunded to your account.'.PHP_EOL.
	'Please click this link for more info: ##transaction_page_link##'.PHP_EOL.PHP_EOL.

	'Thank you,'.PHP_EOL.
	'##your_site_name## Team' );