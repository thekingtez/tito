<?php

// Migration from v5 to v6
if ( ! get_option( 'wpjobster_skip_migration' ) ) {

	add_action( 'admin_notices', 'wpj_import_pages_notice' );
	function wpj_import_pages_notice() {
		if ( ! wpj_get_option( 'pages_imported' ) ) { ?>

			<div class="notice notice-error">
				<p><?php _e( 'You are using older version of the pages. For this version to work properly, you must import the new pages.', 'wpjobster' ); ?></p>
				<p><?php _e( 'Because this version is a major change, we strongly recommend you to make a backup before continuing the migration.', 'wpjobster' ); ?></p>
				<p><a class="button action" href="<?php echo admin_url( 'admin.php?import-pages=true' ); ?>"><?php _e( 'Import new pages', 'wpjobster' ); ?></a></p>
			</div>

		<?php }
	}

	add_action( 'admin_notices', 'wpj_import_menus_notice' );
	function wpj_import_menus_notice() {
		if ( wpj_get_option( 'pages_imported' ) && ! wpj_get_option( 'menus_imported' ) ) { ?>

			<div class="notice notice-error">
				<p><?php _e( 'You are using older version of the menus. For this version to work properly, you must import the new menus.', 'wpjobster' ); ?></p>
				<p><?php _e( 'Current menus will be rewritten / deleted.', 'wpjobster' ); ?></p>
				<p><a class="button action" href="<?php echo admin_url( 'admin.php?import-menus=true' ); ?>"><?php _e( 'Import new menus', 'wpjobster' ); ?></a></p>
			</div>

		<?php }
	}

	add_action( 'admin_notices', 'wpj_import_widgets_notice' );
	function wpj_import_widgets_notice() {
		if ( wpj_get_option( 'pages_imported' ) && wpj_get_option( 'menus_imported' ) && ! wpj_get_option( 'widgets_imported' ) ) { ?>

			<div class="notice notice-error">
				<p><?php _e( 'You are using older version of the widgets. For this version to work properly, you must import the new widgets.', 'wpjobster' ); ?></p>
				<p><?php _e( 'Current footer widgets will be rewritten / deleted.', 'wpjobster' ); ?></p>
				<p><a class="button action" href="<?php echo admin_url( 'admin.php?import-widgets=true' ); ?>"><?php _e( 'Import new widgets', 'wpjobster' ); ?></a></p>
			</div>

		<?php }
	}

}

add_action( 'admin_notices', 'wpj_openexchangerates_appid_required_notice' );
function wpj_openexchangerates_appid_required_notice() {
	if ( wpj_get_option( 'wpjobster_enable_open_exchange_api_rate' ) == 'yes' && ! wpj_get_option( 'openexchangerates_appid' ) ) { ?>

		<div class="notice notice-warning is-dismissible">
			<p><?php echo sprintf( __( 'Please access %s and fill in the \'OpenExchange app ID\' field with your own key.', 'wpjobster' ), '<a href="' . admin_url( 'admin.php?page=jobster-settings&tab=' . wpj_get_settings_tab_number_by_field_id( 'general-main-settings' ) ) . '">this link</a>' ); ?></p>
		</div>

	<?php }
}

add_action( 'admin_notices', 'wpj_deprecated_plugins_notice' );
function wpj_deprecated_plugins_notice() {
	if ( is_plugin_active( 'acf-qtranslate/acf-qtranslate.php' ) || is_plugin_active( 'brizy/brizy.php' ) || is_plugin_active( 'revslider/revslider.php' ) ) { ?>

		<div class="notice notice-warning is-dismissible">
			<p><?php _e( 'The new version of the theme no longer uses plugins like Advanced Custom Fields: qTranslate, Brizy or Slider Revolution.', 'wpjobster' ); ?></p>
			<p><?php _e( 'For better theme performance, you can disable/delete these plugins.', 'wpjobster' ); ?></p>
		</div>

	<?php }
}

add_action( 'admin_notices', 'wpj_qtranslate_notice' );
function wpj_qtranslate_notice() {
	if ( function_exists( 'qtranxf_generateLanguageSelectCode' ) ) { ?>

		<div class="notice notice-warning is-dismissible">
			<p><?php _e( 'The qTranslate X plugin is deprecated and no longer works with Gutenberg and the v6 version of the theme.', 'wpjobster' ); ?></p>
			<p><?php _e( 'Please install the TranslatePress plugin from the Plugins > Required Plugins menu of the theme.', 'wpjobster' ); ?></p>
			<p><a class="button action" href="<?php echo admin_url( 'plugins.php?page=tgmpa-install-plugins' ); ?>"><?php _e( 'Go to Required Plugins', 'wpjobster' ); ?></a></p>
		</div>

	<?php }
}